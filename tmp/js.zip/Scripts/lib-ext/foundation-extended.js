﻿define(['jquery',
    //'Foundation.DatePicker',
    //'Foundation.Abide',
    'Foundation.Accordion',
    'Foundation.Reveal',
    'Foundation.Dropdown',
    'Modernizr'
    //'Foundation.Alert',
    //'Foundation.Clearing',
    //'Foundation.Interchange',
    //'Foundation.Joyride',
    //'Foundation.Magellan',
    //'Foundation.Offcanvas',
    //'Foundation.Orbit',
    //'Foundation.Tab',
    //'Foundation.Tooltip',
    //'Foundation.Topbar'
], function ($) {
    return {
        LoadFoundation: function (selector) {
            if (!selector) {
                selector = document;
            }
            $(selector).foundation({
                tab: {
                    deep_linking: false,
                    scroll_to_content: false
                },
                reveal: {
                    close_on_background_click: false,
                    close_on_esc: false
                }
            });
        },
        RefreshFoundation: function (selector) {
            if (!selector) {
                selector = document;
            }
            $(selector).foundation('reflow');
        }
    };
});