define(['knockout.raw', 'knockout.amd.helpers', 'knockout.custom.bindings'], function (ko) {
    var originalComponentLoader = ko.components.defaultLoader.loadComponent;

    ko.components.defaultLoader.loadComponent = function (componentName, config, callback) {
        if (config && config.template && config.template.require && config.viewModel && config.viewModel.require) {
            var templatePromise = function () {
                var deferred = $.Deferred();
                require([config.template.require], function (template) {
                    if (template) {
                        ko.components.defaultLoader.loadTemplate(componentName, template, deferred.resolve);
                    } else {
                        deferred.reject();
                    }
                }, deferred.reject);

                return deferred.promise();
            };

            var viewModelPromise = function () {
                var deferred = $.Deferred();
                require([config.viewModel.require], function (viewModel) {
                    ko.components.defaultLoader.loadViewModel(componentName, viewModel, deferred.resolve);
                }, deferred.reject);

                return deferred.promise();
            }

            $.when(templatePromise(), viewModelPromise()).then(function (template,viewModel) {
                callback({ template: template, createViewModel: viewModel });
            }, function () {
                try {
                    callback(null);
                } finally {
                    requirejs.undef(config.template.require);
                    requirejs.undef(config.viewModel.require);
                    ko.components.clearCachedDefinition(componentName);
                }
            });
        } else {
            originalComponentLoader(componentName, config, callback);
        }
    };

    ko.components.register('add-bank-account', {
        viewModel: { require: 'add-bank-account-js' },
        template: { require: 'text!add-bank-account-html' }
    });

    ko.components.register('add-credit-debit-account', {
        viewModel: { require: 'add-credit-debit-account-js' },
        template: { require: 'text!add-credit-debit-account-html' }
    });

    ko.components.register('billing-address', {
        viewModel: { require: 'billing-address-js' },
        template: { require: 'text!billing-address-html' }
    });
    ko.components.register('add-biller', {
        viewModel: { require: 'add-biller-js' },
        template: { require: 'text!add-biller-html' }
    });

    ko.components.register('add-reload-carrier', {
        viewModel: { require: 'add-reload-carrier-js' },
        template: { require: 'text!add-reload-carrier-html' }
    });

    ko.components.register('add-pinless-carrier', {
        viewModel: { require: 'add-reload-carrier-js' },
        template: { require: 'text!add-pinless-carrier-html' }
    });

    ko.components.register('add-biller-lcr', {
        viewModel: { require: 'add-biller-lcr-js' },
        template: { require: 'text!add-biller-lcr-html' }
    });

    ko.components.register('select-biller', {
        viewModel: { require: 'select-biller-js' },
        template: { require: 'text!select-biller-html' }
    });

    ko.components.register('select-biller-lcr', {
        viewModel: { require: 'select-biller-lcr-js' },
        template: { require: 'text!select-biller-lcr-html' }
    });

    ko.components.register('billpay-lcr-payment-method', {
        viewModel: { require: 'billpay-lcr-payment-method-js' },
        template: { require: 'text!billpay-lcr-payment-method-html' }
    });

    ko.components.register('manage-add-recipient', {
        viewModel: { require: 'manage-add-recipient-js' },
        template: { require: 'text!manage-add-recipient-html' }
    });

    ko.components.register('topups-select-carrier', {
        viewModel: { require: 'topups-select-carrier-js' },
        template: { require: 'text!topups-select-carrier-html' }
    });

    ko.components.register('topups-payment-method', {
        viewModel: { require: 'topups-payment-method-js' },
        template: { require: 'text!topups-payment-method-html' }
    });

    ko.components.register('select-epin', {
        viewModel: { require: 'topups-select-epin-js' },
        template: { require: 'text!select-epin-html' }
    });

    ko.components.register('manage-recipient', {
        viewModel: { require: 'manage-recipient-js' },
        template: { require: 'text!manage-recipient-html' }
    });

    ko.components.register('manage-lcr-billing-account', {
        viewModel: { require: 'manage-lcr-billing-account-js' },
        template: { require: 'text!manage-lcr-billing-account-html' }
    });

    ko.components.register('manage-billing-account', {
        viewModel: { require: 'manage-billing-account-js' },
        template: { require: 'text!manage-billing-account-html' }
    });

    ko.components.register('manage-carrier', {
        viewModel: { require: 'manage-carrier-js' },
        template: { require: 'text!manage-carrier-html' }
    });

    ko.components.register('manage-transaction-details', {
        viewModel: { require: 'manage-transaction-details-js' },
        template: { require: 'text!manage-transaction-details-html' }
    });

    ko.components.register('personal-settings', {
        viewModel: { require: 'personal-settings-js' },
        template: { require: 'text!personal-settings-html' }
    });

    ko.components.register('settings-payment-method', {
        viewModel: { require: 'settings-payment-method-js' },
        template: { require: 'text!settings-payment-method-html' }
    });

    ko.components.register('select-recipient', {
        viewModel: { require: 'select-recipient-js' },
        template: { require: 'text!select-recipient-html' }
    });

    return ko;
});
