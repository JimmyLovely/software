define(['knockout.raw', 'jquery'], function (ko) {
    ko.virtualElements.allowedBindings['modulestring'] = true;
    ko.virtualElements.allowedBindings['commonstring'] = true;
    ko.bindingHandlers.modulestring = {
        init: function () {
            // Prevent binding on the dynamically-injected text node (as developers are unlikely to expect that, and it has security implications).
            // It should also make things faster, as we no longer have to consider whether the text node might be bindable.
            return { 'controlsDescendantBindings': false };
        },
        update: function (element, valueAccessor, allBindingsAccessor) {
            var value = ko.utils.unwrapObservable(valueAccessor()), allBindings = allBindingsAccessor();
            require([paths[require('app').page().name + '-strings']], function (strings) {
                getString(value, element, strings);
            });
        }
    };

    ko.bindingHandlers.commonstring = {
        init: function () {
            // Prevent binding on the dynamically-injected text node (as developers are unlikely to expect that, and it has security implications).
            // It should also make things faster, as we no longer have to consider whether the text node might be bindable.
            return { 'controlsDescendantBindings': false };
        },
        update: function (element, valueAccessor, allBindingsAccessor) {
            var value = ko.utils.unwrapObservable(valueAccessor()), allBindings = allBindingsAccessor();
            require([paths['common-strings']], function (strings) {
                getString(value, element, strings);
            });
        }
    };

    function getString(value, element, strings)
    {
        var key = typeof value == 'object' ? value.data : value;
        var _html = getStringFromSource(key, strings) || '';
        _html = handleStringArgs(_html, value.args);

        if (value.asHtml) {
            ko.utils.setHtml(element, _html);
        } else if (value.attr) {
            if (typeof value.attr == 'string') {
                $(element).attr(value.attr, _html);
            }
        } else {
            ko.utils.setTextContent(element, _html);
        }
    }

    function handleStringArgs(html, args) {
        if (typeof args === 'object') {
            for (var key in args) {
                var reg = new RegExp('{' + key + '}')
                html = html.replace(reg, args[key])
            }
        }

        return html;
    }

    function getStringFromSource(key, source) {
        var array = key.split('.');
        for (var i = 0; i < array.length; i++) {
            if (source[array[i]] != undefined) {
                source = source[array[i]];
            } else {
                var error = { message: '"' + array[i] + '" is undefined in the ' + key + '.' };
                error.toString = function () { return error.message; };
                throw error;
            }
        }

        return source;
    }

    /* TODO: add other ko custom bindings */

    return ko;

});
