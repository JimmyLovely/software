﻿/*
    This is a file for customized knockout validation rules.
*/
define(['knockout', 'app', 'TrackEvent', 'knockout.validation'], function (ko, app, track) {
    //#region Utilities
    var utils = (function () {
        return {
            isEmptyVal: function (val) {
                if (val === undefined) {
                    return true;
                }
                if (val === null) {
                    return true;
                }
                if (val === "") {
                    return true;
                }
            }
        }
    }());
    //#endregion

    ko.bindingHandlers['validationMessage'] = { // individual error message, if modified or post binding
        update: function (element, valueAccessor) {
            var options = valueAccessor();
            var obsv = options.data || options,
                config = ko.validation.utils.getConfigOptions(element),
                val = ko.utils.unwrapObservable(obsv),
                msg = null,
                isModified = false,
                isValid = false;

            obsv.extend({ validatable: true });

            isModified = obsv.isModified();
            isValid = obsv.isValid();

            // create a handler to correctly return an error message
            var errorMsgAccessor = function () {
                if (!config.messagesOnModified || isModified) {
                    return isValid ? null : obsv.error;
                } else {
                    return null;
                }
            };

            //toggle visibility on validation messages when validation hasn't been evaluated, or when the object isValid
            var visiblityAccessor = function () {
                var isVisible = (!config.messagesOnModified || isModified) ? !isValid : false;
                if (isVisible) {
                    setTimeout(function () {
                        if (obsv.isModified() && !obsv.isValid()) { 
                            track.commonTrackErrorMessage(obsv.error);
                        }
                    });
                }
                return isVisible;
            };

            ko.bindingHandlers.text.update(element, errorMsgAccessor);
            ko.bindingHandlers.visible.update(element, visiblityAccessor);
        }
    };

    ko.validation.rules['minTrimLength'] = {
        validator: function (val, minTrimLength) {
            return utils.isEmptyVal(val) || val.trim().length >= minTrimLength;
        },
        message: 'Please enter at least {0} characters.'
    };

    function ValidateDate(value, validationType) {
        if (!value) {
            return false;
        }

        if (typeof (value) == "number") {
            value = value.toString();
        };

        if (typeof value === 'string') {
            if (value.match(/^\d{2}\/\d{2}\/\d{1,4}$/g)) {
                var day = value.replace(/^(\d{2})\/(\d{2})\/(\d{1,4})$/g, '$2');
                if (new Date(value).getDate() == day) {
                    var year = value.replace(/^.*\/(\d{1,4})$/g, '$1');
                } else {
                    return false;
                }
            }
            else if (value.match(/^\d{1,4}-\d{2}-\d{2}$/g)) {
                var day = value.replace(/^(\d{1,4})-(\d{2})-(\d{2})$/g, '$3');
                if (new Date(value.replace(/-/g, "/")).getDate() == day) {
                    var year = value.replace(/^(\d{1,4})-(\d{2})-(\d{2})$/g, '$1');
                }
                else {
                    return false;
                }
            } else {
                return false;
            }
        }

        inputDate = new Date(value);
        inputYear = inputDate.getFullYear();
        inputMinYear = new Date().getFullYear() - getSenderMaxAge();
        switch (validationType) {
            case "DateOfBirth":
                if (inputYear > new Date().getFullYear() - 18) {
                    return false;
                }
                break;
            case "MinDate":
                if (year) {
                    return year >= inputMinYear;
                }
                if (inputYear < inputMinYear) {
                    return false;
                }
                break;
            case "Expiration":
                if (inputYear < new Date().getFullYear() || inputDate > new Date().getFullYear() + 100) {
                    return false;
                }
                break;
            case "BillerDateOfBirth":
                if (inputYear < new Date('01/01/1753').getFullYear() || inputDate > new Date()) {
                    return false;
                }
                break;
            default:
                if (inputDate < new Date("01/01/1900") || inputDate > new Date("12/31/9999")) {
                    return false;
                }
        }
        return true;
    };

    var senderMaxAge;
    function getSenderMaxAge() {
        if (!!senderMaxAge) {
            return senderMaxAge;
        }

        return app.configurations().senderMaxAge;
    }

    //  Valida date
    ko.validation.rules['isValidDate'] = {
        validator: function (value, validationType) {
            if (utils.isEmptyVal(value)) return true;
            return ValidateDate(value, validationType);
        },
        message: "Invalid Date",
    };

    ko.validation.rules['isMinDate'] = {
        validator: function (value, validationType) {
            if (utils.isEmptyVal(value)) return true;
            return ValidateDate(value, validationType);
        },
        message: "Invalid Date",
    };

    // Override original rule
    ko.validation.rules['email'] = {
        validator: function (val, validate) {
            if (!validate) return true;

            //if one want's to enforce entry it should be done with 'required: true'
            return utils.isEmptyVal(val) || (
                validate && /^((".*?[^\\]"@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)[0-9a-z]@)|(([0-9a-z]@)))((\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$/i.test(val)
            );
        },
        message: 'Please enter a proper email address'
    };

    ko.validation.registerExtenders();

    (function () {
        var beforeShowAllMessageMiddleWares = [];
        var afterShowAllMessageMiddleWares = [];
        ko.validation.showAllMessageMiddleWare = function (beforeMiddleWare, afterMiddleWare) {
            if (typeof beforeMiddleWare === 'function') {
                beforeShowAllMessageMiddleWares.push(beforeMiddleWare);
            }

            if (typeof afterMiddleWare === 'function') {
                afterShowAllMessageMiddleWares.push(afterMiddleWare);
            }
        }

        var group = ko.validation.group;
        ko.validation.group = function (obj, options) {//Overwrite group,
            var result = group(obj, options);

            var showAllMessage = result.showAllMessages;

            result.showAllMessages = function (show) {// Overwrite showAllMessage,
                ko.utils.arrayForEach(beforeShowAllMessageMiddleWares, function (middleWare) {
                    middleWare();
                });

                showAllMessage(show);

                ko.utils.arrayForEach(afterShowAllMessageMiddleWares, function (middleWare) {
                    middleWare();
                });
            }

            return result;
        }
    })();
})
