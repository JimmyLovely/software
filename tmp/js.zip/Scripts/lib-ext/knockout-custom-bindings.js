define(['knockout.custom.bindings.core', 'ClientScript','TrackEvent', paths['common-strings']/* TODO: add other ko binding modules as needed */], function (ko, cs, track,commonstrings) {
    ko.bindingHandlers.foundation = {
        update: function (element, valueAccessor, allBindings) {
            require(['foundation.extended'], function () {
                var options = ko.unwrap(valueAccessor());
                if (!options) {
                    options = {
                        reveal: {
                            dismiss_modal_class: 'we-need-custom-close-modal',
                            close_on_background_click: false,
                            close_on_esc: false,
                            animation_speed: 0,
                            animation: 'foo'
                        }
                    }
                    if (!cs.IsMobileDevice()) {
                        delete options.reveal.animation_speed;
                        delete options.reveal.animation;
                    }
                }
                $(document).foundation(options, 'reflow');
            })
        }
    };

    ko.bindingHandlers.toggleMenu = {
        update: function (element, valueAccessor, allBindings) {
            $(element).off("click")
            .on("click", function () {
                if (cs.IsMobileDevice() && !cs.IsIOS()) {
                    setTimeout(function () {
                        cs.disableOverFlow();
                    }, 100);
                } else {
                    cs.disableOverFlow();
                }
                cs.CollapseLeftMenu();
                $('#header').addClass("blur");
                $('#wrapper').addClass("blur");
                $('.quick-button').hide();
                return false;
            });
            $("#menu-background-page").off("click")
            .on("click", function () {
                cs.RemoveOpen();
                return false;
            })
        }
    };

    ko.bindingHandlers.toggleSubMenu = {
        update: function (element, valueAccessor, allBindings) {
            $(element).off("click");//class .toggle-submenu
            $(element).on("click", function () {
                $(this).parent().parent().next('.submenu').toggleClass('hide');
            });

            $('.submenu-hide').off("click");
            $('.submenu-hide').on("click", function () {
                $(this).parent().parent('.submenu').addClass('hide');
            });
        }
    };

    ko.bindingHandlers.tableWrapper = {
        update: function (element, valueAccessor, allBindings) {
            $(element).children(".fi-minus").each(function () {
                if ($(this).parent().parent().parent().hasClass("open")) {
                    $(this).click();
                }
                else {
                    $(this).addClass("hide");
                }
            });
            $(element).off("click");
            $(element).on("click", function () {
                $(this).children().toggleClass("hide");
                $(this).parent().parent().toggleClass("open");
                $(this).parent().parent().children(".mobile-list-item").toggleClass("show");
                return false;
            });
        }
    };

    ko.bindingHandlers.toggleFilter = {
        update: function (element, valueAccessor, allBindings) {
            $(element).off("click");
            $(element).on("click", function () {
                $(this).parent().next(".filter-controls").toggleClass("hide-for-medium-down");
                $(this).children().toggleClass("hide");
            });
        }
    };

    ko.bindingHandlers.toggleHelpImage = {
        update: function (element, valueAccessor, allBindings) {
            $(element).off("click");
            $(element).on("click", function () {
                $(this).toggleClass("dd-show");
                $(this).next().toggleClass("dd-show");

                return false;
            });
        }
    };

    ko.bindingHandlers.initCustomAttributes = {
        update: function (element, valueAccessor, allBindings) {
            cs.initCustomAttributes();
        }
    };

    ko.bindingHandlers.appendDropDown = {
        update: function (element, valueAccessor, allBindings) {
            $(element).click(function () {
                $('#' + $(this).data('dropdown')).appendTo(this);
            });
        }
    };

    ko.bindingHandlers.disableOptionsCaption = {
        init: function (element, valueAccessor, allBindingsAccessor) {
            var options = ko.unwrap(valueAccessor());
            var allBindings = allBindingsAccessor();
            var captionString = allBindings.disableOptionsCaption.captionString;

            if (options.Caption) {
                options.optionsCaption = options.Caption;
            }
            if (options.captionString) {
                if (captionString.isCommon) {
                    //  If select element is inside of control flow binding (if, with, foreach), need set select caption first,
                    //  otherwise select element will show an incorrect caption in IOS.
                    //  and we put this caption in common-string file for localization.
                    options.optionsCaption = cs.getStringFromSource(captionString.data, commonstrings);
                } else {
                    options.optionsCaption = 'Caption';//default value
                }
            }
            options.optionsAfterRender = function (option, item) {
                var subOptions = {
                    disable: !item
                };
                if (!item) {// bind language for optionsCaption
                    if (typeof captionString == 'object') {
                        if (captionString.isCommon) {
                            subOptions.commonstring = captionString.data;
                        } else {
                            subOptions.modulestring = captionString.data;
                        }
                    }
                }
                ko.applyBindingsToNode(option, subOptions, item);
            }
            ko.applyBindingsToNode(element, options);
        }
    };

    ko.bindingHandlers.enter = {
        init: function (element, valueAccessor, allBindingsAccessor) {
            var func = ko.unwrap(valueAccessor());
            var options = {
                event: {
                    keydown: function (data, event) {
                        if (event.which == 13) {
                            func();
                        }

                        return true;
                    }
                }
            }
            ko.applyBindingsToNode(element, options);
        }
    };

    ko.bindingHandlers.src = {
        init: function (element, valueAccessor, allBindingsAccessor) {
            var url = ko.unwrap(valueAccessor());
            var options = { attr: { src: url } }
            ko.applyBindingsToNode(element, options);
        }
    };

    ko.bindingHandlers.initSettingPage = {
        init: function (element, valueAccessor, allBindingsAccessor) {
            var $winWidth = $(window).width();
            if ($winWidth < 640) {
                $(element).addClass("closed");
            }
        }
    };

    ko.bindingHandlers.initAmountEvents = {
        update: function (element, valueAccessor, allBindings) {
            cs.initAmountEvents(element, ko.unwrap(valueAccessor()));
        }
    };

    ko.bindingHandlers.setBanner = {
        init: function (element, valueAccessor, allBindings) {
            var type = ko.unwrap(valueAccessor());
            var isMobile = cs.IsMobileDevice();
            if (!isMobile) {
                $(element).attr("src", commonstrings.image.appbanner);
                $(element).css("width", '100%');
                $(element).css("height", '100%');
            } else {
                if (type == "moneytransfer") {
                    $(element).attr("src", commonstrings.image.bpbanner);
                } else if (type == "billpay") {
                    $(element).attr("src", commonstrings.image.tubanner);
                } else if (type == "topup") {
                    $(element).attr("src", commonstrings.image.mtbanner);
                }
            }
        }
    };

    ko.bindingHandlers.readonly = {
        update: function (element, valueAccessor) {
            if (element.tagName == "INPUT" && $(element).attr("type") == "text") {
                if (valueAccessor()) {
                    element.readOnly = true;
                } else {
                    element.readOnly = false;
                }
            }
        }
    };

    ko.bindingHandlers.checkState = {
        init: function (element, valueAccessor) {
            var options = {
                click: function () {
                    if (!valueAccessor().stateId) {
                        $('#' + valueAccessor().errorMsgId).show();
                        track.commonTrackErrorMessage($('#' + valueAccessor().errorMsgId).text());
                    }
                },
            }
            ko.applyBindingsToNode(element, options);
        },
        update: function (element, valueAccessor) {
            if (valueAccessor().stateId) {
                $('#' + valueAccessor().errorMsgId).hide();
            }
        }
    };

    ko.bindingHandlers.moveToNext = {
        init: function (element, valueAccessor) {
            //event: The bind of event
            //fn: The ajax call back
            enterToNext = cs.enterToNext, options = {};
            bindEvent = valueAccessor().event,
            options.event = {};
            if (!cs.IsMobileDevice() && !cs.IsChrome()) {
                options.event = {
                    keydown: function (data, e) {
                        if (e.which === 13 || e.which === 9) {
                            enterToNext.moveToNext(element, enterToNext.findNextElement(element), valueAccessor().fn);
                        }
                        return true;
                    },
                    click: function (data, e) {
                        if (element.size > 1) {
                            enterToNext.moveToNext(element, enterToNext.findNextElement(element), valueAccessor().fn);
                        }
                    }
                };
            }

            if (bindEvent) {
                options.event[bindEvent] = function () {
                    if (element.size < 2) {
                        enterToNext.moveToNext(element, enterToNext.findNextElement(element), valueAccessor().fn);
                    }
                };
            }

            ko.applyBindingsToNode(element, options);
        }
    };

    /*** Data Capture start ***/

    /*
     * @param initialize          : Start transaction from dash-board(1), left-bar(2), quick-pay(4), click-to-pay(5).
     * @param transactionType     : Transaction Type.
     * @param stepId              : If current element is in doing transaction, this mean transaction-step, like (select recipient, amount-to-load and so on).
     * @CardHolderActivityTypeId  : Log User Activity.
    */
    ko.bindingHandlers.dataCapture = {
        init: function (element, valueAccessor, allBindingsAccessor) {
            var value = ko.unwrap(valueAccessor());

            if (value.event && value.event === 'focus') {
                $(element).off("blur.data-capture-step")
                $(element).on("blur.data-capture-step", function (event) {
                    if (event.hasOwnProperty("isTrigger")) {
                        return true;  //Event response by event-trigger. It's not user click event.
                    }

                    cs.AddTransactionStep(value.stepId, value.label, value.data());
                });

                return;
            }

            if (value.stepId !== 0 && typeof value.stepId === "number") {
                if (typeof value.data === "function") {
                    $(element).off("click.data-capture-step")
                    $(element).on("click.data-capture-step", function () {
                        if (typeof value.label === "function") {
                            cs.AddTransactionStep(value.stepId, value.label(), value.data());
                        } else {
                            cs.AddTransactionStep(value.stepId, value.label, value.data());
                        }
                    });
                }
                else {
                    $(element).off("click.data-capture-step")
                    $(element).on("click.data-capture-step", function () {
                        cs.AddTransactionStep(value.stepId, value.label, value.data);
                    });
                }
            } else if (value.stepId === 0) {
                $(element).off("click.data-capture-start")
                $(element).on("click.data-capture-start", function () {
                    if (value.transactionType === 14) {
                        value.transactionType = 1;
                    } else if (value.transactionType === 2 || value.transactionType === 11) {
                        value.transactionType = 5;
                    } else if (value.transactionType === 13) {
                        value.transactionType = 12;
                    }

                    cs.AddTransactionStart(value.initializePositionId, value.initializePositionId == 4 ? 1 : 0, value.transactionType);
                });
            }

            if (value.cardHolderActivityTypeId) {
                $(element).off("click.data-capture-activity")
                $(element).on("click.data-capture-activity", function () {
                    cs.AddActivityInfo(value.cardHolderActivityTypeId);
                });
            }
        },
    };

    /*  
     * Description: Log startTime and endTime of action, startTime stands for time initiating the modal, endTime stands for time that adding new one successfully.
     */

    ko.bindingHandlers.logActionTime = {
        update: function (element, valueAccessor, allBinding, viewModel) {
            var value = ko.unwrap(valueAccessor());

            if (value.value > 0) {
                cs.AddTransactionStep(value.transactionStepId, value.label, value.value, viewModel.startDateTime);
                return;
            }

            viewModel.startDateTime = cs.GetDateTimeOffset();
        }
    };

    ko.bindingHandlers.logAbandonTransactionAction = {
        init: function (element, valueAccessor) {
            var value = ko.unwrap(valueAccessor());

            $(element).off('click.logAbandonTransactionAction');
            $(element).on('click.logAbandonTransactionAction', function () {
                if (cs.IsTransactionPage()) {
                    cs.AddTransactionStep(value.transactionStepId, value.label, value.value);
                }
            });
        }
    };

    /*** Data Capture end ***/

    ko.bindingHandlers.fitText = {
        init: function (element, valueAccessor) {
            if (element.tagName == "INPUT") {
                var $el = $(element),
                    defaultSize,
                    defaultLineHeight,
                    cssFontSize = 'font-size',
                    cssLineHeight = 'line-height';

                var resetFitText = function () {
                    //reset, remove inline styles to get the theme style definitions
                    defaultSize = $el.css(cssFontSize, '').css(cssFontSize);
                    defaultLineHeight = $el.css(cssLineHeight, '').css(cssLineHeight);
                    //apply fixed line-height so the input box height doesn't change
                    $el.css(cssLineHeight, defaultLineHeight);
                    updateFitText();
                };
                var updateFitText = function () {
                    if (typeof $el.inputfit === 'function') {
                        $el.inputfit({
                            minSize: 1,
                            maxSize: parseFloat(defaultSize)
                        });
                    }
                };

                //reset to account for media query style changes
                require(['foundation.extended'], function () {
                    $(window).resize(Foundation.utils.debounce(resetFitText, 250, false));
                    resetFitText();
                });
            }
        }
    };

    ko.bindingHandlers.modelCheck = {
        init: function (element, valueAccessor) {
            if (!valueAccessor()) return;

            var model = valueAccessor();

            $(element).find('input[type=tel], input[type=text], input[type=password]').each(function (index, ele) {
                var feildName = $(ele).attr('data-bind'), temp = feildName;
                if (!feildName) return;

                feildName = feildName.replace(/.*value:\s*\$?(\w*\.)?([a-zA-Z]*),.*|.*value:\s*\$?(\w*\.)?([a-zA-Z]*)/i, '$2$4');
                if (temp != feildName)
                    $(ele).attr("data-feildName", feildName);
            });

            $(element).off("input.validCheck", "input[data-feildName]")
            .on("input.validCheck", "input[data-feildName]", function (e) {
                var feildName = $(this).attr('data-feildName');
                if (!feildName) return;

                var feild = model[feildName];

                if (feild && feild.isModified && feild.isModified()) {
                    $(this).trigger("change");
                }
            }).off("blur.validCheck", "input[data-feildName]")
            .on("blur.validCheck", "input[data-feildName]", function (e) {
                $(this).trigger("change");
            });
        }
    }

    ko.bindingHandlers.modelCheckWithoutFieldName = {
        init: function (element, valueAccessor) {
            $(element).off("input.validCheck", "input[type=tel], input[type=text]")
            .on("input.validCheck", "input[type=tel], input[type=text]", function () {
                if ($(this).attr("class") == undefined) return;
                $(this).trigger("change");
            })
            .off("blur.validCheck", "input[type=tel], input[type=text]")
            .on("blur.validCheck", "input[type=tel], input[type=text]", function () {
                $(this).trigger("change");
            })
        }
    }

    ko.bindingHandlers.closeFoundationDropdown = {
        update: function (element, valueAccessor, allBindings) {
            valueAccessor();
            cs.closeFoundationDropdown();
        }
    };

    ko.bindingHandlers.realTimeCalculate = {
        init: function (element, valueAccessor) {
            var element = $(element);
            var option = valueAccessor();
            if (cs.IsMobileDevice()) {
                var oldValue = element.val();

                element.off("input.attribute.amount");
                element.on("input.attribute.amount", function () {
                    cs.formatAmountForInput(element, oldValue);
                    if (oldValue != element.val()) {
                        oldValue = element.val();
                        option.receiverAmount(element.val());

                        var rate = 1;
                        if (typeof option.rate == 'function') {
                            rate = option.rate();
                        }
                        else {
                            rate = option.rate;
                        }
                        var amountToPay = cs.getAmountToSend(element.val(), rate);
                        if ($("#input-send-amount").val() != amountToPay) {
                            cs.fitTextAmountField($("#input-send-amount"), amountToPay);
                            option.sendAmount(amountToPay);
                        }
                        if ($("#input-quickpay-send-amount")) {
                            cs.fitTextAmountField($("#input-quickpay-send-amount"), amountToPay);
                        }
                    }
                });

                element.off("focus.attribute.amount");
                element.on("focus.attribute.amount", function (e) {
                    oldValue = element.val();
                });
            } else {
                element.off("input.attribute.amount");
                element.on('input.attribute.amount', function (event) {
                    option.receiverAmount(element.val());

                    var rate = 1;
                    if (typeof option.rate == 'function') {
                        rate = option.rate();
                    }
                    else {
                        rate = option.rate;
                    }
                    var amountToPay = cs.getAmountToSend(element.val(), rate);
                    if ($("#input-send-amount").val() != amountToPay) {
                        cs.fitTextAmountField($("#input-send-amount"), amountToPay);
                        option.sendAmount(amountToPay);
                    }
                    if ($("#input-quickpay-send-amount")) {
                        cs.fitTextAmountField($("#input-quickpay-send-amount"), amountToPay);
                    }
                });
            }
        }
    }

    ko.bindingHandlers.registerExpandCollapse = {
        init: function (element, valueAccessor) {
            var $win = $(window);
            var $winWidth = $win.width();
            var $modExpandCollapse = $('.mod-header .expand-collapse');
            $modExpandCollapse.off("click");
            $modExpandCollapse.on("click", function () {
                $(this).parent().parent().toggleClass('closed');
                return false;
            })

            if ($winWidth < 640) {
                $('.mod-header .expand-collapse').parent().parent().addClass('closed');
            }
            else {
                $('.mod-header .expand-collapse').parent().parent().removeClass('closed');
            }
        }
    }

    ko.bindingHandlers.removeTitle = {
        update: function (element, valueAccessor) {
            var obsv = valueAccessor();
            obsv();

            var removeAttr = function () {
                return { title: null };
            };

            ko.bindingHandlers.attr.update(element, removeAttr);
        }
    }

    ko.bindingHandlers.validateInteger = {
        init: function (element, valueAccessor) {
            var ele = $(element);
            var oldValue = ele.val();
            ele.off("focus.validateInteger")
            .on("focus.validateInteger", function () {
                oldValue = ele.val();
            })
            .off("input.validateInteger")
           .on("input.validateInteger", function () {
               var reg = new RegExp('^[0-9]*$');
               if (!reg.test(ele.val())) {
                   ele.val(oldValue);
               }
               else {
                   oldValue = ele.val();
               }
           })
        }
    }
    ko.bindingHandlers.openMenu = {
        init: function (element, valueAccessor) {
            $(element).off("click.openMenu")
            .on("click.openMenu", function () {
                $('body').toggleClass('open');
                $('#header').addClass("blur").removeClass("fix-screen");
                $('#wrapper').addClass("blur").removeClass("fix-screen");
                $('.quick-button').hide();
                $('#welcome').hide();
                if (cs.IsMobileDevice() && !cs.IsIOS()) {
                    setTimeout(function () {
                        cs.disableOverFlow();
                    }, 100);
                } else {
                    cs.disableOverFlow();
                }

                return false;
            });
        }
    }
    ko.bindingHandlers.xClose = {
        init: function (element, valueAccessor) {
            $(element).off("click.xClose")
            .on("click.xClose", function () {
                cs.ShowQuickButton();
                $('html').removeClass('disable-overflow-x');
                $('body').removeClass('disable-overflow-x');
                return false;
            });
        }
    }
    ko.bindingHandlers.quickButton = {
        init: function (element, valueAccessor) {
            $(element).off("click.quickButton")
            .on("click.quickButton", function () {
                $('.quick-menu').toggle();
                $(this).toggleClass("close");
                $('#header').toggleClass("blur").removeClass("fix-screen");
                $('#wrapper').toggleClass("blur").removeClass("fix-screen");
                $('#welcome').hide();
                return false;
            });
        }
    }
    ko.bindingHandlers.tapHere = {
        init: function (element, valueAccessor) {
            $(element).off("click.tapHere")
            .on("click.tapHere", function () {
                if ($(".quick-button").hasClass('close')) {
                    cs.RemoveQuickTransactionPage();
                    return false;
                } else {

                }
            });
        }
    }
    ko.bindingHandlers.welcomeContinue = {
        init: function (element, valueAccessor) {
            $(element).off("click.welcomeContinue")
            .on("click.welcomeContinue", function () {
                $('#welcome').hide();
                $('#header').removeClass("fix-screen");
                $('#wrapper').removeClass("fix-screen");
                return false;
            });
        }
    }
    ko.bindingHandlers.showQuickBottun = {
        init: function (element, valueAccessor) {
            $(element).off("click.headerClick")
            .on("click.headerClick", function () {
                if ($("body").hasClass("open")) {
                    cs.ShowQuickButton();
                    return false;
                } else {

                }
            });
        }
    }
    ko.bindingHandlers.showQuickReload = {
        init: function (element, valueAccessor) {
            $(element).off("click.showQuickReload")
            .on("click.showQuickReload", function () {
                cs.ToggleQuickReload();
            });
        }
    }
    // REFERRAL HOW IT WORKS - DESKTOP
    ko.bindingHandlers.showHowReferralWork = {
        init: function (element, valueAccessor) {
            $('a#how-works').off('click.how.works')
            .on('click.how.works', function (e) {
                e.preventDefault();
                $(this).stop(true).hide();
                $('.how-it-works').stop(true).slideDown();
                $('#works-close').stop(true).fadeIn();

                var trackHowItWorkTotalClicks = function () {
                    require(['TrackEvent'], function (T) {
                        T.trackEvent({
                            sendType: T.GA + T.MP,
                            eventCategory: T.CategoryEnum.ReferralLandingPage,
                            eventAction: T.ActionEnum.ButtonClick,
                            eventLabel: "Landing: How it Works",
                            eventPage: T.PageEnum.ReferralLandingPage,
                            source: T.PageEnum.ReferralLandingPage
                        });
                    });
                }
                trackHowItWorkTotalClicks();

                var trackTotalLoads = function () {
                    require(['TrackEvent'], function (T) {
                        T.trackEvent({
                            sendType: T.GA + T.MP,
                            eventCategory: T.CategoryEnum.ReferralLandingPage,
                            eventAction: T.ActionEnum.ScreenView,
                            eventLabel: "How it Works",
                            eventPage: T.PageEnum.HowItWork,
                            source: T.PageEnum.HowItWork
                        });
                    });
                }
                trackTotalLoads();

                require(['TrackEvent'], function (track) {
                    track.trackTimeOnPageForPageLink("HowItWorks");
                    track.generatePartialTimeOnPageTrack();// clear time on page track
                });
            });

            $('#works-close').off('click.close.works')
            .on('click.close.works', function (e) {
                e.preventDefault();
                $(this).stop(true).fadeOut();
                $('.how-it-works').stop(true).slideUp({
                    complete: function () {
                        $('a#how-works').show();
                    }
                });

                var trackCloseXTotalClicks = function () {
                    require(['TrackEvent'], function (T) {
                        T.trackEvent({
                            sendType: T.GA + T.MP,
                            eventCategory: T.CategoryEnum.ReferralLandingPage,
                            eventAction: T.ActionEnum.ButtonClick,
                            eventLabel: "How it Works: X",
                            eventPage: T.PageEnum.HowItWork,
                            source: T.PageEnum.HowItWork
                        });
                    });
                }
                trackCloseXTotalClicks();
            });
        }
    }
    ko.bindingHandlers.closeRefer = {
        init: function (element, valueAccessor) {
            $('#close-refer,#tap-close').off('click.close.refer')
            .on('click.close.refer', function () {
                $('.refer-menu').toggle();
                $('#header').toggleClass("blur");
                $('#wrapper').toggleClass("blur");

                cs.ShowQuickButtonForMobile(true);

                $("#referral-layout-share").html($("#referral-share"));

                $("#copy-link").css('display', 'inline-block');
                $("#link-copyed").css('display', 'none');
            });
        }
    }
    ko.bindingHandlers.CopyLink = {
        init: function (element, valueAccessor) {
            $(element).off('click.copylink')
            .on('click.copylink', function () {
                $(this).hide().next(".link-copied").css("display", "inline-block");
                $(this).prev($('i')).addClass('copied');
            });
        }
    }
    ko.bindingHandlers.ReferralItems = {
        init: function (element, valueAccessor) {
            $(element).off('click.showreferralitems')
            .on('click.showreferralitems', function () {
                $("body").append($("#referral-share"));
                $("#referral-layout-share").html('');

                $('.refer-menu').toggle();
                $('#header').toggleClass("blur");
                $('#wrapper').toggleClass("blur");
                cs.ShowQuickButtonForMobile(false);
            });
        }
    }
    ko.bindingHandlers.AddEmailItem = {
        init: function (element, valueAccessor) {
            $(element).off('click.addemailtem')
            .on('click.addemailtem', function () {
                var $newEmail = $("<p class='friends'>Friend's Email</p>" + "<input type ='email' class='email' placeholder='ex.name@domain.com' value=''>" + "<br>");
                $newEmail.insertBefore($(this));
                return false;
            });
        }
    }
    ko.bindingHandlers.InitialDropDown = {
        init: function (element, valueAccessor) {
            $("li.has-dropdown").on("click.start.transaction", function () {
                $(this).toggleClass("open");
                $(this).next(".is-dropdown").toggleClass("open");
            });
            $("li.has-dropdown").bind("touchstart click", function () {
                $(this).toggleClass("open");
                $(this).next(".is-dropdown").toggleClass("open");
            });
        }
    }
    ko.bindingHandlers.limitMaxLength = {
        init: function (element, valueAccessor) {
            if (cs.IsMobileDevice() && !cs.IsIOS()) {
                var maxlength = $(element).attr('maxlength');
                if (maxlength && maxlength > 0) {
                    $(element).off('keyup.limitlength')
                    .on('keyup.limitlength', function () {
                        var currentValue = $(element).val();
                        if (currentValue && currentValue.length >= maxlength) {
                            var maxValue = currentValue.substr(0, maxlength);
                            $(element).val(maxValue);
                            $(element).focus();
                        }
                    });
                }
            }
        }
    }

    ko.bindingHandlers.disablePaste = {
        init: function (element, valueAccessor) {
            $(element).off("paste")
            .on("paste", function () {
                return false;
            })
        }
    };

    ko.bindingHandlers.disableHover = {
        init: function (element, valueAccessor) {
            $(element).removeClass("has-hover");

            $(element).parent().off("click.dashboard.hover")
            .on("click.dashboard.hover", function () {
                if (cs.IsMobileDevice()) {
                    $(element).toggleClass("has-hover");
                }
            })
        }
    };

    ko.bindingHandlers.delayLoading = {
        update: function (element, valueAccessor) {
            var value = valueAccessor();
            if (value) {
                setTimeout(function () {
                    if (valueAccessor()) {
                        $(element).show();
                    }
                }, cs.delayTime);
            } else {
                $(element).hide();
            }
        }
    };

    return ko;
});
