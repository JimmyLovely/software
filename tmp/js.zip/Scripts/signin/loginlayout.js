﻿(function () {
    function LoginLayoutModel() {
        var self = this;
        var openEmailScheme = "message://";

        self.androidAppId = "";
        self.androidAppScheme = "";
        self.androidDownloadLink = "";

        var appInstalled = false;

        //var universalAppLinkForAndroid = "https://ufs.onl/.well-known/assetlinks.json";
        //var universalAppLinkForIOS = "https://ufs.onl/apple-app-site-association";
        window.unidos = window.unidos || {};

        unidos.resource = {
            'unidos': 'Sengo',
            'unidosfinacialservices': 'Sengo',
            'view': 'VIEW',
            'free': 'FREE',
            'ontheappstore': 'On the App Store',
            'ingoogleplay': 'In Google Play',
            'sendemailto': 'We have sent an email to',
            'clicktogoemail': 'Click below to go to your email',
            'openemail': 'Open Email',
            'resendlink': 'Resend Verification Link',
            'resendvarificationlink': 'Resend Verification Link',
            'linkresend': 'Verification Link Resent!',
            'thankyou': 'Thank You - Sengo',
            'language': 'Español',
            'login': 'Login',
            'openunidosapp': 'Go To App',
            'continuetomobile': 'Continue to mobile site',
            'copyright': 'Copyright © 2017 Unidos Financial Services, Inc. All rights reserved.',
            'verifyunidos': 'Verify - Sengo',
            'enablecookie': 'Please enable your browser cookie',
            'emailhasbeenverified': 'Your Email Address has been verified.',
            'downloadapp': 'Click below to go to the Sengo App.',
            'commonerror': 'Please contact Customer Care at 1-855-398-2569.',
            'emailto': 'Email to ',
            'enterpassword': 'Enter Password',
            'verificationlinksend': 'Verification link has been resended successfully, please check your email.',
            'checkemail': 'Please check your email for the verification link.',
            'logintitle': 'Login - Sengo',
            'linktologin': 'Already verified your email address? Login',
            'passwordchangesuccess': 'Password Change Successful!',
            'passwordsuccessfullychanged': 'Your password has been successfully changed.',
            'emailhasalreadyverified': 'Email address has already been verified.',
            'verificationlinkexpired': 'This verification link has expired. Please check your email for a more recent verification link.',
            'resetpasswordfailed': 'Reset Password Failed',
            'emailisinvalid': 'Email is invalid!',
            'open': 'Open',
            'ok': 'OK'

        };
        unidos.resourceMX = {
            'unidos': 'Sengo',
            'unidosfinacialservices': 'Sengo',
            'view': 'VER',
            'free': 'GRATIS',
            'ontheappstore': 'En la App Store',
            'ingoogleplay': 'En Google Play',
            'sendemailto': 'Hemos enviado un correo a',
            'clicktogoemail': 'Haz click abajo para abrir tu correo',
            'openemail': 'Abrir correo electrónico',
            'resendlink': 'Reenviar liga de verificación',
            'resendvarificationlink': 'Reenviar liga de verificación',
            'linkresend': '¡Liga de verificación enviada!',
            'thankyou': '¡Gracias - Sengo',
            'language': 'English',
            'login': 'Iniciar Sesión',
            'openunidosapp': 'Ir al App',
            'continuetomobile': 'Continuar al sitio móvil',
            'copyright': 'Copyright © 2017 Unidos Servicios Financieros, Inc. Todos los derechos reservados.',
            'verifyunidos': 'verificar - Sengo',
            'enablecookie': 'Por favor habilita los cookies en el navegador.',
            'emailhasbeenverified': 'Tu cuenta de correo electrónico ha sido verificada.',
            'downloadapp': 'Haz click para ir al App de Sengo.',
            'commonerror': 'Por favor contacta a Servicio al Cliente a 1-855-398-2569.',
            'emailto': 'Correo a ',
            'enterpassword': 'Ingresa tu contraseña',
            'verificationlinksend': '¡Liga de verificación enviada!',
            'checkemail': 'Por favor revisa tu correo electrónico  para localizar el mensaje con la liga de verificación.',
            'logintitle': 'Inicia Sesión - Sengo',
            'linktologin': '¿Has verificado tu correo electrónico? Inicia Sesión',
            'passwordchangesuccess': '¡Tu contraseña fue cambiada exitosamente!',
            'passwordsuccessfullychanged': 'Tu contraseña ha sido actualizada exitosamente.',
            'emailhasalreadyverified': 'El correo electrónico ya ha sido verificado.',
            'verificationlinkexpired': 'Esta liga de verificación ha expirado. Por favor revisa tu correo electrónico  para localizar el mensaje con la liga de verificación más reciente.',
            'resetpasswordfailed': 'El restablecimiento de la contraseña fallo.',
            'emailisinvalid': 'La dirección de correo electrónico en Invalida!',
            'open': 'Abrir',
            'ok': 'OK'
        };

        self.InitializeAppBanner = function () {
            var meta = document.createElement("meta");
            meta.name = "google-play-app";
            meta.content = "app-id=" + self.androidAppId;
            document.getElementsByTagName("head")[0].appendChild(meta);

            $.LoginLayout.SetAppStoreDisplay();
            if (IsAndroid()) {
                var SmartBanner = $.smartbanner.Constructor;
                SmartBanner.prototype.install = function () {
                    $.LoginLayout.OpenApp();
                }

                $(document).on('visibilitychange webkitvisibilitychange', function () {
                    if (document.hidden || document.webkitHidden) {
                        appInstalled = true;
                    }
                })
            }
            $.smartbanner({
                daysHidden: -1, // days to hide banner after close button is clicked (defaults to 15)
                daysReminder: -1, // days to hide banner after "VIEW" button is clicked (defaults to 90)
                appStoreLanguage: 'us', // language code for the App Store (defaults to user's browser language)
                title: getResourse('unidos'),
                author: getResourse('unidosfinacialservices'),
                button: getResourse('view'),
                force: null,
                price: getResourse('free'),
                inAppStore: getResourse('ontheappstore'),
                inGooglePlay: getResourse('ingoogleplay'),
            });
            $(".smartbanner-button").attr("href", "javascript:void(0);");

            $(".sb-button").attr("href", "#");
        }

        self.resetPosition = function () {
            if (IsAndroid() && $("#smartbanner")[0]) {
                $(".sb-close").on("click.banner.close", function () {
                    $("#wrapper").removeAttr("style");
                });
                
                var height = $("#smartbanner").css("height");
                $("#wrapper").css("margin-top", height);
            }
        }

        self.OpenApp = function () {
            if (IsAndroid()){
                appInstalled = false;
                window.location.href = self.androidAppScheme;
                setTimeout(function () {
                    if (!appInstalled) {
                        // TODO: Here should unidos app id for google play store
                        //window.location.href = "http://play.google.com/store/apps/details?id=" + androidAppId;
                        window.location.href = self.androidDownloadLink;
                    }
                }, 800);
            } else {
                location.href = "/Home/GoToAppPage";
            }
        }

        self.SetAppStoreDisplay = function () {
            if (IsMobileDevice()) {
                if ($("#show-message")) {
                    $("#show-message").css("display","block");
                    $("#show-message").text(getResourse('downloadapp'));
                }
                $("#button-continue-login").css("display", "none");
                $("#button-continue-open-app").css("display", "block");
                $("#mobile-site-link").css("display", "block");
                $("#app-store-logo").css("display", "inline-block");

                if (IsIOS()) {
                    $("#app-store-logo").attr("src", "/assets/img/app-store.png");
                } else {
                    $("#app-store-logo").attr("src", "/assets/img/google-store.png");
                }
            }
        }

        self.GetEmailURL = function (emailAddress) {
            var emailURL;
            var isRecognized = false;
            // TODO: Here should change IsIOS to IsMobileDevice.
            if (IsIOS()) {
                ChangeHintMessage(true);
                $("#button-continue").attr("data-language", "openemail");
            } else if (IsAndroid()) {
                ChangeHintMessage(false);
                $("#button-continue").css("display","none");
            }
            else {
                var emailArray = new Array(
                   { EmailClient: "Gmail", URL: "http://www.gmail.com", EmailEnding: "gmail.com" },
                   { EmailClient: "Outlook", URL: "http://www.outlook.com", EmailEnding: "outlook.com" },
                   { EmailClient: "Yahoo", URL: "https://mail.yahoo.com/", EmailEnding: "yahoo.com" },
                   { EmailClient: "AOL", URL: "http://mail.aol.com/", EmailEnding: "aol.com" },
                   { EmailClient: "Zoho", URL: "http://www.zoho.com/mail/", EmailEnding: "zoho.com" },
                   { EmailClient: "Mail.com", URL: "http://www.mail.com/", EmailEnding: "mail.com" },
                   { EmailClient: "Yandex", URL: "https://mail.yandex.com/", EmailEnding: "yandex.com" },
                   { EmailClient: "Inbox.com", URL: "http://www.inbox.com/", EmailEnding: "inbox.com" },
                   { EmailClient: "GMX Email", URL: "http://www.gmx.com/mail", EmailEnding: "gmx.com" },
                   { EmailClient: "iCloud", URL: "https://www.icloud.com/", EmailEnding: "icloud.com" },
                   { EmailClient: "Hotmail", URL: "http://www.hotmail.com", EmailEnding: "hotmail.com" },
                   { EmailClient: "Live.com", URL: "https://login.live.com/", EmailEnding: "live.com" }
                   );

                for (var i = 0; i < emailArray.length; i++) {
                    var index = emailAddress.indexOf("@");
                    var emailEnding = emailAddress.substring(index + 1, emailAddress.length);
                    if (emailEnding.toLowerCase().indexOf(emailArray[i].EmailEnding + '.') == 0 ||
                        emailEnding.toLowerCase() == emailArray[i].EmailEnding) {
                        isRecognized = true;
                        ChangeHintMessage(true);
                        $("#button-continue").text(getResourse('open') + " " + emailArray[i].EmailClient);
                        emailURL = emailArray[i].URL;
                        break;
                    }
                }

                if (!isRecognized) {
                    ChangeHintMessage(false);
                    $("#button-continue").css("display", "none");
                    // TODO
                    // Not show button
                    // Display icon and Text
                }
            }

            return emailURL;
        }

        self.OpenEmail = function (emailAddress, emailURL) {
            // TODO: Here should change IsIOS to IsMobileDevice.
            if (IsIOS()) {
                window.location.href = openEmailScheme;
            } else {
                window.open(emailURL, '_blank');
                window.focus();
            }
        }
    }

    window.$.LoginLayout = new LoginLayoutModel();
    var universalAppLink = "";

    function ChangeHintMessage(isOpenHint)
    {
        var element = "#hint-message";
        if ($(element).length > 0) {
            if (isOpenHint) {
                $(element).text(getResourse('clicktogoemail'));
            } else {
                $(element).text(getResourse('checkemail'));
            }
        }
    }

    function IsIOS() {
        return !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
    }

    function IsMobileDevice() {
        return !!navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|Windows Phone)/i);
    }

    function IsChrome() {
        return !!(navigator.userAgent.match(/(Chrome)/i) && !navigator.userAgent.match(/(Edge)/i));
    }

    function IsAndroid() {
        return (navigator.userAgent.indexOf('Android') > -1 || navigator.userAgent.indexOf('Adr') > -1);
    }

    function IsSafari() {
        return (navigator.userAgent.indexOf('Safari') > -1);
    }
}(window))