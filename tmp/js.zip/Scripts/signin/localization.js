﻿var timeout = 60 * 1000;
var cookies = document.cookie.split(';');
var language = '';
var passwordInvalidTime = 0;
if (cookies) {
    for (var i = 0; i < cookies.length ; i++) {
        var cookie = cookies[i].replace(/\s/g, '').split('=');
        if (cookie[0] == 'Language') {
            language = cookie[1];
        }
    }

    if (!language) {
        var browserLanguage = navigator.language || navigator.userLanguage;
        language = browserLanguage.toLowerCase().indexOf('es') > -1 ? 'es-MX' : 'en-US';
        document.cookie = "Language = " + language + ";Path=/";
    }
}

String.format = function () {
        var str = arguments[0];
        for (var i = 0; i < arguments.length - 1; i++) {
            var reg = new RegExp("\\{" + i + "\\}", "gm");
            str = str.replace(reg, arguments[i + 1]);
        }

        return str;
    }

function isEnglish() {
    return ['en-us', 'english'].indexOf(language.toLowerCase()) !== -1;
}

function addSpanishClass() {
    if (isEnglish()) {
        $('html').removeClass('spanish');
    }
    else {
        $('html').addClass('spanish');
    }
}
addSpanishClass();

function getResourse(key) {
    if (isEnglish()) {
        return unidos.resource[key];
    }
    else {
        return unidos.resourceMX[key];
    }
}

function localizationForLoginPage() {
    var list = $("[data-language]");
    var tempList = (list.container && list.container[0].length > 0) ? list.container[0] : list;
    for (var i = 0; i < tempList.length; i++) {
        if (tempList[i].tagName == "INPUT") {
            tempList[i].setAttribute('placeholder', getResourse(tempList[i].getAttribute("data-language")));
        } else {
            if(tempList[i].getAttribute("data-language") == 'passwordinvalid') {
                tempList[i].innerText = String.format(getResourse(tempList[i].getAttribute("data-language")), passwordInvalidTime);
            }
            else {
                tempList[i].innerText = getResourse(tempList[i].getAttribute("data-language"));                            
            }
        }
    }

    if (location.pathname.indexOf('AuthorizationDevicePage') !== -1) {
        InitialEmailAddressButton();
    }
    else if (['/', '/Home/OnBoardingCarousel'].indexOf(location.pathname) !== -1) {
        var owl = $("#owl-demo").data("owlCarousel");
        var amount = owl.itemsAmount;
        for (var i = 0; i < amount; i++) {
            owl.removeItem(0);
        }
        $(".inside-loading-modal-bg").show();
        setTimeout(function () {
            initCarouselPages(true);
        }, 300);
    }
    else if (location.pathname.indexOf('SignUpConsumerSuccess') !== -1) {
        var tempemailAddress = sessionStorage.getItem("signupEmailAddress");
        $.LoginLayout.GetEmailURL(tempemailAddress);
    }
}

function localization() {
    var list = $("[data-language]");
    for (var i = 0; i < list.length; i++) {
        if (list[i].tagName == "INPUT") {
            list[i].setAttribute('placeholder', getResourse(list[i].getAttribute("data-language")));
        } else {
            list[i].innerText = getResourse(list[i].getAttribute("data-language"));
        }
    }
}

var element = document.getElementById('language');
if (element) {
    element.onclick = switchLanguage;
}

function switchLanguage() {
    var eventCategory;
    var eventPage;
    var eventLabel = "Language Changed: " + (isEnglish() ? "Espanol" : "English");
    if (location.pathname.indexOf("LoginConsumer") != -1) {
        eventCategory = T.CategoryEnum.LoginScreen;
        eventPage = T.PageEnum.LoginScreen;
    } else if (['/', '/Home/OnBoardingCarousel'].indexOf(location.pathname) !== -1) {
        eventCategory = T.CategoryEnum.CarouselScreen;
        eventPage = T.PageEnum.CarouselScreen + getCurrentCarouselItem();
    } else if (location.pathname.indexOf('SignUpConsumerSuccess') !== -1) {
        eventCategory = T.CategoryEnum.RegistrationConfirmation;
        eventPage = T.PageEnum.RegistrationConfirmation;
    } else if (location.pathname.indexOf('SignUpConsumer') !== -1) {
        eventCategory = T.CategoryEnum.Registration;
        eventPage = T.PageEnum.Registration;
    } else if (location.pathname.indexOf('AuthorizationDevicePage') !== -1) {
        if (document.querySelector("#div-input-validation-code").style.display !== "none") {
            eventCategory = T.CategoryEnum.DeviceAuthorizationActivation;
            eventPage = T.PageEnum.DeviceAuthorizationActivation;
        } else {
            eventCategory = T.CategoryEnum.DeviceAuthorization;
            eventPage = T.PageEnum.DeviceAuthorization;
        }

    } else if (location.pathname.indexOf('ForgotConsumer') !== -1) {
        eventCategory = T.CategoryEnum.ForgotPassword;
        eventPage = T.PageEnum.ForgotPassword;
    } else if (location.pathname.indexOf('FeeCalculator') !== -1) {
        eventCategory = T.CategoryEnum.CalculatorScreenPre;
        eventPage = T.PageEnum.CalculatorScreenPre;
    } else if (location.pathname.indexOf('SelfServiceResetPassword') !== -1) {
        eventCategory = T.CategoryEnum.ResetPassword;
        eventPage = T.PageEnum.ResetPassword;
    } else if (location.pathname.indexOf('ResetPasswordSuccessfully') !== -1) {
        eventCategory = T.CategoryEnum.ResetPasswordConfirmation;
        eventPage = T.PageEnum.ResetPasswordConfirmation;
    }else if (location.pathname.indexOf('VerifyEmail') !== -1) {
        eventCategory = T.CategoryEnum.RegistrationComplete;
        eventPage = T.PageEnum.RegistrationComplete;
    }

    trackEnglishOrEspanolTotalClicks(eventCategory, eventLabel, eventPage);

    Login$SwitchLanguage(isEnglish() ? 'es-MX' : 'en-US');
}

function trackEnglishOrEspanolTotalClicks(eventCategory, eventLabel, eventPage) {
    if (eventCategory) {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: eventCategory,
            eventAction: T.ActionEnum.ButtonClick,
            eventLabel: eventLabel,
            eventPage: eventPage
        });
    }
}

function Login$SwitchLanguage(tempLanguage) {
    language = tempLanguage;
    var ajaxUrl = '/Home/SwitchLanguage';
    var jsonData = JSON.stringify({ "language": tempLanguage });
    var xhr = new XMLHttpRequest();
    xhr.open("POST", ajaxUrl);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.timeout = timeout;
    xhr.ontimeout = function (e) {
        $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.Login, false, emailAddress);
        isExcuting = false;
        //Inline message
        showServerError(getResourse('systemerror'));
        removeClass(document.getElementById("LoginButton"), "now-loading");
        return;
    };
    xhr.onreadystatechange = function () {
        if (this.readyState == 4) {
            if (this.status == 200 || this.status == 302) {
                addSpanishClass();
                localizationForLoginPage();
            }
            else {
                isExcuting = false;

                if (this.status == 404) {
                    //Inline message
                    showServerError(getResourse('systemerror'));
                    return;
                }
            }
        }
    }
    xhr.onerror = function (e) {
        isExcuting = false;
        //Inline message
        showServerError(getResourse('systemerror'));
        return;
    }
    xhr.send(jsonData);
}

// Only for parse invaid password error message.
function getPasswordInvalidTime(errorMessage) {
    var invalidTime = 0;
    if (errorMessage && errorMessage != "") {
        for (var i = 0; i < errorMessage.length; i++) {
            if (errorMessage[i] != ' ' && !isNaN(errorMessage[i])) {
                invalidTime = errorMessage[i];
                break;
            }
        }
    }
    return invalidTime;
}