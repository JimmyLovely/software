﻿(function () {
    var rememberMe = 'RememberMe';
    var rememberMeTimeout = 'RememberMeTimeout';
    var timeout = 60 * 1000;
    window.unidos = window.unidos || {};

    unidos.resource = {
        'email': 'Email',
        'password': 'Password',
        'usernamepasswordnotmatch': 'Username and Password do not match',
        'show': 'SHOW',
        'hide': 'HIDE',
        'rememberme': 'Remember Me',
        'enablecookie': 'Please enable your browser cookie',
        'login': 'Login',
        'signup': 'Don\'t have an account? Sign-up.',
        'forgetpassword': 'Forgot your password?',
        'copyright': 'Copyright © 2017 Unidos Financial Services, Inc. All rights reserved.',
        'passwordrequired': 'Password Required',
        'emailaddressrequired': 'Email Address Required',
        'invalidemailaddress': 'Valid Email Address Required',
        'systemerror': 'We\'re Sorry. Something went wrong while connecting to Sengo. Please try again.',
        'commonerror': 'Please contact Customer Care at 1-855-398-2569.',
        'language': 'Español',
        'logintitle': 'Login - Sengo',
        'passwordinvalid': 'Password is invalid. You have {0} more attempt(s) before the account locks. Please attempt login again or reset your password.',
        'accountlockederror': 'Account is locked. Please reset your password or call customer service at 1-855-398-2569.',
        'emailaddressnotregister': 'Email Address has not been registered.',
        'addressnotverified': 'This email address has not been verified. A new verification link has been sent.',
        'accountfrozen': 'Account is frozen. Please call customer service at 1-855-398-2569.'
    };
    unidos.resourceMX = {
        'email': 'Correo electrónico',
        'password': 'Contraseña',
        'usernamepasswordnotmatch': 'Tu usuario y tu contraseña no coinciden',
        'show': 'Mostrar',
        'hide': 'Ocultar',
        'rememberme': 'Recordarme',
        'enablecookie': 'Por favor habilita los cookies en el navegador.',
        'login': 'Iniciar Sesión',
        'signup': '¿Aún no tienes cuenta? Regístrate.',
        'forgetpassword': '¿Olvidaste tu contraseña?',
        'copyright': 'Copyright © 2017 Unidos Servicios Financieros, Inc. Todos los derechos reservados.',
        'passwordrequired': 'Se requiere contraseña',
        'emailaddressrequired': 'Se requiere dirección de correo electrónico',
        'invalidemailaddress': 'Se requiere  una dirección de correo electrónico válida',
        'systemerror': 'Lo sentimos. Ocurrió un error al conectarnos a Sengo. Por favor inténtalo De nuevo.',
        'commonerror': 'Por favor llama a Servicio al Cliente al 1-855-398-2569.',
        'language': 'English',
        'logintitle': 'Iniciar Sesión - Sengo',
        'passwordinvalid': 'La contraseña es inválida. Tienes {0} intentos más antes de que tu cuenta quede bloqueada. Por favor intenta de nuevo iniciar tu sesión o restablece tu contraseña.',
        'accountlockederror': 'La cuenta está bloqueada. Por favor restablece tu contraseña o llama al número de Servicios al Cliente 1-855-398-2569.',
        'emailaddressnotregister': 'La dirección de correo electrónico no ha sido registrada.',
        'addressnotverified': 'Esta dirección de correo electrónico no ha sido verificada. Una nueva liga de verificación será enviada.',
        'accountfrozen': 'Tu cuenta está bloqueada. Por favor llama a Servicios al Cliente al 1-855-398-2569.'
    };

    // Start appsflyer track event
    function trackEvent(eventLabel) {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.LoginScreen,
            eventAction: T.ActionEnum.ButtonClick,
            eventLabel: eventLabel,
            eventPage: T.PageEnum.LoginScreen
        });
    }

    function trackNextPage(eventLabel) {
        T.trackEvent({
            sendType: T.GA,
            eventCategory: T.CategoryEnum.LoginScreen,
            eventAction: T.ActionEnum.ExitPage,
            eventLabel: eventLabel,
            eventPage: T.PageEnum.LoginScreen
        });
    }

    function trackLoginError() {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.LoginScreen,
            eventAction: T.ActionEnum.Error,
            eventLabel: "Login Error: Validation failed",
            eventPage: T.PageEnum.LoginScreen
        });
    };

    var trackTotalLoads = function () {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.LoginScreen,
            eventAction: T.ActionEnum.ScreenView,
            eventLabel: "LoginScreen",
            eventPage: T.PageEnum.LoginScreen,
            nonInteraction:true
        });
    }

    var trackTimeOnPage = function () {
        T.trackTimeOnPage({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.LoginScreen,
            eventAction: T.ActionEnum.Metric,
            eventLabel: "TimeOnPage",
            eventPage: T.PageEnum.LoginScreen
        });
    };

            var trackRememberMeTotalClicks = function () {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.LoginScreen,
                    eventAction: T.ActionEnum.InputField,
                    eventLabel: "RememberMe:" + (document.getElementById("remember-me").checked ? 'ON' : 'OFF'),
                    eventPage: T.PageEnum.LoginScreen
                });
            };

    var trackTimeStart = T.generatePartialTimeOnPageTrack(T.CategoryEnum.LoginScreen, T.PageEnum.LoginScreen);

    var trackBeforeLoginTimeOnPage = function () {
        trackTimeStart("Login");
    };

    var trackBeforeSignUpTimeOnPage = function () {
        trackTimeStart("Don't have an account? Sign-up.");
    };

    var trackBeforeForgotPasswordTimeOnPage = function () {
        trackTimeStart("Forgot your password?");
    };

    var trackErrorMessage = T.generateErrorMessageTrack(T.CategoryEnum.LoginScreen, T.PageEnum.LoginScreen);

    // End appsflyer track event

    window.onload = function () {
        /*Capture login button click in carousel.*/
        $.DataCapture.CarouselConversion($.DataCapture.CarouselActionType.ClickOnLoginButton);

        document.getElementById("remember-me").checked = true;

        document.getElementById("remember-me").onclick = function () {
            trackRememberMeTotalClicks();
        };

        var hostName = document.getElementById("host-name").innerHTML;

        //I18n.js
        localizationForLoginPage();

        try {
            localStorage.setItem("HostName", hostName);
        }
        catch (e) {
            console.log(e.message);
        }
        var isValidateEmailAddress = false;
        var isValidatePassword = false;

        document.getElementById("LoginButton").onclick = doLogin;

        document.getElementById("show-pass").onclick = function () {
            var t = "text", e = document.getElementById("input-password");
            e.setAttribute("type", t);
            document.getElementById("show-pass").style.display = "none";
            document.getElementById("hide-pass").style.display = "block";

            var trackPasswordShowTotalClicks = trackEvent;
            trackPasswordShowTotalClicks("Password SHOW");
        }

        document.getElementById("hide-pass").onclick = function () {
            var n = "password", e = document.getElementById("input-password");
            e.setAttribute("type", n);
            document.getElementById("hide-pass").style.display = "none";
            document.getElementById("show-pass").style.display = "block";
        }

        document.getElementById("input-email-address").onfocus = function () {
            if (!isValidateEmailAddress && document.getElementById("input-email-address").className.indexOf("error") > -1) {
                isValidateEmailAddress = true;
            };
        }

        document.getElementById("input-password").onfocus = function () {
            if (!isValidatePassword && document.getElementById("input-password").className.indexOf("error") > -1) {
                isValidatePassword = true;
            };
        }

        document.getElementById("input-email-address").onkeydown = function (e) {
            if (e.which === 13) {
                document.getElementById("input-password").focus();
            }
        }

        document.getElementById("input-password").onkeydown = function (e) {
            if (e.which === 13) {
                doLogin();
            }
        }

        document.getElementById("input-email-address").onkeyup = function (e) {
            if (isValidateEmailAddress) {
                validationEmailAddress();
            }
        }

        document.getElementById("input-password").onkeyup = function () {
            if (isValidatePassword) {
                validationPassword();
            }
        }

        document.getElementById("sign-up").onclick = function () {
            var trackSignUpLinkTotalClicks = trackEvent;
            trackSignUpLinkTotalClicks("Don't have an account? Sign-up.");

            trackNextPage("Sign Up Page");

            trackBeforeSignUpTimeOnPage();

            location.href = "/SelfService/SignUpConsumer";
            return true;
        };

        document.getElementById("forget-password").onclick = function () {
            var trackForgetPasswordLinkTotalClicks = trackEvent;
            trackForgetPasswordLinkTotalClicks("Forgot your password?");

            trackNextPage("Forget Password Page");

            trackBeforeForgotPasswordTimeOnPage();

            location.href = "/SelfService/ForgotConsumer";
            return true;
        };

        if (isIOS()) {
            document.getElementById("input-email-address").onfocusout = function (e) {
                getEmailAddress();
                validationEmailAddress();
                reviseEvent(e);
            }

            document.getElementById("input-password").onfocusout = function (e) {
                validationPassword();
                reviseEvent(e);
            }
        } else {
            if (navigator.userAgent.indexOf("Firefox") > 0) {
                var isValidateEmail = false;
                $("#input-email-address").off("blur")
                    .on("blur", function () {
                        if (isValidateEmail) {
                            getEmailAddress();
                            validationEmailAddress();
                            reviseEvent(e);
                            isValidateEmail = false;
                        }
                    })
                    .off("focus")
                    .on("focus", function () {
                        if (!isValidateEmail) {
                            isValidateEmail = true;
                        }
                    });
            } else {
                document.getElementById("input-email-address").addEventListener("focusout", function (e) {
                    getEmailAddress();
                    validationEmailAddress();
                    reviseEvent(e);
                });
            }

            document.getElementById("input-password").addEventListener("focusout", function (e) {
                validationPassword();
                reviseEvent(e);
            });
        }

        var rememberEmailAddress = localStorage.getItem(rememberMe);
        var remembermeTimeoutValue = localStorage.getItem(rememberMeTimeout);
        var expireDate = new Date();
        try {
            expireDate = new Date(remembermeTimeoutValue);
        }
        catch (error) { }

        if (rememberEmailAddress && remembermeTimeoutValue) {
            var nowDate = new Date();
            if (nowDate < expireDate) {
                document.getElementById("input-email-address").value = rememberEmailAddress;
            }
            else {
                localStorage.removeItem(rememberMe);
                localStorage.removeItem(rememberMeTimeout);
            }
        }

        //var ajaxUrl = "/CustomerDashBoard/GetBuildVersion";
        //ajaxCall(ajaxUrl, "Get", null, function (response) {
        //    if (response.readyState == 4 && response.status == 200) {
        //        //var content = JSON.parse(response.response);
        //        //var BuildVersionInformation = content.HostName + (!content.BuilderNumber ? "" : " - ") + content.BuilderNumber + content.AppVersion;
        //        //document.getElementById("host-name").innerHTML = BuildVersionInformation;
        //    }
        //}, function (response) {
        //    // todo, network issue.
        //});

        //var fragment = document.createDocumentFragment(),
        //    dynamicLoadStatic = {
        //        js: function (src) {
        //            var jsE = document.createElement("object");
        //            jsE.data = src;
        //            jsE.style.width = jsE.style.height = 0;
        //            jsE.style.display = 'inherit';
        //            return jsE;
        //        }
        //    };
        // fragment.appendChild(dynamicLoadStatic.js("/Scripts/lib-ext/foundation-extended.js"));
        //    fragment.appendChild(dynamicLoadStatic.js("/Scripts/common.js"));
        //document.body.appendChild(fragment);

        trackTotalLoads();

        trackTimeOnPage();
    };

    function getEmailAddress() {
        var emailAddress = $("#input-email-address").val().trim();
        $("#input-email-address").val("");
        $("#input-email-address").val(emailAddress);
    }

    function ajaxCall(url, type, jsonData, callBack, callBackError, isLogUserActivity) {
        var xhr = new XMLHttpRequest();
        if (isLogUserActivity) {
            xhr.open(type, url, false);
        } else {
            xhr.open(type, url);
        }
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');

        if (jsonData != null && jsonData != "") {
            xhr.send(jsonData);
        }
        else {
            xhr.send();
        }
        xhr.onreadystatechange = function () {
            callBack(xhr);
        }

        xhr.onerror = function () {
            callBackError(xhr);
        }
    }

    function validationPassword() {
        var password = document.getElementById("input-password").value;
        if (!password) {
            hideServerError(document.getElementById("login-email-error-message").style.display == "none");
            showPasswordError(getResourse('passwordrequired'), 'passwordrequired');
        } else {
            if (document.getElementById("login-error-message") != null
                && document.getElementById("login-error-message").style.display != "none") {
                hideServerError(document.getElementById("login-email-error-message").style.display == "none");
            }

            hidePasswordError();
            return true;
        }

        return false;
    }
    function validationEmailAddress() {
        var emailAddress = $("#input-email-address").val().trim();
        if (!emailAddress) {
            //Inline message
            showEmailAddressError(getResourse('emailaddressrequired'), 'emailaddressrequired');
        } else if (emailAddress.length > 50) {
            //Inline message
            showEmailAddressError(getResourse('invalidemailaddress'), 'invalidemailaddress');
        } else if (!(/^((".*?[^\\]"@)|(([0-9a-z]((\.(?!\.))|[-!#\$%&'\*\+/=\?\^`\{\}\|~\w])*)[0-9a-z]@)|(([0-9a-z]@)))((\[(\d{1,3}\.){3}\d{1,3}\])|(([0-9a-z][-\w]*[0-9a-z]*\.)+[a-z0-9][\-a-z0-9]{0,22}[a-z0-9]))$/i.test(emailAddress))) {
            //Inline message
            showEmailAddressError(getResourse('invalidemailaddress'), 'invalidemailaddress');
        } else {
            var password = document.getElementById("input-password").value;

            if (document.getElementById("login-error-message") != null && document.getElementById("login-error-message").style.display != "none") {
                hideServerError();
            }

            hideEmailAddressError();
            SetShowHidePosition();
            return true;
        }
        SetShowHidePosition();
        return false;
    }

    function SetShowHidePosition() {
        if (document.getElementById("login-email-error-message").style.display == "block") {
            document.getElementById("show-pass").style.top = "111px";
            document.getElementById("hide-pass").style.top = "111px";
        } else {
            document.getElementById("show-pass").style.top = "80px";
            document.getElementById("hide-pass").style.top = "80px";
        }
    }

    function hasClass(element, cla) {
        return element.className.match(new RegExp('(\\s|^)' + cla + '(\\s|$)'));
    }

    function addClass(element, cla) {
        if (!hasClass(element, cla)) {
            element.className += " " + cla;
        }
    }

    function removeClass(element, cla) {
        if (hasClass(element, cla)) {
            var reg = new RegExp('(\\s|^)' + cla + '(\\s|$)');
            element.className = element.className.replace(reg, ' ');
        }
    }

    function showEmailAddressError(message, messageKey) {
        addClass(document.getElementById("input-email-address"), "error");
        document.getElementById("login-email-error-message").textContent = message;
        document.getElementById("login-email-error-message").style.display = "block";
        document.getElementById("login-email-error-message").setAttribute("data-language", messageKey);

        trackErrorMessage(message);
    }

    function hideEmailAddressError() {
        removeClass(document.getElementById("input-email-address"), "error");
        document.getElementById("login-email-error-message").textContent = "";
        document.getElementById("login-email-error-message").style.display = "none";
    }

    function showPasswordError(message, messageKey) {
        addClass(document.getElementById("input-password"), "error");
        document.getElementById("login-password-error-message").textContent = message;
        document.getElementById("login-password-error-message").style.display = "block";
        document.getElementById("login-password-error-message").setAttribute("data-language", messageKey);
        
        trackErrorMessage(message);
    }

    function hidePasswordError() {
        removeClass(document.getElementById("input-password"), "error");
        document.getElementById("login-password-error-message").textContent = "";
        document.getElementById("login-password-error-message").style.display = "none";
    }

    function showServerError(message, messageKey) {
        addClass(document.getElementById("input-email-address"), "error");
        addClass(document.getElementById("input-password"), "error");
        document.getElementById("login-error-message").textContent = message;
        document.getElementById("login-error-message").style.display = "block";
        document.getElementById("login-error-message").setAttribute("data-language", messageKey);

        trackErrorMessage(message, true);
    }

    function hideServerError(shouldHideEmailError) {
        if (shouldHideEmailError) {
            removeClass(document.getElementById("input-email-address"), "error");
        }
        removeClass(document.getElementById("input-password"), "error");
        document.getElementById("login-error-message").textContent = "";
        document.getElementById("login-error-message").style.display = "none";
    }

    var isExcuting = false;
    function doLogin() {
        if (isExcuting) {
            return;
        }

        var trackLoginButtonTotalClicks = trackEvent;
        trackLoginButtonTotalClicks("Login");

        if (!CheckEnabledCookie()) {
            document.getElementById("disable-cookie-error-message").style.display = "block";
            return;
        }

        document.getElementById("disable-cookie-error-message").style.display = "none";

        if (!validationEmailAddress() || !validationPassword()) {
            return;
        }
        isExcuting = true;

        var emailAddress = document.getElementById("input-email-address").value;
        var password = document.getElementById("input-password").value;
        var isRememberMe = false;
        isRememberMe = document.getElementById("remember-me").checked;
        var timeZone = new Date().getTimezoneOffset();

        //addClass(document.getElementById("LoginButton"), "now-loading");
        document.getElementById("LoginButton").className += " now-loading";

        var ajaxUrl = "/Home/LoginConsumer";
        var authenticationModel = { "EmailAddress": emailAddress, "Password": password, "IsBrowser": "true" },
            previewTransaction = JSON.parse(localStorage && localStorage.getItem("PreviewSendMoneyTransaction")),
            marketingCampaignActivity = JSON.parse(localStorage && localStorage.getItem("MarketingCampaignActivity"));
        jsonData = JSON.stringify({
            "authenticationModel": authenticationModel,
            "previewSendMoneyTransactionModel": previewTransaction,
            "marketingCampaignActivity": marketingCampaignActivity
        });
        var xhr = new XMLHttpRequest();
        xhr.open("POST", ajaxUrl);
        xhr.setRequestHeader('Content-Type', 'application/json');
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.setRequestHeader('TimeZone', timeZone);

        xhr.timeout = timeout;
        xhr.ontimeout = function (e) {
            $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.Login, false, emailAddress);
            isExcuting = false;
            //Inline message
            showServerError(getResourse('systemerror'), 'systemerror');
            removeClass(document.getElementById("LoginButton"), "now-loading");
            return;
        };

        xhr.onreadystatechange = function () {
            if (this.readyState == 4) {
                if (this.status == 200 || this.status == 302) {
                    saveEmailAddress(isRememberMe, emailAddress);
                    try {
                        sessionStorage.setItem("IsFirstLogin", JSON.parse(this.responseText).IsFirstLogin);
                        sessionStorage.setItem("IsBrowser", "true");
                        sessionStorage.setItem("DashboardFromPage", "Login");

                        //Data capture device info.
                        $.DeviceInfo.CheckDeviceInfo(emailAddress);

                        var internalHash = localStorage.getItem("InternalHash");
                        var marketingCampaignActivity = JSON.parse(localStorage && localStorage.getItem("MarketingCampaignActivity"));
                        var refereeActivityId = marketingCampaignActivity && marketingCampaignActivity.RefereeActivityId;

                        trackBeforeLoginTimeOnPage();

                        localStorage.removeItem("InternalHash");
                        localStorage.removeItem("MarketingCampaignActivity");
                        localStorage.removeItem("ReferralUrl");
                        if (!!internalHash && !!refereeActivityId) {
                            trackNextPage("Referral Page");
                            location.href = "/SelfService/ReferralLandingConsumer";
                        } else {
                            trackNextPage("Dashboard Page");
                            location.href = "/SelfService/CustomerDashboard";
                        }
                    }
                    catch (e) {
                        console.log(e.message);
                    }
                }
                else {
                    isExcuting = false;

                    if (this.status == 404) {
                        $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.Login, false, emailAddress);
                        //Inline message
                        showServerError(getResourse('systemerror'), 'systemerror');
                        removeClass(document.getElementById("LoginButton"), "now-loading");
                        return;
                    }

                    try {
                        if (isJson(JSON.parse(this.responseText).Message)) {
                            var resultCode = JSON.parse(JSON.parse(this.responseText).Message).exceptionCode;
                            if (resultCode == -443) {
                                trackBeforeLoginTimeOnPage();

                                trackNextPage("Authorization Device Page");
                                saveEmailAddress(isRememberMe, emailAddress);
                                $.DataCapture.LogUserActivityBySync($.DataCapture.CardHolderActivityType.Login, false, emailAddress);
                                //Use submit form to transfer value.
                                var authorizeDeviceForm = document.createElement("form");
                                authorizeDeviceForm.action = "/SelfService/AuthorizationDevicePage";
                                authorizeDeviceForm.method = 'POST';

                                var tempInput = document.createElement("input");
                                tempInput.name = 'emailAddress';
                                tempInput.value = emailAddress;
                                authorizeDeviceForm.appendChild(tempInput);

                                if (JSON.parse(JSON.parse(this.responseText).Message).reason.indexOf('&') != -1) {
                                    var tempInputPhone = document.createElement("input");
                                    tempInputPhone.name = 'phoneNumber';
                                    tempInputPhone.value = JSON.parse(JSON.parse(this.responseText).Message).reason.substring(JSON.parse(JSON.parse(this.responseText).Message).reason.indexOf('&') + 1);
                                    authorizeDeviceForm.appendChild(tempInputPhone);
                                }

                                document.getElementById("authorizeForm").appendChild(authorizeDeviceForm);
                                authorizeDeviceForm.submit();
                                return;
                            } else if (resultCode == -1001) {
                                //Inline message
                                showServerError(getResourse('commonerror'), 'commonerror');
                            }
                        }

                        $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.Login, false, emailAddress);

                        if (!isJson(this.responseText)) {
                            showServerError(this.responseText);
                        } else if (!isJson(JSON.parse(this.responseText).Message)) {
                            if (JSON.parse(this.responseText).ReturnCode && JSON.parse(this.responseText).ReturnCode == -876) {
                                showServerError(getResourse('systemerror'), 'systemerror');
                            }
                            if (JSON.parse(this.responseText).ReturnCode && JSON.parse(this.responseText).ReturnCode == -877) {
                                showServerError(getResourse('commonerror'), 'commonerror');
                            }
                            else {
                                showServerError(JSON.parse(this.responseText).Message);
                            }
                        } else if (!isJson(JSON.parse(JSON.parse(this.responseText).Message).reason)) {
                            if (resultCode == -463) {
                                passwordInvalidTime = getPasswordInvalidTime(JSON.parse(JSON.parse(this.responseText).Message).reason);
                                showServerError(String.format(getResourse('passwordinvalid'), passwordInvalidTime), 'passwordinvalid');
                            }
                            else if (resultCode == -472) {
                                showServerError(getResourse('accountlockederror'), 'accountlockederror');
                            }
                            else if (resultCode == -446) {
                                showServerError(getResourse('emailaddressnotregister'), 'emailaddressnotregister');
                            }
                            else if (resultCode == -442) {
                                showServerError(getResourse('addressnotverified'), 'addressnotverified');
                            }
                            else if (resultCode == -467) {
                                showServerError(getResourse('accountfrozen'), 'accountfrozen');
                            }
                            else {
                                showServerError(JSON.parse(JSON.parse(this.responseText).Message).reason);
                            }
                            
                            if (resultCode == -447) {
                                $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.PasswordLock, true, emailAddress, "L", "");
                            }
                        }
                        else {
                            showServerError(JSON.parse(JSON.parse(this.responseText).Message).reason);
                        }
                    }
                    catch (e) {
                        if (this && this.responseText) {
                            if (!isJson(this.responseText)) {
                                showServerError(this.responseText);
                            } else if (!isJson(JSON.parse(this.responseText).Message)) {
                                showServerError(JSON.parse(this.responseText).Message);
                            } else if (!isJson(JSON.parse(JSON.parse(this.responseText).Message).reason)) {
                                showServerError(JSON.parse(JSON.parse(this.responseText).Message).reason);
                            }
                            else {
                                showServerError(JSON.parse(JSON.parse(this.responseText).Message).reason);
                            }
                        }
                    }
                    removeClass(document.getElementById("LoginButton"), "now-loading");
                }
            }
        }
        xhr.onerror = function (e) {
            $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.Login, false, emailAddress);
            isExcuting = false;
            //Inline message
            showServerError(getResourse('systemerror'), 'systemerror');
            removeClass(document.getElementById("LoginButton"), "now-loading");
            return;
        }

        xhr.send(jsonData);
    }

    function saveEmailAddress(isRememberMe, emailAddress) {
        try {
            if (isRememberMe) {
                var localEmailAddress = localStorage.getItem(rememberMe);
                if (localEmailAddress && localEmailAddress == emailAddress) {
                    return;
                }
                try {
                    localStorage.setItem(rememberMe, emailAddress);
                } catch (e) {
                    console.log(e.message);
                }
                var timeOutTime = new Date();
                timeOutTime.setDate(timeOutTime.getDate() + 30);
                try {
                    localStorage.setItem(rememberMeTimeout, timeOutTime.toISOString());
                } catch (e) {
                    console.log(e.message);
                }
            }
            else {
                localStorage.removeItem(rememberMe);
                localStorage.removeItem(rememberMeTimeout);
            }
        } catch (e) { }
    }

    function isJson(content) {
        try {
            JSON.parse(content);
            return true;
        } catch (e) {
            return false;
        }
    }

    function CheckEnabledCookie() {
        if (!navigator.cookieEnabled) {
            return false;
        }
        if (!CookieEnable()) {
            return false;
        }
        return true;
    }

    function CookieEnable() {
        return ("cookie" in document && (document.cookie.length > 0 || (document.cookie = "TestCookie").indexOf.call(document.cookie, "TestCookie") > -1));
    }

    function reviseEvent(e) {
        if (!e.relatedTarget || e.relatedTarget.id == "remember-me") return;

        e.relatedTarget.click();
        return false;
    }

    function isIOS() {
        return !!navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
    }

})(window);