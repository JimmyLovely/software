﻿(function () {
    function Obj(obj) {
        var self = this;
        self.container = [];
        if (obj instanceof HTMLElement) {
            self.container[0] = obj;
        } else if (obj instanceof HTMLCollection || obj instanceof NodeList) {
            each(obj, function (o) {
                self.container.push(o);
            });
        } else if(obj instanceof Array) {
            self.container[0] = obj;
        }
    }

    Obj.prototype.hide = function () {
        each(this.container, function (element) {
            element.style.display = 'none';
        });
    };

    Obj.prototype.show = function () {
        each(this.container, function (element) {
            element.style.display = 'block';
        });
    };

    Obj.prototype.html = function (content) {
        each(this.container, function (element) {
            element.innerHTML = content;
        });
    };

    Obj.prototype.text = function (content) {
        each(this.container, function (element) {
            element.innerText = content;
        });
    };

    Obj.prototype.hasClass = function (className) {
        var result = true;
        each(this.container, function (obj) {
            result = obj.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'));
            if (result == false) {
                return false;
            }
        });

        return result;
    };

    Obj.prototype.addClass = function (className) {
        each(this.container, function (obj) {
            if (!obj.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'))) {
                obj.className += " " + className;
            }
        });
    };

    Obj.prototype.removeClass = function (className) {
        each(this.container, function (obj) {
            if (obj.className.match(new RegExp('(\\s|^)' + className + '(\\s|$)'))) {
                var reg = new RegExp('(\\s|^)' + className + '(\\s|$)');
                obj.className = obj.className.replace(reg, ' ');
            }
        });
    };

    var eventStack = [];
    Obj.prototype.on = function (eventName, handler) {
        each(this.container, function (obj) {
            eventStack.push({
                obj: obj,
                eventName: eventName,
                handler: handler
            });
            var bindEventName = eventName.split('.')[0];
            if (window.addEventListener) { // Mozilla, Netscape, Firefox
                obj.addEventListener(bindEventName, handler, false);
            } else if (window.attachEvent) { // IE
                obj.attachEvent(bindEventName, handler);
            } else {
                obj['on' + bindEventName] = handler;
            }
        });

        return this;
    };
    Obj.prototype.off = function (eventName) {
        each(this.container, function (obj) {
            each(eventStack, function (item) {
                if (item.obj == obj && item.eventName == eventName) {
                    var bindEventName = eventName.split('.')[0];
                    if (window.addEventListener) { // Mozilla, Netscape, Firefox
                        obj.removeEventListener(bindEventName, item.handler, false);
                    } else if (window.attachEvent) { // IE
                        obj.detachEvent('on' + bindEventName, item.handler);
                    } else {
                        obj['on' + bindEventName] = "";
                    }
                }
            });
        });

        return this;
    }

    Obj.prototype.css = function (key, value) {
        var style = this;
        each(this.container, function (obj) {
            if (typeof key === 'undefined') {
                return;
            }

            if (typeof value === 'undefined') {
                style = obj.style[key];
            } else {
                obj.style[key] = value;
            }
        });
        return style;
    };

    Obj.prototype.val = function (value) {
        var result = null;
        each(this.container, function (obj) {
            if (typeof value === 'undefined') {
                result = obj.value;
            } else {
                obj.value = value;
            }
        });
        return result;
    };

    Obj.prototype.length = function () {
        return this.container.length;
    };

    Obj.prototype.modal = function (action) {
        if ($('.reveal-modal-bg').length() == 0) {
            $('body').append('<div class="reveal-modal-bg" style="display: none;"></div>');
        }

        if (action == 'open') {
            $('.reveal-modal-bg').css('display', 'block');
            this.addClass('open');
            each(this.container, function (obj) {
                obj.style = 'top: 50px; position: fixed; display: block; opacity: 1; visibility: visible;';
            });
        } else {
            $('.reveal-modal-bg').css('display', 'none');
            this.removeClass('open');
            each(this.container, function (obj) {
                obj.style = '';
            });
        }
    };

    Obj.prototype.append = function (html) {
        each(this.container, function (obj) {
            var divTemp = document.createElement("div"), nodes = null
            , fragment = document.createDocumentFragment();
            divTemp.innerHTML = html;
            nodes = divTemp.childNodes;
            for (var i = 0, length = nodes.length; i < length; i += 1) {
                fragment.appendChild(nodes[i].cloneNode(true));
            }
            obj.appendChild(fragment);
            nodes = null;
            fragment = null;
        });
    };

    Obj.prototype.blur = function () {
        each(this.container, function (obj) {
            obj.blur();
        });
    }


    Obj.prototype.focus = function () {
        each(this.container, function (obj) {
            obj.focus();
        });
    };

    Obj.prototype.trigger = function (eventName) {
        each(this.container, function (obj) {
            obj[eventName]();
        });
    }

    Object.prototype.each = function (obj, callback) {
        if (typeof obj == 'undefined') {
            return;
        }

        if ("length" in obj) {
            for (var i = 0; i < obj.length; i++) {
                var result = callback(obj[i], i);
                if (result == false) {
                    break;
                }
            }
        } else {
            for (var k in obj) {
                if (callback(k, obj[k]) == false) {
                    break;
                }
            }
        }
    }

    function $(selector) {
        if (typeof selector == 'undefined') {
            return new Obj(nul)
        } else if (selector instanceof HTMLElement) {
            return new Obj(selector);
        } else if (typeof selector === 'string') {
            var func = function (parentObj, childSelecor) {
                if (parentObj == null) {
                    if (childSelecor.indexOf("#") == 0) {
                        return document.getElementById(childSelecor.replace('#', ''));
                    } else if (childSelecor.indexOf('.') == 0) {
                        return document.getElementsByClassName(childSelecor.replace('.', ''));
                    } else if (childSelecor.indexOf("data-language") > -1) {
                        var selector = document.querySelectorAll("*");
                        var selectArray = new Array();
                        for (var i = 0; i < selector.length; i++) {
                            if (selector[i].getAttribute('data-language'))
                            {
                                selectArray.push(selector[i]);
                            }
                        }
                        return selectArray;
                    }

                    else {
                        return document.getElementsByTagName(childSelecor);
                    }
                } else {
                    if (childSelecor.indexOf("#") == 0) {
                        return parentObj.getElementById(childSelecor.replace('#', ''));
                    } else if (childSelecor.indexOf('.') == 0) {
                        return parentObj.getElementsByClassName(childSelecor.replace('.', ''));
                    }
                    else {
                        return parentObj.getElementsByTagName(childSelecor);
                    }
                }
            };
            var selectorSplit = selector.split(' ');
            var obj = null;
            for (var i = 0; i < selectorSplit.length; i++) {
                obj = func(obj, selectorSplit[i]);
            }
            return new Obj(obj);
        }
    }

    $.ajax = function (options) {
        options = options || {};
        options.type = (options.type || "GET").toUpperCase();
        options.dataType = options.dataType || "json";
        options.async = options.async != null ? options.async : true;

        var params = options.data;

        if (window.XMLHttpRequest) {
            var xhr = new XMLHttpRequest();
        } else {
            var xhr = new ActiveXObject('Microsoft.XMLHTTP');
        }

        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) {
                var status = xhr.status;
                if (status >= 200 && status < 300) {
                    if (options.dataType.toLowerCase() == 'json' && xhr.responseText.length > 0) {
                        options.success && options.success(JSON.parse(xhr.responseText));
                    } else {
                        options.success && options.success(xhr.responseText, xhr.responseXML);
                    }
                } else {
                    options.error && options.error(xhr, status);
                }
            }
        }

        if (options.type == "GET") {
            xhr.open("GET", options.url + "?" + formatGetParams(params), options.async);
        } else if (options.type == "POST") {
            xhr.open("POST", options.url, options.async);
        }

        xhr.setRequestHeader("Content-Type", options.contentType || "application/json");
        xhr.setRequestHeader("X-Requested-With", "XMLHttpRequest");
        if (typeof options.beforeSend === 'function') {
            options.beforeSend(xhr);
        }
        xhr.send(options.type == 'GET' ? null : params);
    };

    function formatGetParams(data) {
        var arr = [];
        each(data, function (k, v) {
            arr.push(k + "=" + v);
        })
        return arr.join("&");
    }
    window.$ = window.$ || $;
})(window)
