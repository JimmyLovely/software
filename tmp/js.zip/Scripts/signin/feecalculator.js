﻿(function () {
    function CurrencyModel() {
        this.Value = ko.observable("");
        this.Symbol = ko.observable('$');
    }

    function FeeCalculator() {
        var self = this,
            USA_CURRENCY_CODE = "USD",
            USA_COUNTRY_ID = 840;

        var timeHandler = 0;

        var AmountToSendValue = "0";
        var AmountToReceiveValue = "0";

        self.AmountToSend = new CurrencyModel();
        self.AmountToBeDispensed = new CurrencyModel();
        self.AmountCollected = new CurrencyModel();
        self.TotalFee = new CurrencyModel();

        self.FromCurrency = '';
        self.FromCurrencyCode = ko.observable(USA_CURRENCY_CODE);
        self.ToCurrency = 0;
        self.ToCurrencyCode = ko.observable('');
        self.ToCountryImage = ko.observable();
        self.ExchangeRate = ko.observable('');
        self.CountryId = ko.observable();
        self.CountryName = ko.observable();
        self.NumberOfLocations = ko.observable();
        self.Countries = ko.observable();
        self.Country = ko.observable();
        self.NumberOfLocations = ko.observable();
        self.showPickupAndPayment = ko.observable(true);
        self.lastTypeIsSend = ko.observable(true);

        //1: Credit Card
        //3: Bank Account  
        self.PaymentMethodTypeId = ko.observable(3);
        // 2: Calculate AmountToSend
        // 3: Calculate AmountToBeDispensed 
        self.CalculateCase = 3;
        self.original = { AmountToSend: "0.00", AmountToBeDispensed: "0.00" };
        window.unidos = window.unidos || {};

        unidos.resource = {
            "feecalculatortitle": "Fee Calculator",
            "language": "Español",
            "send": "SEND",
            "choose": "Choose a",
            'country': 'Country',
            "receive": "RECEIVE",
            "paymentmethod": "Payment Method",
            "bank": "Bank",
            'account': 'Account',
            "credit": "Credit",
            "card": "Card",
            "pickupcash": "Pickup cash from one of our",
            "pickuplocations": "locations.",
            "youpay": "You Pay",
            "sendmoney": "Send Money",
            "hide": "Hide",
            'copyright': 'Copyright © 2017 Unidos Financial Services, Inc. All rights reserved.',
            'fee': 'Fee',
            'enteranamount': 'Please enter an amount',
            'getstarted': 'Get Started',
            'ok': 'OK',
        };
        unidos.resourceMX = {
            "feecalculatortitle": "Calculadora de Tarifa",
            "language": "English",
            "send": "Enviar",
            "choose": "Selecciona un",
            'country': 'País',
            "receive": "Recibir",
            "paymentmethod": "Método de pago",
            "bank": "Cuenta", // Need show 'Cuenta de banco' and 'de banco' is in newline
            'account': 'de banco',
            "credit": "Tarjeta", // Need show 'Tarjeta de crédito' and 'de crédito' is in newline
            "card": "de crédito",
            "pickupcash": "Recoje efectivo de uno de nuestros",
            "pickuplocations": "puntos de pago.",
            "youpay": "Tu pagarás",
            "sendmoney": "Enviar dinero",
            "hide": "Esconder",
            'copyright': 'Copyright © 2017 Unidos Servicios Financieros, Inc. Todos los derechos reservados.',
            'fee': 'Tarifa',
            'enteranamount': 'Por favor ingresa una cantidad',
            'getstarted': 'Enviar dinero',
            'ok': 'OK',
        };

        self.Language = ko.observable(['en-US', 'english'].indexOf(language) !== -1 ? unidos.resource : unidos.resourceMX);

        self.init = function () {
            initializePreviewTransaction();

            $.DataCapture.CarouselConversion($.DataCapture.CarouselActionType.ClickOnFeeCalculatorButton);
            localization();
        }

        // Start appsflyer event track
        var trackGetStartedTotalClicks = function () {
            T.trackEvent({
                sendType: T.GA + T.MP,
                eventCategory: T.CategoryEnum.CalculatorScreenPre,
                eventAction: T.ActionEnum.ButtonClick,
                eventLabel: "Get Started",
                eventPage: T.PageEnum.CalculatorScreenPre,
                amount: self.AmountToSend.Value()
            });
        };

        var trackCloseIconTotalClicks = function () {
            T.trackEvent({
                sendType: T.GA + T.MP,
                eventCategory: T.CategoryEnum.CalculatorScreenPre,
                eventAction: T.ActionEnum.ButtonClick,
                eventLabel: "Calculator Close",
                eventPage: T.PageEnum.CalculatorScreenPre
            });

            trackBeforeCancelTimeOnPage();
        };

        var trackTimeStart = T.generatePartialTimeOnPageTrack(T.CategoryEnum.CalculatorScreenPre, T.PageEnum.CalculatorScreenPre);

        var trackBeforeCancelTimeOnPage = function () {
            trackTimeStart("Cancel");
        };

        var trackBeforeSaveTimeOnPage = function () {
            trackTimeStart("Save");
        };

        // End appsflyer event track
        self.afterRender = function () {
            initAmountAttr();
            amountFitInTime();

            /*Click back element*/
            $('#header i').click(function () {
                /*If "CarouselRequestId" is null, it's back to fee calculator screen from login screen.*/
                if (!$.DataCaptureStorage.GetLocalStorage("CarouselRequestId")) {
                    return;
                }

                $.DataCaptureStorage.SetSessionStorage('FeeCalculatorBackToCarousel', true);
            });

            $('.pay-wrapper form.country').click(function (event) {
                $("#country-select-dropdown").toggle();
                event.stopPropagation();
            });

            $(document).click(function () {
                $("#country-select-dropdown").hide();
            })

            // Reload fee calculator data if already done once.
            var previewTransaction = getPreviewTransactionModel();
            if (previewTransaction) {
                self.CountryId(previewTransaction.ToCountryId);
                self.ToCurrency = previewTransaction.ToCurrencyId;
                self.AmountToSend.Value(previewTransaction.AmountToSend.Value == 0 ? "" : previewTransaction.AmountToSend.Value);
                self.AmountToBeDispensed.Value(previewTransaction.AmountToBeDispensed.Value == 0 ? "" : previewTransaction.AmountToBeDispensed.Value);
                self.CalculateCase = previewTransaction.CalculateCase;
                self.PaymentMethodTypeId(previewTransaction.PaymentMethodTypeId);
            }
        }

        self.bindEventToAmount = function (element, isSend) {
            var element = $(element);
            var oldValue = element.val();
            element.off("input.attribute.amount");
            element.on("input.attribute.amount", function () {
                clearTimeout(timeHandler);
                oldValue = LimitNumber(element, isSend, oldValue, self.ExchangeRate());
                self.amountChanged(element, isSend, oldValue);
                
                addDisable('get-started');
                timeHandler = setTimeout(function () {
                        self.amountCalculate(isSend, element);
                }, 500);
            });
            element.off("focus.attribute.amount");
            element.on("focus.attribute.amount", function (e) {
                self.lastTypeIsSend(isSend);
                oldValue = GetOriginalNumber(element.val());

                $('small').css('display', 'none');
                if (!IsMobileDevice()) {
                    this.value = this.value.replace(/,|\.00/g, "");
                }
            });
        }

        self.ChangeLanguage = function () {
            if (['en-US', 'english'].indexOf(language) !== -1) {
                self.Language(unidos.resource);
            }
            else {
                self.Language(unidos.resourceMX);
            }
        }

        function suitFontSizeOfInput(transaction, isSend, value) {
            var amount = "-1";
            transaction.DominantControl = isSend ? 'AmountToBeSent' : 'AmountToBeReceived';
            amount = value;
            if (amount == null) {
                amount = "-1";
            }

            if (amount && parseFloat(GetOriginalNumber(amount.toString())) > 0) {
                amount = parseFloat(GetOriginalNumber(amount.toString()));
                if (transaction.DominantControl == "AmountToBeSent") {
                    //transaction().AmountToSend.Value(amount);
                    var result = 1.0 * amount * transaction.ExchangeRate();
                    if (!isNaN(result)) {
                        var amountToBeDispensed = keepAmountDecimalPlaces(result);
                        transaction.AmountToBeDispensed.Value(amountToBeDispensed);

                        if ($("#input-amount-receive") && $("#input-amount-receive").length > 0) {
                            fitTextAmountField($("#input-amount-receive"), amountToBeDispensed);
                        }
                    }
                } else {
                    //transaction().AmountToBeDispensed.Value(amount);
                    var result = 1.0 * amount / transaction.ExchangeRate();
                    if (!isNaN(result)) {
                        var sendToAmount = keepAmountDecimalPlaces(result);
                        transaction.AmountToSend.Value(sendToAmount);
                        if ($("#input-amount-send") && $("#input-amount-send").length > 0) {
                            fitTextAmountField($("#input-amount-send"), sendToAmount);
                        }
                    }
                }
            } else {
                if (value == "" || value == null || value == '0.00') {
                    //transaction().AmountToBeDispensed.Value(null);
                    //transaction().AmountToSend.Value();
                    if (IsMobileDevice()) {
                        $("#input-amount-to-be-dispensed").val("0.00");
                        $("#receiver-amount-input").val("0.00");

                        $("#input-amount-to-send").val("0.00");
                        $("#send-amount-input").val("0.00");
                    } else {
                        $("#input-amount-to-be-dispensed").val("");
                        $("#receiver-amount-input").val("");

                        $("#input-amount-to-send").val("");
                        $("#send-amount-input").val("");
                    }
                }
            }
        }

        self.amountChanged = function (element, isAmountToSend, amount) {
            var rate = self.ExchangeRate(), result;

            if (isAmountToSend) {
                result = (1.0 * amount * rate).toFixed(2);
                if (IsMobileDevice()) {
                    self.AmountToSend.Value(getFormatFloat(amount));
                    self.AmountToBeDispensed.Value(getFormatFloat(result));
                } else {
                    self.AmountToSend.Value(amount);
                    self.AmountToBeDispensed.Value(result);
                }
                AmountToSendValue = amount;
                AmountToReceiveValue = result;
            } else {
                result = (1.0 * amount / rate).toFixed(2);

                if (IsMobileDevice()) {
                    self.AmountToSend.Value(getFormatFloat(result));
                    self.AmountToBeDispensed.Value(getFormatFloat(amount));
                } else {
                    self.AmountToSend.Value(result);
                    self.AmountToBeDispensed.Value(amount);
                }
                AmountToSendValue = result;
                AmountToReceiveValue = amount;
            }

            suitFontSizeOfInput(self, isAmountToSend, element.val());

            /*For value is 0*/
            if (self.AmountToSend.Value() == 0) {
                self.AmountCollected.Value(0);
                self.TotalFee.Value(0);
            }
        }

        self.getStarted = function () {
            trackGetStartedTotalClicks();

            if ($('a.button').attr("disabled") == "disabled") {
                return false;
            }

            trackBeforeSaveTimeOnPage();
            cachePreviewTransactionModel();
            $.DataCapture.ResetFlagForCarousel();
            window.location.href = '/SelfService/LoginConsumer';
        };

        self.closeFeeCalculator = function () {
            trackCloseIconTotalClicks();

            var referralUrl = localStorage.getItem("ReferralUrl");
            if (!!referralUrl) {
                location.href = "/" + referralUrl;
            } else {
                location.href = "/";
            }
        };

        function LimitNumber(element, isSend, originalAmount, rate) {

            amount = $(element).val().replace(/[^\d\.\,]/g, "");

            if (IsMobileDevice()) {
                var selectionEnd = $(element).val().length - $(element)[0].selectionEnd;

                originalAmount = getFormatFloat(originalAmount);

                //if changedChar is only one letter,judge if is "," and "." ;
                if (originalAmount != null && amount.length == (originalAmount.length - 1)) {
                    var end = $(element)[0].selectionEnd;
                    var start = $(element)[0].selectionStart;
                    var changedChar = originalAmount.substring(start, end + 1);
                    if (changedChar == "," || changedChar == ".") {
                        amount = originalAmount.substring(0, start - 1) + originalAmount.substring(start, originalAmount.length);
                    }
                }

                amountValue = amount;

                //Dynamic change maximum length
                if (amount != "") {
                    amount = (parseInt(amount.toString().replace(/[^0-9]*/g, '')) * 0.01).toFixed(2);
                } else {
                    amount = 0;
                    amount = amount.toFixed(2);
                }

                var start = $(element)[0].selectionEnd;
                //distinguish Several digits between before and after
                if (isSend) {
                    //according to the cursor position,decide where to delete
                    for (var i = amountValue.length; i > 0; i--) {
                        DispensedAmount = (1.0 * amount * rate).toFixed(2);
                        if (/^\d{0,7}?\.?\d{0,2}$/.test(DispensedAmount) && /^\d{0,5}?\.?\d{0,2}$/.test(parseFloat(amount).toFixed(2))) {
                            $(element).val(amount.replace(/(\d{1,3})(?=(?:\d{3})+\.)/g, '$1,'));
                            break;
                        } else {
                            amountValue = amountValue.substring(0, start - 1) + amountValue.substring(start, amountValue.length);
                            amount = amountValue.replace(/\,/g, "");
                            start = start - 1;
                        }
                    }
                } else {
                    for (var i = amountValue.length; i > 0; i--) {
                        SendAmount = (1.0 * amount / rate).toFixed(2);
                        if (/^\d{0,5}?\.?\d{0,2}$/.test(SendAmount) && /^\d{0,7}?\.?\d{0,2}$/.test(parseFloat(amount).toFixed(2))) {
                            $(element).val(amount.replace(/(\d{1,3})(?=(?:\d{3})+\.)/g, '$1,'));
                            break;
                        } else {
                            amountValue = amountValue.substring(0, start - 1) + amountValue.substring(start, amountValue.length);
                            amount = amountValue.replace(/\,/g, "");
                            start = start - 1;
                        }
                    }
                }

                amountValue = amount.replace(/(\d{1,3})(?=(?:\d{3})+\.)/g, '$1,');
                $(element).val(amountValue)
                $(element)[0].selectionEnd = keepAmountDecimalPlaces(amount).length - selectionEnd;
            } else {
                //Filter the data(add Decimal)
                if (!(/^\d{0,7}?\.?\d{0,2}$/.test(amount))) {
                    amount = originalAmount;
                    $(element).val(originalAmount);
                }

                var start = $(element)[0].selectionEnd;
                var length = amount.length;
                if (isSend) {
                    //according to the cursor position,decide where to delete
                    for (var i = length; i > 0; i--) {
                        DispensedAmount = (1.0 * amount * rate).toFixed(2);
                        if (/^\d{0,7}?\.?\d{0,2}$/.test(DispensedAmount) && /^\d{0,5}?\.?\d{0,2}$/.test(parseFloat(amount).toFixed(2))) {
                            $(element).val(amount);
                            break;
                        } else {
                            amount = amount.substring(0, start - 1) + amount.substring(start, amount.length);
                            start = start - 1;
                        }
                    }
                } else {
                    for (var i = length; i > 0; i--) {
                        SendAmount = (1.0 * amount / rate).toFixed(2);
                        if (/^\d{0,5}?\.?\d{0,2}$/.test(SendAmount) && /^\d{0,7}?\.?\d{0,2}$/.test(parseFloat(amount).toFixed(2))) {
                            $(element).val(amount);
                            break;
                        } else {
                            amount = amount.substring(0, start - 1) + amount.substring(start, amount.length);
                            start = start - 1;
                        }
                    }
                }
                if (amount == "") {
                    $(element).val("");
                }
                $(element)[0].selectionEnd = start;
            }
            return amount;
        }

        self.amountCalculate = function (isAmountToSend, element) {
            self.CalculateCase = isAmountToSend ? 3 : 2;

            if (getAmountFloat(self.original.AmountToBeDispensed) != getAmountFloat(self.AmountToBeDispensed.Value()) ||
                getAmountFloat(self.original.AmountToSend) != getAmountFloat(self.AmountToSend.Value())) {
                $.when(calculate('#virtualElement'))
                .always(function () {
                    removeDisable('get-started');
                });

                if (isAmountToSend) {
                    self.original.AmountToBeDispensed = self.AmountToBeDispensed.Value();
                } else {
                    self.original.AmountToSend = self.AmountToSend.Value();
                }
            } else {
                removeDisable('get-started');
            }
        }

        self.receiverCountryChanged = function (countryId, isUlElementSelect) {
            if (typeof isUlElementSelect != "boolean") {
                initCountrySelect(self.CountryId());
            } else {
                $("#country-select-dropdown").toggle();
                initCountrySelect(countryId);
            }

            if (self.lastTypeIsSend()) {
                var receiveFloatValue = 1.0 * (AmountToSendValue.replace(/,/g, ''));

                if (receiveFloatValue <= 0) {
                    return;
                }

                AmountToReceiveValue = getFormatFloat((receiveFloatValue * self.ExchangeRate()).toFixed(2));
                self.AmountToBeDispensed.Value(AmountToReceiveValue);
            } else {
                var sendFloatValue = 1.0 * (AmountToReceiveValue.replace(/,/g, ''));
                if (sendFloatValue <= 0) {
                    return;
                }

                AmountToSendValue = getFormatFloat((sendFloatValue / self.ExchangeRate()).toFixed(2));
                self.AmountToSend.Value(AmountToSendValue);
            }
            calculate();
        }

        self.paymentMethodChanged = function (element, isBankAccount) {
            self.PaymentMethodTypeId(isBankAccount ? 3 : 1);
            calculate();
            //if (!isActivedChanged(element)) return;
        }

        function calculate(element) {
            if (self.AmountToSend.Value() <= 0 && self.AmountToBeDispensed.Value() <= 0) {
                return $.Deferred().reject();
            }


            var previewTransactionModel = clone(self);
            delete previewTransactionModel.Countries;
            delete previewTransactionModel.Country;

            previewTransactionModel.ToCountryId = previewTransactionModel.CountryId;
            previewTransactionModel.FromCurrencyId = previewTransactionModel.FromCurrency;
            previewTransactionModel.ToCurrencyId = previewTransactionModel.ToCurrency;
            previewTransactionModel.AmountToSend.Value = AmountToSendValue;
            previewTransactionModel.AmountToBeDispensed.Value = AmountToReceiveValue;

            var deferred = $.Deferred();
            ajaxByLoading({
                url: "/Home/CalculatorNotLoggedInForWeb",
                type: "post",
                contentType: "application/json",
                data: JSON.stringify({ previewSendMoneyTransactionModel: previewTransactionModel, appVersion: "5.0" })
            }, element)
            .done(function (data) {
                if (checkAmountChange(previewTransactionModel)) {
                    return;
                }

                clone(data, self);
                self.original.AmountToSend = data.AmountToSend.Value;
                self.original.AmountToBeDispensed = data.AmountToBeDispensed.Value;



                /*Log Fee Calculation.*/
                var feeCalculationModel = {
                    FromCountryCode: data.FromCurrencyCode,
                    ToCountryCode: data.ToCurrencyCode,
                    ExchangeRate: data.ExchangeRate,
		            EmailAddress: $.DataCaptureStorage.GetLocalStorage("RememberMe"),
                    BackBtnClicked: $.DataCaptureStorage.GetSessionStorage("FeeCalculatorBackToCarousel"),
                    CarouselPageId: $.DataCaptureStorage.GetSessionStorage('CarouselPageId'),

                    FromCountryId: "840",  //Defaultsend country is USA.
                    ToCountryId: data.ToCountryId,
                    FromCurrencyId: "840",
                    ToCurrencyId: data.ToCurrencyId,
                    AmountToSend: data.AmountToSend.Value,
                    AmountToReceive: data.AmountToBeDispensed.Value,
                    AmountToCollected: data.AmountCollected.Value,
                    PaymentTypeId: data.PaymentMethodTypeId
                }

                $.DataCapture.LogFeeCalculation(feeCalculationModel);

                deferred.resolve();
            })
            .fail(function (xhr, status) {
                console.log(xhr);
                self.AmountCollected.Value("");
                self.TotalFee.Value("");
                var data = $.parseJSON(xhr.responseText);
                showPopUpMessage(data.Caption, data.Message);
                deferred.reject();
            });

            return deferred;
        }

        function checkAmountChange(previewTransactionModel) {
            if (previewTransactionModel.DominantControl == 'AmountToBeSent') {
                if (Number(GetOriginalNumber(previewTransactionModel.AmountToSend.Value)) != Number(GetOriginalNumber(self.AmountToSend.Value()))) {
                    return true;
                }
            } else if (previewTransactionModel.DominantControl == 'AmountToBeReceived') {
                if (Number(GetOriginalNumber(previewTransactionModel.AmountToBeDispensed.Value)) != Number(GetOriginalNumber(self.AmountToBeDispensed.Value()))) {
                    return true;
                }
            }

            return false;
        }

        function GetOriginalNumber(number) {
            if (typeof number == "string") {
                number = number.replace(/,/g, "");
            }

            return number;
        }

        function cachePreviewTransactionModel() {
            var previewTransaction = clone(self);
            previewTransaction.AmountToSend.Value = AmountToSendValue;
            previewTransaction.AmountToBeDispensed.Value = AmountToReceiveValue;

            return localStorage && localStorage.setItem("PreviewSendMoneyTransaction", JSON.stringify({
                ToCountryId: previewTransaction.CountryId,
                FromCurrencyId: previewTransaction.FromCurrency,
                ToCurrencyId: previewTransaction.ToCurrency,
                AmountToSend: previewTransaction.AmountToSend,
                AmountToBeDispensed: previewTransaction.AmountToBeDispensed,
                CalculateCase: previewTransaction.CalculateCase,
                PaymentMethodTypeId: previewTransaction.PaymentMethodTypeId
            }));
        }

        function getPreviewTransactionModel() {
            return localStorage && JSON.parse(localStorage.getItem("PreviewSendMoneyTransaction"));
        }

        function initializePreviewTransaction() {
            if (localStorage && localStorage.PreviewSendMoneyTransaction) {
                var sessionTransactionModel = JSON.parse(localStorage.PreviewSendMoneyTransaction);
                if (sessionTransactionModel.AmountToSend.Value && sessionTransactionModel.AmountToSend.Value != 0) {
                    AmountToSendValue = keepAmountDecimalPlaces(sessionTransactionModel.AmountToSend.Value);
                    self.AmountToSend.Value(AmountToSendValue);
                    AmountToReceiveValue = keepAmountDecimalPlaces(sessionTransactionModel.AmountToBeDispensed.Value);
                    self.AmountToBeDispensed.Value(AmountToReceiveValue);

                    self.PaymentMethodTypeId(sessionTransactionModel.PaymentMethodTypeId);
                    self.CalculateCase = sessionTransactionModel.CalculateCase;
                    self.CountryId(sessionTransactionModel.ToCountryId);

                    $('#input-amount-send').prev('small').css('display', 'none');
                    $('#input-amount-receive').prev('small').css('display', 'none');
                }

            }

            ajaxByLoading({
                url: "/Home/InitializePreviewTransactionForWeb",
                type: "get"
            })
            .done(function (data) {
                var previewTransactionModel = data.PreviewTransactionModel || {},
                    countries = data.Countries || [];
                self.Countries(countries);

                if (sessionTransactionModel && sessionTransactionModel.AmountToSend.Value && sessionTransactionModel.AmountToSend.Value != 0) {
                    initCountrySelect(sessionTransactionModel.ToCountryId);
                    sessionTransactionModel.ExchangeRate = self.ExchangeRate();
                    initPreviewTransactionModel(sessionTransactionModel);
                    calculate();
                } else {
                    initCountrySelect(previewTransactionModel.ToCountryId);
                    initPreviewTransactionModel(previewTransactionModel);
                }
            });
        }

        function initPreviewTransactionModel(previewTransactionModel) {
            if (!previewTransactionModel) return;

            self.CountryId(previewTransactionModel.ToCountryId);
            self.ExchangeRate(previewTransactionModel.ExchangeRate);
            self.FromCurrencyCode(USA_CURRENCY_CODE);
            self.FromCurrency = previewTransactionModel.FromCurrencyId;
        }

        function initCountrySelect(selectedCountryId) {
            var countries = self.Countries();

            for (var i = 0, l = countries.length; i < l; i++) {
                if (countries[i].CountryId == selectedCountryId) {
                    var country = countries[i];

                    self.Country(country);
                    self.CountryId(country.CountryId);
                    self.ToCountryImage(country.CountryImage);
                    self.CountryName(country.CountryName);
                    self.ExchangeRate(country.ExchangeRate);
                    self.ToCurrencyCode(country.CurrencyCode);
                    self.ToCurrency = country.CurrencyId;
                    self.showPickupAndPayment(true);
                    self.NumberOfLocations(country.NumberOfLocations);
                    break;
                }
            }
            $("#countryName").css("display", "inline");
        }

        function amountFitInTime() {
            ko.computed(function () {
                var amountToSend = self.AmountToSend.Value(),
                    AmountToBeDispensed = self.AmountToBeDispensed.Value();

                if (self.original.AmountToBeDispensed != self.AmountToBeDispensed.Value()) {
                    $("#input-amount-receive").triggerHandler("keyup.amountFit", AmountToBeDispensed);
                }
                
                if (self.original.AmountToSend != self.AmountToSend.Value()) {
                    $("#input-amount-send").triggerHandler("keyup.amountFit", amountToSend);
                }
            })
        }

        function isActivedChanged(element) {
            if ($(element).hasClass("selected")) return false;

            return $(element).addClass("selected").removeClass("not-selected")
                .siblings(".selected").addClass("not-selected").removeClass("selected");
        }

        function hideLoading() {
            $("#modal-loading").hide();
        }

        function showLoading(element) {
            if (!element) {
                $("#modal-loading").show();
            }
        }

        // Start For function
        function ajaxByLoading(options, element) {
            showLoading(element);
            return $.ajax(options)
                .always(function () {
                    hideLoading();
                })
                .fail(function () {
                    hideLoading();
                });
        }
       
        function initAmountAttr() {
            var dataAmount = $("[data-amount]");

            dataAmount.attr("maxLength", "12")
                .off('paste.number')
                .on('paste.number', function (e) {
                    var clipboardContent = getClipboardContent(e);
                    var selectionStart = this.selectionStart;
                    var selectionEnd = this.selectionEnd;
                    var selectionLength = selectionEnd - selectionStart;
                    var maxLength = parseInt(isNaN($(this).attr('maxlength')) ? '2147483647' : $(this).attr('maxlength'));
                    var tempVal = $(this).val();

                    if (tempVal.length - selectionLength + clipboardContent.length > maxLength) {
                        clipboardContent = clipboardContent.substr(0, maxLength - (tempVal.length - selectionLength));
                    }

                    tempVal = tempVal.substr(0, selectionStart) + clipboardContent + tempVal.substr(selectionEnd);

                    var reg = new RegExp(/[^(0-9)]/g);
                    if ($(this).attr('amount') == "") {
                        reg = new RegExp(/[^(0-9|.)]/g);
                        if (tempVal.indexOf('.') == 0 || tempVal.indexOf(".") != tempVal.lastIndexOf(".")) {// contains more then one dot or the dot is at the beginning.
                            return false;
                        }
                    }

                    if (reg.test(clipboardContent)) {
                        return false;
                    }
                })
                .off("keydown.amount")
                .on("keydown.amount", function (e) {
                    var keyCode = e.which;
                    // Prevent ctrl + CVXZY
                    if (e.ctrlKey) {
                        return ['C', 'V', 'X', 'Z', 'Y'].indexOf(String.fromCharCode(keyCode).toUpperCase()) <= -1;
                    }
                    // key tab and enter
                    if (keyCode == 9 || keyCode == 13) {
                        e.preventDefault();
                        $(this).trigger("blur");
                    }
                }).off("keypress.amount")
                .on("keypress.amount", function (e) {
                    var keyCode = e.which,
                        value = this.value,
                        length = value.length,
                        start = this.selectionStart,
                        dotIndex = value.indexOf("."),
                        isNotThreeDecimal = dotIndex > length - 4 || dotIndex == -1;

                    //key code 0-9, not two decimal or selection start before the dot
                    if (keyCode >= 48 && keyCode <= 57) {
                        if (IsMobileDevice()) {
                            if (length >= 12) {
                                return false;
                            }
                            return true;
                        } else {
                            if ((isNotThreeDecimal || start <= dotIndex)) {
                            return true;
                        }
                        else if (e.currentTarget && (e.currentTarget.selectionEnd - e.currentTarget.selectionStart) > 0) {
                            return true;
                        }
                    }
                    }
                    //no dot or key code '.'
                    if (start > 0 && dotIndex == -1 && keyCode == 46) return true;
                    // Press Backspace or arrow left and right.
                    if (keyCode == 8 || keyCode == 0) return true;

                    return false;
                }).off("blur.amount")
                .on("blur.amount", function () {
                    if (this.value == "") {
                        $('input').val('');
                        $('small').css('display', 'block');
                    }

                    if (this.value == '0.00') {
                        $('input').val('0.00');
                    }

                    this.value = getFormatFloat(this.value);
                });
        }

        function formatAmountForInput(element, oldValue) {
            element = $(element);
            var validationReg = new RegExp(/^\d+\.{0,2}\d*$/);
            if (!validationReg.test(element.val().replace(/,/g, ''))) {
                var totleValue = oldValue.replace(".", "").replace(/,/g, '');
                var leftValue = totleValue.substring(1, totleValue.length);
                var formatedValue = parseFloat(leftValue.substring(0, leftValue.length - 2) + "." + leftValue.substring(leftValue.length - 2, leftValue.length)).toFixed(2);
                element.val(formatedValue);
                element[0].selectionStart = element[0].selectionEnd = 1;
            }

            // Validate input value.
            var selectionStart = element[0].selectionStart;
            var selectionEnd = element[0].selectionEnd;
            var selectionLength = selectionEnd - selectionStart;
            var maxLength = parseInt(isNaN($(element).attr('maxlength')) ? '2147483647' : $(element).attr('maxlength'));
            var tempVal = $(element).val().replace(/,/g, '');

            if (tempVal.length > maxLength) {
                tempVal = tempVal.substr(0, maxLength);
            }

            var reg = new RegExp(/[^(0-9)]/g);
            if ($(element).attr('data-amount') == "") {
                reg = new RegExp(/[^(0-9|.)]/g);
                if (tempVal.indexOf(".") != tempVal.lastIndexOf(".")) {// contains more then one dot or the dot is at the beginning.
                    $(element).val(oldValue);
                }
            }

            if (reg.test(tempVal)) {
                $(element).val(oldValue);
            }

            var value = element.val().replace(".", "").replace(/,/g, '');
            var length = element.val().length - element[0].selectionEnd;

            if (value.length == 0) {
                $(element).val("0.00");
            } else if (value.length == 1) {
                $(element).val("0.0" + value);
            } else if (value.length == 2) {
                $(element).val("0." + value);
            } else {
                $(element).val(parseFloat(value.substring(0, value.length - 2) + "." + value.substring(value.length - 2, value.length)).toFixed(2));
            }
            var changedChar = oldValue.substring(selectionStart, selectionEnd + 1);
            if (element.val().replace(/,/g, '') <= oldValue.replace(/,/g, '') && (changedChar == "," || changedChar == ".")) {
                $(element).val((oldValue.substring(0, selectionStart - 1) + oldValue.substring(selectionStart, oldValue.length)).replace(/,/g, ''));
            }
            $(element).val(keepAmountDecimalPlaces($(element).val()));
            element[0].selectionStart = element[0].selectionEnd = $(element).val().length - length;
        }

        function keepAmountDecimalPlaces(value) {
            if (value && !isNaN(value)) {
                value = parseFloat(value).toFixed(2);
            }

            return getFormatFloat(value);
        }

        function GetOriginalNumber(number) {
            if (typeof number == "string") {
                number = number.replace(/,/g, "");
            }

            return number;
        }

        function fitTextAmountField(element, value) {
            var $input = $(element);
            if ($input && $input.length > 0) {
                defaultSize = $input.css('font-size', '').css('font-size');
                var minSize = 1;
                var maxSize = parseFloat(defaultSize || $input.css('font-size'), 10);
                var clone = $input.next("div");
                var width = $input.width();

                clone.html(value);

                var ratio = width / (clone.width() || 1);
                var currentFontSize = parseInt(clone.css('font-size'), 10);
                var fontSize = Math.floor(currentFontSize * ratio);
                if (fontSize > maxSize) { fontSize = maxSize; }
                if (fontSize < minSize) { fontSize = minSize; }

                $input.css('font-size', fontSize);
                clone.css('font-size', fontSize);
                $input.val(value);
            }
        }

        function getClipboardContent(event) {
            if (window.clipboardData) {
                return window.clipboardData.getData('Text');
            }
            else {
                return event.originalEvent.clipboardData.getData('Text');
            }
        }

        function keepAmountDecimalPlaces(value) {
            if (value && !isNaN(value)) {
                value = parseFloat(value).toFixed(2);
            }

            return getFormatFloat(value);
        }

        // Start For utils
        function getFormatFloat(value) {
            if (!/^(\d+)(\.\d+)?$/.test(value)) {
                return value;
            }

            var integerPart = RegExp.$1,
                decimalPart = RegExp.$2,
                reg = new RegExp();

            reg.compile("(\\d)(\\d{3})(,|$)");

            while (reg.test(integerPart)) {
                integerPart = integerPart.replace(reg, "$1,$2$3");
            }

            return integerPart.replace(/^[0]+/g, "0").replace(/^[0]+([1-9]+)/g, "$1") + "" + (decimalPart || ".00");
        }

        function getAmountFloat(num) {
            if (!num) return 0;

            return parseFloat(num.replace(/,/g, ''));
        }

        function clone(o1, o2) {
            if (!o1) return;

      var isMobile = IsMobileDevice();
      var isO2Undefined = typeof o2 == "undefined";
            o2 = o2 || {};

            for (var property in o1) {
                var pro1 = ko.toJS(o1[property]),
                    pro2 = o2[property];

                if (!property.isPrototypeOf(o1) && typeof pro1 != "function") {

          if (!isO2Undefined && (property == "AmountToSend" || property == "AmountToBeDispensed")) {
            continue;
          }

                    if (ko.isObservable(pro2)) {
                            o2[property](pro1);
                    } else if (typeof pro2 == "object") {
                        o2[property] = clone(o1[property], o2[property]);
                    }
                    else {
                        o2[property] = pro1;
                    }
                }
            }

            return o2;
        }

        function IsMobileDevice() {
            return !!navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|Windows Phone)/i);
        }

        function removeDisable(element) { //element is id or object
            element = GetElementIdWithSymbol(element);

            $(element).attr("disabled", false)

            if ($(element).hasClass("disabled")) {
                $(element).removeClass("disabled");
            }
        }

        function addDisable(element) { //element is id or object
            element = GetElementIdWithSymbol(element);
            $(element).attr("disabled", "disabled");
            $(element).addClass("disabled");
        }

        function GetElementIdWithSymbol(element) {
            if (typeof element === "string") {
                if (element.indexOf("#") != 0) {
                    return element = "#" + element;
                }
                return element;
            }
            return element;
        }

        function showPopUpMessage(caption, message) {
            $("#ErrorCaption").text(caption);
            $("#ErrorMessage").text(message);
            $("#ErrorOk").text(getResourse('ok'));
            $("#ErrorOk").off("click");
            $("#ErrorOk").on("click", function () {
                $("#modal-error").foundation('close');
            });
            $("#modal-error").foundation('open');
        };
    }

    window.onload = function () {
        if (!feeCalculator.AmountToSend.Value() || feeCalculator.AmountToSend.Value() == 0) {
            $("#input-amount-send").val("");
            $("#input-amount-receive").val("");
        }

        $("#modal-error").foundation();
    }

    // for fire fox issue: cannot execute javascript after clicking browse's back button.
    window.onbeforeunload = function () { }

    // for safari issue: cannot execute javascript after clicking browse's back button.
    window.onpageshow = function (e) {
        if (e.persisted) {
            window.location.reload();
        }
    }



    var feeCalculator = new FeeCalculator();
    ko.applyBindings(feeCalculator);
    feeCalculator.init();


    var trackTotalLoads = function () {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.CalculatorScreenPre,
            eventAction: T.ActionEnum.ScreenView,
            eventLabel: "CalculatorScreen",
            eventPage: T.PageEnum.CalculatorScreenPre,
            nonInteraction: true
        });
    }

    trackTotalLoads();

    var trackTimeOnPage = function () {
        T.trackTimeOnPage({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.CalculatorScreenPre,
            eventAction: T.ActionEnum.Metric,
            eventLabel: "TimeOnPage",
            eventPage: T.PageEnum.CalculatorScreenPre
        });
    };

    trackTimeOnPage();

    var trackReferralUrl = function () {
        T.trackEvent({
            sendType: T.GA,
            eventCategory: T.CategoryEnum.CalculatorScreenPre,
            eventAction: T.ActionEnum.SourcePage,
            eventLabel: document.referrer,
            eventPage: T.PageEnum.CalculatorScreenPre,
            nonInteraction: true
        });
    };

    trackReferralUrl();
})(window)