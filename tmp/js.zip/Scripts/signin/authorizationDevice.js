﻿(function () {
    var isValidateActiveCode = false;
    var isValidatePassword = false;
    window.unidos = window.unidos || {};

    unidos.resource = {
        'deviceregistration': 'Device Registration',
        'deviceregistrationmessage': 'For security we need to further verify your account. Click below to receive a security code and continue.',
        'enablecookie': 'Please enable your browser cookie',
        'alreadyhavecode': 'Already have a code? Click Here.',
        'backtologin': 'Back to Login',
        'computerregistration': 'Device Registration',
        'checkemailtogetcode': 'Enter the security code received and your password.',
        'entercode': 'Enter Code',
        'coderequired': 'Code Required',
        'copyright': 'Copyright © 2017 Unidos Financial Services, Inc. All rights reserved.',
        'passwordrequired': 'Password Required',
        'codeandpasswordnotmatch': 'Code and Password do not match',
        'finish': 'Finish',
        'resendcode': 'Resend Code',
        'systemerror': 'We\'re Sorry. Something went wrong while connecting to Sengo. Please try again.',
        'commonerror': 'Please contact Customer Care at 1-855-398-2569.',
        'language': 'Español',
        'emailto': 'Email to ',
        'enterpassword': 'Enter Password',
        'textto': 'Text to ***-***-**',
        'passwordinvalid': 'Password is invalid. You have {0} more attempt(s) before the account locks. Please attempt login again or reset your password.',
        'accountlockederror': 'Account is locked. Please reset your password or call customer service at 1-855-398-2569.',
        'registercodeinvalid': 'Registration code is invalid.',
        'accountfrozen': 'Account is frozen. Please call customer service at 1-855-398-2569.'
    };
    unidos.resourceMX = {
        'deviceregistration': 'Registro de dispositivo',
        'deviceregistrationmessage': 'Por seguridad, necesitamos verificar tu cuenta. Por favor selecciona una opcion para recibir tu codigo de seguridad y continuar.',
        'enablecookie': 'Por favor habilita los cookies en el navegador.',
        'alreadyhavecode': '¿Ya tienes un código? Haz click aquí.',
        'backtologin': 'Regresar a Inicio de sesión',
        'computerregistration': 'Registro de dispositivo',
        'checkemailtogetcode': 'Ingresa el código de seguridad que recibiste y tu contraseña.',
        'entercode': 'Ingresa código',
        'coderequired': 'Se requiere código',
        'copyright': 'Copyright © 2017 Unidos Servicios Financieros, Inc. Todos los derechos reservados.',
        'passwordrequired': 'Se requiere contraseña',
        'codeandpasswordnotmatch': 'El código y la contraseña no coinciden',
        'finish': 'Completar',
        'resendcode': 'Reenviar código',
        'systemerror': 'Lo sentimos. Ocurrió un error al conectarnos a Sengo. Por favor inténtalo De nuevo.',
        'commonerror': 'Por favor llama a Servicio al Cliente al 1-855-398-2569.',
        'language': 'English',
        'emailto': 'Correo electrónico a ',
        'enterpassword': 'Ingresa tu contraseña',
        'textto': 'Enviar texto a ***-***-**',
        'passwordinvalid': 'La contraseña es inválida. Tienes {0} intentos más antes de que tu cuenta quede bloqueada. Por favor intenta de nuevo iniciar tu sesión o restablece tu contraseña.',
        'accountlockederror': 'La cuenta está bloqueada. Por favor restablece tu contraseña o llama al número de Servicios al Cliente 1-855-398-2569.',
        'registercodeinvalid': 'Código de Registro Invalido.',
        'accountfrozen': 'Tu cuenta está bloqueada. Por favor llama a Servicios al Cliente al 1-855-398-2569.'
    };

    // Start appsflyer track event
    var trackErrorMessage = T.generateErrorMessageTrack(T.CategoryEnum.DeviceAuthorizationActivation, T.PageEnum.DeviceAuthorizationActivation);

    // End appsflyer track event
    window.onload = bodyLoaded;

    // Start appsflyer track event
    var trackPartialTimeOnPage = T.generatePartialTimeOnPageTrack(T.CategoryEnum.DeviceAuthorization, T.PageEnum.DeviceAuthorization);

    var trackBeforeSendEmailTimeOnPage = function () {
        trackPartialTimeOnPage("Send email button");
    };

    var trackBeforeLoginTimeOnPage = function () {
        trackPartialTimeOnPage("Back to Login");
    };

    var trackBeforeAlreadyCodeTimeOnPage = function () {
        trackPartialTimeOnPage("Already have a code? Click Here.");
    };

    // End appsflyer track event

    function bodyLoaded() {

        //I18n
        localizationForLoginPage();

        $("#button-send-email").on("click", sendEmail);
        $("#button-send-sms").on("click", sendSMS);
        $("#button-sign-in").on("click", goToAuthorizationDeviceActivation);
        $("#button-finish").on("click", authorizationDevice);
        $("#button-finish").on("keydown", triggerAuthorizationDevice);
        $("#button-resend-code").on("click", showSendCodeTypePage);

        var trackLoginButtonTotalClicks = function () {
            trackEvent("Back To Login");
            trackBeforeLoginTimeOnPage();

            location.href = "/SelfService/LoginConsumer";
        };
        $("#button-login").on("click", trackLoginButtonTotalClicks);

        InitialEmailAddressButton();

        var oldAuthorizationDeviceActiveCode = "";
        $("#input-authrization-device-active-code").off("focus")
        .on("focus", function () {
            if ($(this).hasClass("error")) {
                isValidateActiveCode = true;
            }
            oldAuthorizationDeviceActiveCode = this.value;
        })
        .off("keyup")
        .on("keyup", function () {
            if (isValidateActiveCode) {
                hideServerErrorMessage();
                validationCode();
            }
        })
        .off("focusout")
        .on("focusout", function () {
            if ($("#device-error-message").css("display") != "block") {
                validationCode();
            }
        })
        .off("keydown.moveToNext")
        .on("keydown.moveToNext", function (e) {
            if (e.which === 13) {
                $("#input-authrization-device-password").focus();
            }
        })
        .off("input")
        .on("input", function () {
            var reg = new RegExp('^[0-9]*$');
            if (!reg.test(this.value)) {
                this.value = oldAuthorizationDeviceActiveCode;
            }
            else {
                oldAuthorizationDeviceActiveCode = this.value;
            }
        });

        $("#input-authrization-device-password").off("focus")
        .on("focus", function () {
            if ($(this).hasClass("error")) {
                isValidatePassword = true;
            }
        })
        .off("keyup")
        .on("keyup", function () {
            if (isValidatePassword) {
                hideServerErrorMessage();
                validationPassword();
            }
        })
        .off("focusout")
        .on("focusout", function () {
            if ($("#device-error-message").css("display") != "block") {
                validationPassword();
            }
        })
        .off("keydown.moveToNext")
        .on("keydown.moveToNext", function (e) {
            if (e.which === 13) {
                $(this).blur();
                $('#button-finish').trigger("click");
            }
        });
    };

    window.InitialEmailAddressButton = function () {
        emailAddress = viewModel.EmailAddress;
        phoneNumber = viewModel.PhoneNumber;

        if (!emailAddress) {
            location.href = "/SelfService/LoginConsumer"
        }

        var emailAddressPrefix = viewModel.EmailAddress.substring(0, viewModel.EmailAddress.indexOf('@'));
        var emailAddressSuffix = viewModel.EmailAddress.substring(viewModel.EmailAddress.indexOf('@'));

        if (emailAddress != null && emailAddressPrefix.length > 2) {
            emailAddressPrefix = emailAddressPrefix.substring(0, 1) + "..." + emailAddressPrefix.substring(emailAddressPrefix.length - 1);
        }
        if (emailAddress != null) {
            $("#send-email-button").removeClass("visibility-hidden");
        }
        $('#button-send-email .button-text').html(getResourse('emailto') + emailAddressPrefix + emailAddressSuffix);
        if (!!phoneNumber) {

            $('#button-send-sms .button-text').html(getResourse('textto') + phoneNumber.substr(phoneNumber.length - 2, 2));
            $("#send-sms-button").removeClass("visibility-hidden");
        }
    }

    var sendEmailIsExcuting = false;
    function sendEmail() {
        var element = this;
        if (sendEmailIsExcuting) {
            return;
        }
        sendEmailIsExcuting = true;
        $(element).addClass("now-loading");
        BaseAjax({
            url: '/Home/SendEmailRegisterDevice',
            type: "POST",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "emailAddress": viewModel.EmailAddress, "isBrowser": true }),
            success: function (data) {
                goToAuthorizationDevice();
                sendEmailIsExcuting = false;
                $(element).removeClass("now-loading");
                trackDeviceAuthorizationActivationTotalLoads();
            },
            error: function (xhr, status) {
                $(element).removeClass("now-loading");
                sendEmailIsExcuting = false;
                try {
                    if (!isJson(xhr.responseText)) {
                        showPopUpMessage(xhr.responseText);
                    } else if (!isJson(JSON.parse(xhr.responseText).Message)) {
                        showPopUpMessage(JSON.parse(xhr.responseText).Message);
                    } else if (!isJson(JSON.parse(JSON.parse(xhr.responseText).Message).reason)) {
                        showPopUpMessage(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                    } else {
                        showPopUpMessage(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                    }
                } catch (e) {
                    if (xhr && xhr.responseText) {
                        showPopUpMessage(xhr.responseText);
                    }
                }
            }
        });

        var trackEmailButtonTotalClicks = trackEvent;
        trackEmailButtonTotalClicks("Email Code");
        trackBeforeSendEmailTimeOnPage();
    }

    function trackDeviceAuthorizationActivationTotalLoads() {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.DeviceAuthorizationActivation,
            eventAction: T.ActionEnum.ScreenView,
            eventLabel: "Device Authorization Activation",
            eventPage: T.PageEnum.DeviceAuthorizationActivation,
            nonInteraction: true
        });
    }

    var sendSmsIsExcuting = false;
    function sendSMS() {
        var element = this;
        if (sendSmsIsExcuting) {
            return;
        }
        sendSmsIsExcuting = true;
        $(element).addClass("now-loading");
        BaseAjax({
            url: '/Home/SelfServiceSendReAuthorizationDeviceMessageForWeb',
            type: "POST",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "emailAddress": viewModel.EmailAddress, "phoneNumber": phoneNumber }),
            success: function (data) {
                goToAuthorizationDevice();
                sendSmsIsExcuting = false;
                $(element).removeClass("now-loading");
            },
            error: function (xhr, status) {
                sendSmsIsExcuting = false;
                try {
                    if (!isJson(xhr.responseText)) {
                        showPopUpMessage(xhr.responseText);
                    } else if (!isJson(JSON.parse(xhr.responseText).Message)) {
                        showPopUpMessage(JSON.parse(xhr.responseText).Message);
                    } else if (!isJson(JSON.parse(JSON.parse(xhr.responseText).Message).reason)) {
                        showPopUpMessage(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                    } else {
                        showPopUpMessage(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                    }
                } catch (e) {
                    if (xhr && xhr.responseText) {
                        showPopUpMessage(xhr.responseText);
                    }
                }
                $(element).removeClass("now-loading");
            }
        });

        var trackSMSButtonTotalClicks = trackEvent;
        trackSMSButtonTotalClicks("SMS Code");

        trackDeviceAuthorizationActivationTotalLoads();
        trackPartialTimeOnPage("Send Text Button");
    }

    function trackEvent(eventLabel) {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.DeviceAuthorization,
            eventAction: T.ActionEnum.ButtonClick,
            eventLabel: eventLabel,
            eventPage: T.PageEnum.DeviceAuthorization
        });
    }

    function trackDeviceAuthorizationActivationEvent(eventLabel) {
        T.trackEvent({
            sendType: T.GA + T.MP,
            eventCategory: T.CategoryEnum.DeviceAuthorizationActivation,
            eventAction: T.ActionEnum.ButtonClick,
            eventLabel: eventLabel,
            eventPage: T.PageEnum.DeviceAuthorizationActivation
        });
    }

    function showPopUpMessage(message) {
        $("#NotificationWithActionCaption").text("Error");
        $("#NotificationWithActionMessage").text(message);
        $("#NotificationWithActionConfirm").text('Login');
        $("#NotificationWithActionConfirm").off("click").on("click", function () {
            $("#modal-notification-with-action").modal('close');
            location.href = "/SelfService/LoginConsumer";
        });

        $('#modal-notification-with-action .close-reveal-modal').off('click').on('click', function () {
            $("#modal-notification-with-action").modal('close');
        });
        $("#modal-notification-with-action").modal('open');
    }

    function goToAuthorizationDevice() {
        $("#div-send-email").hide();
        $("#div-input-validation-code").show();
        $("#input-authrization-device-password").on("keydown", function (e) {
            if ($("#input-authrization-device-active-code").val() && $("#input-authrization-device-password").val() && e.which == 13) {
                viewModel.ActiveCode = $("#input-authrization-device-active-code").val();
                viewModel.Password = $("#input-authrization-device-password").val();

                authorizationDevice($("#button-finish"));
            }
        });

        inputNumber();

        isValidateActiveCode = false;
        isValidatePassword = false;
        hideCodeMessage();
        hidePasswordMessage();
        hideServerErrorMessage();

        trackErrorMessage = T.generateErrorMessageTrack(T.CategoryEnum.DeviceAuthorizationActivation, T.PageEnum.DeviceAuthorizationActivation);
    }

    function goToAuthorizationDeviceActivation() {
        goToAuthorizationDevice();

        var trackHaveAlreadyLinkTotalClicks = trackEvent;
        trackHaveAlreadyLinkTotalClicks("Already Have a Code");
        trackBeforeAlreadyCodeTimeOnPage();
    }

    function validationCode() {
        var validationCode = $("#input-authrization-device-active-code").val();
        if (!validationCode) {
            showCodeMessage(getResourse('coderequired'));
        } else {
            hideCodeMessage();
            return true;
        }

        return false;
    }

    function validationPassword() {
        var password = $("#input-authrization-device-password").val();
        if (!password) {
            showPasswordMessage(getResourse('passwordrequired'));
        } else {
            hidePasswordMessage();
            return true;
        }

        return false;
    }

    var isExcuting = false;
    var isValidCode = false;
    var isValidPassword = false;

    function triggerAuthorizationDevice(e) {
        if (e.which == 13) {
            authorizationDevice();
            return false;
        }
    }

    function authorizationDevice() {
        var element = "#button-finish";
        if ($("#device-error-message").css("display") == "block") return;

        isValidCode = validationCode();
        isValidPassword = validationPassword();
        if (isValidCode && isValidPassword) {
            if (isExcuting) {
                return;
            }
            isExcuting = true;
            var timeZone = new Date().getTimezoneOffset();

            viewModel.Password = $("#input-authrization-device-password").val();
            viewModel.ActiveCode = $("#input-authrization-device-active-code").val();
            viewModel.IsBrowser = "true";

            var previewTransaction = JSON.parse(localStorage && localStorage.getItem("PreviewSendMoneyTransaction"));

            $(element).addClass("now-loading");
            BaseAjax({
                url: "/Home/AuthorizationDevice",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                beforeSend: function (request) {
                    request.setRequestHeader("TimeZone", timeZone);
                },
                data: JSON.stringify({ 'authenticationModel': viewModel, 'previewSendMoneyTransactionModel': previewTransaction }),
                success: function (data) {
                    try {
                        //Data capture device info.
                        $.DeviceInfo.CheckDeviceInfo(viewModel.EmailAddress);

                        sessionStorage.setItem("IsBrowser", "true");
                        sessionStorage.setItem("DashboardFromPage", "Authorization");

                        var internalHash = localStorage.getItem("InternalHash");
                        var marketingCampaignActivity = JSON.parse(localStorage && localStorage.getItem("MarketingCampaignActivity"));
                        var refereeActivityId = marketingCampaignActivity && marketingCampaignActivity.RefereeActivityId;

                        localStorage.removeItem("InternalHash");
                        localStorage.removeItem("MarketingCampaignActivity");
                        localStorage.removeItem("ReferralUrl");

                        if (!!internalHash && !!refereeActivityId) {
                            location.href = "/SelfService/ReferralLandingConsumer";
                        } else {
                            location.href = "/SelfService/CustomerDashboard";
                        }
                    }
                    catch (e) {
                        console.log(e.message);
                    }
                },
                error: function (xhr, status) {
                    $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.DeviceReauthorization, false, viewModel.EmailAddress);
                    isExcuting = false;
                    try {
                        if (!isJson(xhr.responseText)) {
                            showErrorMessage(xhr.responseText);
                        } else if (!isJson(JSON.parse(xhr.responseText).Message)) {
                            if (JSON.parse(xhr.responseText).ReturnCode && JSON.parse(xhr.responseText).ReturnCode == -876) {
                                showErrorMessage(getResourse('systemerror'), 'systemerror');
                            }
                            if (JSON.parse(xhr.responseText).ReturnCode && JSON.parse(xhr.responseText).ReturnCode == -877) {
                                showErrorMessage(getResourse('commonerror'), 'commonerror');
                            }
                            else {
                                showErrorMessage(JSON.parse(xhr.responseText).Message);
                            }
                        } else if (!isJson(JSON.parse(JSON.parse(xhr.responseText).Message).reason)) {
                            var resultCode = JSON.parse(JSON.parse(xhr.responseText).Message).exceptionCode;
                            if (resultCode == -463) {
                                passwordInvalidTime = getPasswordInvalidTime(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                                showErrorMessage(String.format(getResourse('passwordinvalid'), passwordInvalidTime), 'passwordinvalid');
                            }
                            else if (resultCode == -472) {
                                showErrorMessage(getResourse('accountlockederror'), 'accountlockederror');
                            }
                            else if (resultCode == -436) {
                                showErrorMessage(getResourse('registercodeinvalid'), 'registercodeinvalid');
                            }
                            else if (resultCode == -467) {
                                showErrorMessage(getResourse('accountfrozen'), 'accountfrozen');
                            }
                            else {
                                showErrorMessage(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                            }
                            
                            if (resultCode == -447) {
                                $.DataCapture.LogUserActivity($.DataCapture.CardHolderActivityType.PasswordLock, true, viewModel.EmailAddress, "L", "");
                            }
                        } else {
                            showErrorMessage(JSON.parse(JSON.parse(xhr.responseText).Message).reason);
                        }
                    } catch (e) {
                        if (xhr && xhr.responseText) {
                            showErrorMessage(xhr.responseText);
                        }
                    }
                    $(element).removeClass("now-loading");
                }
            }, element)
        }

        var trackFinishButtonTotalClicks = trackDeviceAuthorizationActivationEvent;
        trackFinishButtonTotalClicks("Finish");
        trackPartialTimeOnPage("Finish");
    }

    function isJson(content) {
        try {
            JSON.parse(content);
            return true;
        } catch (e) {
            return false;
        }
    }


    function showCodeMessage(message) {
        $("#input-authrization-device-active-code").addClass('error');
        $("#authrization-device-active-code-error-message").text(message);
        $("#authrization-device-active-code-error-message").show();

        trackErrorMessage(message);
    }

    function hideCodeMessage() {
        $("#input-authrization-device-active-code").removeClass('error');
        $("#authrization-device-active-code-error-message").hide();

    }

    function showPasswordMessage(message) {
        $("#input-authrization-device-password").addClass('error');
        $("#authrization-device-password-error-message").text(message);
        $("#authrization-device-password-error-message").show();

        trackErrorMessage(message);
    }

    function hidePasswordMessage() {
        $("#input-authrization-device-password").removeClass('error');
        $("#authrization-device-password-error-message").hide();
    }

    function showErrorMessage(message, messageKey) {
        $("#input-authrization-device-active-code").addClass('error');
        $("#input-authrization-device-password").addClass('error');
        $("#device-error-message").text(message);
        document.getElementById("device-error-message").setAttribute("data-language", messageKey);
        $("#device-error-message").show();

        trackErrorMessage(message, true);
    }

    function hideErrorMessage() {
        $("#input-authrization-device-active-code").removeClass('error');
        $("#input-authrization-device-password").removeClass('error');
        $("#device-error-message").hide();
    }

    function hideServerErrorMessage() {
        if ($("#device-error-message").css("display") == "block") {
            hideErrorMessage();
        }
    }

    function showSendCodeTypePage() {
        $("#input-authrization-device-active-code").val("");
        $("#input-authrization-device-password").val("");
        $("#div-input-validation-code").hide();
        $("#div-send-email").show();

        var trackResendCodeTotalClicks = trackDeviceAuthorizationActivationEvent;
        trackResendCodeTotalClicks("Resend Code");
        trackPartialTimeOnPage("Resend Code");
    }

    function isKeyPressInArray(keyCode, alphaArray) {
        var result = false;

        var keyChar = String.fromCharCode(keyCode).toUpperCase();

        for (var index in alphaArray) {
            if (keyChar == alphaArray[index].toUpperCase()) {
                result = true;
            }
        }

        return result;
    }

    function isKeyPressAlpha(keyCode) {
        return (keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122);  //a-zA-Z
    }

    function isKeyPressPunctuationMark(keyCode) {
        return (keyCode >= 32 && keyCode <= 47)
            || (keyCode >= 58 && keyCode <= 64)
            || (keyCode >= 91 && keyCode <= 96)
            || (keyCode >= 123 && keyCode <= 126);
    }

    function getClipboardContent(event) {
        if (window.clipboardData) {
            return window.clipboardData.getData('Text');
        }
        else {
            return event.originalEvent.clipboardData.getData('Text');
        }
    }

    function inputNumber() {
        $("input[type=tel]").each(function () {
            var tempInput = $(this);

            tempInput.off('keypress.number');
            tempInput.on('keypress.number', function (event) {
                if (tempInput.attr('amount') == undefined) {
                    var keyCode = event.which;
                    if (event.ctrlKey == true && isKeyPressInArray(keyCode, new Array('C', 'V', 'X', 'Z', 'Y'))) {
                        return true;
                    }
                    else if (isKeyPressAlpha(keyCode) || isKeyPressPunctuationMark(keyCode)) {
                        return false;
                    }
                }
            });

            tempInput.off('paste.number');
            tempInput.on('paste.number', function (e) {
                var clipboardContent = getClipboardContent(e);
                var selectionStart = tempInput[0].selectionStart;
                var selectionEnd = tempInput[0].selectionEnd;
                var selectionLength = selectionEnd - selectionStart;
                var maxLength = parseInt(isNaN(tempInput.attr('maxlength')) ? '2147483647' : tempInput.attr('maxlength'));
                var tempVal = tempInput.val();

                if (tempVal.length - selectionLength + clipboardContent.length > maxLength) {
                    clipboardContent = clipboardContent.substr(0, maxLength - (tempVal.length - selectionLength));
                }

                tempVal = tempVal.substr(0, selectionStart) + clipboardContent + tempVal.substr(selectionEnd);

                var reg = new RegExp(/[^(0-9)]/g);
                if (tempInput.attr('amount') == "") {
                    reg = new RegExp(/[^(0-9|.)]/g);
                    if (tempVal.indexOf('.') == 0 || tempVal.indexOf(".") != tempVal.lastIndexOf(".")) {// contains more then one dot or the dot is at the beginning.
                        return false;
                    }
                }

                if (reg.test(clipboardContent)) {
                    return false;
                }
            });
        });
    }
})(window);