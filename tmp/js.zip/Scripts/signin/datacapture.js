﻿/* 
 * 1. data capture before login 
 * 2. device info: register device info, update device info.
 */
(function () {
    /***********************1. data capture before login  start**********************/
	function DataCaptureModel() {
		var self = this;
		self.dataCaptureServerUrl = '';

		self.InitDataCaptureSetting = function(dataCaptureServerUrl) {
			self.dataCaptureServerUrl = dataCaptureServerUrl;
			self.GetDataCaptureSetting();
		}

		self.GetDataCaptureSetting = function(async) {
			try {
			    if (localStorage.getItem("DataCaptureConfigure") && JSON.parse(localStorage.getItem("DataCaptureConfigure")).IsEnabled) {
					return;
				}

				if (async == null) {
					async = true;
				}

				var ajaxUrl = self.dataCaptureServerUrl + "/DataCapture/GetClientSettings";
				var jsonData = JSON.stringify({
					"ClientIdentity": "SELFSERVICE"
				});

				$.ajax({
					url: ajaxUrl,
					type: "POST",
					async: async,
					contentType: "application/json",
					data: jsonData,
					dataType: "json",
					success: function (response) {
					    try {
					        localStorage.setItem("DataCaptureConfigure", JSON.stringify(response));
					    }
					    catch (e)
					    {
					        console.log(e.message);
					    }
					},
					error: function (xhr, status) {
					    try {
					        localStorage.setItem("DataCaptureConfigure", '{"IsEnabled":false}');
					    }
					    catch (e) {
					        console.log(e.message);
					    }
					}
				})
			} catch (e) {
				console.error(e.name);
			}
		}

	    /********Log user activity start ************/

		self.LogUserActivity = function (actionCode, isSuccessful, emailAddress, /*option*/ memberStatus, /*option*/ memberLevelId, /*option*/ signupPageLoadTime, /*option*/ signupEmailActionTime) {
			var informationObject = {
				actionCode: actionCode,
				isSuccessful: isSuccessful,
				emailAddress: emailAddress,
				memberStatus: memberStatus,
				memberLevelId: memberLevelId,
				signupPageLoadTime: signupPageLoadTime,
				signupEmailActionTime: signupEmailActionTime
			};

			PostLogUserActivityRequest.apply(informationObject, [true]);
		}

		self.LogUserActivityBySync = function (actionCode, isSuccessful, emailAddress, /*option*/ memberStatus, /*option*/ memberLevelId, /*optional*/phonevalidationModel, /*option*/ signupPageLoadTime, /*option*/ signupEmailActionTime) {
			var informationObject = {
				actionCode: actionCode,
				isSuccessful: isSuccessful,
				emailAddress: emailAddress,
				memberStatus: memberStatus,
				memberLevelId: memberLevelId,
				signupPageLoadTime: signupPageLoadTime,
				signupEmailActionTime: signupEmailActionTime
			};

			PostLogUserActivityRequest.apply(informationObject, [false, phonevalidationModel])
		}

		self.CardHolderActivityType = {
			DeviceReauthorization: 8,
			EmailAuthorization: 9,
			Login: 10,
			PasswordLock: 12,
			PasswordReset: 13,
			SignUp: 20,
			SendEmailToResetPassword: 41
		}

	    /********Log user activity end ************/

	    /********Log onbording carousel start******/

		self.InitialRequestIdForCarouselPage = function () {
		    /*This is check that carousel page navigate by clicking back button in fee calculator screen.
             * If so, it's will not generate new guid.
             */
		    if ($.DataCaptureStorage.GetSessionStorage('FeeCalculatorBackToCarousel')) {
		        return;
		    }

		    /*Initialize guid for carousel request id*/
		    $.DataCaptureStorage.RemoveLocalStorage("CarouselRequestId");
		    $.DataCaptureStorage.SetLocalStorage("CarouselRequestId", NewGuid());
		}

		self.InitialOnboardingCarouselData = function (data) {
		    if (Object.prototype.toString.call(data).slice(8, -1) !== 'Array') {
		        console.error("The parameter is not Array, current data's type is" + typeof data);
		        return;
		    }

		    self.OnboardingCarouselData.PagesData = data;
		}

		self.OnboardingCarouselData = {
		    LoadWebPageCarouselId: "Load_carousel_page_in_web",
		    PagesData: [],
		    GetCurrrentPageData: function (itemIndex /*item index in owl*/) {
		        var self = this;

		        if (this.PagesData === undefined) {
		            console.error('Page data is error data!');
		            return;
		        }

		        var data = this.PagesData.filter(function (value) {
		            return value.Position == (itemIndex + 1);
		        });

		        if (data.length !== 1) {
		            console.log("Get currentPageData failed!");
		        }

		        return data[0];
		    }
		};

	    /*Capture button click(login, signup, fee calculate) in carousel page.*/
		self.CarouselConversion = function (carouselActionTypeId) {
		    if ($.DataCaptureStorage.GetSessionStorage("CarouselPageId")) {
		        self.LogCarouselAction($.DataCaptureStorage.GetSessionStorage("CarouselPageId"), carouselActionTypeId);
                
		       /* 
                * Carousel navigate to login/signup page, remove "CarouselRequestId", "CarouselPageId", "FeeCalculatorBackToCarousel".
                * If Carousel navigate to Fee Calculator, don't remove the flag until user click "Get Started" button.
                */
		        if (carouselActionTypeId !== self.CarouselActionType.ClickOnFeeCalculatorButton) {
		            self.ResetFlagForCarousel();
		        } 
		    }
		};

		self.ResetFlagForCarousel = function () {
		    $.DataCaptureStorage.RemoveLocalStorage("CarouselRequestId");
		    $.DataCaptureStorage.RemoveSessionStorage("CarouselPageId");
		    $.DataCaptureStorage.RemoveSessionStorage("FeeCalculatorBackToCarousel");
		};

		self.CarouselActionType = {
		    StartToLoadCarousel: 1,
            EndToLoadCarousel: 2,
		    LeftSwipe: 3,
		    RightSwipe: 4,
		    ClickOnSignupButton: 5,
		    ClickOnLoginButton: 6,
		    ClickOnFeeCalculatorButton: 7,
		    ClickBackButtonOnTheFeeCalculatorScreen: 8,
		    LoadCarouselPage: 9,
            ChangeLanguageCode: 10
		}

		self.CacheLoadCarouselTime = {};

		self.LogCarouselAction = function (carouselId, actionCode, /*Optional*/ languageCode) {
		    try {
		        if (!localStorage.getItem("DataCaptureConfigure")) {
		            $.DataCapture.GetDataCaptureSetting(false);
		        }

		        if ((localStorage.getItem("DataCaptureConfigure") && JSON.parse(localStorage.getItem("DataCaptureConfigure")).IsEnabled)) {
		            var carouselActionObject = new Object();
		            carouselActionObject.RequestId = localStorage.getItem("CarouselRequestId");
		            carouselActionObject.CarouselId = carouselId;
		            carouselActionObject.ActionTime = GetOperationTime();
		            carouselActionObject.ActionCode = actionCode;
		            carouselActionObject.LanguageCode = languageCode ? languageCode : null;
		            carouselActionObject.TimeSpan = null;

		            if (actionCode == 1) {
		                self.CacheLoadCarouselTime[carouselActionObject.RequestId] = carouselActionObject.ActionTime;
		            } else if (actionCode == 2) {
		                carouselActionObject.TimeSpan = MillisecondToDate((new Date(carouselActionObject.ActionTime).getTime() - new Date(self.CacheLoadCarouselTime[carouselActionObject.RequestId]).getTime()));
		                self.CacheLoadCarouselTime = {};
                    } 

		            $.ajax({
		                url: $.DataCapture.dataCaptureServerUrl + '/DataCapture/LogCarouselAction',
		                type: "POST",
		                contentType: "application/json",
		                data: JSON.stringify(carouselActionObject),
		                dataType: "json",
		                success: function (data) {
		                    //Success. To do nothing.
		                },
		                error: function (xhr, status) {
		                    //Fail. To do nothing.
		                }
		            })
		        }
		    } catch (e) {
		        console.error(e.name);
		    }
		}

	    /********Log onbording carousel end******/

	    /********Log Fee Calculation start*******/

		self.LogFeeCalculation = function (feeCalculationModel) {
		    if (typeof feeCalculationModel !== "object") {
		        console.error("The arguments is not object, current the type of arguments is:" + typeof feeCalculationModel);
		        return;
		    }


            /* Add emailaddress, calcula*/
		    feeCalculationModel.EquipmentId = GetCookieEquipmentId();
		    feeCalculationModel.GeoPosition = GetCookie("Device_Geo_Position");
		    feeCalculationModel.ServiceProvider = GetCookie("Device_Service_Provider");
		    feeCalculationModel.GeoAddress = GetCookie("Device_Geo_Position_Address");
            /*Add fee calculation time.*/
		    feeCalculationModel.CalculationTime = GetOperationTime();
		    feeCalculationModel.BuilderNumber = $.DeviceInfo.BuilderNumber;

		    try {
		        if (!localStorage.getItem("DataCaptureConfigure")) {
		            $.DataCapture.GetDataCaptureSetting(false);
		        }

		        if ((localStorage.getItem("DataCaptureConfigure") && JSON.parse(localStorage.getItem("DataCaptureConfigure")).IsEnabled)) {
		            
		            $.ajax({
		                url: $.DataCapture.dataCaptureServerUrl + '/DataCapture/LogFeeCalculation',
		                type: "POST",
		                contentType: "application/json",
		                data: JSON.stringify(feeCalculationModel),
		                dataType: "json",
		                success: function (data) {
		                    //Success. To do nothing.
		                },
		                error: function (xhr, status) {
		                    //Fail. To do nothing.
		                }
		            })
		        }
		    } catch (e) {
		        console.error(e.message);
		    }

		}

	    /********Log Fee Calculation end*********/

		self.DatePatternFormat = (function() {
			Date.prototype.pattern = function(fmt) {
				var o = {
					"M+": this.getMonth() + 1,
					"d+": this.getDate(),
					"h+": this.getHours() % 12 == 0 ? 12 : this.getHours() % 12,
					"H+": this.getHours(),
					"m+": this.getMinutes(),
					"s+": this.getSeconds(),
					"q+": Math.floor((this.getMonth() + 3) / 3),
					"S": this.getMilliseconds()
				};
				if (/(y+)/.test(fmt)) {
					fmt = fmt.replace(/(y+)/, (this.getFullYear() + "").substr(4 - /(y+)/.exec(fmt)[0].length));
				}
				if (/(E+)/.test(fmt)) {
					fmt = fmt.replace(/(E+)/, ((/(E+)/.exec(fmt)[0].length > 1) ? (/(E+)/.exec(fmt)[0].length > 2 ? "/u661f/u671f" : "/u5468") : "") + week[this.getDay() + ""]);
				}
				for (var k in o) {
					var reg = new RegExp("(" + k + ")");
					if (reg.test(fmt)) {
						fmt = fmt.replace(reg.exec(fmt)[0], (reg.exec(fmt)[0].length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
					}
				}
				return fmt;
			};
		})();

		self.DateOffsetFormat = (function() {
			Date.prototype.timeZoneOffSet = function() {
				var offSet = this.getTimezoneOffset() / 60;
				var offSetMin = offSet - Math.floor(offSet);

				return (offSet < 0 ? " +" : " -") + Math.floor(Math.abs(offSet)) + (offSetMin > 0 ? ":" + offSetMin * 60 : "");
			};
		})();
	}

	function PostLogUserActivityRequest(async, phonevalidationModel) {
		try {
			if (!localStorage.getItem("DataCaptureConfigure")) {
				$.DataCapture.GetDataCaptureSetting(false);
			}

			if ((localStorage.getItem("DataCaptureConfigure") && JSON.parse(localStorage.getItem("DataCaptureConfigure")).IsEnabled)) {
				var activityInfo = new Object();
				activityInfo.EmailAddress = this.emailAddress;
				activityInfo.MemberStatus = this.isSuccessful ? this.memberStatus : '';
				activityInfo.MemberInfoId = this.isSuccessful ? this.memberLevelId : '';
				activityInfo.EquipmentId = this.isSuccessful ? GetCookieEquipmentId() : -1;
				activityInfo.Message = "";
				activityInfo.OperationTime = GetOperationTime();
				activityInfo.ActionCode = this.actionCode;
				activityInfo.IsSuccessful = this.isSuccessful;
				activityInfo.GeoPosition = GetCookie("Device_Geo_Position");
				activityInfo.ServiceProvider = GetCookie("Device_Service_Provider");
				activityInfo.SignupPageLoadTime = this.signupPageLoadTime;
				activityInfo.SignupEmailActionTime = this.signupEmailActionTime;
				activityInfo.BuilderNumber = $.DeviceInfo.BuilderNumber;

				if (async == false && this.actionCode == $.DataCapture.CardHolderActivityType.SignUp) {
				    activityInfo.InternalHash = localStorage && localStorage.getItem('InternalHash');
				}

				if (phonevalidationModel != undefined) {
				    activityInfo.PhoneValidationActivity = phonevalidationModel;
				}

				$.ajax({
					url: $.DataCapture.dataCaptureServerUrl + '/DataCapture/LogUserActivity',
					type: "POST",
					async: async,
					contentType: "application/json",
					data: JSON.stringify(activityInfo),
					dataType: "json",
					success: function(data) {
						//Success. To do nothing.
					},
					error: function(xhr, status) {
						//Fail. To do nothing.
					}
				})
			}
		} catch (e) {
			console.error(e.name);
		}
	}

	function GetOperationTime() {
		var date = new Date();
		return date.pattern("yyyy-MM-dd HH:mm:ss.S") + " " + date.timeZoneOffSet();
	};

	function GetCookie(name) {
	    var cookie_start = document.cookie.indexOf(name + '=');
	    var cookie_end = document.cookie.indexOf(";", cookie_start);
	    return cookie_start == -1 ? '' : unescape(document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length)));
	};

	function GetCookieEquipmentId() {
	    var cookieValueToInt = parseInt(GetCookie("EquipmentId"));

	    if (typeof cookieValueToInt === "number" && cookieValueToInt === cookieValueToInt) {
	        return cookieValueToInt;
	    } else {
	        return -1;
	    }
	};

	function NewGuid() {
	    var guid = "";
	    for (var i = 1; i <= 32; i++) {
	        var n = Math.floor(Math.random() * 16.0).toString(16);
	        guid += n;
	        if ((i == 8) || (i == 12) || (i == 16) || (i == 20))
	            guid += "-";
	    }
	    return guid;
	};

	function MillisecondToDate(msd) {
	    var time = Math.abs(parseFloat(msd) / 1000);
	    return time;
	}

	window.$.DataCapture = new DataCaptureModel();

	window.$.DataCaptureStorage = {
	    GetLocalStorage: function (key) {
	        try {
	            return window.localStorage.getItem(key);
	        } catch (e) {
	            console.error(e.message);
	            return false;
	        }
	    },
	    SetLocalStorage: function (key, val) {
	        try {
	            window.localStorage.setItem(key, val);
	        } catch (e) {
	            console.error(e.message);
	        }
	    },
	    RemoveLocalStorage: function (key) {
	        try {
	            window.localStorage.removeItem(key);
	        } catch (e) {
	            console.error(e.message);
	        }
	    },
	    GetSessionStorage: function (key) {
	        try {
	            return window.sessionStorage.getItem(key);
	        } catch (e) {
	            console.error(e.message);
	            return false;
	        }
	    },
	    SetSessionStorage: function (key, val) {
	        try {
	            window.sessionStorage.setItem(key, val);
	        } catch (e) {
	            console.error(e.message);
	        }
	    },
	    RemoveSessionStorage: function (key) {
	        try {
	            window.sessionStorage.removeItem(key);
	        } catch (e) {
	            console.error(e.message);
	        }
	    }
	}
    /***********************1. data capture before login  end**********************/


    /***********************2. device info  start**********************/
	function DeviceInfoModel() {
	    var self = this;

	    self.BuilderNumber = "";

	    self.SetBuilderNumber = function (buildNumberValue) {
	        self.BuilderNumber = buildNumberValue;
	    }

	    self.CheckDeviceInfo = function (emailAddress) {
	        if (HasEquipmentId() && HasBrowserUniqueId()) {
	            if (IsDeviceInfoChange()) {
	                UpgradeBrowser(emailAddress);
	            }
	        } else {
	            RegisterBrowser(emailAddress);
	        }
	    };

	    function HasEquipmentId() {
	        var equipmentId = parseInt(GetCookie("EquipmentId"));

	        return typeof equipmentId == 'number' && equipmentId % 1 == 0;
	    };

	    function HasBrowserUniqueId() {
	        var applicationId = localStorage && localStorage.getItem("ApplicationId");
	        var uniqueId = localStorage && localStorage.getItem("UniqueId");

	        return applicationId != null && uniqueId != null;
	    }

	    function IsDeviceInfoChange() {
	        var userAgentInfoOriginal = localStorage.getItem('UserAgent');
	        var buildNumberOrigianl = localStorage.getItem('BuildNumber');
	        var languageCode = localStorage.getItem('LanguageCode');

	        return window.navigator.userAgent != userAgentInfoOriginal ||
                   self.BuilderNumber != buildNumberOrigianl ||
                   GetCookie('Language') != languageCode;
	    }

	    function RegisterBrowser(emailAddress) {
	        var deviceInfo = {
	            emailAddress: emailAddress,
	            activeCode: GetCookie('ValidationCode_' + emailAddress),
                languageCode: localStorage.getItem('LanguageCode')
	        };

	        $.ajax({
	            url: '/Home/RegisterBrowser',
	            type: "POST",
	            async: false,
	            contentType: "application/json",
	            data: JSON.stringify(deviceInfo),
	            dataType: "json",
	            success: function (data) {
	                CacheDeviceInfo(data.applicationId, data.uniqueId);
	            },
	            error: function (xhr, status) {
	                //Fail. To do nothing.
	            }
	        })
	    }

	    function UpgradeBrowser(emailAddress) {
	        var deviceInfo = {
	            emailAddress: emailAddress,
	            activeCode: GetCookie('ValidationCode_' + emailAddress),
	            applicationId: localStorage.getItem('ApplicationId'),
	            uniqueId: localStorage.getItem('UniqueId'),
	            languageCode: localStorage.getItem('LanguageCode')
	        };

	        $.ajax({
	            url: '/Home/RegisterBrowser',
	            type: "POST",
	            async: false,
	            contentType: "application/json",
	            data: JSON.stringify(deviceInfo),
	            dataType: "json",
	            success: function (data) {
	               CacheDeviceInfo(data.applicationId, data.uniqueId);
	            },
	            error: function (xhr, status) {
	                //Fail. To do nothing.
	            }
	        })
	    }

	    function CacheDeviceInfo(applicationId, uniqueId) {
	        localStorage.setItem('UserAgent', window.navigator.userAgent);
	        localStorage.setItem('BuildNumber', self.BuilderNumber);
	        localStorage.setItem('LanguageCode', GetCookie('Language'));
	        localStorage.setItem('ApplicationId', applicationId);
	        localStorage.setItem('UniqueId', uniqueId);
	    }
	}

	window.$.DeviceInfo = new DeviceInfoModel();

    /***********************2. device info  end**********************/

}(window));