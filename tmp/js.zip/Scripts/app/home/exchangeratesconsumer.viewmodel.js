﻿define(['knockout', 'ClientScript', 'app', paths['common-strings']], function (ko, cs, app, commonstrings) {
    function ExchangeRatesConsumerViewModel() {
        var self = this,
            timerHandler = 0;
        self.isReady = ko.observable(false);
        self.ExchangeRateSearchText = ko.observable("");
        self.SortedExchangeRateModels = ko.observable(null);
        self.title = commonstrings.viewmodeltitle.exchangerates;
        self.init = function () {

        }

        self.getExchangeRates = function () {
            cs.BaseAjax({
                url: '/Customers/GetAllExchangeRates',
                type: "POST",
                dataType: "json",
                contentType: "application/json"
            }).done(function (data) {
                ko.mapping.fromJS(data, {}, self);
                ko.mapping.fromJS(data.ExchangeRateModels, {}, self.SortedExchangeRateModels);
            });
        }

        self.dispose = function () { };

        self.afterRender = function () {
        };

        self.AutoSearchExchangeRates = function (value) {
            self.ExchangeRateSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.ExchangeRateSearchText(value);
            }
            else if (value.trim() != "" && value.length < 1) {
                isSearch = false;
            }

            if (isSearch) {
                $("#ExchangeRateId").addClass("now-loading");
                timerHandler = setTimeout(function () { self.SearchExchangeRates(); }, 500);
            }
        }

        self.SearchExchangeRatesManualClick = function () {
                $("#ExchangeRateId").addClass("now-loading");
                setTimeout(function () { self.SearchExchangeRates(); }, 500);
        }

        self.SearchExchangeRates = function () {
            try {
                if ($('#input-search-for-recipients').length < 1) {
                    return;
                }

                var searchText = $('#input-search-for-recipients').val().toUpperCase()
                var searchedExchangeRateModels = new Array();

                $.each(self.ExchangeRateModels(), function (i, exchangeRateModel) {
                    if (isMatchSearched(exchangeRateModel, searchText)) {
                        searchedExchangeRateModels.push(exchangeRateModel);
                    }
                });

                self.SortedExchangeRateModels(searchedExchangeRateModels);
            }
            catch (e) {

            }
            finally {
                $("#ExchangeRateId").removeClass("now-loading");
            }
        }

        function isMatchSearched(exchangeRateModel, searchText) {
            var isMatchSearchedText = exchangeRateModel && exchangeRateModel.CountryName().toUpperCase().indexOf(searchText) != -1 ||
                exchangeRateModel.CurrencyName().toUpperCase().indexOf(searchText) != -1 ||
                exchangeRateModel.ExchangeRate().toUpperCase().indexOf(searchText) != -1 ||
                searchText.trim() == "";

            return isMatchSearchedText;
        }
    }
    return new ExchangeRatesConsumerViewModel();
});