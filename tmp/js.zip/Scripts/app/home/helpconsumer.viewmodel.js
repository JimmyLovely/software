﻿define(['knockout', 'ClientScript', 'app', paths['common-strings']], function (ko, cs, app, commonstrings) {
    function HelpConsumerViewModel(app, dataModel) {
        var self = this;
        self.title = commonstrings.viewmodeltitle.help;
        self.isReady = ko.observable(false);

        self.init = function () { };

        self.dispose = function () { };

        self.controllers = {};

        self.afterRender = function () {
            cs.RemoveOpen();
        };

        self.Ready = function () {
            $("#input-search-for-recipients").on("keydown", function (e) {
                if (isKeyPressEnter(e.which)) {
                    self.SearchFAQs("#search-faqs");
                }
            });
        }

        self.SearchFAQs = function (element) {
            $(element).addClass("now-loading");
            clearSelection();

            var searchText = $('#input-search-for-recipients').val();
            if (searchText.length == 0) {
                $('.accordion-navigation').each(function (index, element) {
                    $(element).css("display", "block");
                });
                $(element).removeClass("now-loading");
                return false;
            }
            searchText = searchText.replace('\\', '\\\\');
            var regExp = new RegExp(searchText, 'ig');
            $('.accordion-navigation').each(function () {
                var text = $(this).find('.answer').text();
                newText = text.replace(regExp, '<span class="highlight">' + '$&' + '</span>');

                $(this).find('.answer').html(newText);

                var title = $(this).find('.left').text();
                var newTitle = title.replace(regExp, '<span class="highlight">' + '$&' + '</span>');
                $(this).find('.mod-header').html('<h3 class="left"><i class="entypo-icon-arrow-up"></i>' + newTitle + '</h3><span class="check"><i class="fi-check hide"></i></span>');

                if (text != newText || title != newTitle) {
                    $(this).find(".left").addClass("selected");
                    $(this).css("display", "block");
                } else {
                    $(this).css("display", "none");
                }
            });

            setTimeout(function () {
                $(element).removeClass("now-loading");
            }, 300);
        }

        function clearSelection() {
            $('.accordion-navigation').each(function () {
                $(this).find('.highlight').each(function () {
                    $(this).replaceWith($(this).html());
                });

                $(this).find(".left").removeClass("selected");
            });
        }

    }

    return new HelpConsumerViewModel();
});
