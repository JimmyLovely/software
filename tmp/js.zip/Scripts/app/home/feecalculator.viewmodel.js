define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'R', 'TrackEvent', 'Plugins'], function (ko, cs, app, dataModel, commonstrings, R, track) {

    function CurrencyModel() {
        this.Value = ko.observable("");
        this.Symbol = ko.observable('$');
    }

    function FeeCalculator() {
        var self = this,
            USA_CURRENCY_CODE = "USD",
            USA_COUNTRY_ID = 840;

        var timeHandler = 0;

        var AmountToSendValue = "0";
        var AmountToReceiveValue = "0";

        self.title = commonstrings.viewmodeltitle.feecalculator;
        self.AmountToSend = new CurrencyModel();
        self.AmountToBeDispensed = new CurrencyModel();
        self.AmountCollected = new CurrencyModel();
        self.TotalFee = new CurrencyModel();

        self.FromCurrency = '';
        self.FromCurrencyCode = ko.observable(USA_CURRENCY_CODE);
        self.ToCurrency = 0;
        self.ToCurrencyCode = ko.observable('');
        self.ToCountryImage = ko.observable();
        self.ExchangeRate = ko.observable('');
        self.CountryId = ko.observable();
        self.CountryName = ko.observable();
        self.NumberOfLocations = ko.observable();
        self.Countries = ko.observable();
        self.Country = ko.observable();
        self.NumberOfLocations = ko.observable();
        self.showPickupAndPayment = ko.observable(true);
        self.lastTypeIsSend = ko.observable(true);
        var continueLoading = true;

        //1: Credit Card
        //3: Bank Account  
        self.PaymentMethodTypeId = ko.observable(3);
        // 2: Calculate AmountToSend
        // 3: Calculate AmountToBeDispensed 
        self.CalculateCase = 3;
        self.original = { AmountToSend: "0.00", AmountToBeDispensed: "0.00" };

        self.init = function () {
            cs.RemoveOpen();
            initializePreviewFeeCalculatorInfoAfterLogin();
        }

        self.dispose = function () {
        };

        self.controllers = {
            '/': function () {
                app.isShowDemo = true;
            }
        };

        // Start appsflyer track event
        var trackFeeCalculatorTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP + track.AF,
                eventCategory: track.CategoryEnum.CalculatorScreenPost,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "CalculatorScreen",
                eventPage: track.PageEnum.CalculatorScreenPost,
                eventStructure: track.StructureEnum.ContentView,
                eventName: 'af_content_view_Calculator_Post'
            });
        }

        var trackTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.CalculatorScreenPost,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.CalculatorScreenPost
            });
        }

        var trackGetStartedTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP + track.AF,
                eventCategory: track.CategoryEnum.CalculatorScreenPost,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Get Started",
                eventPage: track.PageEnum.CalculatorScreenPost,
                amount: AmountToSendValue,
                eventStructure: track.StructureEnum.AddToCart,
                eventName: 'af_getstarted_Calculator_Post',
                price: AmountToSendValue,
                contentType: self.ToCurrencyCode(),
                currency: self.FromCurrencyCode()
            });
        }
        var trackCloseIconTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.CalculatorScreenPost,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Calculator Close",
                eventPage: track.PageEnum.CalculatorScreenPost
            });
        }
        // End appsflyer track event

        self.afterRender = function () {
            initAmountAttr();

            $('#select-country').click(function (event) {
                $("#country-select-dropdown").toggle();
                event.stopPropagation();
            });

            $(document).click(function () {
                $("#country-select-dropdown").hide();
            })

            if (self.AmountToSend && self.AmountToSend.Value() != 0) {
                $('#input-amount-send').prev('small').css('display', 'none');
                $('#input-amount-receive').prev('small').css('display', 'none');
            } else {
                /*Reset value*/
                resetFeeCalculateValue();
            }

            trackFeeCalculatorTotalLoads();
            trackTimeOnPage();
        }

        function resetFeeCalculateValue() {
            self.AmountToSend.Value("");
            self.AmountToBeDispensed.Value("");
            self.AmountCollected.Value("");
            self.TotalFee.Value("");
            AmountToSendValue = "0";
            AmountToReceiveValue = "0";
            self.original = { AmountToSend: "0.00", AmountToBeDispensed: "0.00" };
            $("#input-amount-send").val("");
            $("#input-amount-receive").val("");
            $(".fit-text-placeholder").show();
        }

        self.bindEventToAmount = function (element, isSend) {
            var element = $(element);
            var oldValue = element.val();
            element.off("input.attribute.amount");
            element.on("input.attribute.amount", function () {
                clearTimeout(timeHandler);
                oldValue = cs.LimitNumber(element, isSend, oldValue, self.ExchangeRate());
                self.amountChanged(element, isSend, oldValue);

                cs.addDisable('get-started');
                timeHandler = setTimeout(function () {
                    self.amountCalculate(isSend, element);
                }, 500);
            });
            element.off("focus.attribute.amount");
            element.on("focus.attribute.amount", function (e) {
                self.lastTypeIsSend(isSend);
                oldValue = cs.GetOriginalNumber(element.val());
            });
            if (cs.IsMobileDevice()) {
                if (isSend) {
                    if (!self.AmountToSend.Value()) {
                        self.AmountToSend.Value('0.00');
                    }
                } else {
                    if (!self.AmountToBeDispensed.Value()) {
                        self.AmountToBeDispensed.Value('0.00');
                    }
                }
            }
        }

        function suitFontSizeOfInput(transaction, isSend, value) {
            var amount = "-1";
            transaction.DominantControl = isSend ? 'AmountToBeSent' : 'AmountToBeReceived';
            amount = value;
            if (amount == null) {
                amount = "-1";
            }

            if (amount && parseFloat(cs.GetOriginalNumber(amount.toString())) > 0) {
                amount = parseFloat(cs.GetOriginalNumber(amount.toString()));
                if (transaction.DominantControl == "AmountToBeSent") {
                    //transaction().AmountToSend.Value(amount);
                    var result = 1.0 * amount * transaction.ExchangeRate();
                    if (!isNaN(result)) {
                        var amountToBeDispensed = cs.keepAmountDecimalPlaces(result);
                        transaction.AmountToBeDispensed.Value(amountToBeDispensed);

                        if ($("#input-amount-receive") && $("#input-amount-receive").length > 0) {
                            cs.fitTextAmountField($("#input-amount-receive"), amountToBeDispensed);
                        }
                    }
                } else {
                    //transaction().AmountToBeDispensed.Value(amount);
                    var result = 1.0 * amount / transaction.ExchangeRate();
                    if (!isNaN(result)) {
                        var sendToAmount = cs.keepAmountDecimalPlaces(result);
                        transaction.AmountToSend.Value(sendToAmount);
                        if ($("#input-amount-send") && $("#input-amount-send").length > 0) {
                            cs.fitTextAmountField($("#input-amount-send"), sendToAmount);
                        }
                    }
                }
            } else {
                if (value == "" || value == null || value == '0.00') {
                    //transaction().AmountToBeDispensed.Value(null);
                    //transaction().AmountToSend.Value();
                    if (cs.IsMobileDevice()) {
                        $("#input-amount-to-be-dispensed").val("0.00");
                        $("#receiver-amount-input").val("0.00");

                        $("#input-amount-to-send").val("0.00");
                        $("#send-amount-input").val("0.00");
                    } else {
                        $("#input-amount-to-be-dispensed").val("");
                        $("#receiver-amount-input").val("");

                        $("#input-amount-to-send").val("");
                        $("#send-amount-input").val("");
                    }
                }
            }
        }

        self.amountChanged = function (element, isAmountToSend, amount) {
            var rate = self.ExchangeRate(), result;


            if (isAmountToSend) {
                result = (1.0 * amount * rate).toFixed(2);
                if (cs.IsMobileDevice()) {
                    self.AmountToSend.Value(cs.getFormatFloat(amount));
                    self.AmountToBeDispensed.Value(cs.getFormatFloat(result));
                } else {
                    self.AmountToSend.Value(amount);
                    self.AmountToBeDispensed.Value(result);
                }
                AmountToSendValue = amount;
                AmountToReceiveValue = result;
            } else {
                result = (1.0 * amount / rate).toFixed(2);

                if (cs.IsMobileDevice()) {
                    self.AmountToSend.Value(cs.getFormatFloat(result));
                    self.AmountToBeDispensed.Value(cs.getFormatFloat(amount));
                } else {
                    self.AmountToSend.Value(result);
                    self.AmountToBeDispensed.Value(amount);
                }
                AmountToSendValue = result;
                AmountToReceiveValue = amount;
            }

            suitFontSizeOfInput(self, isAmountToSend, element.val());
            /*For value is 0*/
            if (self.AmountToSend.Value() == 0) {
                self.AmountCollected.Value(0);
                self.TotalFee.Value(0);
            }
        }

        self.amountCalculate = function (isAmountToSend, element) {
            self.CalculateCase = isAmountToSend ? 3 : 2;

            if (getAmountFloat(self.original.AmountToBeDispensed) != getAmountFloat(self.AmountToBeDispensed.Value()) ||
                 getAmountFloat(self.original.AmountToSend) != getAmountFloat(self.AmountToSend.Value())) {
                $.when(calculate('#virtualElement'))
                .always(function () {
                    cs.removeDisable('get-started');
                });

                if (isAmountToSend) {
                    self.original.AmountToBeDispensed = self.AmountToBeDispensed.Value();
                } else {
                    self.original.AmountToSend = self.AmountToSend.Value();
                }
            } else {
                cs.removeDisable('get-started');
            }
        }

        self.receiverCountryChanged = function (countryId, isUlElementSelect) {
            if (typeof isUlElementSelect != "boolean") {
                initCountrySelect(self.CountryId());
            } else {
                $("#country-select-dropdown").toggle();
                initCountrySelect(countryId);
            }

            if (self.lastTypeIsSend()) {
                var receiveFloatValue = 1.0 * (AmountToSendValue.replace(/,/g, ''));

                if (receiveFloatValue <= 0) {
                    return;
                }

                AmountToReceiveValue = getFormatFloat((receiveFloatValue * self.ExchangeRate()).toFixed(2));
                self.AmountToBeDispensed.Value(AmountToReceiveValue);
            } else {
                var sendFloatValue = 1.0 * (AmountToReceiveValue.replace(/,/g, ''));
                if (sendFloatValue <= 0) {
                    return;
                }

                AmountToSendValue = getFormatFloat((sendFloatValue / self.ExchangeRate()).toFixed(2));
                self.AmountToSend.Value(AmountToSendValue);
            }
            calculate();
        }

        self.paymentMethodChanged = function (element, isBankAccount) {
            self.PaymentMethodTypeId(isBankAccount ? 3 : 1);
            calculate();
        }

        function calculate(element, isNonDelay) {
            if (self.AmountToSend.Value() <= 0 && self.AmountToBeDispensed.Value() <= 0) {
                return $.Deferred().reject();
            }

            var previewTransactionModel = clone(self);
            delete previewTransactionModel.Countries;
            delete previewTransactionModel.Country;

            previewTransactionModel.ToCountryId = previewTransactionModel.CountryId;
            previewTransactionModel.FromCurrencyId = previewTransactionModel.FromCurrency;
            previewTransactionModel.ToCurrencyId = previewTransactionModel.ToCurrency;
            previewTransactionModel.AmountToSend.Value = AmountToSendValue;
            previewTransactionModel.AmountToBeDispensed.Value = AmountToReceiveValue;

            var deferred = $.Deferred();
            ajaxByLoading({
                url: "/Home/CalculatorNotLoggedInForWeb",
                type: "post",
                contentType: "application/json",
                data: JSON.stringify({ previewSendMoneyTransactionModel: previewTransactionModel, appVersion: "5.0" })
            }, element, isNonDelay)
            .done(function (data) {
                if (checkAmountChange(previewTransactionModel)) {
                    return;
                }

                clone(data, self);
                self.original.AmountToSend = data.AmountToSend.Value;
                self.original.AmountToBeDispensed = data.AmountToBeDispensed.Value;
                cs.LogFeeCalculation(data);
                deferred.resolve();
            })
            .fail(function (xhr, status) {
                console.log(xhr);
                self.AmountCollected.Value("");
                self.TotalFee.Value("");
                var data = $.parseJSON(xhr.responseText);
                cs.showErrorMessage(data.Caption, data.Message);
                deferred.reject();
            });

            return deferred;
        };

        function checkAmountChange(previewTransactionModel) {
            if (previewTransactionModel.DominantControl == 'AmountToBeSent') {
                if (Number(cs.GetOriginalNumber(previewTransactionModel.AmountToSend.Value)) != Number(cs.GetOriginalNumber(self.AmountToSend.Value()))) {
                    return true;
                }
            } else if (previewTransactionModel.DominantControl == 'AmountToBeReceived') {
                if (Number(cs.GetOriginalNumber(previewTransactionModel.AmountToBeDispensed.Value)) != Number(cs.GetOriginalNumber(self.AmountToBeDispensed.Value()))) {
                    return true;
                }
            }

            return false;
        }

        self.saveFeeCalculatorData = function saveSelfToSessionStorage(element) {
            if (cs.isDisabled(element)) {
                return false;
            }

            var previewTransaction = clone(self);
            previewTransaction.AmountToSend.Value = AmountToSendValue;
            previewTransaction.AmountToBeDispensed.Value = AmountToReceiveValue;

            var previewTransactionModel = JSON.stringify({
                ToCountryId: previewTransaction.CountryId,
                FromCurrencyId: previewTransaction.FromCurrency == 0 ? 840 : previewTransaction.FromCurrency,
                ToCurrencyId: previewTransaction.ToCurrency,
                AmountToSend: previewTransaction.AmountToSend,
                AmountToBeDispensed: previewTransaction.AmountToBeDispensed,
                CalculateCase: previewTransaction.CalculateCase,
                PaymentMethodTypeId: previewTransaction.PaymentMethodTypeId
            });

            trackGetStartedTotalClicks();

            // Save fee calculator data to db.
            ajaxByLoading({
                url: "/MoneyTransfer/SelfServiceSendMoneyPreviewTransacion",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ 'previewSendMoneyTransactionModel': JSON.parse(previewTransactionModel), "cardHolderId": GetCardHolderId() })
            });

            if (app.senderInfo() && app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                app.goToPersonalInfo("/SelfService/MoneyTransferConsumer/StartPositionCode/FromFeeCalculator", cs.getShortUrlPath());
            }
            else {
                app.redirectTo('/SelfService/MoneyTransferConsumer/StartPositionCode/FromFeeCalculator');
            }
            
            track.trackTimeOnPageForPageLink("Save");
        }

        function GetCardHolderId() {
            var senderInfo = localStorage.getItem("SenderInfo") != null ? $.parseJSON(localStorage.getItem("SenderInfo")) : null;
            var cardHolderId = null;
            if (senderInfo) {
                cardHolderId = senderInfo.Customer.CustomerBasic.CardHolderId;
            }
            else {
                cardHolderId = require('app').senderInfo().Customer().CustomerBasic.CardHolderId();
            }

            return cardHolderId;
        }

        function initializePreviewFeeCalculatorInfoAfterLogin() {
            countries = JSON.parse(localStorage.getItem("FeeCalculatorCountries")) || [];
            var hasCountries = (countries && countries.length > 0) ? true : false;

            ajaxByLoading({
                url: "/MoneyTransfer/SelfServiceGetSendMoneyFeeCalculatorInfo",
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ cardHolderId: GetCardHolderId(), hasCountries: hasCountries })
            })
            .done(function (data) {
                var previewTransactionModel = data.PreviewTransactionModel;
                var defaultCountryId = 484;                        /*Mexico*/

                // Save countries to localStorage
                if (!hasCountries) {
                    countries = data.Countries || [];
                    localStorage.setItem("FeeCalculatorCountries", JSON.stringify(countries));
                }
                self.Countries(countries);

                if (previewTransactionModel && previewTransactionModel.AmountToSend.Value && previewTransactionModel.AmountToSend.Value != 0
                    && previewTransactionModel.AmountToBeDispensed.Value && previewTransactionModel.AmountToBeDispensed.Value != 0) {
                    // Hide amount field placeholder.
                    $(".fit-text-placeholder").hide();

                    initCountrySelect(previewTransactionModel.ToCountryId);
                    initPreviewTransactionModel(previewTransactionModel);
                    calculate(null, true);
                } else {
                    resetFeeCalculateValue();
                    initCountrySelect(defaultCountryId);
                }
            });
        }

        function initPreviewTransactionModel(previewTransactionModel) {
            self.CountryId(previewTransactionModel.ToCountryId);
            for (var i = 0; i < self.Countries().length; i++) {
                if (self.Countries()[i].CountryId == self.CountryId()) {
                    self.ExchangeRate(self.Countries()[i].ExchangeRate);
                    break;
                }
            }
            self.CalculateCase = previewTransactionModel.CalculateCase;

            AmountToSendValue = cs.keepAmountDecimalPlaces(previewTransactionModel.AmountToSend.Value);
            self.AmountToSend.Value(AmountToSendValue);
            AmountToReceiveValue = cs.keepAmountDecimalPlaces(previewTransactionModel.AmountToBeDispensed.Value);
            self.AmountToBeDispensed.Value(AmountToReceiveValue);

            if (previewTransactionModel.PaymentMethodTypeId == 1 || previewTransactionModel.PaymentMethodTypeId == 3) {
                self.PaymentMethodTypeId(previewTransactionModel.PaymentMethodTypeId);
            }
        }

        function initCountrySelect(selectedCountryId) {
            var countries = self.Countries();

            for (var i = 0, l = countries.length; i < l; i++) {
                if (countries[i].CountryId == selectedCountryId) {
                    var country = countries[i];

                    self.Country(country);
                    self.CountryId(country.CountryId);
                    self.ToCountryImage(country.CountryImage);
                    self.CountryName(country.CountryName);
                    self.ExchangeRate(country.ExchangeRate);
                    self.ToCurrencyCode(country.CurrencyCode);
                    self.ToCurrency = country.CurrencyId;
                    self.showPickupAndPayment(true);
                    self.NumberOfLocations(country.NumberOfLocations);
                    break;
                }
            }
        }

        function amountFitInTime() {
            ko.computed(function () {
                var amountToSend = self.AmountToSend.Value(),
                    AmountToBeDispensed = self.AmountToBeDispensed.Value();

                if (self.original.AmountToBeDispensed != self.AmountToBeDispensed.Value()) {
                    $("#input-amount-receive").triggerHandler("keyup.amountFit", AmountToBeDispensed);
                }

                if (self.original.AmountToSend != self.AmountToSend.Value()) {
                    $("#input-amount-send").triggerHandler("keyup.amountFit", amountToSend);
                }
            })
        }

        function hideLoading() {
            $("#modal-loading-feecalculator").hide();
        }

        function showLoading(element, isNonDelay) {
            if (!element) {
                if (isNonDelay) {
                    $("#modal-loading-feecalculator").show();
                    return;
                }
                setTimeout(function () {
                    if (continueLoading) {
                        $("#modal-loading-feecalculator").show();
                    }
                }, cs.delayTime);
            }
        }

        // Start For function
        function ajaxByLoading(options, element, isNonDelay) {
            showLoading(element, isNonDelay);
            continueLoading = true;
            return cs.BaseAjax(options, null, null, function () {
                continueLoading = false;
                hideLoading();
            }, function () {
                continueLoading = false;
                hideLoading();
            });
        }

        function initAmountAttr() {
            var dataAmount = $("[data-amount]");
            dataAmount
                .off("focus.placeholder")
                .on("focus.placeholder", function () {
                    $("small").css('display', 'none');
                }).off("blur.placeholder")
                .on("blur.placeholder", function () {
                    if (this.value == "") {
                        $('input').val('');
                        $('small').css('display', 'block');
                    }

                    if (this.value == '0.00') {
                        $('input').val('0.00');
                    }
                });

            var smallElement = $("small");
            smallElement.off("click.small")
                        .on("click.small", function () {
                            $('small').css('display', 'none');
                            $(this).next().focus();
                        })
        }

        function keepAmountDecimalPlaces(value) {
            if (value && !isNaN(value)) {
                value = parseFloat(value).toFixed(2);
            }

            return getFormatFloat(value);
        }

        // Start For utils
        function getFormatFloat(value) {
            if (!/^(\d+)(\.\d+)?$/.test(value)) {
                return value;
            }

            var integerPart = RegExp.$1,
                decimalPart = RegExp.$2,
                reg = new RegExp();

            reg.compile("(\\d)(\\d{3})(,|$)");

            while (reg.test(integerPart)) {
                integerPart = integerPart.replace(reg, "$1,$2$3");
            }

            return integerPart.replace(/^[0]+/g, "0").replace(/^[0]+([1-9]+)/g, "$1") + "" + (decimalPart || ".00");
        }

        function getAmountFloat(num) {
            if (!num) return 0;

            return parseFloat(num.replace(/,/g, ''));
        }

        function clone(o1, o2) {
            if (!o1) return;

            var isO2Undefined = typeof o2 == "undefined";
            o2 = o2 || {};

            for (var property in o1) {
                var pro1 = ko.toJS(o1[property]),
                    pro2 = o2[property];

                if (!property.isPrototypeOf(o1) && typeof pro1 != "function") {

                    if (!isO2Undefined && (property == "AmountToSend" || property == "AmountToBeDispensed")) {
                        continue;
                    }

                    if (ko.isObservable(pro2)) {
                        o2[property](pro1);
                    } else if (typeof pro2 == "object") {
                        o2[property] = clone(o1[property], o2[property]);
                    }
                    else {
                        o2[property] = pro1;
                    }
                }
            }

            return o2;
        }

        function IsMobileDevice() {
            return !!navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|Windows Phone)/i);
        }

        self.cancel = function () {
            trackCloseIconTotalClicks();

            app.redirectTo("/SelfService/CustomerDashboard");

            track.trackTimeOnPageForPageLink("Cancel");
        };
    }

    return new FeeCalculator();
})