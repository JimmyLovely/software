﻿define(['knockout', 'ClientScript', 'app', paths['common-strings'], 'R', 'TrackEvent', 'app'], function (ko, cs, app, commonstrings, R, track, app) {
    function SettingConsumerViewModel(dataModel) {
        var self = this;
        self.title = commonstrings.viewmodeltitle.settings;
        self.personalSettingsFlag = ko.observable(false);
        self.paymentMethodFlag = ko.observable(false);

        self.init = function () {
        };

        self.dispose = function () {
            app.isShowDemo = false;

            track.clearTrackErrorMessage();
        };

        self.controllers = {
            '/': function () {
                app.isShowDemo = true;
            }
        };

        // Start appsflyer track event
        var trackPaymentMethodsTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PaymentMethods,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Payment Methods",
                eventPage: track.PageEnum.PaymentMethods
            });
        }

        var trackPaymentMethodsTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.PaymentMethods,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.PaymentMethods
            });
        }

        var trackPaymentMethodsTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PersonalSettings,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Payment Methods",
                eventPage: track.PageEnum.PersonalSettings
            });
        }

        var trackPersonalSettingTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PersonalSettings,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Personal Settings",
                eventPage: track.PageEnum.PersonalSettings
            });
        }

        var trackPersonSettingTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.PersonalSettings,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.PersonalSettings
            });
        }

        var trackPersonSettingsFromPaymentMethodTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PersonalSettings,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "From Payment Methods",
                eventPage: track.PageEnum.PersonalSettings
            });
        }

        var trackPersonSetttingsTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PaymentMethods,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Personal Settings",
                eventPage: track.PageEnum.PaymentMethods,
                source: app.page().name
            });
        }
        // End appsflyer track event

        self.afterRender = function () {
            var hash = location.hash;
            if (hash.indexOf('#panel-personal') == -1 && hash != '#panel-payments') {
                cs.triggerTab("panel-personal");
            }
            cs.RemoveOpen();
        };

        self.GetPersonalSettings = function () {
            resetDropDownStatus();
            track.generateErrorMessageTrack(track.CategoryEnum.PersonalSettings, track.PageEnum.PersonalSettings);
            self.personalSettingsFlag(true);
            var hash = location.hash;
            if (hash.indexOf('#panel-payments') != -1) {
                trackPersonSetttingsTotalClicks();

                trackPersonSettingsFromPaymentMethodTotalLoads();
            }

            trackPersonSettingTimeOnPage();

            trackPersonalSettingTotalLoads();
            if (location.href.indexOf("_refresh") < 0) {
                track.trackTimeOnPageForPageLink("PersonalSettingsLink");
            }
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.PersonalSettings, track.PageEnum.PersonalSettings);
        }
        self.GetPaymentMethods = function () {
            track.clearTrackErrorMessage();
            resetDropDownStatus();

            self.paymentMethodFlag(true);
            var hash = location.hash;
            if (hash.indexOf('#panel-personal') != -1) {
                trackPaymentMethodsTotalClicks();
            }

            trackPaymentMethodsTimeOnPage();

            trackPaymentMethodsTotalLoads();

            track.trackTimeOnPageForPageLink("PaymentMethodsLink");
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.PaymentMethods, track.PageEnum.PaymentMethods);
        }

        function resetDropDownStatus() {
            var $winWidth = $(window).width();
            if ($winWidth < 640) {
                $(".add-borders").addClass("closed");
            } else {
                $(".add-borders").removeClass("closed");
            }
        }
    };

    return new SettingConsumerViewModel();
})