﻿define(['knockout', 'ClientScript', 'DataModel', 'TrackEvent', 'app', 'instant-bank-verification-component'], function (ko, cs, dataModel, track, app) {
    return function (params) {
        var self = this;
        self.PaymentMethods = ko.observable();
        self.SelectedPaymentMethod = ko.observable();

        self.addCreditDebitFlag = ko.observable(false);
        self.addBankAccountFlag = ko.observable(false);
        self.editBankAccountFlag = ko.observable(false);
        self.editCreditDebitFlag = ko.observable(false);
        self.linkIBVAccountFlag = ko.observable(false);

        self.IBVStatus = ko.observable(cs.IBVStatus.Normal);
        self.initialData = ko.observable(null);
        self.callBackData = ko.observable(null);
        self.existedPaymentMethod = ko.observable(null);
        
        ko.components.unregister('eidt-credit-debit');
        ko.components.register('eidt-credit-debit', {
            viewModel: { require: 'edit-credit-debit-js' },
            template: { require: 'text!edit-credit-debit-html' }
        });

        self.GetPaymentMethods = function () {
            cs.BaseAjax({
            url: '/PaymentMethod/GetPaymentMethods',
            type: 'get',
            dataType: 'json'
        })
        .done(function (result) {
            result = result || [];
            if (result.length === 0) return self.PaymentMethods(result);
           
            $.each(result, function (index, r) {
                r.IsDefault = ko.observable(r.IsDefault);
                r.CardNickname = ko.observable(r.CardNickname);
            });

            self.PaymentMethods(result);
            cs.collapseDropDowns();
        });
        }

        self.OpenNewModal = function () {
            self['addCreditDebitFlag'](false);
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');
        }

        self.GetPaymentMethods();

        self.ToggleCreditOrDebitListOpenOrClose = function () {
            $("#CreditOrDebitList").toggleClass('closed');

            var trackCCExpandCollapseIconTotalClicks = trackEvent;
            trackCCExpandCollapseIconTotalClicks("Expand/Collapse Card Account");
        }

        self.ToggleBankAccountListOpenOrClose = function () {
            $("#BankAccountList").toggleClass('closed');

            var trackBankExpandCollapseIconTotalClicks = trackEvent;
            trackBankExpandCollapseIconTotalClicks("Expand/Collapse Bank Account");
        }

        self.UpdateDefaultAccount = function (account) {
            if (account.StatusCode != 'E' && !account.IsDefault()) {
                cs.BaseAjax({
                    url: '/PaymentMethod/UpdateDefaultPaymentMethod',
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ "paymentMethodId": account.PaymentMethodId })
                })
                .done(function () {
                    $.each(self.PaymentMethods(), function (index, r) {
                        if (r.IsBank === account.IsBank) {
                            r.IsDefault(account.PaymentMethodId === r.PaymentMethodId);
                        }
                    });
                });
            }
        }

        self.InitializeNewCreditAccount = function () {
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');

            var trackAddCardTotalClick = trackEvent;
            trackAddCardTotalClick("Add Credit/Debit Card");
            track.trackTimeOnPageForPageLink("Add Credit/Debit Card");
        }

        self.InitializeNewBankAccount = function (element) {
            $.when(dataModel.checkIBVNetwork(null, element))
            .done(function (result) {
                self.IBVStatus(cs.IBVStatus.AddingPrompt);
            })
            .fail(function () {
            InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            })
            var trackAddBankTotalClick = trackEvent;
            trackAddBankTotalClick("Add Bank Account");
            track.trackTimeOnPageForPageLink("Add Bank Account");
        }

        self.promptIBVResult = function (isIBV) {
            if (isIBV) {
                $.when(dataModel.checkIBVNetwork())
                .done(function (result) {
                    self.IBVStatus(cs.IBVStatus.Normal);
                    InitializePaymentMethodModel('modal-link-ibv-account', 'linkIBVAccountFlag');
                    setTimeout(function () {
                        dataModel.addIBVPostMessageListener();
                        $("#ibv-submit-form").append(result);
                        document.getElementById('rsessionPost').submit();
                    }, 500);

                    dataModel.setFastLinkEvent(function (data) {
                        setTimeout(function () {
                            AddIBVPaymentMethod(data);
                        }, 300);

                    })
                })
                .fail(function () {
                    //
                })
            } else {
                self.IBVStatus(cs.IBVStatus.Normal);
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
        }

        function AddIBVPaymentMethod(data) {
            var newAddedPaymentMethod = {};
            newAddedPaymentMethod.CardName = data.AccountName;
            if (data.AccountType == "CHECKING") {
                newAddedPaymentMethod.AccountTypeId = 3
            } else if (data.AccountType == "SAVINGS") {
                newAddedPaymentMethod.AccountTypeId = 4
            }
            newAddedPaymentMethod.AccountRoutingNumber = data.BankTransferCode;
            newAddedPaymentMethod.CardNumber = data.AccountNumber;
            newAddedPaymentMethod.IsBank = true;
            newAddedPaymentMethod.IBVAccount = data;
            newAddedPaymentMethod.IsIBVAccount = true;
            newAddedPaymentMethod.PaymentProviderId = !!app.senderInfo() ? !!app.senderInfo().PosPaymentConfig() ? app.senderInfo().PosPaymentConfig().BankAccountProviderId : 2 : 2;
            newAddedPaymentMethod.IsDefault = false;
            cs.AjaxByLoading({
                url: '/PaymentMethod/AddPaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(newAddedPaymentMethod))
            })
            .done(function (data) {
                data.Selected = ko.observable(true);
                self.CompletedAddBankAccount(data);
            })
        }

        self.continueAddBankAccount = function (isContinue) {
            if (isContinue) {
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
            self.IBVStatus(cs.IBVStatus.Normal);
        }

        self.InitializeEditBankAccount = function (paymentMethod) {
            $.when(getPaymentMethod(paymentMethod.PaymentMethodId))
            .done(function (data) {
                self.SelectedPaymentMethod(data);
                InitializePaymentMethodModel('modal-bank-account-edit', 'editBankAccountFlag');
            });
        }

        self.InitializeEditCreditDebit = function (paymentMethod) {
            $.when(getPaymentMethod(paymentMethod.PaymentMethodId))
            .done(function (data) {
                self.SelectedPaymentMethod(data);
                InitializePaymentMethodModel('modal-credit-debit-edit', 'editCreditDebitFlag');
            });
            track.trackTimeOnPageForPageLink("Edit");
        }

        var removeStatus = new cs.executeStatus();
        self.Remove = function (account) {
            cs.closeModalCallBack('modal-remove', function () {
                removeStatus.complete();
            });
            
            $("#ConfirmToRemove").off('click')
            .on('click', function () {
                //For DataCapture, remove payment.
                cs.AddActivityInfo(18);

                $.when(RemoveAccount(account.PaymentMethodId, this))
                .done(function () {
                    cs.closeModal();
                })
                .fail(function () {
                    removeStatus.complete();
                });
            });

            cs.openModal('modal-remove');
            track.trackTimeOnPageForPageLink("Remove");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        self.CompletedAddBankAccount = function (paymentMethod) {
            var tempPaymentMethod = {
                PaymentMethodId: paymentMethod.PaymentMethodId,
                CardName: paymentMethod.CardName,
                CardType: paymentMethod.CardType,
                CardNickname: ko.observable(paymentMethod.CardNickname),
                DisplayCardNumber: paymentMethod.DisplayCardNumber,
                IsBank: paymentMethod.IsBank,
                StatusCode: paymentMethod.StatusCode,
                AccountTypeId: paymentMethod.AccountTypeId,
                AccountType: paymentMethod.AccountType,
                IsDefault: ko.observable(paymentMethod.IsDefault),
                IsIBVAccount: paymentMethod.IsIBVAccount
            };

            var paymentMethods = self.PaymentMethods() || [];

            paymentMethods.push(tempPaymentMethod);
            self.PaymentMethods(paymentMethods);
        }

        self.CompletedEditCreditCard = function (paymentMethod) {
            var editId;
            $.each(self.PaymentMethods(), function (index, p) {
                if (p.PaymentMethodId === paymentMethod.PaymentMethodId) {
                    return editId = index;
                }
            });
            if (editId != 0 && !editId) return;

            self.PaymentMethods()[editId].CardNickname(paymentMethod.CardNickname);
        }

        function InitializePaymentMethodModel(modalId, flagName) {
            cs.closeModalCallBack(modalId, function () {
                self[flagName](false);
                if (modalId == 'modal-link-ibv-account') {
                    window.removeEventListener("message", dataModel.ibvPostMessage);
                }
            });

            self[flagName](true);
            cs.openModal(modalId);
        }

        function RemoveAccount(paymentMethodId, element) {
            $("#ConfirmToRemove").next('a').attr("disabled", true);;
            $("#ConfirmToRemove").next('a').off("click")
            return cs.AjaxBySpinner({
                url: '/PaymentMethod/DeletePaymentMethod',
                type: "POST",
                contentType: 'application/json',
                data: JSON.stringify({ "paymentMethodId": paymentMethodId }),
            }, element)
            .done(function () {
                $("#ConfirmToRemove").next('a').removeAttr("disabled");;
                $("#ConfirmToRemove").next('a').click(function () {
                    cs.closeModal();
                });
                var tempPaymentMethods = self.PaymentMethods().filter(function (p, index) {
                    return p.PaymentMethodId != paymentMethodId;
                });
                self.PaymentMethods(tempPaymentMethods);
            })
            .fail(function () {
                $("#ConfirmToRemove").next('a').removeAttr("disabled");;
                $("#ConfirmToRemove").next('a').click(function () {
                    cs.closeModal();
                });
            });
        }

        function getPaymentMethod(paymentMethodId) {
            return cs.AjaxByDelayLoading({
                url: '/PaymentMethod/GetPaymentMethod',
                type: 'get',
                data: { "paymentMethodId": paymentMethodId },
                dataType: 'json'
            });
        }

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.PaymentMethods,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.PaymentMethods,
                    source: app.page().name
                });
            });
        };
    };
});