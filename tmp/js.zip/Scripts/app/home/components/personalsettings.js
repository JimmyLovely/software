﻿define(['knockout', 'ClientScript', 'DataModel', paths['common-strings'], paths['SettingsConsumer-strings'], 'app', 'R', 'TrackEvent', 'Plugins'], function (ko, cs, dataModel, commonstrings, setingconsumeratrings, app, R, track) {
    return function (params) {
        var self = this;

        self.showPersonalSettings = ko.observable(false);
        self.serverError = ko.observable(false); //For change password
        self.customerBasic = null; //only for save original the value
        self.UpdatePreferences = false;
        self.LanguageId = ko.observable(getCookie('Language') == 'es-MX' ? 2 : 1);
        self.PhoneSMSNotCapable = ko.observable(false);
        self.CITY_ELE_ID = '#autocomplete-city-names-setting';
        self.VALIDATE_MESG = '#ValidateAddressMessageSetting';
        self.ADDRESS_CLEAR = "#personal-address-clear";
        self.smartStreetIds = {
            SelectCityId: self.CITY_ELE_ID,
            SelectStateId: "#input-address-state-setting",
            Address01Id: "#input-address-1-setting",
            Address02Id: "#input-address-2-setting",
            ZipcodeId: "#input-zip-code-setting"
        };
        
        var trackTimeOnPageEnd = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.PersonalSettings, track.PageEnum.PersonalSettings);
        };

        self.OriginalCellPhoneNumber = null;

        cs.BaseAjax({
            url: '/Customers/GetPersonalSettings',
            type: 'get',
            dataType: 'json'
        })
        .done(function (customerBasic) {
            if (!customerBasic) return;

            self.UpdatePreferences = customerBasic.IsAcceptEmailNewsletter;
            customerBasic = initializeCustomerBasicModel(customerBasic);
            self.customerBasic = customerBasic;
            ko.mapping.fromJS(customerBasic, {}, self);

            self.OriginalCellPhoneNumber = self.CellPhoneNumber();
            initializePersonalSettings();
            self.showPersonalSettings(true);

            $.when(getCitiesByStateId(self.StateId(), self.City(), self.CITY_ELE_ID))
            .done(function () {
                self.customerBasic.CityId = self.CityId();
            });

            cs.RemoveBorderAndMessage([self.smartStreetIds.SelectCityId, self.smartStreetIds.SelectStateId, self.smartStreetIds.Address01Id, self.smartStreetIds.Address02Id, self.smartStreetIds.ZipcodeId], $(self.VALIDATE_MESG));
            cs.collapseDropDowns();

            if ($(self.smartStreetIds.Address01Id).val() && $(self.smartStreetIds.Address01Id).val().length > 0) {
                $(self.ADDRESS_CLEAR).show();
            }

            self.PhoneSMSNotCapable(!customerBasic.Sms.PhoneSmsCapable);
        });

        self.getCitiesByStateId = function () {
            self.Zipcode('');
            self.Zipcode.isModified(false);
            self.CityValidateType(0);
            getCitiesByStateId(self.StateId(), '', self.CITY_ELE_ID);
        }

        self.toggleProfileInformation = function () {
            $('#ProfileInformationList').toggleClass('closed');
        }

        var trackProfileExpandCollapseIconTotalClicks = R.compose(trackEvent, R.always('Expand/Collapse Profile Information'));
        self.toggleProfileInformationFromUI = R.compose(trackProfileExpandCollapseIconTotalClicks, self.toggleProfileInformation);

        self.cancelProfileInformation = function () {
            initializeModel(new ProfileInfoModel());
            self.toggleProfileInformation();

            var trackCancelProfileTotalClicks = trackEvent;
            trackCancelProfileTotalClicks("Cancel Update Profile");

            trackTimeOnPageEnd("Cancel Update Profile");
        }

        var updateProfileStatus = new cs.executeStatus();
        self.updateProfileInformation = function (element) {
            if (updateProfileStatus.isExecuting()) {
                return;
            }

            var trackUpdateProfileTotalClicks = trackEvent;
            trackUpdateProfileTotalClicks("Update Profile");

            updateProfileStatus.setExecuting();
            var profileInfoModel = new ProfileInfoModel();
            self.errors = ko.validation.group(profileInfoModel);

            var formatPhoneNumber = function (phoneNumber) {
                if (!phoneNumber) return phoneNumber || '';
                return phoneNumber.replace(/-/g, '');
            }
            var tempLanguageId = getCookie('Language') == 'es-MX' ? 2 : 1;
            if (profileInfoModel.isValid()) {

                /*For SMS DataCapture, Set Validate Request datetime*/
                var dateForValidateRequestDatetime = cs.GetDateTimeOffset();

                return cs.AjaxBySpinner({
                    url: '/Customers/UpdateProfileInformation',
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                        "homePhoneNumber": formatPhoneNumber(self.HomePhoneNumber()),
                        "cellPhoneNumber": formatPhoneNumber(self.CellPhoneNumber()),
                        "workPhoneNumber": formatPhoneNumber(self.WorkPhoneNumber()),
                        "languageId": self.LanguageId()
                    })
                }, element)
                .done(function (result) {
                    initializeModel(new ProfileInfoModel(), result);
                    if (!!result.Sms) {
                        self.PhoneSMSNotCapable(!result.Sms.PhoneSmsCapable);
                    } else {
                        self.PhoneSMSNotCapable(true);
                    }
                    
                    /*Data Capture 14: Update Profile*/
                    if (self.OriginalCellPhoneNumber != self.CellPhoneNumber()) {
                        var smsObject = result.Sms || {};
                        smsObject.ValidateRequestDatetime = dateForValidateRequestDatetime;
                        smsObject.TriggerPlace = "Update Profile";
                        smsObject.EmailAddress = require('app').senderInfo().Customer().CustomerBasic.EmailAddress();
                        smsObject.PhoneNumber = self.CellPhoneNumber();
                        cs.AddActivityInfo(14, null, null, null, result.Sms)

                        self.OriginalCellPhoneNumber = self.CellPhoneNumber();
                    }
                    $.when(openNotifyMessageModal({
                        Title: setingconsumeratrings.message.messagetitle,
                        //Inline message
                        Message: setingconsumeratrings.message.profileinformationupdatesuccess
                    }))
                    .done(function () {
                        updateProfileStatus.complete();
                        if (tempLanguageId != self.LanguageId()) {
                            
                            var selectedLanguage = self.LanguageId() == 1 ? "en-US" : "es-MX";
                            //Post data to Wrapper.
                            try {
                                Android.languageChanged(selectedLanguage);
                            } catch (err) { }
                            try {
                                webkit.messageHandlers.languageChanged.postMessage(selectedLanguage);
                            } catch (err) { }

                            $('#NotificationConfirmOK').one('click.switchlanguage', function () {
                                var self = this;
                                $(self).addClass('now-loading');
                                setTimeout(function () {
                                    location.reload();
                                    $(self).removeClass('now-loading');
                                }, 10)
                            });
                        }
                    });
                })
                .fail(function () {
                    updateProfileStatus.complete();
                    cs.AddActivityInfo(14)
                })
                .always(function () {
                    trackTimeOnPageEnd("Update Profile");
                });
            } else {
                updateProfileStatus.complete();
                self.errors.showAllMessages();
            }
        }

        self.toggleChangePassword = function () {
            $('#ChangePasswordList').toggleClass('closed');
        }

        var trackPasswordExpandCollapseIconTotalClicks = R.compose(trackEvent, R.always('Expand/Collapse Change Password'));
        self.toggleChangePasswordFromUI = R.compose(trackPasswordExpandCollapseIconTotalClicks, self.toggleChangePassword);

        self.cancelChangePassword = function () {
            initializeModel(new ChangePasswordModel());
            self.toggleChangePassword();

            var trackCancelPasswordClicks = trackEvent;

            trackCancelPasswordClicks("Cancel Update Password");

            trackTimeOnPageEnd("Cancel Update Password");
        }

        var changePasswordStatus = new cs.executeStatus();
        self.updateChangePassword = function (element) {
            if (changePasswordStatus.isExecuting()) {
                return;
            }

            changePasswordStatus.setExecuting();

            var trackChangePasswordTotalClicks = trackEvent;
            trackChangePasswordTotalClicks("Change Password");

            var changePassowrdModel = new ChangePasswordModel();
            self.errors = ko.validation.group(changePassowrdModel);
            self.serverError(false);

            if (changePassowrdModel.isValid()) {
                return cs.AjaxBySpinner({
                    url: '/Customers/ChangePassword',
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                        "oldPassword": self.OldPassword(),
                        'newPassword': self.NewPassword(),
                        'emailAddress': app.senderInfo().Customer().CustomerBasic.EmailAddress()
                    })
                }, element, true)
                .done(function (result) {
                    if (result.ReturnCode == 0) { //SUCCESS
                        //Datacapture: Log reset password successfully.
                        cs.AddActivityInfo(13, null, true);
                        initializeModel(new ChangePasswordModel());
                        $.when(openNotifyMessageModal({
                            Title: setingconsumeratrings.message.messagetitle,
                            //Inline message
                            Message: setingconsumeratrings.message.passwordupdatesuccess
                        }))
                        .done(function () {
                            changePasswordStatus.complete();
                        });
                    }
                    else if (result.ReturnCode == -467) {//SELF_SERVICE_PASSWORD_POLICY_VERIFY_FAILED
                        $.when(cs.showErrorMessage(result.Caption, result.Message))
                        .done(function () {
                            changePasswordStatus.complete();
                        });
                    }
                    else {
                        $.when(cs.showErrorMessage(commonstrings.commonmessagebox.error, result))
                        .done(function () {
                            changePasswordStatus.complete();
                        });
                    }
                })
                .fail(function (xhr, status) {
                    try {
                        //Datacapture: Log reset password failed.
                        cs.AddActivityInfo(13, null, false);

                        changePasswordStatus.complete();
                        var resultCode = $.parseJSON($.parseJSON(xhr.responseText).Message).exceptionCode

                        if (resultCode == "-444") {
                            $('#input-setting-old-password').addClass('error');
                            track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.oldpassword);
                        }
                        else {
                            cs.handleAjaxError($.parseJSON($.parseJSON(xhr.responseText).Message).reason, false);
                        }
                        self.serverError(true);
                    }
                    catch (e) {
                        cs.handleAjaxError(e.responseText, false);
                    }
                })
                .always(function () {
                    trackTimeOnPageEnd("Change Password");
                });
            } else {
                changePasswordStatus.complete();
                self.errors.showAllMessages();
            }
        }

        self.toggleAddressInformation = function () {
            $('#AddressInformationList').toggleClass('closed');
            $('#AddressInformationList input').css('line-height', 0); // For IE issue
        }

        var trackAddressInformationExpandCollapseIconTotalClicks = R.compose(trackEvent, R.always('Expand/Collapse Address Information'));
        self.toggleAddressInformationFromUI = R.compose(trackAddressInformationExpandCollapseIconTotalClicks, self.toggleAddressInformation);

        self.cancelAddressInformation = function () {
            $(self.CITY_ELE_ID).val('').trigger('change');
            if (self.StateId() !== self.customerBasic.StateId) {
                getCitiesByStateId(self.customerBasic.StateId, self.customerBasic.City, self.CITY_ELE_ID);
            }

            initalizeAddressInfoModel(self.customerBasic);
            RemoveSmartyStreetValidationStyle();
            self.toggleAddressInformation();

            var trackCancelUpdateAddressInformationTotalClicks = trackEvent;
            trackCancelUpdateAddressInformationTotalClicks("Cancel Update Address Information");

            trackTimeOnPageEnd("Cancel Update Address Information");
        }

        var updateAddressStatus = new cs.executeStatus();
        self.updateAddressInformation = function (element) {
            if (updateAddressStatus.isExecuting()) {
                return;
            }
            updateAddressStatus.setExecuting();

            var trackUpgradeAddressInformationTotalClicks = trackEvent;
            trackUpgradeAddressInformationTotalClicks("Update Address Information");

            var addressInfoModel = new AddressInfoModel();
            self.errors = ko.validation.group(addressInfoModel);
            if ($(self.CITY_ELE_ID).val() === '') {
                self.CityValidateType(1);
            }

            if (addressInfoModel.isValid() && self.CityValidateType() === 0) {
                $.when(dataModel.GetAddressDetails(self.smartStreetIds, element, self, false))
                .done(function () {
                    updateAddressStatus.complete();
                    updateAddressInformation(element);
                    getCitiesByStateId(self.StateId(), self.City(), self.CITY_ELE_ID);
                })
                .fail(function (stateId, cityName) {
                    updateAddressStatus.complete();
                    if (cityName && stateId) {
                        getCitiesByStateId(stateId, cityName, self.CITY_ELE_ID);
                    }
                })
                .always(function () {
                    trackTimeOnPageEnd("Update Address");
                });
            } else {
                updateAddressStatus.complete();
                self.errors.showAllMessages();
            }

        };

        self.toggleProfilePreferences = function () {
            $('#ProfilePreferencesList').toggleClass('closed');
        }

        var trackProfileReferencesExpandCollapseIconTotalClicks = R.compose(trackEvent, R.always('Expand/Collapse Profile References'));
        self.toggleProfileReferencesFromUI = R.compose(trackProfileReferencesExpandCollapseIconTotalClicks, self.toggleProfilePreferences);

        self.cancelProfilePreferences = function () {
            self.IsAcceptEmailNewsletter(self.customerBasic.IsAcceptEmailNewsletter);
            self.toggleProfilePreferences();

            var trackCancelUpdateProfileReferencesTotalClicks = trackEvent;
            trackCancelUpdateProfileReferencesTotalClicks("Cancel Update Profile Preferences");

            trackTimeOnPageEnd("Cancel Update Profile Preferences");
        }

        var updatePreferencesStatus = new cs.executeStatus();
        self.updateProfilePreferences = function (element) {
            if (updatePreferencesStatus.isExecuting()) {
                return;
            }

            var trackUpdateProfilePreferencesTotalClicks = trackEvent;
            trackUpdateProfilePreferencesTotalClicks("Update Profile Preferences");

            if (!self.IsAcceptEmailNewsletter() && self.UpdatePreferences) {
                return unacceptEmailNewsletter(element);
            }

            $.when(updateProfilePreferences(element))
            .done(function () {
                $.when(openNotifyMessageModal({
                    Title: setingconsumeratrings.message.messagetitle,
                    //Inline message
                    Message: setingconsumeratrings.message.profilerpreferencesupdatesuccess
                }))
                .done(function () {
                    updatePreferencesStatus.complete();
                })
                .always(function () {
                    trackTimeOnPageEnd("Update Preferences");
                });
            });
        }

        function refreshDob() {
            if (app.senderInfo()) {
                app.senderInfo().Customer().CustomerBasic.IsShowAddressInformation(false);
                app.senderInfo().Customer().CustomerBasic.Zipcode(self.Zipcode());
                app.senderInfo().Customer().CustomerBasic.Address(self.Address());
                app.senderInfo().Customer().CustomerBasic.Address2(self.Address2());
                app.senderInfo().Customer().CustomerBasic.StateId(self.StateId());
                app.senderInfo().Customer().CustomerBasic.CityId(self.CityId());
                app.senderInfo().Customer().CustomerBasic.City(self.City());

                app.senderInfo().GetSenderLevel('#virtualElement');
            }
        }

        function updateAddressInformation(element) {
            var tempCustomerBasicModel = ko.mapping.toJS(self);
            delete tempCustomerBasicModel.States;
            return cs.AjaxBySpinner({
                url: '/Customers/UpdatePersonalSettingsAddress',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "customerBasicModel": tempCustomerBasicModel })
            }, element, true)
            .done(function (result) {
                if (!result) return;
                initalizeAddressInfoModel(result.CustomerBasic);
                dataModel.updateSenderInfoPermission(result);

                cs.CacheMoneyTransferPermission(app.senderInfo().HasMoneyTransferPermission());

                refreshDob();
                var delegate;
                if (app.senderInfo().SenderLevel()) {
                    delegate = function (element) {
                        return app.senderInfo().GetSenderLevel(element);
                    }
                } else {
                    delegate = function () { return $.Deferred().resolve(); }
                }
                $.when(delegate(element))
                .done(function () {
                    var errorMessage = '';
                    var errorState = '';
                    var emptySpace = " ";
                    for (var i = 0; i < self.States().length; i++) {
                        if (self.States()[i].Value == result.CustomerBasic.StateId) {
                            errorState = self.States()[i].Text;
                            break;
                        }
                    }

                    if (!result.HasMoneyTransfer) {
                        errorMessage = setingconsumeratrings.message.addresssaved + emptySpace + errorState + emptySpace + setingconsumeratrings.message.notifyonceacquired;
                    }
                    else if (!result.HasBillPay && !result.HasLCRBillPay) {
                        errorMessage = setingconsumeratrings.message.addresssaved + emptySpace + errorState + emptySpace + setingconsumeratrings.message.notifyonceacquired;
                    }
                    else {
                        errorMessage = setingconsumeratrings.message.addressinformationupdatesuccess;
                    }

                    $.when(openNotifyMessageModal({
                        Title: setingconsumeratrings.message.messagetitle,
                        //Inline message
                        Message: errorMessage
                    }))
                    .done(function () {
                        updateAddressStatus.complete();
                    });

                    cs.AddActivityInfo(22, null, true);
                })
                .fail(function () {
                    cs.AddActivityInfo(22, null, false);
                    updateAddressStatus.complete();
                });
            })
            .fail(function (xhr, status) {
                updateAddressStatus.complete();
                cs.handleAjaxError(xhr.responseText, false);
            });
        }

        function unacceptEmailNewsletter(element) {
            $('#ConfirmCaption').text(setingconsumeratrings.message.messagetitle);
            //Inline message
            $('#ConfirmMessage').html("<p>" + setingconsumeratrings.message.nolongerreceiveoffers + "</p>");
            $('#ConfirmOk').text(commonstrings.buttons.yes).off('click')
            .on('click', function () {
                if (updatePreferencesStatus.isExecuting()) {
                    return;
                }

                cs.closeModalCallBack('modal-confirm', function (element) {
                    $.when(updateProfilePreferences(element))
                    .done(function () {
                        $.when(openNotifyMessageModal({
                            Title: setingconsumeratrings.message.messagetitle,
                            //Inline message
                            Message: setingconsumeratrings.message.receiveemail
                        }))
                        .done(function () {
                            updatePreferencesStatus.complete();
                        });
                    });
                });
                cs.closeModal();
            });

            $('#ConfirmCancel').text(commonstrings.buttons.no).off('click')
            .one('click', function () {
                $.when(cs.closeModal())
                .done(function () {
                    self.IsAcceptEmailNewsletter(self.customerBasic.IsAcceptEmailNewsletter);
                });
            });
            cs.openModal('modal-confirm');
        }

        function updateProfilePreferences(element) {
            updatePreferencesStatus.setExecuting();
            return cs.AjaxBySpinner({
                url: '/Customers/UpdateProfilePreferences',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                    "isAcceptEmailNewsletter": self.IsAcceptEmailNewsletter(),
                    "languageId": 1
                })
            }, element)
            .done(function (result) {
                self.UpdatePreferences = self.IsAcceptEmailNewsletter();
                self.IsAcceptEmailNewsletter(result.IsAcceptEmailNewsletter);
                self.customerBasic.IsAcceptEmailNewsletter = result.IsAcceptEmailNewsletter;
            })
            .fail(function () {
                updatePreferencesStatus.complete();
            });
        }

        function initializeModel(model, result) {
            for (var pro in model) {
                if (result) {
                    self.customerBasic[pro] = result[pro]; // init customerbasic model value
                }

                self[pro](self.customerBasic[pro] || ''); //reset to the original value
                self[pro].isModified(false); // init model validation
            }
        }

        function initalizeAddressInfoModel(result) {
            initializeModel(new AddressInfoModel(), result);

            result = result || self.customerBasic;
            $(self.CITY_ELE_ID).val(result.City);
            self.CountryId(result.CountryId);
            self.CityValidateType(0);
        }

        function RemoveSmartyStreetValidationStyle() {
            for (var id in self.smartStreetIds) {
                $(self.smartStreetIds[id]).css("border", "");
            }
            $(self.VALIDATE_MESG).css('display', 'none');
        };

        function ProfileInfoModel() {
            var that = this;
            that.HomePhoneNumber = self.HomePhoneNumber;
            that.CellPhoneNumber = self.CellPhoneNumber;
            that.WorkPhoneNumber = self.WorkPhoneNumber;
        };

        function ChangePasswordModel() {
            var that = this;
            that.OldPassword = self.OldPassword;
            that.NewPassword = self.NewPassword;
            that.ConfirmPassword = self.ConfirmPassword;
        };

        function AddressInfoModel() {
            var that = this;
            that.Address = self.Address;
            that.CityId = self.CityId;
            that.StateId = self.StateId;
            that.Zipcode = self.Zipcode;
        };

        function initializeCustomerBasicModel(customerBasic) {
            customerBasic.OldPassword = '';
            customerBasic.NewPassword = '';
            customerBasic.ConfirmPassword = '';
            customerBasic.States = '';
            customerBasic.CityId = '';
            customerBasic.CityValidateType = 0;
            return customerBasic;
        }

        function initializePersonalSettings() {
            applyProfileInformationValidation();
            applyCustomerPasswordValidation();
            applyAddressInfoValidation();

            initializeStates();
        }

        function applyProfileInformationValidation() {
            self.HomePhoneNumber.extend({
                required: false,
                number: { onlyIf: function () { return cs.IsInvalidPhoneNumber(self.HomePhoneNumber()) } },
                maxLength: { onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.HomePhoneNumber()); } },
                minLength: 10
            }).isModified(false);

            self.CellPhoneNumber.extend({
                required: { onlyIf: self.ValidatePhoneAtLeastOneAndValid },
                number: { onlyIf: function () { return cs.IsInvalidPhoneNumber(self.CellPhoneNumber()) } },
                maxLength: { onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.CellPhoneNumber()); } },
                minLength: 10
            }).isModified(false);

            self.WorkPhoneNumber.extend({
                required: false,
                number: { onlyIf: function () { return cs.IsInvalidPhoneNumber(self.WorkPhoneNumber()) } },
                maxLength: { onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.WorkPhoneNumber()); } },
                minLength: 10
            }).isModified(false);

            self.requiredPhoneNumber = ko.computed(function () {
                var result = ((self.CellPhoneNumber.isModified() && !self.CellPhoneNumber.isValid()) || (self.WorkPhoneNumber.isModified() && !self.WorkPhoneNumber.isValid()) || (self.HomePhoneNumber.isModified() && !self.HomePhoneNumber.isValid())) && (self.CellPhoneNumber() == '');
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.profile.errormessage.phonenumberisrequired);
                }
                return result;
            });

            self.noValidPhoneNumber = ko.computed(function () {
                var result = ((self.CellPhoneNumber.isModified() && !self.CellPhoneNumber.isValid()) || (self.WorkPhoneNumber.isModified() && !self.WorkPhoneNumber.isValid()) || (self.HomePhoneNumber.isModified() && !self.HomePhoneNumber.isValid())) && (self.CellPhoneNumber() != '');
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.profile.errormessage.notvalidphonenumber);
                }
                return result;
            });
        };

        function applyCustomerPasswordValidation() {
            ko.computed(function () {
                var oldPassword = self.OldPassword();
                var newPassword = self.NewPassword();
                var confirmPassword = self.ConfirmPassword();
                self.serverError(false);
                return true;
            });

            self.OldPassword.extend({
                required: true,
                minLength: 8,
                maxLength: 20,
                equal: {
                    onlyIf: function () { return validatePassowrd(self.OldPassword()) },
                    //Inline message
                    message: setingconsumeratrings.message.characterslength // Override later as "Not a valid old password".
                }
            }).isModified(false);

            self.NewPassword.extend({
                required: true,
                minLength: 8,
                maxLength: 20,
                equal: {
                    onlyIf: function () { return validatePassowrd(self.NewPassword()) },
                    //Inline message
                    message: setingconsumeratrings.message.characterslength // Override later as "Not a valid new password".
                }
            }).isModified(false);

            self.ConfirmPassword.extend({
                required: true,
                equal: self.NewPassword,
            }).isModified(false);

            self.isInvalidOldPassword = ko.computed(function () {
                var result = self.OldPassword.isModified() && !self.OldPassword.isValid() && self.OldPassword() != '';
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.oldpwdinvalid);
                }
                return result;
            });

            self.isInvalidNewPassword = ko.computed(function () {
                var result = self.NewPassword.isModified() && !self.NewPassword.isValid() && self.NewPassword() != '';
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.newpwdinvalid);

                }
                return result;
            });

            self.isRequiredOldPassword = ko.computed(function () {
                var result = self.OldPassword.isModified() && !self.OldPassword.isValid() && self.OldPassword() == '';
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.oldpwdrequired);
                }
                return result;
            });

            self.isRequiredNewPassword = ko.computed(function () {
                var result = self.NewPassword.isModified() && !self.NewPassword.isValid() && self.NewPassword() == '';
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.newpwdrequired);
                }
                return result;
            });

            self.isRequiredConfirmPassword = ko.computed(function () {
                var result = self.ConfirmPassword.isModified() && !self.ConfirmPassword.isValid() && self.ConfirmPassword() == ''
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.confirmpwdrequired);
                }
                return result;
            });

            self.isMatchPassword = ko.computed(function () {
                var result = self.ConfirmPassword.isModified() && self.NewPassword() != self.ConfirmPassword();
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.nomatch);
                }
                return result;
            });

            self.isInvalidOldPasswordFromServer = ko.computed(function () {
                var result = self.OldPassword.isModified() && self.serverError();
                if (result) {
                    track.commonTrackErrorMessage(setingconsumeratrings.personalsettings.password.validations.oldpwdinvalid);
                }
                return result;
            });
        };

        function applyAddressInfoValidation() {
            self.Address.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.addressvalidation.addressrequired }
            }).isModified(false);

            self.CityId.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.addressvalidation.cityrequired }
            }).isModified(false);
            self.StateId.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.addressvalidation.staterequired }
            }).isModified(false);

            self.Zipcode.extend({
                //Inline message
                required: { params: true, message: commonstrings.address.validations.zipcoderequired },
                number: { params: true, message: commonstrings.address.validations.zipcodevalid },
                minLength: { params: 5, message: commonstrings.address.validations.zipcodeminlength },
                maxLength: { params: 5, message: commonstrings.address.validations.zipcodemaxlength }
            }).isModified(false);

            self.isInvalidAddress = ko.computed(function () {
                var result = self.Address.isModified() && !self.Address.isValid() && self.Address() != '';

                if (result) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.addressinvalid);
                }

                return result;
            });

            self.isRequiredAddress = ko.computed(function () {
                var result = self.Address.isModified() && !self.Address.isValid() && self.Address() == '';

                if (result) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.addressrequired);
                }

                return result;
            });

            self.isRequiredState = ko.computed(function () {
                var result = self.StateId.isModified() && !self.StateId.isValid();

                if (result) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.staterequired);
                }

                return result;
            });

            ko.computed(function () {
                var cityValidateType = self.CityValidateType();

                if (cityValidateType ===1) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.cityrequired);
                } else if (cityValidateType === 2) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.cityinvalid);
                }
            });

            ko.computed(function () {
                var noMatchSuggestionError = self.NoMatchSuggestionError();

                if (noMatchSuggestionError === 1) {
                    track.commonTrackErrorMessage(commonstring.address.validations.zipcodeerror);
                } else if (noMatchSuggestionError === 2) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.citynotfound);
                }
            });
        };

        function initializeStates() {
            $.when(dataModel.GetStatesByCountryId(840))
            .done(function (states) {
                self.States(states);
            });
        }

        var cities = null;
        function getCitiesByStateId(stateId, displayCityName, element) {
            if (!stateId) {
                return;
            }
            RemoveSmartyStreetValidationStyle();
            return $.when(dataModel.GetCitiesByStateId(840, stateId))
            .done(function (data) {
                cities = data;

                $(element).autocomplete({
                    lookup: data,
                    triggerSelectOnValidInput: false,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        self.CityId(suggestion.data.Value);
                        self.City(suggestion.value);
                        self.CityValidateType(0);
                    },
                    lookupFilter: function (k, j, l) {
                        var inputValue = (cs.removeDiacritics(l).toLowerCase());
                        return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1;
                    }
                });
                $(element).autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                $(element).val(displayCityName);
                if (data && displayCityName) {
                    $.each(data, function (index, city) {
                        if (city.value == displayCityName) {
                            self.CityId(city.data.Value);
                            self.City(displayCityName);
                            self.CityValidateType(0);
                        }
                    });
                }

                $(element).off('input.city_changed')
                .on('input.city_changed', function () {
                    var value = $(element).val();

                    if (value == "") {
                        self.CityValidateType(1);
                    }
                    else if (cs.isMatchSuggestion($(element).autocomplete().suggestions, value, false) > -1) {
                        self.CityValidateType(0);
                        return;
                    }
                    else {
                        self.CityValidateType(2);
                    }

                    self.CityId(null);
                });

                $(element).off('blur.city_changed')
                .on('blur.city_changed', function () {
                    if ($('.autocomplete-selected').length > 0) return;

                    var matchedIndex = -1;
                    var value = $(this).val();

                    if (value == "") {
                        self.CityValidateType(1);
                    }
                    else if ($(element).autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($(element).autocomplete().suggestions, value, true)) > -1) {
                        self.CityValidateType(0);
                        $(element).autocomplete().select(matchedIndex);
                        return;
                    } else {
                        self.CityValidateType(2);
                    }
                    self.CityId(null);
                });
            });
        }

        function validatePassowrd(password) {
            if (password != null) {
                return !(/^.*[0-9]+/.test(password) && !(/\s/.test(password)));
            }
            return false;
        }

        function openNotifyMessageModal(notifyMessageModel, element) {
            $("#NotificationHead").text(notifyMessageModel.Title);
            $("#NotificationMessage").text(notifyMessageModel.Message);
            return cs.openModal("modal-notification");
        };

        var timeHandler = 0;
        // 1 zip type is not standard
        // 2 city not found
        self.NoMatchSuggestionError = ko.observable(0);

        self.ClearAddressInfo = function () {
            self.NoMatchSuggestionError(0);
            self.Address(null);
            self.Address.isModified(false);

            self.StateId(null);
            self.StateId.isModified(false);

            $(self.smartStreetIds.SelectCityId).val("");
            self.Zipcode(null);
            self.Zipcode.isModified(false);

            $(self.smartStreetIds.Address01Id).autocomplete({
                lookup: []
            });

            $(self.CITY_ELE_ID).autocomplete({
                lookup: []
            });

            // Clear error mesage.
            $(self.smartStreetIds.Address01Id).trigger('input');

            $(self.ADDRESS_CLEAR).hide();
            $(self.smartStreetIds.Address01Id).focus();
        }

        self.ShowAddressControl = function (element) {
            var value = $(element).val();
            if (value && value.length > 0) {
                $(self.ADDRESS_CLEAR).show();
            }
            else {
                $(self.ADDRESS_CLEAR).hide();
            }
        }

        self.HideAddressControl = function (element) {
            if ($('.autocomplete-selected').length > 0) return;

            $(self.smartStreetIds.Address01Id).autocomplete("hide");
        }

        self.AutoSearchSuggestion = function (element, data, e) {
            if (cs.isKeyPressControlOrSelect(e.which) || e.which == 13) {
                return;
            }

            $(self.smartStreetIds.Address01Id).autocomplete({
                lookup: [],
                showNoSuggestionNotice: false
            });
            self.NoMatchSuggestionError(0);

            var value = $(element).val();
            clearTimeout(timeHandler);

            if (value && value.length > 0) {
                $(self.ADDRESS_CLEAR).show();
                timeHandler = setTimeout(function () {
                    AutoSearchSuggestion(value, element);
                }, 500);
            }
            else {
                $(self.ADDRESS_CLEAR).hide();
            }
        }

        self.CheckCellPhoneNumber = function () {
            self.PhoneSMSNotCapable(false);
        }

        function AutoSearchSuggestion(streetName, bindingElement) {
            $.when(dataModel.GetAutoCompleteSuggestionAddresses(streetName))
            .done(function (result) {
                /*For DataCapture*/
                if (result && result.length == 0) {
                    cs.LogInformationOfAddressSearch($(bindingElement).val(), false /*false stand for no recoeds found*/);
                }

                var containerClass = "autocomplete-bold";
                if (cs.IsMobileDevice()) {
                    // If device is mobile, not tablet, change suggestion div width.
                    if (window.screen.width < 500) {
                        containerClass += " mobile-auto-suggestion-width";
                    }
                }
                containerClass += " personal-auto-address";

                BindingAutoSuggestionAddress(bindingElement, result, containerClass);
            });
        }

        function BindingAutoSuggestionAddress(bindingElement, lookup, containerClass) {
            $(bindingElement).autocomplete({
                lookup: lookup,
                minChars: 1,
                showNoSuggestionNotice: true,
                containerClass: containerClass,
                triggerSelectOnValidInput: false,
                noSuggestionNotice: "No suggestions found",
                onSelect: function (suggestion) {
                    $(bindingElement).blur();
                    self.NoMatchSuggestionError(0);
                    $(bindingElement).val(suggestion.data.StreetName);
                    self.Address(suggestion.data.StreetName);

                    $.when(dataModel.GetAddressAutocompleteDetails(suggestion))
                    .done(function (result) {
                        if (!result.ResultAddress.DeliveryLine2) {
                            result.ResultAddress.DeliveryLine2 = self.Address2();
                        }

                        if (result && result.ResultAddress && result.ResultAddress.Analysis.DpvMatchCode != null && result.ResultAddress.Analysis.DpvMatchCode != 'N') {

                            var address = result.ResultAddress;

                            var resultStreet = address.DeliveryLine1;
                            self.Address(resultStreet);
                            $(bindingElement).val(resultStreet);

                            var resultSecondStreet = address.DeliveryLine2;
                            var resultCity = address.Components.CityName;
                            var resultState = address.Components.StateAbbreviation;
                            var resultZipcode = address.Components.Zipcode;

                            var isCityMatchSuggestion = true;
                            if (address.Metadata.ZipType != 'Standard') {
                                cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.address.validations.zipcodeerror, function () {
                                    $.when(cs.closeModal())
                                    .done(function () {
                                        isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, null, function () {
                                            if (resultZipcode && resultZipcode != "") {
                                                self.Zipcode(resultZipcode);
                                            }
                                            $(self.smartStreetIds.SelectCityId).focus();
                                        });

                                        setTimeout(function () {
                                            $("#input-zip-code-setting").focus();
                                        }, 300);
                                    });
                                });
                            }
                            else {
                             	isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, function () {
                                    self.Zipcode(resultZipcode);
                                    setTimeout(function () {
                                        $(self.smartStreetIds.Address02Id).focus();
                                    }, 100);
                                }, function () {
                                    if (resultZipcode && resultZipcode != "") {
                                        self.Zipcode(resultZipcode);
                                    }
                                    $(self.smartStreetIds.SelectCityId).focus();
                                });
                            }

                            if (!isCityMatchSuggestion) {
                                result.ResultAddress.Components.CityName = "";
                            }

                            //For datacapture. Log address validate.
                            cs.LogAddressValidate(result, true);
                        }
                        else {
                            var lastLine = cs.getSmartStreetLastLine(suggestion.data.City, suggestion.data.State, $("#input-zip-code-setting").val());
                            var message = cs.getAutoCompleteAddressInvalidMessage(suggestion.data.StreetName, $(self.smartStreetIds.Address02Id).val(), lastLine);
                            cs.ShowCustomMessage(function () {

                                //For datacapture. Log address validate.
                                result.ResultAddress.DeliveryLine1 = suggestion.data.StreetName;
                                result.ResultAddress.Components.CityName = suggestion.data.City;
                                result.ResultAddress.Components.StateAbbreviation = suggestion.data.State;
                                for (var i = 0; i < self.States().length; i++) {
                                    var state = self.States()[i];
                                    if (state.Code == suggestion.data.State) {
                                        result.ResultAddress.Metadata.CountyName = state.Text;
                                        break;
                                    }
                                }

                                var isCityMatchSuggestion = FillAddressStateAndCity(suggestion.data.State, suggestion.data.City, function () {
                                    setTimeout(function () {
                                        $(self.smartStreetIds.Address02Id).focus();
                                    }, 100);
                                }, function () {
                                    setTimeout(function () {
                                        $(self.smartStreetIds.SelectCityId).focus();                                 
                                    }, 300);
                                });

                                if (!isCityMatchSuggestion) {
                                    result.ResultAddress.Components.CityName = "";
                                }

                                //For datacapture. Log address validate.
                                cs.LogAddressValidate(result, true);
                            }, function () {
                                setTimeout(function () {
                                    $(self.smartStreetIds.Address01Id).focus();
                                }, 300);
                            }, message);
                        }
                    })
                }
            });
            // If device is mobile, not tablet, change suggestion div position.
            if (cs.IsMobileDevice() && window.screen.width < 500) {
                var left = "-" + $("#label-address").css('width');
                $(".mobile-auto-suggestion-width").css('left', left);
            }

            $(bindingElement).autocomplete().getSuggestionsLocal = function (query) {
                return { suggestions: this.options.lookup };
            }

            if (document.activeElement && document.activeElement.id == bindingElement.id) {
                $(bindingElement).focus();
            }
        }

        function FillAddressStateAndCity(resultState, resultCity, addtionalField, addtionalFocus) {
            var isCityMatchSuggestion = true;
            var stateId = dataModel.GetStateId(resultState, self.States());
            if (stateId && stateId != 0) {
                self.StateId(stateId);
                $.when(self.getCitiesByStateId())
                .done(function () {
                    if (cs.isMatchSuggestion(cities, resultCity, false) > -1) {
                        var city = dataModel.GetCity(resultCity, cities);
                        self.CityId(city.data.Value);
                        self.City(city.value);
                        self.CityValidateType(0);

                        $(self.smartStreetIds.SelectCityId).val(resultCity);
                        if (typeof addtionalField == 'function') {
                            addtionalField();
                        }
                        isCityMatchSuggestion = true;
                    }
                    else {
                        self.StateId(stateId);
                        if (typeof addtionalFocus == 'function') {
                            addtionalFocus();
                        }
                        isCityMatchSuggestion = false;
                    }
                })
            }
            else {
                //todo.
            }
            return isCityMatchSuggestion;
        }

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.PersonalSettings,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.PersonalSettings,
                    source: app.page().name
                });
            });
        };
    };
});