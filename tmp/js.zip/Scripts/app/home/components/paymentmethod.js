﻿define(['knockout', 'ClientScript', 'DataModel'], function (ko, cs, dataModel) {
    return function (params) {
        var self = this;
        self.PaymentMethods = ko.observable();
        self.SelectedPaymentMethod = ko.observable();

        self.addCreditDebitFlag = ko.observable(false);
        self.addBankAccountFlag = ko.observable(false);
        self.editBankAccountFlag = ko.observable(false);
        self.editCreditDebitFlag = ko.observable(false);

        ko.components.unregister('eidt-bank-account');
        ko.components.register('eidt-bank-account', {
            viewModel: { require: 'edit-bank-account-js' },
            template: { require: 'text!edit-bank-account-html' }
        });

        ko.components.unregister('eidt-credit-debit');
        ko.components.register('eidt-credit-debit', {
            viewModel: { require: 'edit-credit-debit-js' },
            template: { require: 'text!edit-credit-debit-html' }
        });

        cs.BaseAjax({
            url: '/BillPayLCR/GetPaymentMethods',
            type: 'get',
            dataType: 'json'
        })
        .done(function (result) {
            result = result || [];
            if (result.length === 0) return self.PaymentMethods(result);

            $.each(result, function (index, r) {
                r.IsDefault = ko.observable(r.IsDefault);
            });
            self.PaymentMethods(result);
        });

        self.ToggleCreditOrDebitListOpenOrClose = function () {
            $("#CreditOrDebitList").toggleClass('closed');
        }

        self.ToggleBankAccountListOpenOrClose = function () {
            $("#BankAccountList").toggleClass('closed');
        }

        self.UpdateDefaultAccount = function (account) {
            if (account.StatusCode != 'E' && !account.IsDefault()) {
                cs.BaseAjax({
                    url: '/Home/UpdateDefaultPaymentMethod',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({"paymentMethodId": account.PaymentMethodId})
                })
                .done(function (data) {
                    if (!data) return;
                    $.each(self.PaymentMethods(), function (index, r) {
                        if (r.IsBank === data.IsBank) {
                            r.IsDefault(data.PaymentMethodId === r.PaymentMethodId);
                        }
                    });
                });
            }
        }

        self.InitializeNewCreditAccount = function () {
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');
        }

        self.InitializeNewBankAccount = function () {
            InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
        }

        self.InitializeEditBankAccount = function (paymentMethod) {
            $.when(getPaymentMethod(paymentMethod.PaymentMethodId))
            .done(function (data) {
                self.SelectedPaymentMethod(data);
                InitializePaymentMethodModel('modal-bank-account-edit', 'editBankAccountFlag');
            });
        }

        self.InitializeEditCreditDebit = function (paymentMethod) {
            $.when(getPaymentMethod(paymentMethod.PaymentMethodId))
            .done(function (data) {
                self.SelectedPaymentMethod(data);
                InitializePaymentMethodModel('modal-credit-debit-edit', 'editCreditDebitFlag');
            });
        }

        var removeStatus = new cs.executeStatus();
        self.Remove = function (account) {
            cs.closeModalCallBack('modal-remove', function () {
                removeStatus.complete();
            });

            $("#ConfirmToRemove").off('click')
            .on('click', function () {
                //For DataCapture, remove payment.
                cs.AddActivityInfo(18);

                $.when(RemoveAccount(account.PaymentMethodId, this))
                .done(function () {
                    cs.closeModal();
                })
                .fail(function () {
                    removeStatus.complete();
                });
            });

            cs.openModal('modal-remove');
        }

        self.CompletedAddBankAccount = function (paymentMethod) {
            var tempPaymentMethod = {
                PaymentMethodId: paymentMethod.PaymentMethodId,
                CardName: paymentMethod.CardName,
                CardType: paymentMethod.CardType,
                CardNickname: paymentMethod.CardNickname,
                DisplayCardNumber: paymentMethod.DisplayCardNumber,
                IsBank: paymentMethod.IsBank,
                StatusCode: paymentMethod.StatusCode,
                AccountTypeId: paymentMethod.AccountTypeId,
                AccountType: paymentMethod.AccountType,
                IsDefault: ko.observable(false)
            };

            var paymentMethods = self.PaymentMethods() || [];

            paymentMethods.push(tempPaymentMethod);
            self.PaymentMethods(paymentMethods);

            cs.AddTransactionStep(10, 'Payment_method_id', tempPaymentMethod.PaymentMethodId);
        }

        function InitializePaymentMethodModel(modalId, flagName) {
            cs.closeModalCallBack(modalId, function () {
                self[flagName](false);
            });

            self[flagName](true);
            cs.openModal(modalId);
        }

        function RemoveAccount(paymentMethodId, element) {
            return cs.AjaxBySpinner({
                url: '/Home/DeletePaymentMethod',
                type: "Post",
                contentType: 'application/json',
                data: JSON.stringify({ "paymentMethodId": paymentMethodId }),
            }, element)
            .done(function () {
                var tempPaymentMethods = self.PaymentMethods().filter(function (p, index) {
                    return p.PaymentMethodId != paymentMethodId;
                });
                self.PaymentMethods(tempPaymentMethods);
            });
        }

        function getPaymentMethod(paymentMethodId) {
            return cs.AjaxByLoading({
                url: '/Home/GetPaymentMethod',
                type: 'get',
                data: { "paymentMethodId": paymentMethodId },
                dataType: 'json'
            });
        }
    };
});