﻿define(["require", 'knockout', 'ClientScript', 'app', 'CustomerModel', 'DataModel', 'R', 'TrackEvent'], function (require, ko, cs, app, CustomerModel, dataModel, R, track) {
    return function SenderInfo(data) {
        var self = this;
        self.layoutModalDobAddressFlag = ko.observable(false);
        self.addBillingAccountFlag = ko.observable(false);
        self.addCarrierFlag = ko.observable(false);
        self.addRecipientFlag = ko.observable(false);
        self.PaymentProviderId = ko.observable(2);
        self.Customer = ko.observable(null);
        self.SenderLevel = ko.observable(null);
        self.PromotionMessages = ko.observableArray();
        self.ShowSubmittedPrompt = false;

        var mapping = {
            'Customer': {
                create: function (options) {
                    return new CustomerModel(options.data, "");
                }
            },
            //'SenderLevel': {
            //    create: function (options) {
            //        return new SenderLevelModel(options.data, dataModel);
            //    }
            //}
        };

        //Start appsflyer track event
        var trackLeftMenu = function (eventLabel) {
            return function () {
                track.trackLeftMenu(eventLabel, app);
                track.trackTimeOnPageForPageLink(eventLabel == "Start a Transaction" ? null : "LeftMenu_" + eventLabel);
            }
        };

        var trackReferraFriendTotalLoadsFromLeftMenu = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "From Left Menu",
                eventPage: track.PageEnum.ReferralLandingPage
            });
        }

        var trackTutorialTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.Tutorial,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Tutorial",
                eventPage: track.PageEnum.Tutorial,
                source: app.page().name
            });
        }

        var trackTutorialContinueTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.Tutorial,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Continue",
                eventPage: track.PageEnum.Tutorial,
                source: app.page().name
            });

            track.trackTimeOnPageForPageLink("Continue");
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.Dashboard, track.PageEnum.Dashboard);
        }

        var trackQuickTransaction = function (eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum["+Button"],
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum["+Button"]
            });
        };

        var trackTransactionHistoryTotalLoadsFromLeftMenu = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionHistory,
                eventAction: track.ActionEnum.SourcePage,
                eventLabel: "Source_LeftMenu",
                eventPage: track.PageEnum.TransactionHistory
            });
        }

        var trackLeftMenuSendingLimitLinkTotalClicks = trackLeftMenu('Sending Limit');

        var trackQuickMenuClickedFromPage = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum["+Button"],
                eventAction: track.ActionEnum.SourcePage,
                eventLabel: track.getEventPage(app),
                eventPage: track.PageEnum["+Button"],
                source: app.page().name
            });
        }

        var trackPersonSettingsTotalLoadsFromLeftMenu = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PersonalSettings,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "From Left Menu",
                eventPage: track.PageEnum.PersonalSettings
            });
        }

        var trackQuickMenuMoneyTransferLinkTotalClicks = R.compose(trackQuickTransaction, R.always("+Button MT"));

        var trackQuickMenuBillPayLinkTotalClicks = R.compose(trackQuickTransaction, R.always("+Button BP"));

        var trackQuickMenuReloadLinkTotalClicks = R.compose(trackQuickTransaction, R.always("+Button TU-reload"));

        var trackQuickMenuEpinLinkTotalClicks = R.compose(trackQuickTransaction, R.always("+Button TU-ePin"));

        var trackQuickMenuPinlessLinkTotalClicks = R.compose(trackQuickTransaction, R.always('+Button TU-pinless'));


        var trackLeftMenuReferralLinkTotalClicks = trackLeftMenu('Refer a Friend');

        var trackLeftMenuMoneyTransferLinkTotalClicks = trackLeftMenu("Send Money");

        var trackLeftMenuHomeLinkTotalClicks = trackLeftMenu("Home");

        var trackLeftMenuTransactionLinkTotalClicks = trackLeftMenu("Transactions");

        var trackLeftMenuBillPayOrLCRLinkTotalClicks = trackLeftMenu("Pay Bills");

        var trackLeftMenuReloadLinkTotalClicks = trackLeftMenu("Reload");

        var trackLeftMenuEpinLinkTotalClicks = trackLeftMenu("EPin");

        var trackLeftMenuPinlessLinkTotalClicks = trackLeftMenu('Pinless');

        var trackLeftMenuIncreaseSendingLimitLinkTotalClicks = trackLeftMenu('Increase Sending Limit');

        var trackLeftMenuFeeCalculatorLinkTotalClicks = trackLeftMenu('Fee Calculator');

        var trackLeftMenuPersonalSettingLinkTotalClicks = trackLeftMenu('Settings');

        var trackLeftMenuLogoutLinkTotalClicks = trackLeftMenu('Log out');

        var trackLeftMenuHelpCenterLinkTotalClicks = trackLeftMenu('Help Center');

        var trackLeftMenuCallUsLinkTotalClicks = R.tap(trackLeftMenu('Call Us'));

        var trackLeftMenuViewFAQsTotalClicks = trackLeftMenu('View FAQs');

        self.trackLeftMenuStartTransactionLinkTotalClicks = trackLeftMenu('Start a Transaction');

        self.trackQuickMenuTotalClicks = R.compose(trackQuickMenuClickedFromPage, trackQuickTransaction, R.always("+Button Open"));

        //End appsflyer track event

        //Add Payment
        self.BankAccount = ko.observable(null);

        self.CreditOrDebitCard = ko.observable(null);

        //Add Payee
        self.BillingAccount = ko.observable(null);

        self.TopUpReloadCarrier = ko.observable(null);

        ko.mapping.fromJS(data, mapping, self);

        //self.Sender().TobeAddedReceiver.AccountTypeExtendForManagerNewBankAccount();

        self.Customer().CustomerBasic.initializeForDOBAndAddress();

        self.GetSelfServicePosMessages = function () {
            var deffered = $.Deferred();
            cs.BaseAjax({
                url: '/Customers/SelfServiceGetPromotionMessages',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "isMobile": cs.IsMobileDevice() })
            }).done(function (data) {
                var promotionMessages = data.length > 0 ? data : [];
                var tempList = new Array();
                $.each(data, function (i, e) {
                    var subject = ko.observable(e.Subject);
                    var message = ko.observable(e.Message);
                    var time = ko.observable(e.DateCreated);

                    tempList.push({ Subject: subject, Message: message, Time: time });
                });
                ko.mapping.fromJS(tempList, {}, self.PromotionMessages);

                deffered.resolve();
            })
            .fail(function () {
                deffered.reject();
            });

            return deffered;
        }

        function ValidateAddAccount(addPaymentMethods) {
            addPaymentMethods.TobeAddedPaymentMethod.errors = ko.validation.group(addPaymentMethods.TobeAddedPaymentMethod);
            addPaymentMethods.TobeAddedPaymentMethod.BillingAddress.errors = ko.validation.group(addPaymentMethods.TobeAddedPaymentMethod.BillingAddress);
            var result = addPaymentMethods.ValidateCityForAdd();
            return addPaymentMethods.TobeAddedPaymentMethod.isValid() && addPaymentMethods.TobeAddedPaymentMethod.BillingAddress.isValid() && result;
        }

        //end: ADD PAYMENT

        self.GoToDashboard = function () {
            track.trackNextPage(track.PageEnum.Dashboard, app);

            app.redirectTo("/SelfService/CustomerDashboard");
        }

        self.GoToDashboardLeftMenu = R.compose(self.GoToDashboard, trackLeftMenuHomeLinkTotalClicks);

        self.goToManager = function () {
            track.trackNextPage(track.PageEnum.TransactionHistory, app);

            app.redirectTo("/SelfService/AccountConsumer#panel-transaction_refresh");
        }

        self.goToManagerLeftMenu = R.compose(self.goToManager, trackTransactionHistoryTotalLoadsFromLeftMenu, trackLeftMenuTransactionLinkTotalClicks);

        self.callPhoneFromLeftMenu = R.compose(app.callPhone, trackLeftMenuCallUsLinkTotalClicks);

        self.viewFAQsLeftMenu = R.compose(app.removeOpen, trackLeftMenuViewFAQsTotalClicks);

        self.helpCalterLeftMenu = R.compose(app.removeOpen, trackLeftMenuHelpCenterLinkTotalClicks);

        self.trackHelpCenterDropDown = trackLeftMenuHelpCenterLinkTotalClicks;

        self.GoToMoneyTransfer = function (startPositionCode) {
            if (startPositionCode == 'FromQuickTransaction') {
                cs.RemoveQuickTransactionPage();
            }
            else {
                cs.RemoveOpen();
            }

            if (self.Customer().CustomerBasic.IsShowDOBAndAddress()) {
                app.goToPersonalInfo("/SelfService/MoneyTransferConsumer/StartPositionCode/" + startPositionCode, cs.getShortUrlPath());

            } else {
                track.trackNextPage(track.PageEnum.SendMoney, app);
                app.redirectTo("/SelfService/MoneyTransferConsumer/StartPositionCode/" + startPositionCode);
            }
        };

        self.goToMoneyTransferFromLeftMenu = R.compose(self.GoToMoneyTransfer, R.always('FromLeftBar'));

        self.goToMoneyTransferFromLeftMenuWithTrack = R.compose(trackLeftMenuMoneyTransferLinkTotalClicks, self.goToMoneyTransferFromLeftMenu);

        var goToMoneyTransferFromQuickMenu = R.compose(self.GoToMoneyTransfer, R.always('FromQuickTransaction'));

        self.goToMoneyTransferFromQuickMenu = R.compose(trackQuickMenuMoneyTransferLinkTotalClicks, goToMoneyTransferFromQuickMenu);

        self.GoToMySetting = function () {
            track.trackNextPage(track.PageEnum.PersonalSettings, app);

            //if (app.page().name == 'Home_Settings-Consumer') {
            //    cs.triggerTab('panel-personal');
            //    $('body').toggleClass('open');
            //} else {
            app.redirectTo("/SelfService/SettingConsumer#panel-personal_refresh");
            //}
        };

        self.goToMySettingLeftMenu = R.compose(self.GoToMySetting, trackPersonSettingsTotalLoadsFromLeftMenu, trackLeftMenuPersonalSettingLinkTotalClicks);

        self.goToLogout = function () {
            track.trackNextPage(track.PageEnum.Logout, app);

            app.logout("#sidebar-logout");
        }

        self.goToLogoutLeftMenu = R.compose(self.goToLogout, trackLeftMenuLogoutLinkTotalClicks);

        self.GoToReferral = function () {
            track.trackNextPage(track.PageEnum.ReferralLandingPage, app);

            dataModel.goToReferral(self.Customer().CustomerBasic.CardHolderId());
        };

        self.goToReferralLeftMenu = R.compose(self.GoToReferral, trackLeftMenuReferralLinkTotalClicks, trackReferraFriendTotalLoadsFromLeftMenu);

        self.GoToPaymentMethod = function () {
            cs.RemoveOpen();
            //if (app.page().name == 'Home_Settings-Consumer') {
            //    cs.triggerTab('panel-payments');
            //    $('body').toggleClass('open');
            //} else {
            app.redirectTo("/SelfService/SettingConsumer#panel-payments_refresh");
            //}
        };

        self.GoToBillPayOrLCR = function (startPositionCode) {
            if (startPositionCode == 'FromQuickTransaction') {
                cs.RemoveQuickTransactionPage();
            }
            else {
                cs.RemoveOpen();
            }
            cs.RemoveOpen();
            if (self.Customer().CustomerBasic.IsShowDOBAndAddress()) {
                var nextPage;

                if (self.Customer().HasLCRBillPay()) {
                    nextPage = "/SelfService/BillPayLCRConsumer/StartPositionCode/" + startPositionCode;
                } else {
                    nextPage = "/SelfService/BillPayConsumer/StartPositionCode/" + startPositionCode;
                }

                app.goToPersonalInfo(nextPage, cs.getShortUrlPath());
            } else {
                track.trackNextPage(track.PageEnum.PayBills, app);
                if (self.Customer().HasLCRBillPay()) {
                    app.redirectTo("/SelfService/BillPayLCRConsumer/StartPositionCode/" + startPositionCode);
                } else {
                    app.redirectTo("/SelfService/BillPayConsumer/StartPositionCode/" + startPositionCode);
                }
            }
        };

        self.goToBillPayOrLCRFromLeftMenu = R.compose(self.GoToBillPayOrLCR, R.always('FromLeftBar'));

        self.goToBillPayOrLCRFromLeftMenuWithTrack = R.compose(trackLeftMenuBillPayOrLCRLinkTotalClicks, self.goToBillPayOrLCRFromLeftMenu);

        var goToBillPayOrLCRFromQuickMenu = R.compose(self.GoToBillPayOrLCR, R.always('FromQuickTransaction'));

        self.goToBillPayrRLCRFromQuickMenu = R.compose(trackQuickMenuBillPayLinkTotalClicks, goToBillPayOrLCRFromQuickMenu);

        self.goToTopUpReload = function (startPositionCode) {
            if (self.Customer().CustomerBasic.IsShowDOBAndAddress()) {
                app.goToPersonalInfo("/SelfService/TopUpsReloadConsumer/StartPositionCode/" + startPositionCode, cs.getShortUrlPath());

            } else {
                track.trackNextPage(track.PageEnum.Reload, app);
                app.redirectTo("/SelfService/TopUpsReloadConsumer/StartPositionCode/" + startPositionCode);
            }
        }

        var goToTopUpsReloadFromLeftMenu = R.compose(self.goToTopUpReload, R.always("FromLeftBar"));

        self.goToTopUpsReloadFromLeftMenu = R.compose(trackLeftMenuReloadLinkTotalClicks, goToTopUpsReloadFromLeftMenu);

        var goToTopUpsReloadFromQuickMenu = R.compose(self.goToTopUpReload, R.always("FromQuickTransaction"));

        self.goToTopUpsReloadFromQuickMenu = R.compose(goToTopUpsReloadFromQuickMenu, trackQuickMenuReloadLinkTotalClicks);

        self.goToTopUpsEpin = function (startPositionCode) {
            if (self.Customer().CustomerBasic.IsShowDOBAndAddress()) {
                app.goToPersonalInfo("/SelfService/TopUpsPurchaseConsumer/StartPositionCode/" + startPositionCode, cs.getShortUrlPath());

            } else {
                track.trackNextPage(track.PageEnum.EPin, app);
                app.redirectTo("/SelfService/TopUpsPurchaseConsumer/StartPositionCode/" + startPositionCode);
            }
        }

        var goToToUpsEpinFromLeftMenu = R.compose(self.goToTopUpsEpin, R.always("FromLeftBar"));

        self.goToToUpsEpinFromLeftMenu = R.compose(goToToUpsEpinFromLeftMenu, trackLeftMenuEpinLinkTotalClicks);

        var goToTopUpsEpinFromQuickMenu = R.compose(self.goToTopUpsEpin, R.always("FromQuickTransaction"));

        self.goToTopUpsEpinFromQuickMenu = R.compose(goToTopUpsEpinFromQuickMenu, trackQuickMenuEpinLinkTotalClicks);

        self.goToTopUpsPinless = function (startPositionCode) {
            track.trackNextPage(track.PageEnum.Pinless, app);

            app.redirectTo("/SelfService/TopUpsPinlessConsumer/StartPositionCode/" + startPositionCode);
        };

        var goToTopUpsPinlessFromLeftMenu = R.compose(self.goToTopUpsPinless, R.always('FromLeftBar'));

        self.goToTopUpsPinlessFromLeftMenu = R.compose(goToTopUpsPinlessFromLeftMenu, trackLeftMenuPinlessLinkTotalClicks);

        var goToTopUpsPinlessFromQuickMenu = R.compose(self.goToTopUpsPinless, R.always('FromQuickTransaction'));

        self.goToTopUpsPinlessFromQuickMenu = R.compose(goToTopUpsPinlessFromQuickMenu, trackQuickMenuPinlessLinkTotalClicks);

        self.CheckPermission = function (transactionTypeId) {
            if (transactionTypeId == 1 || transactionTypeId == 14 || transactionTypeId == 2 || transactionTypeId == 5 || transactionTypeId == 11) {//Money transfer bundle bill pay
                return self.HasMoneyTransferPermission();
            } else if (transactionTypeId == 12) {//TopUpReload and pinless
                return self.HasTopUpReloadPermission();
            } else if (transactionTypeId = 13) {//Epin
                return self.HasTopUpPurchasePermission();
            }

            return false;
        };

        self.HasMoneyTransferPermission = function () {
            return self.Customer().HasMoneyTransfer() && (self.Customer().HasLCRBillPay() || self.Customer().HasBillPay());
        };

        self.HasBillPayPermission = function () {
            return self.Customer().HasMoneyTransfer() && self.Customer().HasBillPay();
        };

        self.HasBillPayLCRPermission = function () {
            return self.Customer().HasMoneyTransfer() && self.Customer().HasLCRBillPay();
        };

        self.HasTopUpReloadPermission = function () {
            return self.Customer().HasTopUpReload();
        };

        self.HasTopUpPurchasePermission = function () {
            return self.Customer().HasTopUpPurchase();
        };

        self.HasTopUpPermission = function () {
            return self.Customer().HasTopUp();
        };

        self.getBuildVersion = function (element) {
            var hostName = localStorage.getItem("HostName");
            if (hostName) {
                $(element).html(hostName);
            }
            else {
                setTimeout(function () {
                    cs.BaseAjax({
                        url: '/Customers/GetBuildVersion',
                        type: "Get",
                        dataType: "json",
                        contentType: "application/json"
                    })
                    .done(function (data) {
                        var BuildVersionInformation = data.HostName + (!data.BuilderNumber ? "" : " - ") + data.BuilderNumber + data.AppVersion;
                        $(element).html(BuildVersionInformation);
                    })
                });
            }
        }

        self.GotoIncreaseLimit = function () {
            if (self.SenderLevel().Status == 0) {
                dataModel.openIncreaseSendingLimit(app.senderInfo().SenderLevel().SenderLevelId);
            } else if (self.SenderLevel().Status == 1) {
                dataModel.openPendingPrompt();
            } else if (self.SenderLevel().Status == 2) {
                dataModel.openSubmitPrompt(app.senderInfo().SenderLevel().SourceLevelId, app.senderInfo().SenderLevel().TargetLevelId);
            } else if (self.SenderLevel().Status == 3) {
                dataModel.openIncreaseSendingLimit(app.senderInfo().SenderLevel().SenderLevelId);
            }
        }

        self.goToIncreaseLimitLeftMenu = R.compose(self.GotoIncreaseLimit, trackLeftMenuIncreaseSendingLimitLinkTotalClicks);

        self.goToIncreaseLimitDashboard = R.compose(self.GotoIncreaseLimit, trackLeftMenuSendingLimitLinkTotalClicks);

        self.GotoFeeCalculator = function () {
            track.trackNextPage(track.PageEnum.CalculatorScreenPost, app);

            dataModel.openFeeCalculator();
        }

        self.gotoFeeCalculatorLeftMenu = R.compose(self.GotoFeeCalculator, trackLeftMenuFeeCalculatorLinkTotalClicks);

        self.GetSenderLevel = function (element) {
            return cs.AjaxBySpinnerOrLoading({
                url: '/Customers/GetSenderLevel',
                type: "GET"
            }, element)
            .done(function (data) {
                self.SenderLevel(data);
            });
        }

        self.initTutorial = trackTutorialTotalLoads;

        self.trackTutorialContinue = trackTutorialContinueTotalClicks;
    }
});