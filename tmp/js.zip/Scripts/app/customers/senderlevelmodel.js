﻿define(['knockout', 'ClientScript', 'app'], function (ko, cs, app) {
    return function SenderLevelModel(data, dataModel) {
        var self = this;

        ko.mapping.fromJS(data, {}, self);
        self.senderLevelDocumentExtensions = '.tif,.tiff,.bmp,.gif,.jpeg,.jpg,.jif,.jfif,.jp2,.jpx,.j2k,.j2c,.fpx,.pcd,.png,.doc,.docx,.txt,.rtf,.wps,.csv,.pdf,.xls,.xlsx';
        self.senderLevelDocumentSize = 15;
        self.UploadDocumentsFlag = ko.observable(false);

        self.showQuickPayCheckMesssage = ko.observable(false);

        self.FilterDocumentTypes = ko.computed(function () {
            if (!self.DocumentTypes()) {
                return self.DocumentTypes();
            }

            var tempDocuemntTypes = new Array();
            for (var i = 0; i < self.DocumentTypes().length; i++) {
                if (self.NeedToUpgradeLevelTwo() && !self.NeedToUpgradeLevelThree()) {
                    if (self.DocumentTypes()[i].SenderLevelInfoId() > self.SenderLevelId() && self.DocumentTypes()[i].SenderLevelInfoId() == 2) {
                        tempDocuemntTypes.push(self.DocumentTypes()[i]);
                    }
                } else if (!self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {
                    if (self.DocumentTypes()[i].SenderLevelInfoId() > self.SenderLevelId() && self.DocumentTypes()[i].SenderLevelInfoId() == 3) {
                        tempDocuemntTypes.push(self.DocumentTypes()[i]);
                    }
                } else {
                    if (self.DocumentTypes()[i].SenderLevelInfoId() > self.SenderLevelId()) {
                        tempDocuemntTypes.push(self.DocumentTypes()[i]);
                    }
                }
            }

            return tempDocuemntTypes;
        });

        var uploadWithUpgradeStatus = new cs.executeStatus();
        self.OpenUploadFileWithUpgrade = function (element) {
            if (uploadWithUpgradeStatus.isExecuting()) {
                return;
            }
            uploadWithUpgradeStatus.setExecuting();
            self.NeedToUpgradeLevelTwo(false);
            self.NeedToUpgradeLevelThree(false);
            $.when(cs.openModal("modal-m-upload"))
            .done(function () {
                uploadWithUpgradeStatus.complete();
            });
            self.OpenUploadFileModal(element);
        }

        var uploadWithSendEmailStatus = new cs.executeStatus();
        self.OpenUploadFileWithSendEmail = function (element) {
            if (uploadWithSendEmailStatus.isExecuting()) {
                return;
            }
            uploadWithSendEmailStatus.setExecuting();
            $.when(cs.openModal("modal-m-upload"))
            .done(function () {
                uploadWithSendEmailStatus.complete();
            });
            return $.when(SendEmailByToSpecialLevel(element))
           .done(function () {
               self.OpenUploadFileModal(element);
           });
        }

        function resetEmailModal() {
            cs.closeModalCallBack('modal-m-email', function () {
                $("#button-email-done,#button-upload-done").off("click.transaction");
            });
        }

        var emailWithUpgradeStatus = new cs.executeStatus();
        self.OpenEmailModalWithUpgrade = function (element) {
            if (emailWithUpgradeStatus.isExecuting()) {
                return;
            }
            emailWithUpgradeStatus.setExecuting();

            self.NeedToUpgradeLevelTwo(false);
            self.NeedToUpgradeLevelThree(false);
            $.when(cs.openModal("modal-m-email"))
            .done(function () {
                emailWithUpgradeStatus.complete();
            });

            self.OpenEmailModal(element);
        }


        self.OpenEmailModal = function (element) {
            resetEmailModal();
            self.GetSenderLevel(element);
        }

        function SendEmailByToSpecialLevel(element) {
            var upgradeToLevel = 0;
            if (self.NeedToUpgradeLevelTwo() && !self.NeedToUpgradeLevelThree()) {// need to upgrade level 2
                upgradeToLevel = 2;
            } else if (self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {//need to upgrade level 3
                upgradeToLevel = 3;
            } else if (!self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {// Current level is 2 ,need to upgrade level 3
                upgradeToLevel = 3;
            }

            return SendEmail(upgradeToLevel, element);
        };

        var emailWithSendEmailStatus = new cs.executeStatus();
        self.OpenEmailModalWithSendEmail = function (element) {
            if (emailWithSendEmailStatus.isExecuting()) {
                return;
            }
            emailWithSendEmailStatus.setExecuting();
            $.when(cs.openModal("modal-m-email"))
            .done(function () {
                emailWithSendEmailStatus.complete();
            });
            return $.when(SendEmailByToSpecialLevel(element))
           .done(function () {
               self.OpenEmailModal(element);
           });
        }

        function SendEmail(upgradeToLevel, element) {
            return cs.AjaxBySpinnerOrLoading({
                url: '/Customers/UpgradeRequestEmail',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "upgradeToLevel": upgradeToLevel })
            }, element)
        }


        function resetUploadFileModal() {
            cs.closeModalCallBack('modal-m-upload', function () {
                $("#button-email-done,#button-upload-done").off("click.transaction");
                if (self.UploadDocumentsFlag()) {
                    self.UploadDocumentsFlag(false);
                    return cs.AjaxByLoading({
                        url: '/Customers/ConfirmUploadDocumentEmail',
                        type: "POST"
                    });
                }
            });
        };

        self.OpenUploadFileModal = function (element) {
            resetUploadFileModal();
            self.GetSenderLevel(element);
            require(['jquery.ui.widget', 'jquery.iframe-transport', 'jquery.fileupload',
                    'jquery.postmessage-transport', 'jquery.xdr-transport']);
        };

        var upgradeStatus = new cs.executeStatus();
        self.OpenUpgradeModal = function () {
            if (upgradeStatus.isExecuting()) {
                return;
            }
            upgradeStatus.setExecuting();
            cs.HideSystemProfile();
            var deffered = $.Deferred();
            $.when(SendEmail(3, null))
            .done(function () {
                $.when(cs.openModal("modal-m-upgrade"))
                .done(function () {
                    upgradeStatus.complete();
                });
            })
            .fail(function () {
                upgradeStatus.complete();
            });

            return deffered;
        };

        self.GetSenderLevel = function (element) {
            return cs.AjaxBySpinnerOrLoading({
                url: '/Customers/GetSenderLevel',
                type: "GET"
            }, element)
            .done(function (data) {
                self.SenderLevelId(data.SenderLevelId);
                self.AvailableAmount(data.AvailableAmount);
                ko.mapping.fromJS(data.Documents, {}, self.Documents);
                ko.mapping.fromJS(data.DocumentTypes, {}, self.DocumentTypes);
            });
        }

        self.OpenStatusModal = function () {
            return cs.openModal("modal-m-status", true);
        }

        var addFiles = new Array();
        var totalFileSize;
        var isCanceled = false;
        self.ClickUpload = function (documentType, element) {
            addFiles = new Array();
            totalFileSize = 0;
            isCanceled = false;
            $('#upload-file').fileupload({
                url: '/Customers/UploadSenderLevelDocument',
                formData: { documentTypeId: documentType.DocumentTypeId() },
                add: function (e, data) {
                    if (isCanceled) {
                        return;
                    }

                    if (validFileExtension(data.originalFiles) == false) {
                        cs.showErrorMessage("Error", "We only allow the following extensions for upload: " + self.senderLevelDocumentExtensions.replace(/\./g, ' ').trim() + ".");
                        isCanceled = true;
                    } else
                        if (validFileSize(data.originalFiles) == false) {
                            cs.showErrorMessage("Error", "We do not allow any file image greater than " + self.senderLevelDocumentSize + " MB. Please try to use a lower resolution image or smaller document and try again.");
                            isCanceled = true;
                        } else {
                            totalFileSize += data.files[0].size;
                            addFiles.push(data);
                            if (addFiles.length == data.originalFiles.length) {
                                $('#progress').show();
                                $("#progress div").css("width", 0 + "%");
                                addFiles.shift().submit()
                            }
                        }
                },
                done: function (e, data) {
                    var html;
                    if (data.result[0].body) {
                        html = data.result[0].body.innerHTML;
                    }
                    else {
                        html = data.result;
                    }

                    var document = $.parseJSON(html);
                    if (document && document.DocumentTypeId != 0) {
                        var array = ko.mapping.toJS(app.senderInfo().SenderLevel().Documents);
                        if (array == null) {
                            array = new Array();
                        }

                        var isContain = false;
                        for (var i = 0; i < array.length; i++) {
                            if (array[i].DocumentTypeId == document.DocumentTypeId) {
                                isContain = true;
                                break;
                            }
                        }
                        if (isContain == false) {
                            array.push(document);
                            ko.mapping.fromJS(array, {}, self.Documents);
                        }
                    }

                    self.UploadDocumentsFlag(true);
                    if (addFiles.length > 0) {
                        addFiles.shift().submit();
                    } else {
                        if (document.UploadedFilesCount > 1) {
                            cs.showErrorMessage("Message", "Successfully uploaded " + document.UploadedFilesCount + " pages for " + documentType.DocumentTypeName());
                        } else {
                            cs.showErrorMessage("Message", "Successfully uploaded " + document.UploadedFilesCount + " page for " + documentType.DocumentTypeName());
                        }

                        self.GetSenderLevel(element);

                        $('#progress').hide();
                    }
                },
                fail: function (xhr, status) {
                    if (status.jqXHR) {
                        cs.handleAjaxError(status.jqXHR.responseText)
                    }

                    $('#progress').hide();
                },
                progressall: function (e, data) {
                    var totalProgress = data.loaded / totalFileSize * 100;
                    $("#progress div").css("width", totalProgress + "%");
                }
            });
            $(element).blur();
            $("#upload-file").click();

        };

        function validFileExtension(fileArray) {
            var isValid = true;
            for (var i = 0; i < fileArray.length; i++) {
                var fileName = fileArray[i].name;
                if (fileName.lastIndexOf(".") == -1) {
                    isValid = false;
                    break;
                }

                var extensionName = fileName.substring(fileName.lastIndexOf("."));
                if (self.senderLevelDocumentExtensions.toLowerCase().indexOf(extensionName.toLowerCase()) == -1) {
                    isValid = false;
                    break;
                }
            }

            return isValid;
        }

        function validFileSize(fileArray) {
            var isValid = true;
            for (var i = 0; i < fileArray.length; i++) {
                var file = fileArray[i];
                if (file.size <= 0 || file.size > self.senderLevelDocumentSize * 1024 * 1024) {
                    isValid = false;
                    break;
                }
            }

            return isValid;
        }

        self.TryToGetAmount = ko.observable(false);
        self.GetAmountLoading = ko.observable(false);
        self.GetAvailableBalance = function (element) {
            self.TryToGetAmount(false)
            self.GetAmountLoading(true);
            return cs.AjaxBySpinner({
                url: '/Customers/GetSenderAvailableBalance',
                type: "GET",
                dataType: "json",
                contentType: "application/json"
            }, element)
            .done(function (data) {
                self.GetAmountLoading(false);
                self.AvailableAmount(data);
            })
            .fail(function (data) {
                self.GetAmountLoading(false);
                self.TryToGetAmount(true);
            });
        };

        self.SetQuickPayOnHold = function (isShow) {
            self.showQuickPayCheckMesssage(isShow);
            self.IsOnHold(false);
        };

        // isNormalBP & isRppsBillingAccount only for Normal BP limitation check.
        self.CheckTransactionAmount = function (transactionTypeId, amountToSend, isQuickPay, isNormalBP, isRppsBillingAccount, element, isNeedHandleError, billingAccountId) {
            if (!cs.isAmountValid(amountToSend)) {
                return $.Deferred().reject();
            }

            var deferred = $.Deferred();
            cs.AjaxBySpinnerOrLoading({
                url: '/Customers/CheckTransactionAmount',
                datType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    "transactionTypeId": transactionTypeId,
                    "amountToSend": cs.GetOriginalNumber(amountToSend),
                    "isNormalBP": isNormalBP,
                    "isRppsBillingAccount": isRppsBillingAccount,
                    "billingAccountId": billingAccountId
                })
            }, element, isNeedHandleError)
            .done(function (data) {
                if (transactionTypeId == 11 || transactionTypeId == 5) {// for bill pay
                    deferred.resolve();
                    return;
                }

                ko.mapping.fromJS(data, {}, self);
                if (self.showQuickPayCheckMesssage() == true) {
                    self.IsOnHold(false);
                }

                if (self.OverMaxLimitAmount() > 0) {
                    cs.showErrorMessage("Error", 'You’ve exceeded your sending limits. Please contact Customer Care at 1-855-398-2569');
                    deferred.reject();
                } else if (!self.showQuickPayCheckMesssage() && !self.IsOnHold()) {
                    deferred.resolve();
                } else if (self.NeedToUpgradeLevelTwo() && !self.NeedToUpgradeLevelThree()) {// need to upgrade level 2
                    self.OpenStatusModal();
                    $("#button-email-done,#button-upload-done").off("click.transaction");
                    $("#button-email-done,#button-upload-done").one("click.transaction", function () {
                        //if (isQuickPay == true) {
                        self.showQuickPayCheckMesssage(false);
                        self.IsOnHold(true);
                        //}

                        deferred.resolve();
                    });
                } else if (self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {//need to upgrade level 3
                    self.OpenStatusModal();
                    $("#button-email-done,#button-upload-done").off("click.transaction");
                    $("#button-email-done,#button-upload-done").one("click.transaction", function () {
                        //if (isQuickPay == true) {
                        self.showQuickPayCheckMesssage(false);
                        self.IsOnHold(true);
                        //}

                        deferred.resolve();
                    });
                } else if (!self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {// Current level is 2 ,need to upgrade level 3
                    $.when(self.OpenStatusModal())
                    .done(function () {
                        cs.addDisable("upload-passport");
                    });
                    $("#button-email-done,#button-upload-done").off("click.transaction");
                    $("#button-email-done,#button-upload-done").one("click.transaction", function () {
                        //if (isQuickPay == true) {
                        self.showQuickPayCheckMesssage(false);
                        self.IsOnHold(true);
                        //}

                        deferred.resolve();
                    });
                } else {
                    self.showQuickPayCheckMesssage(false);
                    self.IsOnHold(false);
                    deferred.resolve();
                }
            })
            .fail(function (xhr, status) {
                deferred.reject(xhr, status);
            });
   
            return deferred;
        }
    }
});