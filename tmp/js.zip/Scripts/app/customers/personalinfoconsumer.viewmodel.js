﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], paths['PersonalInfoConsumer-strings'], paths['SettingsConsumer-strings'], 'R', 'TrackEvent', 'knockout.validation', 'knockout.validation.extended'], function (ko, cs, app, dataModel, commonstrings, personalinfostrings, settingconsumerstrings, R, track) {
    function PersonalInfoConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.personalinfo;
        self.isReady = ko.observable(false);
        self.CustomerBasic = ko.observable(null);

        self.IsShowNameInformation = ko.observable(false);
        self.IsShowDateOfBirth = ko.observable(false);
        self.IsShowAddressInformation = ko.observable(false);

        self.prePage = "";
        self.preStartPositionCode = "";
        self.nextPage = "";
        self.nextStartPositionCode = "";

        self.CityValidateType = ko.observable(0);
        ko.computed(function () {
            var cityValidType = self.CityValidateType();

            if (cityValidType==1) {
                self.trackErrorMessage(commonstrings.address.validations.cityrequired);
            } else if (cityValidType == 2) {
                self.trackErrorMessage(commonstrings.address.validations.cityvalide);
            }
        });

        var addressListOfDOBAddress = new Array();

        self.init = function () {
        };

        self.dispose = function () {
            delete app.senderInfo().tempReceiver;
            delete app.senderInfo().tempBillingAccount;

            track.clearTrackErrorMessage();
        };

        self.smartStreetIds = {
            SelectCityId: "#input-city",
            SelectStateId: "#input-state",
            Address01Id: "#input-address1",
            Address02Id: "#input-address2",
            ZipcodeId: "#input-zip"
        };

        self.controllers = {
            '/': function () {
                if (app.senderInfo() && app.senderInfo().Customer() && app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                    initPersonalInfo();
                } else {
                    self.LoadedSenderInfo = function () {
                        initPersonalInfo();
                    }
                }
            }
        };

        // Start appsflyer track event
        //app flyer

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PersonalInformation,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.PersonalInformation,
                source: app.page().name
            });
        }

        var trackPersonalInfoTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.PersonalInformation,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Personal Information Screen",
                eventPage: track.PageEnum.PersonalInformation,
                source: app.page().name
            });
        }

        var trackTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.PersonalInformation,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.PersonalInformation,
                source: app.page().name
            });
        }

        var trackSaveAndContinueTotalClicks = R.compose(trackEvent, R.always('Save and Continue'));

        var trackCancelTotalClicks = R.compose(trackEvent, R.always('Cancel'));

        self.trackErrorMessage;
        // End appsflyer track event

        self.afterRender = function () {
            trackPersonalInfoTotalLoads();

            trackTimeOnPage();

            self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.PersonalInformation, track.PageEnum.PersonalInformation);
        };

        function initPersonalInfo() {
            var data = app.senderInfo().Customer().CustomerBasic;
            var tempCustomerBasic = ko.mapping.toJS(data);
            self.CustomerBasic = ko.mapping.fromJS(tempCustomerBasic);

            self.initializeForDOBAndAddress();
            self.CustomerBasic.CountryId(840);
            $.when(dataModel.GetStatesByCountryId(840))
            .done(function (data) {
                var states = ko.mapping.toJS(data);
                ko.mapping.fromJS(states, {}, self.CustomerBasic.States);

                var tempStates;
                if (self.isMobile()) {
                    tempStates = $.map(states, function (item, index) {
                        return {
                            value: item.Code,
                            data: { Text: item.Text, Value: item.Value, Code: item.Code, CountryId: item.CountryId }
                        }
                    });
                } else {
                    tempStates = $.map(states, function (item, index) {
                        return {
                            value: item.Text,
                            data: { Text: item.Text, Value: item.Value, Code: item.Code, CountryId: item.CountryId }
                        }
                    });
                }

                var containerClass = "autocomplete-suggestions personal-info-auto-address";

                require(['Plugins'], function () {
                    GetStateElement().autocomplete({
                        lookup: tempStates,
                        triggerSelectOnValidInput: true,
                        minChars: 1,
                        maxHeight: 220,
                        containerClass: containerClass,
                        onSelect: function (suggestion) {
                            updateCustomerBasicStateChanged(suggestion);
                        },
                        lookupFilter: function (k, j, l) {
                            var inputValue = (cs.removeDiacritics(l).toLowerCase());
                            return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1;
                        }
                    });
                    GetStateElement().autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                });
            })

            self.isReady(true);
        }

        function SetDefaultState(defaultStateId, autocomplete) {
            if (!autocomplete) {
                return;
            }

            var defaultState;
            $.each(autocomplete.options.lookup, function (index, item) {
                if (defaultStateId == item.data.Value) {
                    defaultState = item;
                    return false;
                }
            })

            autocomplete.selection = defaultState;
            autocomplete.currentValue = defaultState.value;
            autocomplete.el.val(defaultState.value);
            originalState = defaultState.value;
        }

        var originalState = "";
        function updateCustomerBasicStateChanged(suggestion) {
            self.StateValidateType(0);

            if (GetStateElement().val() == originalState && !!updateCustomerCities) {
                return;
            }

            self.CustomerBasic.City("");
            self.CityValidateType(0);
            self.CustomerBasic.StateId(suggestion.data.Value);
            self.CustomerBasic.State(suggestion.data.Text);
            originalState = GetStateElement().val();

            self.GetCitiesByStateId();
        }

        self.StateValidateType = ko.observable(0);

        self.computedState = ko.computed({
            read: function () {

            },
            write: function (value) {
                if (!value) {
                    self.StateValidateType(0);
                } else if (isMatchState(value, false, self.isMobile())) {
                    self.StateValidateType(0);
                } else {
                    self.StateValidateType(2);
                }

                if (self.StateValidateType() == 1) {
                    self.trackErrorMessage(commonstrings.address.validations.staterequired);
                } else if (self.StateValidateType() == 2) {
                    self.trackErrorMessage(commonstrings.address.validations.entervalidstate);
                }
            }
        })

        function isMatchState(value, isExact, isMobile) {
            if (!self.CustomerBasic.States() || self.CustomerBasic.States().length == 0) {
                return false;
            }

            var isMatch = false;
            if (isMobile) {
                if (isExact) {
                    $.each(self.CustomerBasic.States(), function (index, item) {
                        if (value == item.Code()) {
                            isMatch = true;
                            return false;
                        }
                    })
                } else {
                    $.each(self.CustomerBasic.States(), function (index, item) {
                        if (item.Code().toUpperCase().indexOf(value.toUpperCase()) != -1) {
                            isMatch = true;
                            return false;
                        }
                    })
                }
            } else {
                if (isExact) {
                    $.each(self.CustomerBasic.States(), function (index, item) {
                        if (value == item.Text()) {
                            isMatch = true;
                            return false;
                        }
                    })
                } else {
                    $.each(self.CustomerBasic.States(), function (index, item) {
                        if (item.Text().toUpperCase().indexOf(value.toUpperCase()) != -1) {
                            isMatch = true;
                            return false;
                        }
                    })
                }
            }

            return isMatch;
        }

        var dateBefore = getNowFormatDate();
        self.afterRenderAddDOBAndAddressPage = function () {
            if (cs.IsIpad()) {
                $("#dob-body").addClass('dob-body-max-height');
            }
            cs.datepickerFormat();
            cs.addPlaceHolderToDate();
            self.RemoveValidationMessage();
            self.ResetDOBAndAddress();

            self.flag = 0;
            if (!cs.IsMobileDevice()) {
                initDOBDatePicker();
            } else {
                if (cs.IsIOS()) {
                    self.CustomerBasic.DateOfBirth(dateBefore);
                    $("#input-birth-day").off("focus").on("focus", function () {
                        SetOrRemoveDatePlaceHolder();
                        $("#date-error").addClass("dislpay-none");
                    });

                    $(".placeholder-button").off("focus").on("focus", function () {
                        SetOrRemoveDatePlaceHolder();
                        $("#date-error").addClass("dislpay-none");
                        $("#input-birth-day").focus();
                    });

                    $("#input-birth-day").off("input propertychange").on("input propertychange", function () {
                        SetOrRemoveDatePlaceHolder();
                        if ($(this).hasClass("error")) {
                            $(".placeholder-button").addClass("error");
                        } else {
                            $(".placeholder-button").removeClass("error");
                        }
                    });

                    $("#input-birth-day").off("blur").on("blur", function () {
                        if ($("#input-birth-day").val().length == 0) {
                            self.CustomerBasic.DateOfBirth(dateBefore);
                            $("#date-error").removeClass("dislpay-none");
                        }
                    });
                }
                else {
                    $("#input-birth-day").off("input propertychange").on("input propertychange", function () {
                        UpdateDateOfBirthStatus();
                    }).off("blur").on("blur", function () {
                        if (!self.CustomerBasic.DateOfBirth.isModified()) {
                            $(this).trigger("change");
                        }
                    });

                    $("#input-birth-day").off("blur").on("blur", function () {
                        if (!$(this).val()) {
                            $(".text-placeholder").css("display", "block");
                        }
                    });

                    $("#input-birth-day").off("focus").on("focus", function () {
                        if (!$("#input-birth-day").val()) {
                            var date = getNowFormatDate();
                            $("#input-birth-day").val(date);
                            self.CustomerBasic.DateOfBirth(date);
                            UpdateDateOfBirthStatus();
                        }
                    });

                    $(".text-placeholder").off("focus").on("focus", function () {
                        $(this).nextAll(".label-placeholder").click();
                    });

                    $("#input-last-name").off("keydown").on("keydown", function (e) {
                        if (e.keyCode == 13) {
                            if (!$("#input-birth-day").val()) {
                                var date = getNowFormatDate();
                                $("#input-birth-day").val(date);
                                self.CustomerBasic.DateOfBirth(date);
                                UpdateDateOfBirthStatus();
                            }
                        }
                    });
                }
            }

            if (self.IsShowAddressInformation()) {
                self.GetCitiesByStateId(null);

                var element = GetCityElement();
                element.off("input.validatecity")
                .on("input.validatecity", function () {
                    var value = element.val();
                    if (value == "") {
                        return;
                    }
                    if (cs.isMatchSuggestion(updateCustomerCities, value, false) > -1) {
                        self.CityValidateType(0);
                    }
                    else {
                        self.CityValidateType(2);
                    }
                })
                .off("blur.validatecity")
                .on("blur.validatecity", function () {
                    if ($('.autocomplete-selected').length > 0) return;

                    var city = element.val();
                    var validAutocompleteCity = cs.setCityValidateType(self.CityValidateType, element, updateCustomerCities);
                    if (validAutocompleteCity[0]) {
                        self.CustomerBasic.CityId(validAutocompleteCity[1]);
                    }

                    if (element.autocomplete()) {
                        element.autocomplete().hide();
                    }
                })
                .off("focus.validatecity")
                .on("focus.validatecity", function () {
                    if (element.autocomplete().visible) {
                        self.CityValidateType(0);
                    }
                })

                GetStateElement().off("blur.validateState")
                .on("blur.validateState", function () {
                    var state = GetStateElement().val();
                    if ($('.autocomplete-selected').length > 0) {
                        self.StateValidateType(0);
                    } else if (!state) {
                        self.StateValidateType(1);

                        GetCityElement().autocomplete({
                            lookup: []
                        });
                        GetCityElement().val("");
                        self.CityValidateType(0);
                        updateCustomerCities = null;
                        self.CustomerBasic.City("");
                    } else if (isMatchState(state, true, self.isMobile())) {
                        self.StateValidateType(0);
                    } else {
                        self.StateValidateType(2);
                    }
                })

                addressListOfDOBAddress.push($("#input-address1"), $("#input-address2"), $("#input-city"),
                    $("#input-state"), $("#input-zip"));
                cs.RemoveBorderAndMessage(addressListOfDOBAddress, $("#ValidateAddressMessage"));
            }
        }

        self.RemoveValidationMessage = function () {
            if (self.IsShowNameInformation()) {
                self.CustomerBasic.TempFirstName.isModified(false);
                self.CustomerBasic.TempLastName.isModified(false);
            }

            if (self.IsShowAddressInformation()) {
                self.CustomerBasic.Address.isModified(false);
                self.CustomerBasic.CityId.isModified(false);
                self.CustomerBasic.CountryId.isModified(false);
                self.CustomerBasic.Zipcode.isModified(false);
            }

            if (self.IsShowDateOfBirth()) {
                self.CustomerBasic.DateOfBirth.isModified(false);
            }
        }

        self.ResetDOBAndAddress = function () {
            if (self.IsShowAddressInformation()) {
                self.NoMatchSuggestionError(0);
                self.CustomerBasic.Address("");
                self.CustomerBasic.Address2("");
                self.CustomerBasic.Zipcode("");
                self.CustomerBasic.Address.isModified(false);
                self.CustomerBasic.Zipcode.isModified(false);
            };

            if (self.IsShowNameInformation()) {
                self.CustomerBasic.TempFirstName("");
                self.CustomerBasic.TempMiddleName("");
                self.CustomerBasic.TempLastName("");
                self.CustomerBasic.TempFirstName.isModified(false);
                self.CustomerBasic.TempLastName.isModified(false);
            }

            if (self.IsShowDateOfBirth()) {
                self.CustomerBasic.DateOfBirth("");

                self.CustomerBasic.DateOfBirth.isModified(false);
            }
        };

        var emptyBeforeBlur = false;
        function initDOBDatePicker() {
            var enterToNext = cs.enterToNext;
            var datepicker = $("#input-birth-day");
            require(['Foundation.DatePicker'], function () {
                datepicker.fdatepicker({
                    language: getCookie('Language') || "en-US",
                    appendElement: datepicker.parents()[1],
                    container: datepicker.closest("form[auto-slide-input]"),
                    startDate: new Date('01/01/1920'),
                    forceParse: false
                });

                $(".datepicker").off("click.moveToNext").on("click.moveToNext", ".day", function () {
                    var element = datepicker[0];
                    enterToNext.moveToNext(element, enterToNext.findNextElement(element));
                });

                $("#input-birth-day").off('focus').on('focus', function () {
                    if (!$(this).val()) {
                        var str = getNowFormatDate();
                        var d = new Date(str.replace(/-/g, "/"));
                        $("#input-birth-day").fdatepicker('setDate', d);
                    }
                    $(this).fdatepicker("show");
                });


                $("#input-birth-day").off('change').on('change', function (e) {
                    if (!$(this).val()) {
                        emptyBeforeBlur = true;
                    }
                    if (self.flag == 1) {
                        self.CustomerBasic.DateOfBirth($(this).val());
                    }
                    if (self.flag != 0 && !self.CustomerBasic.DateOfBirth.isModified()) {
                        self.CustomerBasic.DateOfBirth.isModified(true);
                    }
                });

                $("#input-birth-day").off('blur').on('blur', function () {
                    self.flag = 1;
                    if (emptyBeforeBlur) {
                        var str = getNowFormatDate();
                        var d = new Date(str.replace(/-/g, "/"));
                        $("#input-birth-day").fdatepicker('setDate', d);
                        $("#input-birth-day").val(getNowFormatDate(true));
                        emptyBeforeBlur = false;
                    }

                    if (self.flag == 1) {
                        self.CustomerBasic.DateOfBirth($(this).val());
                    }
                    if (self.flag != 0 && !self.CustomerBasic.DateOfBirth.isModified()) {
                        self.CustomerBasic.DateOfBirth.isModified(true);
                    }
                });

                $("#input-birth-day").off('click').on('click', function () {
                    if (!$(this).val()) {
                        var str = getNowFormatDate();
                        var d = new Date(str.replace(/-/g, "/"));
                        $("#input-birth-day").fdatepicker('setDate', d);
                    }
                });
            });
        }

        function getNowFormatDate(isSeperator1) {
            var date = new Date();
            var seperator1 = "\/";
            var seperator2 = "-";
            var year = date.getFullYear();
            year = year - 18;
            var month = date.getMonth() + 1;
            var strDate = date.getDate();
            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            var currentdate = year + seperator2 + month + seperator2 + strDate;

            if (isSeperator1) {
                currentdate = month + seperator1 + strDate + seperator1 + year;
            }
            return currentdate;
        }

        function SetOrRemoveDatePlaceHolder() {
            if ($("#input-birth-day").val().length == 0) {
                self.CustomerBasic.DateOfBirth($("#input-birth-day").val());
                $(".placeholder-button").removeClass("display-none");
                $("#input-birth-day").css("opacity", "0");
            } else {
                $(".placeholder-button").addClass("display-none");
                $("#input-birth-day").css("opacity", "1");
            }
        }

        function UpdateDateOfBirthStatus() {
            if (self.flag != 0 && !self.CustomerBasic.DateOfBirth.isModified()) {
                self.CustomerBasic.DateOfBirth.isModified(true);
            }

            if (self.flag == 1) {
                self.CustomerBasic.DateOfBirth($("#input-birth-day").val());
            }

            if (!$("#input-birth-day").val()) {
                $(".text-placeholder").css("display", "block");
            }

            self.flag = 1;
        }

        self.initializeForDOBAndAddress = function () {
            self.CustomerBasic.TempFirstName = ko.observable("");
            self.CustomerBasic.TempMiddleName = ko.observable("");
            self.CustomerBasic.TempLastName = ko.observable("");

            if (!(self.CustomerBasic.FirstName().trim() && self.CustomerBasic.LastName().trim())) {
                self.IsShowNameInformation(true);
                self.ApplyCustomerBasicNameInformation();
            }

            if (self.CustomerBasic.DateOfBirth() == '01/01/1753' || self.CustomerBasic.DateOfBirth() == "") {
                self.CustomerBasic.DateOfBirth("");
                self.IsShowDateOfBirth(true);
                self.ApplyCustomerBasicDateOfBithValidation();
            }

            if (self.CustomerBasic.CountryId() < 1 || self.CustomerBasic.StateId() < 1 || self.CustomerBasic.CityId() < 1 ||
                !self.CustomerBasic.Address() || !self.CustomerBasic.Zipcode()) {
                self.IsShowAddressInformation(true);
                self.ApplyCustomerBasicAddressValidation();
            }
        }

        self.ApplyCustomerBasicNameInformation = function () {
            self.CustomerBasic.TempFirstName.extend({
                //Inline message
                required: { params: true, message: commonstrings.commonvalidation.firstnamerequired },
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.CustomerBasic.TempFirstName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.CustomerBasic.TempFirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
                }
            }).isModified(false);

            self.CustomerBasic.TempMiddleName.extend({
                //Inline message
                maxLength: { params: 50, message: personalinfostrings.validation.middlenamemaxlength },
                equal: {
                    onlyIf: function () { return self.CustomerBasic.TempMiddleName() != "" && cs.IsInvalidName(self.CustomerBasic.TempMiddleName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.CustomerBasic.TempMiddleName()) == 1 ? personalinfostrings.validation.middlenamestart : personalinfostrings.validation.middlenameinvalid }
                }
            }).isModified(false);

            self.CustomerBasic.TempLastName.extend({
                //Inline message
                required: { params: true, message: commonstrings.commonvalidation.lastnamerequired },
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.CustomerBasic.TempLastName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.CustomerBasic.TempLastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
                }
            }).isModified(false);
        };

        self.ApplyCustomerBasicAddressValidation = function () {

            self.CustomerBasic.Address.extend({
                //Inline message
                required: { params: true, message: commonstrings.address.validations.addressrequired }
            }).isModified(false);
            self.CustomerBasic.CityId.extend({
                //Inline message
                required: { params: true, message: commonstrings.address.validations.cityrequired }
            }).isModified(false);
            self.CustomerBasic.CountryId.extend({
                //Inline message
                required: { params: true, message: commonstrings.address.validations.countryrequired }
            }).isModified(false);
            self.CustomerBasic.Zipcode.extend({
                //Inline message
                required: { params: true, message: commonstrings.address.validations.zipcoderequired },
                number: { params: true, message: commonstrings.address.validations.zipcodevalid },
                minLength: { params: 5, message: commonstrings.address.validations.zipcodeminlength },
                maxLength: { params: 5, message: commonstrings.address.validations.zipcodemaxlength }
            }).isModified(false);
        };

        self.ApplyCustomerBasicDateOfBithValidation = function () {
            self.CustomerBasic.DateOfBirth.extend({
                //Inline message
                required: { params: true, message: commonstrings.address.validations.dataofbirthrequired },
                isMinDate: {
                    //Inline message
                    params: 'MinDate',
                    message: personalinfostrings.validation.selectdate
                },
                isValidDate: {
                    //Inline message
                    params: 'DateOfBirth',
                    message: personalinfostrings.validation.userage
                }
            }).isModified(false);
        };

        self.showDefaultCity = true;
        var updateCustomerCities;

        self.GetCitiesByStateId = function (displayCityName) {
            var countryId = self.CustomerBasic.CountryId();
            var stateId = self.CustomerBasic.StateId();
            $.when(dataModel.GetCitiesByStateId(countryId, stateId))
            .done(function (result) {
                updateCustomerCities = result;
                if (!self.showDefaultCity) {
                    GetCityElement().val("");

                    self.CustomerBasic.Zipcode("");
                    self.CustomerBasic.Zipcode.isModified(false);
                }
                else {
                    self.showDefaultCity = false;
                    GetCityElement().val(self.CustomerBasic.City());

                    if (displayCityName && typeof displayCityName === "string") {
                        GetCityElement().val(displayCityName);

                        var newCityId = ""
                        for (var j = 0; j < result.length; j++) {
                            if (result[j].value == displayCityName) {
                                newCityId = result[j].data.Value;
                                break;
                            }
                        }
                        self.CustomerBasic.CityId(newCityId);
                    }
                }

                var containerClass = "autocomplete-suggestions personal-info-auto-address";
                require(['Plugins'], function () {
                    GetCityElement().autocomplete({
                        lookup: result,
                        triggerSelectOnValidInput: true,
                        minChars: 1,
                        maxHeight: 220,
                        containerClass: containerClass,
                        onSelect: function (suggestion) {
                            UpdateCustomerBasicCityChanged(suggestion);
                        },
                        lookupFilter: function (k, j, l) {
                            var inputValue = (cs.removeDiacritics(l).toLowerCase());
                            return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1;
                        }
                    });
                    GetCityElement().autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                });
            });
        }

        function UpdateCustomerBasicCityChanged(suggestion) {
            self.CustomerBasic.City(suggestion.value);
            self.CustomerBasic.CityId(suggestion.data.Value);
            self.CityValidateType(0);
        }

        self.ClearAddressInfo = function () {
            self.NoMatchSuggestionError(0);
            self.CustomerBasic.Address("");
            self.CustomerBasic.Address.isModified(false);

            self.CustomerBasic.StateId(null);
            GetStateElement().val("");
            self.StateValidateType(0);
            originalState = "";

            GetCityElement().val("");
            self.CityValidateType(0);
            self.CustomerBasic.Zipcode("");
            self.CustomerBasic.Zipcode.isModified(false);

            $('#input-address1').autocomplete({
                lookup: []
            });
            // Clear error message.
            $('#input-address1').trigger('input');
            GetCityElement().autocomplete({
                lookup: []
            });

            $("#address-clear").hide();
            $("#input-address1").focus();
        }

        self.ShowAddressControl = function (element) {
            var value = $(element).val();
            if (value && value.length > 0) {
                $("#address-clear").show();
            }
            else {
                $("#address-clear").hide()
            }
        }

        self.HideAddressControl = function (element, event) {
            if ($('.autocomplete-selected').length > 0) return;

            $('#input-address1').autocomplete("hide");
        }

        var timeHandler = 0;
        // 1 zip type is not standard
        // 2 city not found
        self.NoMatchSuggestionError = ko.observable(0);
        ko.computed(function () {
            var matchCode = self.NoMatchSuggestionError();
            if (matchCode === 1) {
                self.trackErrorMessage(commonstrings.address.validations.zipcodeerror);
            } else if (matchCode === 2) {
                self.trackErrorMessage(commonstrings.address.validations.citynotfound);
            }
        });

        self.AutoSearchSuggestion = function (element, data, e) {
            if (cs.isKeyPressControlOrSelect(e.which) || e.which == 13) {
                return;
            }

            $('#input-address1').autocomplete({
                lookup: [],
                showNoSuggestionNotice: false
            });
            self.NoMatchSuggestionError(0);

            var value = $(element).val();
            clearTimeout(timeHandler);

            if (value && value.length > 0) {
                timeHandler = setTimeout(function () {
                    $("#address-clear").show();

                    AutoSearchSuggestion(element, value);
                }, 500);
            }
            else {
                $("#address-clear").hide();
            }
        }

        function AutoSearchSuggestion(element, streetName) {
            $.when(dataModel.GetAutoCompleteSuggestionAddresses(streetName))
            .done(function (result) {
                /*For DataCapture*/
                if (result && result.length == 0) {
                    cs.LogInformationOfAddressSearch($(element).val(), false /*false stand for no recoeds found*/);
                }

                var containerClass = "autocomplete-bold personal-info-auto-address";
                BindingAutoSuggestionAddress(element, result, containerClass);
            });
        }

        function BindingAutoSuggestionAddress(bindingElement, lookup, containerClass) {
            $(bindingElement).autocomplete({
                lookup: lookup,
                minChars: 1,
                showNoSuggestionNotice: true,
                containerClass: containerClass,
                triggerSelectOnValidInput: false,
                noSuggestionNotice: "No suggestions found",
                onSelect: function (suggestion) {
                    $(bindingElement).blur();
                    self.NoMatchSuggestionError(0);
                    $(bindingElement).val(suggestion.data.StreetName);
                    self.CustomerBasic.Address(suggestion.data.StreetName);

                    $.when(dataModel.GetAddressAutocompleteDetails(suggestion))
                    .done(function (result) {
                        if (result && result.ResultAddress && result.ResultAddress.Analysis.DpvMatchCode != null && result.ResultAddress.Analysis.DpvMatchCode != 'N') {

                            var address = result.ResultAddress;
                            var resultStreet = address.DeliveryLine1;
                            self.CustomerBasic.Address(resultStreet);
                            $(bindingElement).val(resultStreet);

                            var resultSecondStreet = address.DeliveryLine2;
                            var resultCity = address.Components.CityName;
                            var resultState = address.Components.StateAbbreviation;
                            var resultZipcode = address.Components.Zipcode;

                            var isCityMatchSuggestion = true;
                            if (address.Metadata.ZipType != 'Standard') {
                                cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.address.validations.zipcodeerror, function () {
                                    $.when(cs.closeModal())
                                    .done(function () {
                                        isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, null, function () {
                                            if (resultZipcode && resultZipcode != "") {
                                                self.CustomerBasic.Zipcode(resultZipcode);
                                            }
                                            $("#input-city").focus();
                                        });

                                        setTimeout(function () {
                                            $("#input-zip").focus();
                                        }, 300);
                                    });
                                });

                                self.trackErrorMessage(commonstrings.address.validations.zipcodeerror);
                            }
                            else {
                                isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, function () {
                                    self.CustomerBasic.Zipcode(resultZipcode);
                                    setTimeout(function () {
                                        $("#input-address2").focus();
                                    }, 100);
                                }, function () {
                                    if (resultZipcode && resultZipcode != "") {
                                        self.CustomerBasic.Zipcode(resultZipcode);
                                    }
                                    $("#input-city").focus();
                                });
                            }

                            if (!isCityMatchSuggestion) {
                                result.ResultAddress.Components.CityName = "";
                            }

                            //For datacapture. Log address validate.
                            cs.LogAddressValidate(result, true);
                        }
                        else {
                            var lastLine = cs.getSmartStreetLastLine(suggestion.data.City, suggestion.data.State, $("#input-zip").val());
                            var message = cs.getAutoCompleteAddressInvalidMessage(suggestion.data.StreetName, $("#input-address2").val(), lastLine);
                            cs.ShowCustomMessage(function () {

                                //For datacapture. Log address validate.
                                result.ResultAddress.DeliveryLine1 = suggestion.data.StreetName;
                                result.ResultAddress.Components.CityName = suggestion.data.City;
                                result.ResultAddress.Components.StateAbbreviation = suggestion.data.State;
                                for (var i = 0; i < self.CustomerBasic.States().length; i++) {
                                    var state = self.CustomerBasic.States()[i];
                                    if (state.Code() == suggestion.data.State) {
                                        result.ResultAddress.Metadata.CountyName = state.Text();
                                        break;
                                    }
                                }

                                var isCityMatchSuggestion = FillAddressStateAndCity(suggestion.data.State, suggestion.data.City, function () {
                                    setTimeout(function () {
                                        $("#input-address2").focus();
                                    }, 100);
                                }, function () {
                                    setTimeout(function () {
                                        $("#input-city").focus();
                                    }, 300);
                                });

                                if (!isCityMatchSuggestion) {
                                    result.ResultAddress.Components.CityName = "";
                                }

                                cs.LogAddressValidate(result, false);
                            }, function () {
                                setTimeout(function () {
                                    $("#input-address1").focus();
                                }, 300);
                            }, message);
                        }
                    })
                }
            });

            $(bindingElement).autocomplete().getSuggestionsLocal = function (query) {
                return { suggestions: this.options.lookup };
            }

            if (document.activeElement && document.activeElement.id == bindingElement.id) {
                $(bindingElement).focus();
            }
        }

        function FillAddressStateAndCity(resultState, resultCity, addtionalField, addtionalFocus) {
            var stateId = dataModel.GetStateId(resultState, self.CustomerBasic.States());

            if (self.isMobile()) {
                GetStateElement().val(resultState);
                originalState = resultState;
            } else {
                var state = dataModel.GetStateWithAbbreviation(resultState, self.CustomerBasic.States());
                GetStateElement().val(state);
                originalState = state;
            }

            self.StateValidateType(0);

            var isCityMatchSuggestion = true;
            if (stateId && stateId != 0) {
                self.CustomerBasic.StateId(stateId);
                $.when(self.GetCitiesByStateId(""))
                .done(function () {
                    if (cs.isMatchSuggestion(updateCustomerCities, resultCity, false) > -1) {
                        var city = dataModel.GetCity(resultCity, updateCustomerCities);
                        UpdateCustomerBasicCityChanged(city);
                        GetCityElement().val(resultCity);
                        if (typeof addtionalField == 'function') {
                            addtionalField();
                        }

                        isCityMatchSuggestion = true;
                    }
                    else {
                        self.CustomerBasic.StateId(stateId);
                        if (typeof addtionalFocus == 'function') {
                            addtionalFocus();
                        }

                        isCityMatchSuggestion = false;
                    }
                })
            }
            else {
                //todo.
            }
            return isCityMatchSuggestion;
        }

        var saveDOBStatus = new cs.executeStatus();
        self.Save = function (element) {
            if (saveDOBStatus.isExecuting()) {
                return;
            }

            trackSaveAndContinueTotalClicks();

            saveDOBStatus.setExecuting();

            if (cs.isDisabled(element)) {
                return;
            }

            self.CustomerBasic.errors = ko.validation.group(self.CustomerBasic);

            if (self.isIOS() && !$(".placeholder-button").hasClass("display-none")) {
                saveDOBStatus.complete();
                self.CustomerBasic.errors.showAllMessages();
                $(".placeholder-button").addClass("error");
                $("#date-error").removeClass("dislpay-none");
                return;
            }

            cs.RemoveBorderAndMessage(addressListOfDOBAddress, $("#ValidateAddressMessage"));
            if (self.IsShowAddressInformation()) {
                var cityIsValid = self.ValidateCity();
                var stateIsValid = self.ValidateState();

                if (self.CustomerBasic.isValid() && cityIsValid && stateIsValid) {
                    if (self.CustomerBasic.CountryId() != "840") {
                        DOBShowErrorMessage(personalinfostrings.errormessage.error, personalinfostrings.errormessage.serviceavailableinus);

                        self.trackErrorMessage(personalinfostrings.errormessage.serviceavailableinus);

                        saveDOBStatus.complete();
                        return;
                    }
                    $.when(dataModel.GetAddressDetails(self.smartStreetIds, element, self.CustomerBasic, false))
                    .done(function () {
                        updateAddressStatus.complete();
                        saveDOBStatus.complete();
                        Update();
                    })
                    .fail(function (stateId, cityName) {
                        updateAddressStatus.complete();
                        saveDOBStatus.complete();
                    });
                } else {
                    saveDOBStatus.complete();
                    self.CustomerBasic.errors.showAllMessages();
                }
            } else {
                if (self.CustomerBasic.isValid()) {
                    Update(element);
                } else {
                    saveDOBStatus.complete();
                    self.CustomerBasic.errors.showAllMessages();
                }
            }

            track.trackTimeOnPageForPageLink("SaveAndContinue");
        }

        self.ValidateState = function () {
            var state = GetStateElement().val();
            if (!state) {
                self.StateValidateType(1);
                return false;
            }

            if (isMatchState(state, true, self.isMobile())) {
                return true;
            } else {
                self.StateValidateType(2);
                return false;
            }
        }

        self.ValidateCity = function () {
            if (self.CityValidateType() != 0) {
                return false;
            }

            var city = GetCityElement().val();
            if (!city) {
                self.CityValidateType(1);
                return false;
            } else {
                return true;
            }
        }

        function DOBShowErrorMessage(caption, message) {
            return cs.showErrorMessage(caption, message);
        }

        var updateAddressStatus = new cs.executeStatus();

        function RemoveSmartyStreetValidationStyle() {
            GetAddress1Element().css("border", "");
            GetAddress2Element().css("border", "");
            GetCityElement().css("border", "");
            GetStateElement().css("border", "");
            GetZipCodeElement().css("border", "");
        };

        function Update(element) {
            FillParamters();
            var customerBasic = ko.toJS(self.CustomerBasic);
            var personInfo = {
                FirstName: customerBasic.FirstName,
                MiddleName: customerBasic.MiddleName,
                LastName: customerBasic.LastName,
                Address: customerBasic.Address,
                Address2: customerBasic.Address2,
                StateId: customerBasic.StateId,
                CityId: customerBasic.CityId,
                Zipcode: customerBasic.Zipcode,
                DateOfBirth: customerBasic.DateOfBirth,
                AddressChanged: self.IsShowAddressInformation()
            };

            cs.AjaxBySpinner({
                url: '/Customers/SavePersonalInfo',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(personInfo)
            }, element, true)
            .done(function (result) {
                saveDOBStatus.complete();

                var errorState = '';
                for (var i = 0; i < self.CustomerBasic.States().length; i++) {
                    if (self.CustomerBasic.States()[i].Value() == personInfo.StateId) {
                        errorState = self.CustomerBasic.States()[i].Text();
                        break;
                    }
                }

                refreshPersonalInfo(result, errorState, true);
            })
            .fail(function (xhr, status) {
                saveDOBStatus.complete();
                cs.handleAjaxError(xhr.responseText, false);
            });
        };

        function FillParamters() {
            if (self.IsShowAddressInformation()) {
                var selectCity = GetCityElement().val();
                self.CustomerBasic.City(selectCity);
            }

            if (self.IsShowNameInformation()) {
                self.CustomerBasic.FirstName(self.CustomerBasic.TempFirstName().trim());
                self.CustomerBasic.MiddleName(self.CustomerBasic.TempMiddleName() ? self.CustomerBasic.TempMiddleName().trim() : "");
                self.CustomerBasic.LastName(self.CustomerBasic.TempLastName().trim());
            }
        };

        function GetElement(id) {
            return $("#" + id);
        }

        function GetCityElement() {
            return GetElement("input-city");
        }

        function GetAddress1Element() {
            return GetElement("input-address1");
        }

        function GetAddress2Element() {
            return GetElement("input-address2");
        }

        function GetStateElement() {
            return GetElement("input-state");
        }

        function GetZipCodeElement() {
            return GetElement("input-zip");
        }

        self.IsShowDOBAndAddress = function () {
            return self.IsShowNameInformation() || self.IsShowDateOfBirth() || self.IsShowAddressInformation();
        }

        self.isMobile = function () {
            return cs.IsMobileDevice();
        }

        self.isIOS = function () {
            return cs.IsIOS();
        }

        self.isAndroid = function () {
            return (!cs.IsIOS() && cs.IsMobileDevice());
        }

        self.BackToPrePage = function () {
            cancelPersonalInfo();

            trackCancelTotalClicks();
            track.trackTimeOnPageForPageLink("BackToPrePage");
        }
    }

    return new PersonalInfoConsumerViewModel();
});