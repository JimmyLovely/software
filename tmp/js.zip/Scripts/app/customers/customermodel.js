﻿define(['knockout', 'ClientScript', 'app', 'CustomerBasicModel'], function (ko, cs, app, CustomerBasicModel) {
    return function CustomerModel(data, module) {
        var self = this;

        var mapping = {
            'CustomerBasic': {
                create: function (options) {
                    return new CustomerBasicModel(options.data, module);
                }
            }
        };
        ko.mapping.fromJS(data, mapping, self);
    }
});
