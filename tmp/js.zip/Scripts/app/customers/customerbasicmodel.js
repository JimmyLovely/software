﻿define(['knockout', 'ClientScript', 'app', 'DataModel'], function (ko, cs, app, dataModel) {
    return function CustomerBasicModel(data, module) {
        var self = this;
        self.IsShowNameInformation = ko.observable(false);
        self.IsShowDateOfBirth = ko.observable(false);
        self.IsShowAddressInformation = ko.observable(false);
        self.OldPassword = ko.observable("");
        self.NewPassword = ko.observable("");
        self.ConfirmPassword = ko.observable("");

        self.TempFirstName = ko.observable("");
        self.TempMiddleName = ko.observable("");
        self.TempLastName = ko.observable("");
        self.UpdatePreferences = false;

        ko.mapping.fromJS(data, {}, self);

        if (!module) {
            module = "";
        }

        function ArrayContain(array, value) {
            if (typeof array === 'undifined') {
                return false;
            }

            for (var i = 0; i < array.length; i++) {
                if (array[i] == value) {
                    return true;
                }
            }

            return false;
        }

        self.UpdatePreferences = self.IsAcceptEmailNewsletter();
        var originalCustomerBasicModel = ko.mapping.toJS(data);
        originalCustomerBasicModel.DateOfBirth = "";
        originalCustomerBasicModel.TempFirstName = ko.observable(self.FirstName());
        originalCustomerBasicModel.TempMiddleName = ko.observable(self.MiddleName());
        originalCustomerBasicModel.TempLastName = ko.observable(self.LastName());
        originalCustomerBasicModel.IsAcceptEmailNewsletter = self.IsAcceptEmailNewsletter();
        originalCustomerBasicModel.StateId = ko.observable(self.StateId());

        self.GetStatesByCountryId = function () {
            var countryId = self.CountryId();
            $.when(dataModel.GetStatesByCountryId(countryId))
          .done(function (result) {
              ko.mapping.fromJS(result, {}, self.States);
              self.StateId(null);
              self.StateId.isModified(false);
              ResetCities();
              RemoveSmartyStreetValidationStyle();
          });
        }

        function GetElement(id) {
            var tempModuleId = "";
            if (module.trim() != "") {
                tempModuleId = "-" + module;
            }

            return $("#" + id + tempModuleId);
        }

        function GetCityElement() {
            return GetElement("autocomplete-city-names");
        }

        function GetAddress1Element() {
            return GetElement("input-address-1");
        }

        function GetAddress2Element() {
            return GetElement("input-address-2");
        }

        function GetStateElement() {
            return GetElement("input-address-state");
        }

        function GetCountryElement() {
            return GetElement("input-address-country");
        }

        function GetZipCodeElement() {
            return GetElement("input-zip-code");
        }

        function ResetCities() {
            GetCityElement().val("");
            GetCityElement().autocomplete({
                lookup: [],
            });
        }

        self.showDefaultCity = true;
        var updateCustomerCities;
        self.GetCitiesByStateId = function (displayCityName) {
            var countryId = self.CountryId();
            var stateId = self.StateId();
            $.when(dataModel.GetCitiesByStateId(countryId, stateId))
            .done(function (result) {
                updateCustomerCities = result;
                if (!self.showDefaultCity) {
                    GetCityElement().val("");

                    self.Zipcode(null);
                    self.Zipcode.isModified(false);
                }
                else {
                    self.showDefaultCity = false;
                    GetCityElement().val(self.City());

                    if (displayCityName && typeof displayCityName === "string") {
                        GetCityElement().val(displayCityName);

                        var newCityId = ""
                        for (var j = 0; j < result.length; j++) {
                            if (result[j].value == displayCityName) {
                                newCityId = result[j].data.Value;
                                break;
                            }
                        }
                        self.CityId(newCityId);
                    }
                }
                require(['Plugins'], function () {
                    GetCityElement().autocomplete({
                        lookup: result,
                        triggerSelectOnValidInput: true,
                        minChars: 1,
                        maxHeight: 220,
                        onSelect: function (suggestion) {
                            UpdateCustomerBasicCityChanged(suggestion);
                        },
                        lookupFilter: function (k, j, l) {
                            var inputValue = (cs.removeDiacritics(l).toLowerCase());
                            return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1;
                        }
                    });
                    GetCityElement().autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                });
            });
        }

        self.ShowAddressControl = function (element) {
            var value = $(element).val();
            if (value && value.length > 0) {
                $("#address-clear").show();
            }
            else {
                $("#address-clear").hide()
            }
        }

        self.HideAddressControl = function (element, event) {
            if ($('.autocomplete-selected').length > 0) return;

            $('#input-address-1').autocomplete("hide");
        }

        var timeHandler = 0;
        // 1 zip type is not standard
        // 2 city not found
        self.NoMatchSuggestionError = ko.observable(0);
        
        self.AutoSearchSuggestion = function (element) {
            $('#input-address-1').autocomplete({
                lookup: [],
                showNoSuggestionNotice: false
            });
            self.NoMatchSuggestionError(0);

            var value = $(element).val();
            clearTimeout(timeHandler);

            if (value && value.length > 0) {
                timeHandler = setTimeout(function () {
                    $("#address-clear").show();
                    
                    AutoSearchSuggestion(element, value);
                }, 500);
            }
            else {
                $("#address-clear").hide();
            }
        }

        self.ClearAddressInfo = function () {
            self.NoMatchSuggestionError(0);
            self.Address(null);
            self.Address.isModified(false);

            self.StateId(null);
            self.StateId.isModified(false);
            GetCityElement().val("");
            self.CityValidateType(0);
            self.Zipcode(null);
            self.Zipcode.isModified(false);

            $('#input-address-1').autocomplete({
                lookup: []
            });
            // Clear error message.
            $('#input-address-1').trigger('input');
            GetCityElement().autocomplete({
                lookup: []
            });

            $("#address-clear").hide();
            $("#input-address-1").focus();
        }

        function AutoSearchSuggestion(element, streetName) {
            $.when(dataModel.GetAutoCompleteSuggestionAddresses(streetName))
            .done(function (result) {
                /*For DataCapture*/
                if (result && result.length == 0) {
                    cs.LogInformationOfAddressSearch($(element).val(), false /*false stand for no recoeds found*/);
                }

                var containerClass = "autocomplete-bold";
                if (self.isMobile()) {
                    var height = document.body.clientHeight;
                    // 400 is ios landscape mode, 300 is android landscape mode.
                    if (height < (self.isIOS() ? 400 : 300)) {
                        containerClass += " landscape-height";
                    }
                }

                BindingAutoSuggestionAddress(element, result, containerClass);
            })
            .fail(function (xhr, status) {
                /*For DataCapture*/
                cs.LogInformationOfAddressSearch($(element).val(), true /*true stand for other issue*/, xhr.statusText);
            });
        }

        function BindingAutoSuggestionAddress(bindingElement, lookup, containerClass) {
            $(bindingElement).autocomplete({
                lookup: lookup,
                triggerSelectOnValidInput: false,
                minChars: 1,
                showNoSuggestionNotice: true,
                containerClass: containerClass,
                noSuggestionNotice: "No suggestions found",
                onSelect: function (suggestion) {
                    self.NoMatchSuggestionError(0);
                    $(bindingElement).val(suggestion.data.StreetName);

                    $.when(dataModel.GetAddressAutocompleteDetails(suggestion))
                    .done(function (result) {
                        if (result && result.ResultAddress && result.ResultAddress.Analysis.DpvMatchCode != null && result.ResultAddress.Analysis.DpvMatchCode != 'N') {

                            var address = result.ResultAddress;
                            if (address.Metadata.ZipType != 'Standard') {
                                self.NoMatchSuggestionError(1);
                                $("#input-address-1").focus();
                                return;
                            }

                            var resultStreet = address.DeliveryLine1;
                            self.Address(resultStreet);

                            var resultSecondStreet = address.DeliveryLine2;
                            var resultCity = address.Components.CityName;
                            var resultState = address.Components.StateAbbreviation;
                            var resultZipcode = address.Components.Zipcode;

                            var isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, function () {
                                self.Zipcode(resultZipcode);
                            }, function () {
                                $("#autocomplete-city-names").focus();
                            });

                            if (!isCityMatchSuggestion) {
                                result.ResultAddress.Components.CityName = "";
                            }

                            //For datacapture. Log address validate.
                            cs.LogAddressValidate(result, true);
                        }
                        else {
                            var message = cs.getAutoCompleteAddressInvalidMessage(suggestion.data.StreetName, $("#input-address-2").val());
                            cs.ShowCustomMessage(function () {

                                //For datacapture. Log address validate.
                                result.ResultAddress.DeliveryLine1 = suggestion.data.StreetName;
                                result.ResultAddress.Components.CityName = suggestion.data.City;
                                result.ResultAddress.Components.StateAbbreviation = suggestion.data.State;
                                result.ResultAddress.Metadata.CountyName = self.States().filter(function (x) {
                                                                                                    return x.Code == suggestion.data.State;
                                                                                                })[0].Text;

                                var isCityMatchSuggestion = FillAddressStateAndCity(suggestion.data.State, suggestion.data.City, null, function () {
                                    setTimeout(function () {
                                        $("#autocomplete-city-names").focus();
                                    }, 300);
                                });

                                if (!isCityMatchSuggestion) {
                                    result.ResultAddress.Components.CityName = "";
                                }

                                cs.LogAddressValidate(result, false);
                            }, function () {
                                setTimeout(function () {
                                    $("#input-address-1").focus();
                                }, 300);
                            }, message);
                        }
                    })
                }
            });

            $(bindingElement).autocomplete().getSuggestionsLocal = function (query) {
                var result = {
                    suggestions: this.options.lookup
                };
                return result;
            };

            if (document.activeElement && document.activeElement.id == 'input-address-2') {
                // If user press tab, address2 focus, no need focus address1.
                return;
            }
            $(bindingElement).focus();
        }

        function FillAddressStateAndCity(resultState, resultCity, addtionalField, addtionalFocus) {
            var isCityMatchSuggestion = true;
            var stateId = dataModel.GetStateId(resultState, self.States());
            if (stateId && stateId != 0) {
                self.StateId(stateId);
                $.when(self.GetCitiesByStateId(""))
                .done(function () {
                    if (cs.isMatchSuggestion(updateCustomerCities, resultCity, false) > -1) {
                        var city = dataModel.GetCity(resultCity, updateCustomerCities);
                        UpdateCustomerBasicCityChanged(city);
                        GetCityElement().val(resultCity);
                        if (typeof addtionalField == 'function') {
                            addtionalField();
                        }

                        setTimeout(function () {
                            $("#input-address-2").focus();
                        }, 100);
                        isCityMatchSuggestion = true;
                    }
                    else {
                        self.StateId(stateId);
                        self.NoMatchSuggestionError(2);
                        if (typeof addtionalFocus == 'function') {
                            addtionalFocus();
                        }
                        isCityMatchSuggestion = false;
                    }
                })
            }
            else {
                //todo.
            }
            return isCityMatchSuggestion;
        }

        function UpdateCustomerBasicCityChanged(suggestion) {
            self.City(suggestion.value);
            self.CityId(suggestion.data.Value);
            self.CityValidateType(0);
        }

        self.ApplyCustomerBasicNameInformation = function () {
            self.TempFirstName.extend({
                //Inline message
                required: { params: true, message: 'First name is required' },
                minTrimLength: { params: 2, message: 'Minimum length of first name is 2 characters' },
                maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.TempFirstName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.TempFirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
                }
            }).isModified(false);

            self.TempMiddleName.extend({
                //Inline message
                maxLength: { params: 50, message: 'Maximum length of 50 characters' },
                equal: {
                    onlyIf: function () { return self.TempMiddleName() != "" && cs.IsInvalidName(self.TempMiddleName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.TempMiddleName()) == 1 ? 'Middle name should start with a letter' : 'Invalid middle name' }
                }
            }).isModified(false);

            self.TempLastName.extend({
                //Inline message
                required: { params: true, message: 'Last name is required' },
                minTrimLength: { params: 2, message: 'Minimum length of last name is 2 characters' },
                maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.TempLastName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.TempLastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
                }
            }).isModified(false);
        };

        self.ApplyCustomerBasicAddressValidation = function () {

            self.Address.extend({
                //Inline message
                required: { params: true, message: 'Street Name and Number is required' }
            }).isModified(false);
            self.CityId.extend({
                //Inline message
                required: { params: true, message: 'City is required' }
            }).isModified(false);
            self.StateId.extend({
                //Inline message
                required: { params: true, message: 'State is required' }
            }).isModified(false);
            self.CountryId.extend({
                //Inline message
                required: { params: true, message: 'Country is required' }
            }).isModified(false);
            self.Zipcode.extend({
                //Inline message
                required: { params: true, message: 'Zip code is required' },
                number: { params: true, message: 'Enter a valid zip code' },
                minLength: { params: 5, message: 'Minimum length of zip code is 5 characters' },
                maxLength: { params: 5, message: 'Maximum length of zip code is 5 characters' }
            }).isModified(false);
        };

        self.ApplyCustomerBasicDateOfBithValidation = function () {
            self.DateOfBirth.extend({
                //Inline message
                required: { params: true, message: 'Date of birth is required' },
                isMinDate: {
                    //Inline message
                    params: 'MinDate',
                    message: 'Please select a date after 1920'
                },
                isValidDate: {
                    //Inline message
                    params: 'DateOfBirth',
                    message: 'User is required to be at least 18 years of age'
                }
            }).isModified(false);
        };

        self.RemoveValidationMessage = function () {
            if (self.IsShowNameInformation()) {
                self.TempFirstName.isModified(false);
                self.TempLastName.isModified(false);
            }

            if (self.IsShowAddressInformation()) {
                self.Address.isModified(false);
                self.CityId.isModified(false);
                self.StateId.isModified(false);
                self.CountryId.isModified(false);
                self.Zipcode.isModified(false);
            }

            if (self.IsShowDateOfBirth()) {
                self.DateOfBirth.isModified(false);
            }
        }

        self.IsShowDOBAndAddress = function () {
            return self.IsShowNameInformation() || self.IsShowDateOfBirth() || self.IsShowAddressInformation();
        }

        self.initializeForDOBAndAddress = function () {

            if (!(self.FirstName().trim() && self.LastName().trim())) {
                self.IsShowNameInformation(true);
                self.ApplyCustomerBasicNameInformation();
            }

            if (self.DateOfBirth() == '01/01/1753') {
                self.DateOfBirth("");
                self.IsShowDateOfBirth(true);
                self.ApplyCustomerBasicDateOfBithValidation();
            }

            if (self.CountryId() < 1 || self.StateId() < 1 || (self.CityId() < 1 && !self.City()) || !self.Address() || !self.Zipcode()) {
                self.IsShowAddressInformation(true);
                self.ApplyCustomerBasicAddressValidation();
            }
        }

        self.ValidateCityForUpdate = function (city) {
            if ($('.autocomplete-selected').length > 0) return;

            var validAutocompleteCity = cs.setCityValidateType(self.CityValidateType, city, updateCustomerCities);
            if (validAutocompleteCity[0]) {
                self.CityId(validAutocompleteCity[1]);
                return true;
            }
            return false;
        }

        function GetAddressDetails(element, callBack, showPreviousModal) {
            cs.AjaxBySpinner({
                url: '/Home/GetAddressDetails',
                type: "Get",
                cache: false,
                dataType: 'json',
                contentType: "application/json",
                data: {
                    "street": self.Address(),
                    "street2": self.Address2(),
                    "city": GetCityElement().val(),
                    "state": GetStateElement().find("option:selected").text(),
                    "zipcode": self.Zipcode()
                },
            }, element)
        .done(function (streetAddressResult) {
            if (streetAddressResult.AddressVerificationEnabled) {
                RemoveSmartyStreetValidationStyle();
                var result = streetAddressResult.ResultAddress;

                var resultStreet = result.DeliveryLine1;
                var resultStreet2 = result.DeliveryLine2;
                var resultCity = result.Components.CityName;
                var resultState = result.Components.StateAbbreviation;
                var resultZipcode = result.Components.Zipcode;
                var newState = "";
                var newStateId = "";
                for (var j = 0; j < self.States().length; j++) {
                    if (self.States()[j].Code() == resultState) {
                        newState = self.States()[j].Text();
                        newStateId = self.States()[j].Value();
                    }
                }

                var footnotes = result.Analysis.Footnotes;
                var dpvFootnotes = result.Analysis.DpvFootnotes;
                var dpvMatchCode = result.Analysis.DpvMatchCode;
                var oldStreet = self.Address();
                var oldStreet2 = self.Address2();
                var oldCity = GetCityElement().val();
                var oldState = GetStateElement().find("option:selected").text();
                var oldZipcode = self.Zipcode();
                var valueChangeExist = ((oldStreet != resultStreet) || (resultStreet2 != null && resultStreet2 != oldStreet2) || (oldCity != resultCity) ||
                        (oldState != newState) || (oldZipcode != resultZipcode));
                if (!valueChangeExist) {
                    if (dpvMatchCode == 'D') {
                        var message = "Please input your apartment or suite number.";
                        cs.ShowCustomMessage(function () {
                            updateAddressStatus.complete();
                            saveDOBStatus.complete();

                            setTimeout(function () {
                                $("#input-address-2").focus();
                            }, 300);
                        }, function () {
                            callBack(element);
                        }, message);
                    }
                    else {
                        callBack(element);
                    }
                }
                else {
                    var validateMessages = "";
                    validateMessages += cs.getNotificationMessages(footnotes, dpvFootnotes, oldStreet, oldStreet2,
                            oldCity, oldState, oldZipcode, resultStreet, resultStreet2, resultCity, newState, resultZipcode);
                    if (dpvFootnotes == "ZZ") {
                        GetAddress1Element().css("border", "2px solid red");
                        GetAddress2Element().css("border", "2px solid red");
                        GetCityElement().css("border", "2px solid red");
                        GetStateElement().css("border", "2px solid red");
                        GetZipCodeElement().css("border", "2px solid red");
                        if (showPreviousModal) {
                            $("#ValidateAddressMessage").css("display", "block");
                            $("#ValidateAddressMessage").html(validateMessages);
                        } else {
                            $("#ValidateAddressMessageSetting").css("display", "block");
                            $("#ValidateAddressMessageSetting").html(validateMessages);
                        }
                    }
                    else {
                        if (resultStreet != oldStreet) {
                            self.Address(resultStreet);
                            GetAddress1Element().css("border", "2px solid green");
                        }
                        if (resultStreet2 != null && resultStreet2 != oldStreet2) {
                            self.Address2(resultStreet2);
                            GetAddress2Element().css("border", "2px solid green");
                        }
                        if (newState != oldState) {
                            self.StateId(newStateId);
                            GetStateElement().css("border", "2px solid green");
                        }
                        if (resultCity != oldCity) {
                            self.showDefaultCity = true;
                            self.GetCitiesByStateId(resultCity);
                            GetCityElement().css("border", "2px solid green");
                        }
                        if (resultZipcode != oldZipcode) {
                            self.Zipcode(resultZipcode);
                            GetZipCodeElement().css("border", "2px solid green");
                        }
                    }
                    updateAddressStatus.complete();
                    saveDOBStatus.complete();
                }
            }
            else {
                callBack(element);
            }
        })
        .fail(function () {
            updateAddressStatus.complete();
            saveDOBStatus.complete();
        });
        }
        function isDateOfBirthValid() {
            if (self.DateOfBirth() == "01/01/1753") {
                return true;
            }

            return false;
        }

        function isDateOfBirthAheadOfToday() {
            if (self.DateOfBirth() == "" || self.DateOfBirth() == "Required field") {
                return false;
            }

            return new Date(self.DateOfBirth()) >= new Date();
        }

        var saveDOBStatus = new cs.executeStatus();
        self.Save = function (element) {
            if (saveDOBStatus.isExecuting()) {
                return;
            }

            saveDOBStatus.setExecuting();

            if (cs.isDisabled(element)) {
                return;
            }

            self.errors = ko.validation.group(self);
            var result = self.ValidateCityForUpdate(GetCityElement());

            if (self.isIOS() && !$(".placeholder-button").hasClass("display-none")) {
                saveDOBStatus.complete();
                self.errors.showAllMessages();
                $(".placeholder-button").addClass("error");
                $("#date-error").removeClass("dislpay-none");
                return;
            }
            cs.RemoveBorderAndMessage(addressListOfDOBAddress, $("#ValidateAddressMessage"));
            if (self.IsShowAddressInformation()) {

                if (self.isValid() && result) {
                    if (self.CountryId() != "840") {
                        DOBShowErrorMessage("error", "Currently this service is only available in the US.");
                        saveDOBStatus.complete();
                        return;
                    }
                    GetAddressDetails(element, SelfServiceUpdateAddress, true);
                } else {
                    saveDOBStatus.complete();
                    self.errors.showAllMessages();
                }
            } else {
                if (self.isValid()) {
                    Update(element);
                } else {
                    saveDOBStatus.complete();
                    self.errors.showAllMessages();
                }
            }
        }

        function FillParamters() {
            if (self.IsShowAddressInformation()) {
                var selectCity = GetCityElement().val();
                self.City(selectCity);
            }

            if (self.IsShowNameInformation()) {
                self.FirstName(self.TempFirstName().trim());
                self.MiddleName(self.TempMiddleName() ? self.TempMiddleName().trim() : "");
                self.LastName(self.TempLastName().trim());
            }
        };


        function Update(element) {
            FillParamters();
            cs.AjaxBySpinner({
                url: '/Customers/UpdateSender',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, element, true)
            .done(function (result) {
                ko.mapping.fromJS(result, {}, self);
                result.DateOfBirth = result.DateOfBirth == '01/01/1753' ? '' : result.DateOfBirth;
                ko.mapping.fromJS(result, {}, originalCustomerBasicModel);

                $.when(app.senderInfo().GetSenderLevel(element))
                .done(function () {
                    $('#modal-dob-address').off('close.modal');
                    $.when(cs.closeModal())
                .done(function () {
                    saveDOBStatus.complete();
                    self.IsShowDateOfBirth(false);
                    self.IsShowAddressInformation(false);
                    self.IsShowNameInformation(false);

                    if (callbackfunction) {
                        callbackfunction();
                    }
                });
                })
                .fail(function () {
                    saveDOBStatus.complete();
                });
            })
            .fail(function (xhr, status) {
                saveDOBStatus.complete();
                cs.handleAjaxError(xhr.responseText, false);
                ko.mapping.fromJS(originalCustomerBasicModel, {}, self);
            });
        };

        function SelfServiceUpdateAddress(element) {
            FillParamters();
            cs.AjaxBySpinner({
                url: '/Customers/UpdateAddressInformation',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "customerBasicModel": ko.mapping.toJS(self), "isDob": true })
            }, element)
            .done(function (result) {

                $.when(app.senderInfo().GetSenderLevel(element))
                .done(function () {
                    $('#modal-dob-address').off('close.modal');
                    $.when(cs.closeModal())
                    .done(function () {
                        ko.mapping.fromJS(result, {}, app.senderInfo().Customer());
                        self.DateOfBirth.isModified(false);
                        self.StateId.isModified(false);
                        saveDOBStatus.complete();
                        self.IsShowDateOfBirth(false);
                        self.IsShowAddressInformation(false);
                        self.IsShowNameInformation(false);

                        if (callbackfunction) {
                            callbackfunction();
                        }
                    });
                })
                .fail(function () {
                    ko.mapping.fromJS(result, {}, app.senderInfo().Customer());
                    self.DateOfBirth.isModified(false);
                    self.StateId.isModified(false);
                    saveDOBStatus.complete();
                })
            })
            .fail(function () {
                saveDOBStatus.complete();
            });
            RemoveSmartyStreetValidationStyle();
        };

        var callbackfunction = null;
        var addressListOfDOBAddress = new Array();
        var openDOBStatus = new cs.executeStatus();
        self.OpenDOBAndAddressModal = function (callback) {
            if (openDOBStatus.isExecuting()) {
                return;
            }

            openDOBStatus.setExecuting();

            var deferred = $.Deferred();
            app.senderInfo().Customer().CustomerBasic.CountryId(840);
            $.when(dataModel.GetStatesByCountryId(840))
            .done(function (data) {
                var states = ko.mapping.toJS(data);
                ko.mapping.fromJS(states, {}, app.senderInfo().Customer().CustomerBasic.States);
                if (self.IsShowAddressInformation()) {
                    app.senderInfo().Customer().CustomerBasic.StateId(originalCustomerBasicModel.StateId());
                }

                RemoveSmartyStreetValidationStyle();

                if (!self.IsShowAddressInformation()) {
                    originalCustomerBasicModel = ko.mapping.toJS(self);
                }

                addressListOfDOBAddress.push($("#input-address-1"), $("#input-address-2"), $("#autocomplete-city-names"),
                    $("#input-address-state"), $("#input-zip-code"));
                cs.RemoveBorderAndMessage(addressListOfDOBAddress, $("#ValidateAddressMessage"));
                $.when(cs.openModal("modal-dob-address"))
                .done(function () {
                    openDOBStatus.complete();
                    callbackfunction = callback;
                    deferred.resolve();

                    var element = GetCityElement();
                    element.off("input.validatecity")
                    .on("input.validatecity", function () {
                        var value = element.val();
                        if (cs.isMatchSuggestion(updateCustomerCities, value, false) > -1) {
                            self.CityValidateType(0);
                        }
                        else {
                            self.CityValidateType(2);
                        }
                    })
                    .off("blur.validatecity")
                    .on("blur.validatecity", function () {
                        if ($('.autocomplete-selected').length > 0) return;

                        var city = element.val();
                        var validAutocompleteCity = cs.setCityValidateType(self.CityValidateType, element, updateCustomerCities);
                        if (validAutocompleteCity[0]) {
                            self.CityId(validAutocompleteCity[1]);
                        }

                        if (element.autocomplete()) {
                            element.autocomplete().hide();
                        }
                    })
                    .off("focus.validatecity")
                    .on("focus.validatecity", function () {
                        if (element.autocomplete().visible) {
                            self.CityValidateType(0);
                        }
                    })
                });
            })
            .fail(function () {
                openDOBStatus.complete();
            });
            return deferred;
        }

        self.ResetDOBAndAddress = function () {
            if (self.IsShowAddressInformation()) {
                self.NoMatchSuggestionError(0);
                self.Address(null);
                self.Address2("");
                self.Zipcode(null);
                self.Address.isModified(false);
                self.Zipcode.isModified(false);
            };

            self.TempFirstName(null);
            self.TempMiddleName("");
            self.TempLastName(null);
            self.DateOfBirth("");
            self.TempFirstName.isModified(false);
            self.TempLastName.isModified(false);
            self.DateOfBirth.isModified(false);
        };

        function RemoveSmartyStreetValidationStyle() {
            GetAddress1Element().css("border", "");
            GetAddress2Element().css("border", "");
            GetCityElement().css("border", "");
            GetStateElement().css("border", "");
            GetZipCodeElement().css("border", "");
        };

        self.Cancel = function () {
            if (!(app.page().name == "CustomerDashboard" || app.page().name == "AccountConsumer")) {// Current page is dashboard, will stop this page.
                return app.redirectTo("/SelfService/CustomerDashboard");
            }
        };

        self.resetDOBAfterCancel = function () {
            callbackfunction = null;
            ko.mapping.fromJS(originalCustomerBasicModel, {}, self);
            self.RemoveValidationMessage();
        };

        //Validation bind
        self.ApplyCustomerPasswordValidation = function () {
            self.ValidateRequired = ko.computed(function () {
                var oldpassword = self.OldPassword();
                var newPassword = self.NewPassword();
                var confirmPassword = self.ConfirmPassword();
                self.serverError(false);
                return true;
            });

            self.OldPassword.ValidateCharactersOfOldPassword = ko.computed(function () {
                var password = self.OldPassword();
                if (password != null) {
                    return !(/^.*[0-9]+/.test(password) && !(/\s/.test(password)));
                }

                return false;
            });

            self.OldPassword.extend({
                required: true,
                minLength: 8,
                maxLength: 20,
                equal: {
                    onlyIf: self.OldPassword.ValidateCharactersOfOldPassword,
                    //Inline message
                    message: '8-20 characters, at least one number, no spaces' // Override later as "Not a valid old password".
                }
            }).isModified(false);

            self.NewPassword.ValidateCharactersOfNewPassword = ko.computed(function () {
                var password = self.NewPassword();
                if (password != null) {
                    return !(/^.*[0-9]+/.test(password) && !(/\s/.test(password)));
                }

                return false;
            });

            self.NewPassword.extend({
                required: true,
                minLength: 8,
                maxLength: 20,
                equal: {
                    onlyIf: self.NewPassword.ValidateCharactersOfNewPassword,
                    //Inline message
                    message: '8-20 characters, at least one number, no spaces' // Override later as "Not a valid new password".
                }
            }).isModified(false);

            self.ConfirmPassword.extend({
                required: true,
                equal: self.NewPassword,
                minLength: 8,
                maxLength: 20
            }).isModified(false);
        };

        self.ApplyProfileInformationValidation = function () {
            self.HomePhoneNumber.extend({
                required: false,
                number: { onlyIf: function () { return cs.IsInvalidPhoneNumber(self.HomePhoneNumber()) } },
                maxLength: { onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.HomePhoneNumber()); } },
                minLength: 10
            }).isModified(false);

            self.CellPhoneNumber.extend({
                required: { onlyIf: self.ValidatePhoneAtLeastOneAndValid },
                number: { onlyIf: function () { return cs.IsInvalidPhoneNumber(self.CellPhoneNumber()) } },
                maxLength: { onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.CellPhoneNumber()); } },
                minLength: 10
            }).isModified(false);

            self.WorkPhoneNumber.extend({
                required: false,
                number: { onlyIf: function () { return cs.IsInvalidPhoneNumber(self.WorkPhoneNumber()) } },
                maxLength: { onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.WorkPhoneNumber()); } },
                minLength: 10
            }).isModified(false);
        };

        //Validation Model
        self.ValidateProfileInformationModel = {
            HomePhoneNumber: self.HomePhoneNumber,
            CellPhoneNumber: self.CellPhoneNumber,
            WorkPhoneNumber: self.WorkPhoneNumber
        };

        self.ValidatePasswordModel = {
            OldPassword: self.OldPassword,
            NewPassword: self.NewPassword,
            ConfirmPassword: self.ConfirmPassword
        };

        self.ValidateAddressInformation = {
            Address: self.Address,
            CityId: self.CityId,
            StateId: self.StateId,
            CountryId: self.CountryId,
            Zipcode: self.Zipcode
        };

        //Toggle List Open Or Close
        self.ToggleProfileInformationListOpenOrClose = function () {
            $('#ProfileInformationList').toggleClass('closed');
        }

        self.ToggleChangePasswordListOpenOrClose = function () {
            $('#ChangePasswordList').toggleClass('closed');
        }

        self.ToggleAddressInformationListOpenOrClose = function () {
            $('#AddressInformationList').toggleClass('closed');
            ForIEIssue();
        }

        function ForIEIssue() {
            var tempAddress = self.Address();
            $('#input-address-1-setting').val("");
            self.Address(tempAddress);
            $('#input-address-1-setting').val(tempAddress);
            $('#input-address-1-setting').blur();

            var tempAddress2 = self.Address2();
            $('#input-address-2-setting').val("");
            self.Address2(tempAddress2);
            $('#input-address-2-setting').val(tempAddress2);
            $('#input-address-2-setting').blur();

            var tempZipcode = self.Zipcode();
            $('#input-zip-code-setting').val("");
            self.Zipcode(tempZipcode);
            $('#input-zip-code-setting').val(tempZipcode);
            $('#input-zip-code-setting').blur();

            var tempCity = self.City();
            $('#autocomplete-city-names-setting').val("");
            self.City(tempCity);
            $('#autocomplete-city-names-setting').val(tempCity);
            $('#autocomplete-city-names-setting').blur();
        }

        self.ToggleProfilePreferencesListOpenOrClose = function () {
            $('#ProfilePreferencesList').toggleClass('closed');
        }

        function OpenNotifyMessageModal(notifyMessageModel, element) {
            $("#NotificationHead").text(notifyMessageModel.Title);
            $("#NotificationMessage").text(notifyMessageModel.Message);
            $('#NotificationConfirmOK').unbind('click');
            $('#NotificationConfirmOK').click(function () {
                cs.closeModal();
            });
            $(element).removeClass('now-loading');
            return cs.openModal("modal-notification");
        };

        //Profile Information
        self.InitializeForProfileInformation = function () {
            self.ApplyProfileInformationValidation();
        };

        self.ValidatePhoneAtLeastOneAndValid = ko.computed(function () {
            var cellPhoneNumber = self.CellPhoneNumber();
            return !ko.validation.rules.required.validator(cellPhoneNumber, true);
        });

        self.CancelProfileInformation = function () {
            self.HomePhoneNumber.isModified(false);
            self.CellPhoneNumber.isModified(false);
            self.WorkPhoneNumber.isModified(false);
            self.HomePhoneNumber(originalCustomerBasicModel.HomePhoneNumber);
            self.CellPhoneNumber(originalCustomerBasicModel.CellPhoneNumber);
            self.WorkPhoneNumber(originalCustomerBasicModel.WorkPhoneNumber);
            self.ToggleProfileInformationListOpenOrClose();
        }

        var updateProfileStatus = new cs.executeStatus();
        self.UpdateProfileInformation = function (element) {
            if (updateProfileStatus.isExecuting()) {
                return;
            }

            updateProfileStatus.setExecuting();
            self.errors = ko.validation.group(self.ValidateProfileInformationModel);
            var homePhoneNumber = "";
            if (self.HomePhoneNumber() != null) {
                homePhoneNumber = self.HomePhoneNumber().replace(/-/g, '');
            }

            var cellPhoneNumber = "";
            if (self.CellPhoneNumber() != null) {
                cellPhoneNumber = self.CellPhoneNumber().replace(/-/g, '');
            }

            var workPhoneNumber = "";
            if (self.WorkPhoneNumber() != null) {
                workPhoneNumber = self.WorkPhoneNumber().replace(/-/g, '');
            }

            if (self.ValidateProfileInformationModel.isValid()) {
                return cs.AjaxBySpinner({
                    url: '/Customers/UpdateProfileInformation',
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                        "homePhoneNumber": homePhoneNumber,
                        "cellPhoneNumber": cellPhoneNumber,
                        "workPhoneNumber": workPhoneNumber,
                        "languageId": 1
                    })
                }, element)
            .done(function (result) {
                var notifyMessageModel = {
                    Title: "Message",
                    //Inline message
                    Message: "Profile Information updated successfully!"
                }
                toUpdateProfileInformation(result, self);
                result.DateOfBirth = result.DateOfBirth == '01/01/1753' ? '' : result.DateOfBirth;
                ko.mapping.fromJS(result, {}, originalCustomerBasicModel);
                $.when(OpenNotifyMessageModal(notifyMessageModel, element))
                .done(function () {
                    updateProfileStatus.complete();
                });
            })
            .fail(function () {
                updateProfileStatus.complete();
            });
            } else {
                updateProfileStatus.complete();
                self.errors.showAllMessages();
            }
        };

        function toUpdateProfileInformation(result, self) {
            if (result != null) {
                self.HomePhoneNumber(result.HomePhoneNumber);
                self.CellPhoneNumber(result.CellPhoneNumber);
                self.WorkPhoneNumber(result.WorkPhoneNumber);
                self.LanguageId(result.LanguageId);
            }

        }
        //Change Password
        self.InitializeForChangePassword = function () {
            self.ApplyCustomerPasswordValidation();
            ResetPasswordInformation();
        };

        self.CancelPassword = function () {
            ResetPasswordInformation();
            self.ToggleChangePasswordListOpenOrClose();
        }

        function ResetPasswordInformation() {
            self.OldPassword('');
            self.NewPassword('');
            self.ConfirmPassword('');
            self.serverError(false);
            self.OldPassword.isModified(false);
            self.NewPassword.isModified(false);
            self.ConfirmPassword.isModified(false);
        }

        self.serverError = ko.observable(false);
        var changePasswordStatus = new cs.executeStatus();
        self.UpdateForChangePassword = function (element) {
            if (changePasswordStatus.isExecuting()) {
                return;
            }
            changePasswordStatus.setExecuting();
            self.errors = ko.validation.group(self.ValidatePasswordModel);
            self.serverError(false);
            if (self.ValidatePasswordModel.isValid()) {
                return cs.AjaxBySpinner({
                    url: '/Customers/ChangePassword',
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                        "oldPassword": $('#input-setting-old-password').val(),
                        'newPassword': $('#input-setting-new-password').val()
                    })
                }, element, true)
           .done(function (result) {
               if (result.ReturnCode == 0) { //SUCCESS
                   var notifyMessageModel = {
                       Title: "Message",
                       //Inline message
                       Message: "Password updated successfully!"
                   }
                   ResetPasswordInformation();
                   $.when(OpenNotifyMessageModal(notifyMessageModel, element))
                   .done(function () {
                       changePasswordStatus.complete();
                   });
               }
               else if (result.ReturnCode == -467) {//SELF_SERVICE_PASSWORD_POLICY_VERIFY_FAILED
                   $.when(cs.showErrorMessage(result.Caption, result.Message))
                   .done(function () {
                       changePasswordStatus.complete();
                   });
               }
               else {
                   $.when(cs.showErrorMessage("Error", result))
                   .done(function () {
                       changePasswordStatus.complete();
                   });
               }
           })
          .fail(function (xhr, status) {

              try {
                  changePasswordStatus.complete();
                  var resultCode = $.parseJSON($.parseJSON(xhr.responseText).Message).exceptionCode

                  if (resultCode == "-444") {
                      self.serverError(true);
                      $('#input-setting-old-password').addClass('error');
                  }
                  else {
                      cs.handleAjaxError($.parseJSON($.parseJSON(xhr.responseText).Message).reason, false);
                      self.ServerError(true);
                  }
              }
              catch (e) {
                  cs.handleAjaxError(e.responseText, false);
                  console.log(xhr.responseText);
              }
          });
            } else {
                changePasswordStatus.complete();
                self.errors.showAllMessages();
            }
        }

        //Address Information
        self.InitializeForAddressInformation = function () {
            self.ApplyCustomerBasicAddressValidation();
        };

        self.CancelAddressInformation = function () {
            var originalAddressModel = {
                Address: originalCustomerBasicModel.Address,
                Address2: originalCustomerBasicModel.Address2,
                CityId: originalCustomerBasicModel.CityId,
                City: originalCustomerBasicModel.City,
                StateId: originalCustomerBasicModel.StateId,
                Zipcode: originalCustomerBasicModel.Zipcode,
                CountryId: originalCustomerBasicModel.CountryId
            }
            ko.mapping.fromJS(originalAddressModel, {}, self);

            self.CityValidateType(0);
            self.Address.isModified(false);
            self.Zipcode.isModified(false);
            self.CityId.isModified(false);
            self.CountryId.isModified(false);
            self.StateId.isModified(false);
            RemoveSmartyStreetValidationStyle();
            $("#ValidateAddressMessageSetting").css("display", "none");
            $("#ValidateAddressMessageSetting").html("");

            self.showDefaultCity = true;
            self.GetCitiesByStateId(null);
            self.ToggleAddressInformationListOpenOrClose();
        }

        var updateAddressStatus = new cs.executeStatus();
        self.UpdateAddressInformation = function (element) {
            if (updateAddressStatus.isExecuting()) {
                return;
            }
            updateAddressStatus.setExecuting();

            self.errors = ko.validation.group(self.ValidateAddressInformation);

            if (self.ValidateCityForUpdate(GetCityElement()) && self.ValidateAddressInformation.isValid()) {

                GetAddressDetails(element, UpdateAddress, false);
            } else {
                updateAddressStatus.complete();
                self.errors.showAllMessages();
            }

        };

        function UpdateAddress(element) {
            return cs.AjaxBySpinner({
                url: '/Customers/UpdateAddressInformation',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "customerBasicModel": ko.mapping.toJS(self), "isDob": false })
            }, element, true)
        .done(function (result) {
            var notifyMessageModel = {
                Title: "Message",
                //Inline message
                Message: "Address Information updated successfully!"
            }
            toUpdateAddress(result.CustomerBasic, self);
            result.CustomerBasic.DateOfBirth = result.CustomerBasic.DateOfBirth == '01/01/1753' ? '' : result.CustomerBasic.DateOfBirth;
            ko.mapping.fromJS(result.CustomerBasic, {}, originalCustomerBasicModel);
            ko.mapping.fromJS(result, {}, app.senderInfo().Customer);
            app.senderInfo().Customer().CustomerBasic.IsShowAddressInformation(false);

            $.when(app.senderInfo().GetSenderLevel(element))
            .done(function () {
                $.when(OpenNotifyMessageModal(notifyMessageModel))
                .done(function () {
                    updateAddressStatus.complete();
                });
            })
            .fail(function () {
                updateAddressStatus.complete();
            });
        })
        .fail(function (xhr, status) {
            updateAddressStatus.complete();
            cs.handleAjaxError(xhr.responseText, false);
            ko.mapping.fromJS(originalCustomerBasicModel, {}, self);
        });

            RemoveSmartyStreetValidationStyle();
        }

        function toUpdateAddress(result, self) {
            if (result != null) {
                self.Address(result.Address);
                self.Address2(result.Address2);
                self.City(result.City);
                self.StateId(result.StateId);
                self.Zipcode(result.Zipcode);
                self.CountryId(result.CountryId);
                self.CityId(result.CityId);
            }
        }

        //Profiles Preferences
        self.InitializeForProfilePreferences = function () {
            self.CancelProfilePreferences();
        }

        self.CancelProfilePreferences = function () {
            self.IsAcceptEmailNewsletter(originalCustomerBasicModel.IsAcceptEmailNewsletter);
            self.ToggleProfilePreferencesListOpenOrClose();
        };

        function ValidProfilePreferences() {
            if (!self.IsAcceptEmailNewsletter()) {

                return false;
            }

            return true;
        }

        var updatePreferencesStatus = new cs.executeStatus();
        var noEmailAcceptStatus = new cs.executeStatus();
        self.UpdateProfilePreferences = function (element) {
            if (updatePreferencesStatus.isExecuting()) {
                return;
            }

            if (!self.IsAcceptEmailNewsletter() && self.UpdatePreferences) {
                $('#ConfirmCaption').text('Message');
                //Inline message
                $('#ConfirmMessage').html("<p>Are you sure you no longer want to receive our exciting offers?</p>");
                $('#ConfirmOk').text("Yes");
                $('#ConfirmCancel').text('No');
                $('#ConfirmOk').off('click');
                $('#ConfirmOk').one('click', function () {
                    if (noEmailAcceptStatus.isExecuting()) {
                        return;
                    }

                    noEmailAcceptStatus.setExecuting();
                    $.when(cs.closeModal())
                .done(function () {
                    $.when(DoUpdateProfilePreferences(element))
                    .done(function () {
                        self.UpdatePreferences = self.IsAcceptEmailNewsletter();

                        var notifyMessageModal = {
                            Title: 'Message',
                            //Inline message
                            Message: 'You have been unsubscribed from our Email Newsletter. You will still receive important emails related to your account activity.'
                        };
                        $.when(OpenNotifyMessageModal(notifyMessageModal, element))
                        .done(function () {
                            noEmailAcceptStatus.complete();
                        });
                    })
                    .fail(function () {
                        noEmailAcceptStatus.complete();
                    });
                });
                });
                $('#ConfirmCancel').off('click');
                $('#ConfirmCancel').one('click', function () {
                    $.when(cs.closeModal())
                .done(function () {
                    self.IsAcceptEmailNewsletter(originalCustomerBasicModel.IsAcceptEmailNewsletter);
                });
                });
                cs.openModal('modal-confirm');

                return;
            }

            updatePreferencesStatus.setExecuting();
            $.when(DoUpdateProfilePreferences(element))
            .done(function () {
                self.UpdatePreferences = self.IsAcceptEmailNewsletter();

                var notifyMessageModal = {
                    Title: 'Message',
                    //Inline message
                    Message: 'Profile Preferences updated successfully!'
                };
                $.when(OpenNotifyMessageModal(notifyMessageModal, element))
                .done(function () {
                    updatePreferencesStatus.complete();
                });
            })
            .fail(function () {
                updatePreferencesStatus.complete();
            });
        }

        function DoUpdateProfilePreferences(element) {
            return cs.AjaxBySpinner({
                url: '/Customers/UpdateProfilePreferences',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                    "isAcceptEmailNewsletter": self.IsAcceptEmailNewsletter(),
                    "languageId": self.LanguageId() == 0 ? 1 : self.LanguageId()
                })
            }, element)
        .done(function (result) {
            toUpdateProfilePreferences(result, self);
            result.DateOfBirth = result.DateOfBirth == '01/01/1753' ? '' : result.DateOfBirth;
            ko.mapping.fromJS(result, {}, originalCustomerBasicModel);
        });
        }

        function toUpdateProfilePreferences(result, self) {
            if (result != null) {
                self.IsAcceptEmailNewsletter(result.IsAcceptEmailNewsletter);
            }
        }

        function DOBShowErrorMessage(caption, message) {
            return cs.showErrorMessage(caption, message, function () {
                $.when(cs.closeModal())
            .done(function () {
                ko.mapping.fromJS(originalCustomerBasicModel, {}, self);
                return app.navigateToCustomerDashboardByLoading();
            });
            });
        }

        //Setting page
        self.InitializeForSettingPage = function () {
            self.InitializeForChangePassword();
            self.InitializeForAddressInformation();
            self.InitializeForProfileInformation();
            self.InitializeForProfilePreferences();
        };
        var dateBefore = getNowFormatDate();
        self.afterRenderAddDOBAndAddressPage = function () {
            if (cs.IsIpad()) {
                $("#dob-body").addClass('dob-body-max-height');
            }
            cs.datepickerFormat();
            cs.addPlaceHolderToDate();
            self.RemoveValidationMessage();
            self.ResetDOBAndAddress();
            if (self.IsShowAddressInformation()) {
                self.GetCitiesByStateId(null);
            }
            self.flag = 0;
            if (!cs.IsMobileDevice()) {
                initDOBDatePicker();
            } else {
                if (cs.IsIOS()) {
                    self.DateOfBirth(dateBefore);
                    $("#input-birth-day").off("focus").on("focus", function () {
                        SetOrRemoveDatePlaceHolder();
                        $("#date-error").addClass("dislpay-none");
                    });

                    $(".placeholder-button").off("focus").on("focus", function () {
                        SetOrRemoveDatePlaceHolder();
                        $("#date-error").addClass("dislpay-none");
                        $("#input-birth-day").focus();
                    });

                    $("#input-birth-day").off("input propertychange").on("input propertychange", function () {
                        SetOrRemoveDatePlaceHolder();
                        if ($(this).hasClass("error")) {
                            $(".placeholder-button").addClass("error");
                        } else {
                            $(".placeholder-button").removeClass("error");
                        }
                    });

                    $("#input-birth-day").off("blur").on("blur", function () {
                        if ($("#input-birth-day").val().length == 0) {
                            self.DateOfBirth(dateBefore);
                            $("#date-error").removeClass("dislpay-none");
                        }
                    });
                }
                else {
                    $("#input-birth-day").off("input propertychange").on("input propertychange", function () {
                        UpdateDateOfBirthStatus();
                    }).off("blur").on("blur", function () {
                        if (!self.DateOfBirth.isModified()) {
                            $(this).trigger("change");

                        }
                    });

                    $("#input-birth-day").off("blur").on("blur", function () {
                        if (!$(this).val()) {
                            $(".text-placeholder").css("display", "block");
                        }
                    });

                    $("#input-birth-day").off("focus").on("focus", function () {
                        if (!$("#input-birth-day").val()) {
                            var date = getNowFormatDate();
                            $("#input-birth-day").val(date);
                            self.DateOfBirth(date);
                            UpdateDateOfBirthStatus();
                        }
                    });

                    $(".text-placeholder").off("focus").on("focus", function () {
                        $(this).nextAll(".label-placeholder").click();
                    });

                    $("#input-last-name").off("keydown").on("keydown", function (e) {
                        if (e.keyCode == 13) {
                            if (!$("#input-birth-day").val()) {
                                var date = getNowFormatDate();
                                $("#input-birth-day").val(date);
                                self.DateOfBirth(date);
                                UpdateDateOfBirthStatus();
                            }
                        }
                    });
                }
            }
        }

        function SetOrRemoveDatePlaceHolder() {
            if ($("#input-birth-day").val().length == 0) {
                self.DateOfBirth($("#input-birth-day").val());
                $(".placeholder-button").removeClass("display-none");
                $("#input-birth-day").css("opacity", "0");
            } else {
                $(".placeholder-button").addClass("display-none");
                $("#input-birth-day").css("opacity", "1");
            }
        }

        function UpdateDateOfBirthStatus() {
            if (self.flag != 0 && !self.DateOfBirth.isModified()) {
                self.DateOfBirth.isModified(true);
            }

            if (self.flag == 1) {
                self.DateOfBirth($("#input-birth-day").val());
            }

            if (!$("#input-birth-day").val()) {
                $(".text-placeholder").css("display", "block");
            }

            self.flag = 1;
        }

        self.isMobile = function () {
            return cs.IsMobileDevice();
        }

        self.isIOS = function () {
            return cs.IsIOS();
        }

        self.isAndroid = function () {
            return (!cs.IsIOS() && cs.IsMobileDevice());
        }

        var emptyBeforeBlur = false;
        function initDOBDatePicker() {
            var enterToNext = cs.enterToNext;
            var datepicker = $("#input-birth-day");
            require(['Foundation.DatePicker'], function () {
                datepicker.fdatepicker({
                    appendElement: datepicker.parents()[1],
                    container: datepicker.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920'),
                    forceParse: false
                });

                $(".datepicker").off("click.moveToNext").on("click.moveToNext", ".day", function () {
                    var element = datepicker[0];
                    enterToNext.moveToNext(element, enterToNext.findNextElement(element));
                });

                $("#input-birth-day").off('focus').on('focus', function () {
                    if (!$(this).val()) {
                        var str = getNowFormatDate();
                        var d = new Date(str.replace(/-/g, "/"));
                        $("#input-birth-day").fdatepicker('setDate', d);
                    }
                    $(this).fdatepicker("show");
                });


                $("#input-birth-day").off('change').on('change', function (e) {
                    if (!$(this).val()) {
                        emptyBeforeBlur = true;
                    }
                    if (self.flag == 1) {
                        self.DateOfBirth($(this).val());
                    }
                    if (self.flag != 0 && !self.DateOfBirth.isModified()) {
                        self.DateOfBirth.isModified(true);
                    }
                });

                $("#input-birth-day").off('blur').on('blur', function () {
                    self.flag = 1;
                    if (emptyBeforeBlur) {
                        var str = getNowFormatDate();
                        var d = new Date(str.replace(/-/g, "/"));
                        $("#input-birth-day").fdatepicker('setDate', d);
                        $("#input-birth-day").val(getNowFormatDate(true));
                        emptyBeforeBlur = false;
                    }

                    if (self.flag == 1) {
                        self.DateOfBirth($(this).val());
                    }
                    if (self.flag != 0 && !self.DateOfBirth.isModified()) {
                        self.DateOfBirth.isModified(true);
                    }
                });

                $("#input-birth-day").off('click').on('click', function () {
                    if (!$(this).val()) {
                        var str = getNowFormatDate();
                        var d = new Date(str.replace(/-/g, "/"));
                        $("#input-birth-day").fdatepicker('setDate', d);
                    }
                });

            });
        }

        function getNowFormatDate(isSeperator1) {
            var date = new Date();
            var seperator1 = "\/";
            var seperator2 = "-";
            var year = date.getFullYear();
            year = year - 18;
            var month = date.getMonth() + 1;
            var strDate = date.getDate();
            if (month >= 1 && month <= 9) {
                month = "0" + month;
            }
            if (strDate >= 0 && strDate <= 9) {
                strDate = "0" + strDate;
            }
            var currentdate = year + seperator2 + month + seperator2 + strDate;

            if (isSeperator1) {
                currentdate = strDate + seperator1 + month + seperator1 + year;
            }
            return currentdate;
        }

        if (module == "setting") {
            self.InitializeForSettingPage();
        }
    }
});
