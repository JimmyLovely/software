﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'Router', paths['common-strings'], 'R', 'TrackEvent', 'carousel'], function (ko, cs, app, dataModel, Router, commonstrings, R, track) {
    function CustomerDashboardViewModel() {
        var self = this;
        self.isReady = ko.observable(false);
        self.title = commonstrings.viewmodeltitle.home;

        self.init = function () {
        };

        self.dispose = function () {
        };

        self.controllers = {
            '/': function () {
            }
        };

        var isFinishedGetRecentTransactions = false;
        var isFinishedGetRecentTransactionAccounts = false;
        var isFinishedGetSenderInfo = false;
        var timeoutAccount = 0;
        self.LoadFavoriteReceivers = new cs.executeStatus();
        self.LoadFavoriteBillers = new cs.executeStatus();
        self.LoadFavoriteCarriers = new cs.executeStatus();
        self.LoadRecentTransactions = new cs.executeStatus();
        self.ShowReferralPromoMessage = ko.observable(false);
        self.ShowUpgradePrompt = ko.observable(false);
        self.ShowSubmittedPrompt = ko.observable(false);
        self.ShowExpiredPrompt = ko.observable(false);


        //vStart appsflyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.Dashboard,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.Dashboard
            });
        }

        var trackDashobardTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.Dashboard,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Dashboard",
                eventPage: track.PageEnum.Dashboard,
                source: app.page().name,
                nonInteraction: true
            });
        }

        function trackRecentTransactionQuickPayTotalClicks(transactionTypeId, receiverName) {
            var evenLabel = "Recent Transactions ";
            if (transactionTypeId === cs.TransactionType.MoneyTransferToCard ||
                transactionTypeId === cs.TransactionType.MoneyTransferToCash) {
                evenLabel += "MT";
            } else if (transactionTypeId === cs.TransactionType.BillPayChiocePay ||
                transactionTypeId === cs.TransactionType.BillPayStandard ||
                transactionTypeId === cs.TransactionType.BillPay) {
                evenLabel += "BP";
            } else if (transactionTypeId === cs.TransactionType.EPin) {
                evenLabel += "TU-ePin";
            } else if (transactionTypeId === cs.TransactionType.TopUp && receiverName.indexOf("PINLESS") === -1) {
                evenLabel += "TU-reload";
            } else if (transactionTypeId === cs.TransactionType.TopUp && receiverName.indexOf("PINLESS") !== -1) {
                evenLabel += "TU-pinless";
            }

            trackEvent(evenLabel);
        }

        var trackTransactionHistoryTotalLoadsFromHome = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionHistory,
                eventAction: track.ActionEnum.SourcePage,
                eventLabel: "Source_HomePage",
                eventPage: track.PageEnum.TransactionHistory,
                source: track.PageEnum.TransactionHistory
            });
        }

        var trackMoneyTransferIconTotalClicks = R.compose(trackEvent, R.always('Icon Click MT'));

        var trackBillPayIconTotalClicks = R.compose(trackEvent, R.always('Icon Click BP'));

        var trackReloadIconTotalClicks = R.compose(trackEvent, R.always('Icon Click TU-reload'));

        var trackPinlessIconTotalClicks = R.compose(trackEvent, R.always('Icon Click TU-pinless'));

        var trackEpinIconTotalClicks = R.compose(trackEvent, R.always('Icon Click TU-ePin'));

        var trackViewTransactionHistoryLinkTotalClicks = R.compose(trackEvent, R.always('Transaction History'));

        // End appsflyer track event

        function HandelTimeOut() {
            setTimeout(function () {
                if (timeoutAccount >= 3) {
                    // Please contact customercare and remove loading.
                    if (!isFinishedGetRecentTransactions) {
                        self.Transactions(ko.mapping.fromJS([]));
                        self.TryToGetTransactions(true);
                    }
                    if (!isFinishedGetRecentTransactionAccounts) {
                        self.RemoveFavoriteAccountsLoading();
                    }
                    return;
                }
                if (!isFinishedGetRecentTransactions) {
                    AjaxGetRecentTransactions();
                    HandelTimeOut();
                }
                if (!isFinishedGetRecentTransactionAccounts) {
                    AjaxGetRecentTransactionAccounts();
                    HandelTimeOut();
                }
                if (!isFinishedGetSenderInfo) {
                    AjaxGetSenderInfo();
                    HandelTimeOut();
                }
                if (app.senderInfo() != null && app.senderInfo().PromotionMessages() == null) {
                    self.InitialPromotionCarousel();
                    HandelTimeOut();
                }
                timeoutAccount++;
            }, 10000);
        }

        function AjaxGetSenderInfo() {
            if (app.senderInfo()) {
                return;
            }

            setTimeout(function () {
                $.ajax({
                    url: '/Customers/GetSenderInfo',
                    type: "GET",
                    dataType: "json"
                })
                .done(function (data) {
                    if (app.senderInfo()) {
                        return;
                    }

                    cs.CacheMoneyTransferPermission(app.senderInfo().HasMoneyTransferPermission());

                    localStorage.setItem("SenderInfo", JSON.stringify(data));
                    isFinishedGetSenderInfo = true;
                    require(['SenderInfo'], function (SenderInfoModel) {
                        app.senderInfo(new SenderInfoModel(data));
                        if (app.page().data.LoadedSenderInfo) {
                            app.page().data.LoadedSenderInfo();
                        }

                    });
                });
            });
        }

        function preventBrowserBackToLogin() {
            if (!history.state) {
                window.history.pushState({}, '', app.page().name);
            }
        }

        self.afterRender = function () {
            cs.RemoveOpen();
            //cache pages
            HandelTimeOut();
            //AjaxGetSenderInfo();
            self.checkSenderLevelInfo();
            preventBrowserBackToLogin();

            if (!IsLocalStorageUpdated) {
                setTimeout(function () {
                    self.loadLookUpData();
                }, 500);
            }
            if (app.senderInfo() != null) {
                app.senderInfo().GetSenderLevel("#virtualElement");
            }

            trackDashobardTotalLoads();
        };

        self.checkSenderLevelInfo = function () {
            if (app.senderInfo() && app.senderInfo().SenderLevel()) {
                self.ShowUpgradePrompt(app.senderInfo().SenderLevel().Status == 2 && app.senderInfo().HasMoneyTransferPermission());
                self.ShowExpiredPrompt(app.senderInfo().SenderLevel().Status == 3 && app.senderInfo().HasMoneyTransferPermission());
                self.ShowSubmittedPrompt(app.senderInfo().ShowSubmittedPrompt);
                app.senderInfo().ShowSubmittedPrompt = false;
            } else {
                app.page().data.LoadedSenderInfo = function () {
                    self.checkSenderLevelInfo();
                };
            }
        }

        self.setNotifiedaAndExpired = function (data, event) {
            dataModel.closeExpiredDocumentNotification();
            self.ShowExpiredPrompt(false);
            event.preventDefault();
            event.stopPropagation();
            return false;
        }

        var IsLocalStorageUpdated = false;

        self.loadLookUpData = function () {
            try {
                if (!window.isPrivateMode && window.localStorage) {
                    $.ajax({
                        url: "/Customers/GetLookUp",
                        type: "GET",
                        dataType: "json",
                        contentType: "application/json",
                        data: { "lookupFileVersion": window.localStorage.lookupFileVersion, 'manualRefresh': window.localStorage.manualRefresh }
                    })
                    .done(function (data) {
                        IsLocalStorageUpdated = true;
                        if (data.LookupFileVersion != window.localStorage.lookupFileVersion || data.ManualRefresh != window.localStorage.manualRefresh) {
                            cs.SetLocalStorage("lookupFileVersion", data.LookupFileVersion);

                            cs.SetLocalStorage("manualRefresh", data.ManualRefresh);

                            var transactionDestinations = data.TransactionDestinations;
                            cs.SetLocalStorage("transactionDestinations", JSON.stringify(transactionDestinations));

                            var states = data.States;
                            cs.SetLocalStorage("states", JSON.stringify(states));

                            var cities = data.Cities;
                            cs.SetLocalStorage("cities", JSON.stringify(cities));

                            var BPCountries = data.BPCountries;
                            cs.SetLocalStorage("BPCountries", JSON.stringify(BPCountries));

                            var LCRCountries = data.LCRCountries;
                            cs.SetLocalStorage("LCRCountries", JSON.stringify(LCRCountries));

                            var TUCountries = data.TUCountries;
                            cs.SetLocalStorage("TUCountries", JSON.stringify(TUCountries));
                        }
                    })
                }
            } catch (e) { }
        }

        self.GetSelectedTransaction = function (transaction) {
            if (!app.senderInfo().CheckPermission(transaction.TransactionTypeId)) {
                return;
            }
            dataModel.GetSelectedTransaction(transaction.TransactionTypeId, transaction.ReceiptNumber, transaction.ReceiverName, "FromRecentTransaction");

            trackRecentTransactionQuickPayTotalClicks(transaction.TransactionTypeId, transaction.ReceiverName);
            track.trackTimeOnPageForPageLink("QuickPay");
        }

        self.getRecentTransactions = function () {
            self.Transactions(null);
            self.TryToGetTransactions(false);
            AjaxGetRecentTransactions();
        };

        function AjaxGetRecentTransactions() {
            if (self.LoadRecentTransactions.isExecuting()) {
                return;
            }
            self.LoadRecentTransactions.setExecuting();
            cs.BaseAjax({
                url: '/Customers/SelfServiceGetRecentTransactions',
                type: "GET",
                dataType: "json"
            }).done(function (data) {
                isFinishedGetRecentTransactions = true;
                if (data == null) {
                    data = [];
                }

                self.TryToGetTransactions(false);
                self.Transactions(data);
            }).fail(function () {
                self.LoadRecentTransactions.complete();
                self.Transactions([]);
                self.TryToGetTransactions(true);
            })
        }

        function AjaxGetRecentTransactionAccounts() {
            self.getRecentTransactionAccounts();

            if (location.hash == '#panel-money-transfer') {
                self.GetFavoriteReceivers();
            } else if (location.hash == '#panel-bill-pay') {
                self.GetFavoriteBillingAccounts();
            } else if (location.hash == '#panel-top-ups') {
                self.GetFavoriteCarriers();
            }
        }

        self.initFavoriteAccounts = function () {
            self.Receivers(null);
            self.BillPayBillingAccounts(null);
            self.TopUpBillingAccounts(null);

            self.TryToGetReceivers(false);
            self.TryToGetBillPayBillingAccounts(false);
            self.TryToGetTopUpBillingAccounts(false);
        }

        self.RemoveFavoriteAccountsLoading = function () {
            self.Receivers([]);
            self.BillPayBillingAccounts([]);
            self.TopUpBillingAccounts([]);

            self.TryToGetReceivers(true);
            self.TryToGetBillPayBillingAccounts(true);
            self.TryToGetTopUpBillingAccounts(true);
        };

        self.getRecentTransactionAccounts = function () {
            self.initFavoriteAccounts();

            if (location.hash != '#panel-money-transfer' && location.hash != '#panel-bill-pay' && location.hash != '#panel-top-ups') {
                cs.triggerTab('#panel-money-transfer');
            }
        }

        self.GetFavoriteReceivers = function () {
            if (self.LoadFavoriteReceivers.isExecuting()) {
                return;
            }
            self.LoadFavoriteReceivers.setExecuting();
            cs.BaseAjax({
                url: '/MoneyTransfer/GetFavoriteReceivers',
                type: 'GET',
                dataType: 'json'
            })
            .done(function (data) {
                if (!data) {
                    data = [];
                }
                isFinishedGetRecentTransactionAccounts = true;
                self.TryToGetReceivers(false);
                self.Receivers(data);
            })
            .fail(function () {
                self.LoadFavoriteReceivers.complete();
                self.Receivers([]);
                self.TryToGetReceivers(true);
            });
        }

        self.GetFavoriteBillingAccounts = function () {
            if (self.LoadFavoriteBillers.isExecuting()) {
                return;
            }
            self.LoadFavoriteBillers.setExecuting();

            cs.BaseAjax({
                url: '/Customers/GetFavoriteBillingAccounts',
                type: 'GET',
                data: 'json'
            })
            .done(function (data) {
                if (!data) {
                    data = [];
                }
                isFinishedGetRecentTransactionAccounts = true;
                self.TryToGetBillPayBillingAccounts(false);
                self.BillPayBillingAccounts(data);
            })
            .fail(function () {
                self.LoadFavoriteBillers.complete();
                self.BillPayBillingAccounts([]);
                self.TryToGetBillPayBillingAccounts(true);
            });
        }

        self.GetFavoriteCarriers = function () {
            if (self.LoadFavoriteCarriers.isExecuting()) {
                return;
            }
            self.LoadFavoriteCarriers.setExecuting();

            cs.BaseAjax({
                url: '/TopUp/GetFavoriteCarriers',
                type: 'GET',
                data: 'json'
            })
            .done(function (data) {
                if (!data) {
                    data = [];
                }
                isFinishedGetRecentTransactionAccounts = true;
                self.TryToGetTopUpBillingAccounts(false);
                self.TopUpBillingAccounts(data);
            })
            .fail(function () {
                self.LoadFavoriteCarriers.complete();
                self.TopUpBillingAccounts([]);
                self.TryToGetTopUpBillingAccounts(true);
            });
        }

        self.QuickToPayByReceiver = function (receiver) {
            if (!app.senderInfo().HasMoneyTransferPermission()) {
                return;
            }
            dataModel.QuickToPayByReceiver(receiver);
        };

        self.QuickToPayByBillingAccount = function (isBillPayLCR, billingAccount) {
            if (isBillPayLCR) {
                if (!app.senderInfo().HasBillPayLCRPermission()) {
                    return;
                }
            } else {
                if (!app.senderInfo().HasBillPayPermission()) {
                    return;
                }
            }

            dataModel.QuickToPayByBillingAccount(isBillPayLCR, billingAccount);
        };

        self.QuickToPayByCarrier = function (carrier) {
            if (!app.senderInfo().HasTopUpReloadPermission()) {
                return;
            }
            dataModel.QuickToPayByCarrier(carrier);
        };

        self.FormatAccountNumber = function (accountNumber) {
            if (accountNumber) {
                return accountNumber.substr(-4);
            }

            return "";
        }

        self.initScripts = function () {
            $(".services-expand").off("click.custom");
            $(".services-expand").on("click.custom", function () {
                $(this).parent().toggleClass("open");
                return false;
            });
        }

        self.InitialPromotionCarousel = function () {
            if (app.senderInfo() != null) {
                $.when(app.senderInfo().GetSelfServicePosMessages())
                .done(function () {
                    if (app.senderInfo().PromotionMessages().length > 0 || self.ShowReferralPromoMessage()) {
                        $("#promotion-section").removeAttr("style");
                        $("#promo-slider").owlCarousel();
                    }
                });
            }
        }

        self.SubmitUpgradeDocuments = function (text) {
            dataModel.GoToUpgradeLevel(app.senderInfo().SenderLevel().SourceLevelId, app.senderInfo().SenderLevel().TargetLevelId);
            track.trackTimeOnPageForPageLink(text);
        }

        self.ClosePrompt = function () {
            self.ShowSubmittedPrompt(false);
        }

        self.Receivers = ko.observableArray([]);
        self.BillPayBillingAccounts = ko.observableArray([]);
        self.TopUpBillingAccounts = ko.observableArray([]);
        self.Transactions = ko.observable([]);
        self.PromotionMessages = ko.observableArray([]);

        self.TryToGetReceivers = ko.observable(false);
        self.TryToGetBillPayBillingAccounts = ko.observable(false);
        self.TryToGetTopUpBillingAccounts = ko.observable(false);
        self.TryToGetTransactions = ko.observable(false);
        self.TryToGetPromotionMessages = ko.observable(false);

        self.goToMoneyTransfer = function () {
            trackMoneyTransferIconTotalClicks();

            app.senderInfo().GoToMoneyTransfer("FromDashBoard");
            track.trackTimeOnPageForPageLink("FromDashBoard_SendMoney");
        }

        self.goToBillPayOrLCR = function () {
            trackBillPayIconTotalClicks();

            app.senderInfo().GoToBillPayOrLCR("FromDashBoard");
            track.trackTimeOnPageForPageLink("FromDashBoard_BillPay");
        };

        self.goToReload = function () {
            trackReloadIconTotalClicks();

            app.senderInfo().goToTopUpReload("FromDashBoard");
            track.trackTimeOnPageForPageLink("FromDashBoard_Reload");
        };

        self.goToPinless = function () {
            trackPinlessIconTotalClicks();

            app.senderInfo().goToTopUpsPinless("FromDashBoard");
            track.trackTimeOnPageForPageLink("FromDashBoard_Pinless");
        };

        self.goToEpin = function () {
            trackEpinIconTotalClicks();

            app.senderInfo().goToTopUpsEpin("FromDashBoard");
            track.trackTimeOnPageForPageLink("FromDashBoard_Epin");
        };

        self.goToTransactionDetails = function () {
            app.redirectTo("/SelfService/AccountConsumer#panel-transaction_refresh");

            trackTransactionHistoryTotalLoadsFromHome();

            trackViewTransactionHistoryLinkTotalClicks();
            track.trackTimeOnPageForPageLink("ViewTransactionHistory");
        }

        var trackPromotionTotalClicks = trackEvent;
        self.learnMore = trackPromotionTotalClicks;
    }

    return new CustomerDashboardViewModel();
});