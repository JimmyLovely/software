﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation', 'Plugins', 'knockout.validation.extended'], function (ko, cs, app, dataModel) {
    return function ReceiverModel(data) {
        var self = this;
        self.layoutAddRecipientFlag = ko.observable(false);
        self.EditRecipientFlag = ko.observable(false);
        self.AddPickUpLocationFlag = ko.observable(false);

        //Has Delivery Option
        self.HasAccountDeposit = ko.observable(false);
        self.HasCashPickup = ko.observable(false);
        self.HasUnidosCard = ko.observable(false);
        self.HasHomeDelivery = ko.observable(false);

        ko.computed(function () {
            var s = self.layoutAddRecipientFlag();
            if (s==false) {
                var b = true;
            }
        });

        // 0 means valid.
        // 1 means empty.
        // 2 means no result.
        self.ValidType = ko.observable(0);
        self.ValidTypeForEdit = ko.observable(0);
        self.ValidAddress = ko.observable(0);
        self.ValidCity = ko.observable(0);

        // 0 means empty
        // 1 means cell phone
        // 2 means home phone
        self.PhoneType = ko.observable("0");
        ko.mapping.fromJS(data, {}, self);

        var defaultReceiver = ko.mapping.toJS(self);
        defaultReceiver.NewBankAccount.PaymentType.AccountType = "";
        self.NewBankAccount.PaymentType.AccountType("");
        self.cities;

        self.PhoneNumberIsInValid = ko.computed(function () {
            var phoneNumber = self.PhoneNumber();
            if (!phoneNumber) {
                return;
            }

            var tempPhoneNumber = self.GetRemoveFormatPhoneNumber(phoneNumber);
            if (cs.IsInvalidPhoneNumber(tempPhoneNumber)) {
                return true;
            }

            if (tempPhoneNumber.length <= 17) {
                return false;
            } else {
                return true;
            }
        });

        function applyReceiverValidation() {
            self.FirstName.extend({
                required: { params: true, message: 'First name is required' },
                minTrimLength: { params: 2, message: 'Minimum length of first name is 2 characters' },
                maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.FirstName()) != 0 },
                    message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
                }
            }).isModified(false);
            self.MiddleName.extend({
                maxLength: { params: 50, message: 'Maximum length of middle name is 50 characters' },
                equal: {
                    onlyIf: function () { return self.MiddleName() != "" && cs.IsInvalidName(self.MiddleName()) != 0 },
                    message: function () { return cs.IsInvalidName(self.MiddleName()) == 1 ? 'Middle name should start with a letter' : 'Invalid middle name' }
                }
            }).isModified(false);
            self.LastName.extend({
                required: { params: true, message: 'Last name is required' },
                minTrimLength: { params: 2, message: 'Minimum length of last name is 2 characters' },
                maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.LastName()) != 0 },
                    message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
                }
            }).isModified(false);
            self.Address.extend({ required: { params: true, message: 'Address is required' } }).isModified(false);
            self.StateId.extend({ required: { params: true, message: 'State is required' } }).isModified(false);
            self.PaymentType.AccountNumber.extend({ required: { params: true, message: 'Account number is required' } }).isModified(false);
            self.Zipcode.extend({
                number: {
                    params: true,
                    message: 'Enter a valid zip code'
                },
                maxLength: {
                    params: 12,
                    message: 'Enter a valid zip code'
                }
            }).isModified(false);

            self.PhoneNumber.extend({
                required: {
                    params: true,
                    message: 'Phone is required'
                },
                minLength: {
                    params: 10,
                    message: 'Minimum length of phone number is 10 characters'
                },
                equal: {
                    onlyIf: self.PhoneNumberIsInValid,
                    message: 'Enter a valid phone number'
                }
            }).isModified(false);

            self.RelationShipId.extend({
                required: {
                    params: true,
                    message: 'Relationship is required'
                }
            }).isModified(false);

            self.EmailAddress.extend({
                email: {
                    params: true,
                    message: 'Invalid email address'
                }
            }).isModified(false);

            self.CountryId.extend({
                required: {
                    params: true,
                    message: 'Country is required'
                }
            }).isModified(false);
        }

        applyReceiverValidation();

        function GetLocations() {
            var countryId = self.CountryId();
            var transactionType = 14;
            var city = {
                CorrespondentId: self.NewPickupLocation.PaymentType.Payouts()[0],
                CityName: self.NewPickupLocation.Location.City(),
                StateName: $("#select-cash-state").find("option:selected").text(),
                ItemCount: 0
            }
            $("#loading-icon").css({ "display": "block", "margin-top": "0.6rem" });
            $("#search-icon").fadeOut();
            $("#loading-icon").fadeIn();

            cs.BaseAjax({
                url: '/MoneyTransfer/GetLocations',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": countryId, "matchingCity": city, "transactionTypeId": transactionType })
            })
        .done(function (data) {
            var tempAddresses = new Array();
            for (var i = 0; i < data.length; i++) {
                tempAddresses.push(data[i].Address);
            }

            var locations = $.map(ko.mapping.toJS(data), function (item, index) { return { value: item.Address, data: item }; });;
            locations.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            $('#input-address-01-new').autocomplete({
                lookup: locations,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (self.NewPickupLocation.Location.Address() != suggestion.data.Address) {
                        self.NewPickupLocation.Location.Address(suggestion.data.Address);
                        self.NewPickupLocation.Location.Zipcode(suggestion.data.Zipcode);
                        self.NewPickupLocation.Location.Branch.BranchCode(suggestion.data.Branch.BranchCode);
                        self.NewPickupLocation.Location.Branch.BranchName(suggestion.data.Branch.BranchName);
                    }
                    self.ValidAddress(0);
                },
                onInvalidateSelection: function () {
                    if ($('#input-address-01-new').val().trim() != self.NewPickupLocation.Location.Address() || $('#input-address-01-new').val().trim() == "") {
                        self.NewPickupLocation.Location.Address("");
                        self.ValidAddress($('#input-address-01-new').val() == "" ? 1 : 2);
                        self.NewPickupLocation.Location.Zipcode("");
                    }
                },
            });
        }).fail(function () {
            $("#search-icon").fadeIn();
            $("#loading-icon").fadeOut();
        });
        }

        self.AddDestination = function (element, destination, amountToLoad) {
            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/AddRecipientDeliveryOption',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "receiverCardHolderId": self.CardHolderId(), "recipientDestinationModel": ko.mapping.toJS(destination), "amountToLoad": amountToLoad })
            }, element)
        .done(function (recipientDestination) {
            var tempArray = ko.mapping.toJS(self.RecipientDestinations);
            if (!tempArray) {
                tempArray = new Array();
            }

            if (tempArray.length > 0 && (recipientDestination.PaymentType.PaymentTypeId == 1 || recipientDestination.PaymentType.PaymentTypeId == 4)) {// Bank account deposit and Home Delivery only one, So We need remove the older.
                var array = new Array();
                for (var i = 0; i < tempArray.length; i++) {
                    if (tempArray[i].PaymentType.PaymentTypeId != recipientDestination.PaymentType.PaymentTypeId) {
                        array.push(tempArray[i]);
                    }
                }

                tempArray = array;
            }

            tempArray.push(recipientDestination);
            ko.mapping.fromJS(tempArray, {}, self.RecipientDestinations);
            defaultReceiver.RecipientDestinations = tempArray;
            SetReceiverDeliveryOption(recipientDestination);

            return recipientDestination.Fees;
        });
        };

        // begin: Add Bank Account Deposit
        self.InitializeAddBankAccountDeposit = function (correspondentElement) {
            correspondentElement = cs.GetElementIdWithSymbol(correspondentElement);
            self.ResetValidType();
            ko.mapping.fromJS(defaultReceiver.NewBankAccount, {}, self.NewBankAccount);
            $(correspondentElement).val("");
            self.BankAccountPickupType(1);
            self.NewBankAccount.PaymentType.AccountType.isModified(false);
            self.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
        };

        self.ValidateNewBankAccount = function () {
            var PaymentTypeGroup = {
                Correspondent: self.NewBankAccount.PaymentType.Correspondent,
                AccountNumber: self.NewBankAccount.PaymentType.AccountNumber,
                ConfirmAccountNumber: self.NewBankAccount.PaymentType.ConfirmAccountNumber,
                AccountType: self.NewBankAccount.PaymentType.AccountType
            }
            self.NewBankAccount.PaymentType.errors = ko.validation.group(PaymentTypeGroup);
            if (PaymentTypeGroup.isValid() && self.NewBankAccount.PaymentType.PaymentTypeId() == 1 &&
                (self.NewBankAccount.PaymentType.AccountTypes().length == 0 || self.NewBankAccount.PaymentType.AccountType())) {
                return true;
            } else {
                self.NewBankAccount.PaymentType.errors.showAllMessages();
                if (self.NewBankAccount.PaymentType.PaymentTypeId() != 1) {
                    self.ValidType($("#autocomplete-accountdeposit-names").val().trim() == "" ? 1 : 2);
                }
                return false;
            }
        };

        self.BindBankAccountCorrespondents = function (autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (suggestion.value != self.NewBankAccount.PaymentType.Correspondent()) {
                        ko.mapping.fromJS(suggestion.data, {}, self.NewBankAccount.PaymentType);
                        RemoveNewBankAccountValidationMessage();

                        if (self.NewBankAccount.PaymentType.IsPaymentTypeAccount()) {
                            var accountTypes = self.NewBankAccount.PaymentType.AccountTypes();
                            if (accountTypes.length > 0) {
                                if (accountTypes.length == 1 && accountTypes[0].Value() == 3) {
                                    var accountType = accountTypes[0].Value;
                                    ko.mapping.fromJS(accountType, {}, self.NewBankAccount.PaymentType.AccountType);
                                } else {
                                    self.NewBankAccount.PaymentType.AccountType("");
                                    self.NewBankAccount.PaymentType.AccountType.isModified(false);
                                }
                            }
                        }
                    }
                    self.ValidType(0);
                },
            });

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                var value = $(autoCompleteElement).val().trim();
                if (value != self.NewBankAccount.PaymentType.Correspondent()) {
                    if (value == "") {
                        self.ValidType(1);
                    }
                    else if (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) > -1) {
                        self.ValidType(0);
                        return;
                    }
                    else {
                        self.ValidType(2);
                    }

                    ko.mapping.fromJS(defaultReceiver.NewBankAccount, {}, self.NewBankAccount);
                    RemoveNewBankAccountValidationMessage();
                }
            });

            $(autoCompleteElement).off("blur.correspondentchanged");
            $(autoCompleteElement).on("blur.correspondentchanged", function () {
                if ($('.autocomplete-selected').length > 0) return;

                var value = $(autoCompleteElement).val().trim();
                var matchedIndex = -1;

                if (value != self.NewBankAccount.PaymentType.Correspondent()) {
                    if (value == "") {
                        self.ValidType(1);
                    }
                    else if ($(autoCompleteElement).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, true)) > -1) {
                        self.ValidType(0);
                        $(autoCompleteElement).autocomplete().select(matchedIndex);
                        return;
                    }
                    else {
                        self.ValidType(2);
                    }
                }
            });
        }

        self.BindBankAccountCorrespondentsForEdit = function (autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (suggestion.value != self.BankAccount.PaymentType.Correspondent()) {
                        ko.mapping.fromJS(suggestion.data, {}, self.BankAccount.PaymentType);
                        RemoveBankAccountValidationMessage();
                        if (self.BankAccount.PaymentType.IsPaymentTypeAccount()) {
                            var accountTypes = self.BankAccount.PaymentType.AccountTypes();
                            if (accountTypes.length > 0) {
                                if (accountTypes.length == 1 && accountTypes[0].Value() == 3) {
                                    var accountType = accountTypes[0].Value;
                                    ko.mapping.fromJS(accountType, {}, self.BankAccount.PaymentType.AccountType);
                                } else {
                                    self.BankAccount.PaymentType.AccountType("");
                                    self.BankAccount.PaymentType.AccountType.isModified(false);
                                }
                            }
                        }
                    }

                    self.ValidTypeForEdit(0);
                }
            });

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                if ($(autoCompleteElement).val().trim() != self.BankAccount.PaymentType.Correspondent()) {
                    self.ValidTypeForEdit($(autoCompleteElement).val().trim() == "" ? 1 : 2);
                    ko.mapping.fromJS(defaultReceiver.BankAccount, {}, self.BankAccount);
                    RemoveBankAccountValidationMessage();
                }
            });
        }

        function RemoveBankAccountValidationMessage() {
            self.BankAccount.PaymentType.AccountType.isModified(false);
            self.BankAccount.PaymentType.AccountNumber.isModified(false);
            self.BankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
        };

        function RemoveNewBankAccountValidationMessage() {
            self.NewBankAccount.PaymentType.AccountType.isModified(false);
            self.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
        };

        self.AddBankAccountDeposit = function (amountToLoad, element) {
            return self.AddDestination(element, self.NewBankAccount, amountToLoad);
        };

        self.ResetBankAccountDepositForNewBankAccount = function (autoCompleteElement) {
            autoCompleteElement = cs.GetElementIdWithSymbol(autoCompleteElement);
            ko.mapping.fromJS(defaultReceiver.NewBankAccount, {}, self.NewBankAccount);
            $(autoCompleteElement).val("");
            $(autoCompleteElement).autocomplete({
                lookup: [],
            });
            self.ValidType(0);
            self.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.AccountType.isModified(false);
            self.BankAccountPickupType(0);
        };

        self.ResetBankAccountDepositForBankAccount = function (autoCompleteElement) {
            autoCompleteElement = cs.GetElementIdWithSymbol(autoCompleteElement);
            self.ValidTypeForEdit(0);
            ko.mapping.fromJS(defaultReceiver.BankAccount, {}, self.BankAccount);
            $(autoCompleteElement).val("");
            $(autoCompleteElement).autocomplete({
                lookup: [],
            });
            self.ValidTypeForEdit(0);
            self.BankAccount.PaymentType.AccountNumber.isModified(false);
            self.BankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
            self.BankAccount.PaymentType.AccountType.isModified(false);
            self.BankAccountPickupType(0);
        };

        // end: Add Bank Account Deposit

        function ResetCorrespondentsControl() {
            $('#autocomplete-moneytransfer-correspondent-names').val("");
            $('#autocomplete-moneytransfer-correspondent-names').autocomplete({
                lookup: new Array()
            });

            ko.mapping.fromJS(defaultReceiver.NewPickupLocation.PaymentType, {}, self.NewPickupLocation.PaymentType);
            RestInputAddressControl();
        }

        function RestInputAddressControl() {
            $('#input-address-01-new').val("");
            self.ValidAddress(0);
            $('#input-address-01-new').autocomplete({
                lookup: new Array()
            });

            self.NewPickupLocation.Location.Zipcode("");

        }

        // begin: Add Pick Up Location
        self.BindPickupLocationCities = function (element, stateId) {
            if (!stateId || stateId == -1) {
                return true;
            }

            if (typeof element == "string") {
                if (element.indexOf("#") != 0) {
                    element = "#" + element;
                }
            }

            ResetCorrespondentsControl();
            $(element).val("");
            $.when(dataModel.GetLookUpCities(self.CountryId(), stateId))
            .done(function (LookUpCities) {
                $(element).autocomplete({
                    lookup: LookUpCities,
                    triggerSelectOnValidInput: true,
                    minChars: 0,
                    onSelect: function (suggestion) {
                        if (self.NewPickupLocation.Location.City() != suggestion.value) {
                            self.NewPickupLocation.Location.City(suggestion.value);
                            self.SearchPickupLocationCorrespondents("button-pickup-location");
                        }
                        self.ValidCity(0);
                    },
                    onInvalidateSelection: function () {
                        self.ValidCity($(element).val() == "" ? 1 : 2);
                    }
                });
            });

            return true;
        };

        self.ValidLoctionCity = function (element) {
            if ($(element).val().trim() != self.NewPickupLocation.Location.City() || $(element).val() == "") {
                self.NewPickupLocation.Location.City("");
                ResetCorrespondentsControl();
                self.ValidCity($(element).val() == "" ? 1 : 2);
            }
        };

        self.BindPickUpLocationCorrespondent = function (autoCompleteElement) {// Using Now
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var countryId = self.CountryId();
            var stateName = $("#select-cash-state").find("option:selected").text();
            self.NewPickupLocation.Location.State(stateName);
            var cityName = self.NewPickupLocation.Location.City();
            var stateId = self.NewPickupLocation.Location.StateId();

            if (cityName != "" && cityName != null && stateId > 0) {
                return cs.BaseAjax(
              {
                  url: '/MoneyTransfer/GetCorrespondentsForPickupLocation',
                  type: "Post",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({ "countryId": countryId, "stateName": stateName, "city": cityName })
              })
              .done(function (data) {
                  // Delete this after finished search correspondent.
                  var result = new Array();
                  for (var i = 0; i < data.length; i++) {
                      if (data[i].Correspondent != "" && (data[i].PaymentTypeId == 2 || data[i].PaymentTypeId == 3 || data[i].PaymentTypeId == 6) && data[i].CurrencyId == data[i].CountryId) {
                          result.push(data[i]);
                      }
                  }
                  // End
                  var tempCorrespondents = $.map(ko.mapping.toJS(result), function (item, index) { return { value: item.Correspondent, data: item }; });;
                  tempCorrespondents.sort(function (x, y) {
                      return cs.sortByString(x.value, y.value, true);
                  });
                  $(autoCompleteElement).autocomplete({
                      lookup: tempCorrespondents,
                      triggerSelectOnValidInput: true,
                      minChars: 0,
                      onSelect: function (suggestion) {
                          if (self.NewPickupLocation.PaymentType.Correspondent() != suggestion.value) {
                              ko.mapping.fromJS(suggestion.data, {}, self.NewPickupLocation.PaymentType);
                              RestInputAddressControl();
                              if (self.NewPickupLocation.PaymentType.PaymentTypeId() == 6) { // Cash to branch need add location
                                  GetLocations();
                              }
                          }

                          self.ValidType(0);
                      },
                      onInvalidateSelection: function () {
                          self.ValidType($(autoCompleteElement).val().trim() == "" ? 1 : 2);
                      }
                  });
              });
            }
        }

        self.ValidLocationCorrespondent = function (element) {
            if ($(element).val().trim() != self.NewPickupLocation.PaymentType.Correspondent() || $(element).val() == "") {
                self.ValidType($(element).val().trim() == "" ? 1 : 2);
                ko.mapping.fromJS(defaultReceiver.NewPickupLocation.PaymentType, {}, self.NewPickupLocation.PaymentType);
                RestInputAddressControl();
            }
        };

        self.SearchPickupLocationCorrespondents = function (element) {
            addSearchSpinner(element);
            $.when(self.BindPickUpLocationCorrespondent("autocomplete-moneytransfer-correspondent-names"))
            .always(function () {
                removeSearchSpinner(element);
            });
        }

        self.ValidateNewPickupLocation = function () {
            self.NewPickupLocation.Location.errors = ko.validation.group(self.NewPickupLocation.Location);
            if (self.NewPickupLocation.Location.City().trim() && [2, 3, 6].indexOf(self.NewPickupLocation.PaymentType.PaymentTypeId()) != -1) {
                if (self.NewPickupLocation.PaymentType.PaymentTypeId() == 6) {
                    if (!self.NewPickupLocation.Location.Address()) {
                        self.ValidAddress($('#input-address-01-new').val() == "" ? 1 : 2);
                        return false;
                    }
                };
                return true;
            } else {
                if (!self.NewPickupLocation.Location.City().trim()) {
                    self.ValidCity($("#autocomplete-moneytransfer-city-names").val() == "" ? 1 : 2);
                }
                self.NewPickupLocation.Location.errors.showAllMessages();
                if (self.NewPickupLocation.PaymentType.PaymentTypeId() != 1) {
                    self.ValidType($("#autocomplete-moneytransfer-correspondent-names").val().trim() == "" ? 1 : 2);
                }
                return false;
            }
        };

        self.ValidLocationAddress = function (element) {
            if ($(element).val().trim() != self.NewPickupLocation.Location.Address() || $(element).val() == "") {
                self.NewPickupLocation.Location.Address("");
                self.ValidAddress($(element).val() == "" ? 1 : 2);
            }
            else {
                self.ValidAddress(0);
            }
        };

        self.ValidSelectedDestinationAddress = function (element) {
            if ($(element).val().trim() != self.SelectedDestination.Location.Address() || $(element).val() == "") {
                self.SelectedDestination.Location.Address("");
                self.ValidAddress($(element).val() == "" ? 1 : 2);
            }
            else {
                self.ValidAddress(0);
            }
        }

        self.ShouldShowLocation = ko.observable(true);

        self.AddPickupLocation = function (location, amountToLoad, element) {
            var tempPaymentType = ko.mapping.toJS(self.PaymentType);
            ko.mapping.fromJS(tempPaymentType, {}, self.NewPickupLocation.PaymentType);
            if (location != null) {
                var tempLocation = ko.mapping.toJS(location);
                ko.mapping.fromJS(tempLocation, {}, self.NewPickupLocation.Location);
            }
            return self.AddDestination(element, self.NewPickupLocation, amountToLoad);
        };

        self.resetAddPickupLocation = function () {
            ko.mapping.fromJS(defaultReceiver.PaymentType, {}, self.PaymentType);
            ko.mapping.fromJS(defaultReceiver.NewPickupLocation, {}, self.NewPickupLocation);
            $("#autocomplete-moneytransfer-city-names").error(false, '');

            $("#autocomplete-moneytransfer-city-names").val("");
            $("#autocomplete-moneytransfer-city-names").autocomplete({
                lookup: [],
            });

            $("#autocomplete-moneytransfer-correspondent-names").val("");
            $("#autocomplete-moneytransfer-correspondent-names").autocomplete({
                lookup: [],
            });

            RestInputAddressControl();

            self.AddPickUpLocationFlag(false);
            cs.closeModalCallBack('modal-location-new', function () {
                self.AddPickUpLocationFlag(false);
            });
        };
        // end: Add Pick Up Location

        // begin : Add Home Delivery
        self.BindHomeDeliveryCorrespondents = function (autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    ko.mapping.fromJS(suggestion.data, {}, self.NewPickupLocation.PaymentType);
                    self.ValidType(0);
                },
                onInvalidateSelection: function () {
                    ko.mapping.fromJS(defaultReceiver.NewPickupLocation, {}, self.NewPickupLocation);
                    self.ValidType($(autoCompleteElement).val().trim() == "" ? 1 : 2);
                }
            });

            $(autoCompleteElement).off("keyup.correspondentchanged");
            $(autoCompleteElement).on("keyup.correspondentchanged", function () {
                if ($(autoCompleteElement).val().trim() != self.NewPickupLocation.PaymentType.Correspondent()) {
                    self.ValidType($(autoCompleteElement).val().trim() == "" ? 1 : 2);
                    ko.mapping.fromJS(defaultReceiver.NewPickupLocation, {}, self.NewPickupLocation);
                }
            });
        };

        self.AddHomeDelivery = function (amountToLoad, element) {
            return self.AddDestination(element, self.NewPickupLocation, amountToLoad);
        };

        self.ResetAddHomeDelivery = function () {
            ko.mapping.fromJS(defaultReceiver.NewPickupLocation, {}, self.NewPickupLocation);
            $("#autocomplete-homedelivery-correspondent-names").val("");
            $('#autocomplete-homedelivery-correspondent-names').autocomplete({
                lookup: [],
            });
            self.ResetValidType();
        };
        // end: Add Home Delivery

        // begin: Add Unidos Card Destination
        self.AddUnidosCardDestinationForReceiver = function () {
            return cs.BaseAjax(
        {
            url: '/MoneyTransfer/AddUnidosCardDestinationForReceiver',
            type: "Post",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "receiverCardHolderId": self.CardHolderId() })
        })
        .done(function (data) {
            ko.mapping.fromJS(data.RecipientDestinations, {}, self.RecipientDestinations);
            self.DisplayCardNumber(data.DisplayCardNumber);
            self.LastFourCharCardNumber(data.LastFourCharCardNumber);
            if (self.RecipientDestinations() != null) {
                for (var i = 0; i < self.RecipientDestinations().length; i++) {
                    if (self.RecipientDestinations()[i].PaymentType.PaymentTypeId() == 5) {//Unidos card
                        SetReceiverDeliveryOption(self.RecipientDestinations()[i]);
                        break;
                    }
                }
            }
        });
        };
        // end: begin: Add Unidos Card Destination

        // end: Add destination for receiver

        self.GetRecipientDeliveryOptions = function (element) {
            if (self == null) {
                return;
            }

            return cs.AjaxBySpinner(
        {
            url: '/MoneyTransfer/GetRecipientDeliveryOptions',
            type: "Post",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "receiverCardHolderId": self.CardHolderId() })
        }, element)
        .done(function (data) {
            ko.mapping.fromJS(data, {}, self.RecipientDestinations);
        });
        }

        self.ResetReceiverDeliveryOption = function () {
            SetReceiverDeliveryOption(defaultReceiver.SelectedDestination);
            if (self.RecipientDestinations() != null) {
                for (var i = 0; i < self.RecipientDestinations().length; i++) {
                    self.RecipientDestinations()[i].Selected(false);
                }
            }
        };

        function SetReceiverDeliveryOption(recipientDestination) {
            var temRecipientDestination = ko.mapping.toJS(recipientDestination);
            ko.mapping.fromJS(temRecipientDestination, {}, self.SelectedDestination);
        };

        self.SetSelectedDeliveryOption = function (recipientDestination) {
            SetReceiverDeliveryOption(recipientDestination);
            self.SetDeliveryOptionSelectedStatus(recipientDestination);
        };

        self.SetDeliveryOptionSelectedStatus = function (recipientDestination) {
            var tempRecipientDestination = ko.mapping.toJS(recipientDestination);
            if (self.RecipientDestinations() != null) {
                for (var i = 0; i < self.RecipientDestinations().length; i++) {
                    self.RecipientDestinations()[i].Selected(self.RecipientDestinations()[i].DestinationId() == tempRecipientDestination.DestinationId ||
                        (tempRecipientDestination.PaymentType.PaymentTypeId == 5 && self.RecipientDestinations()[i].PaymentType.PaymentTypeId() == 5));
                }
            }
        }
        // end: delivery option

        self.GetRecipientDestinationsForManagement = function () {
            if (self == null) {
                return;
            }

            return cs.AjaxByDelayLoading(
        {
            url: '/MoneyTransfer/GetRecipientDeliveryOptions',
            type: "Post",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "receiverCardHolderId": self.CardHolderId() })
        })
        .done(function (data) {
            var destinations = new Array();

            for (var i = 0; i < data.length; i++) {
                if (data[i].PaymentType.PaymentTypeId == 1 || data[i].PaymentType.PaymentTypeId == 2 ||
                    data[i].PaymentType.PaymentTypeId == 3 || data[i].PaymentType.PaymentTypeId == 6) {
                    destinations.push(data[i]);
                }
            }

            ko.mapping.fromJS(destinations, {}, self.RecipientDestinations);
        });
        }

        self.ResetValidType = function () {
            self.ValidType(0);
            self.ValidCity(0);
            self.ValidAddress(0);
        };

        self.PhoneNumberFocus = function (element) {
            if (!($(element).val())) {
                return;
            }

            $(element).val(self.GetRemoveFormatPhoneNumber($(element).val()));
        };

        self.EditPhoneNumberBlur = function (element) {
            self.AddPhoneNumberBlur(element);
        };

        self.AddPhoneNumberBlur = function (element) {
            var phoneNumber = $(element).val();
            if (!phoneNumber) {
                return;
            }

            phoneNumber = self.GetRemoveFormatPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10 && !cs.IsInvalidPhoneNumber(phoneNumber)) {
                var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                if (self.PhoneType() == 2) {
                    if (self.AreaCode()) {
                        phoneNumber = '+' + self.AreaCode() + '-' + phoneNumber.replace(reg, "($1) $2-$3");
                    }
                    else {
                        phoneNumber = phoneNumber.replace(reg, "($1) $2-$3");
                    }
                } else {
                    if (self.AreaCode()) {
                        phoneNumber = '+' + self.AreaCode() + '-' + phoneNumber.replace(reg, "$1-$2-$3");
                    } else {
                        phoneNumber = phoneNumber.replace(reg, "$1-$2-$3");
                    }
                }
            }
            else {
                if (self.AreaCode()) {
                    phoneNumber = '+' + self.AreaCode() + '-' + phoneNumber;
                }
            }

            $(element).val(phoneNumber);
        };

        self.GetFormatPhoneNumber = function (phoneNumber) {
            if (!phoneNumber) {
                return phoneNumber;
            }

            phoneNumber = self.GetRemoveFormatPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10) {
                if (self.CellPhoneNumber()) {
                    if (self.AreaCode()) {
                        var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                        return '+' + self.AreaCode() + '-' + phoneNumber.replace(reg, "$1-$2-$3");
                    }
                } else if (self.HomePhoneNumber()) {
                    var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                    return phoneNumber.replace(reg, "($1) $2-$3");
                }
            }
            else {
                if (self.AreaCode() && self.CellPhoneNumber()) {
                    return '+' + self.AreaCode() + '-' + phoneNumber;
                }
                else {
                    return phoneNumber;
                }
            }
        };

        self.GetRemoveFormatPhoneNumber = function (phoneNumber) {
            if (!phoneNumber) {
                return phoneNumber;
            }

            var regAreaCode = new RegExp(/^\+[\d|/|\s]*-/);
            phoneNumber = phoneNumber.replace(regAreaCode, '');

            phoneNumber = phoneNumber.replace(/\(/g, '').replace(/\)/g, '').replace(/ /g, '').replace(/-/g, '');
            if (phoneNumber.length > 17) {
                phoneNumber = phoneNumber.substr((phoneNumber.length - 17), phoneNumber.length-1);
            }
            return phoneNumber;
        };

        self.AccountTypeExtendForManagerNewBankAccount = function () {// for edit for add new bank account.
            self.NewBankAccount.PaymentType.AccountType.extend({
                equal: {
                    onlyIf: function () {
                        if (self.BankAccountPickupType() != 1) {
                            return false;
                        }

                        return (self.ShowAccountTypeForNewBankAccount() && (ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), undefined) ||
                            ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), null) ||
                            ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), "")));
                    },
                    message: 'Account type is required'
                }
            }).isModified(false);
        };

        self.AccountTypeExtendForManagerBankAccount = function () {// for edit old bank account.
            self.BankAccount.PaymentType.AccountType.extend({
                equal: {
                    onlyIf: function () {
                        if (self.BankAccountPickupType() != 2) {
                            return false;
                        }

                        return ko.validation.rules.equal.validator(self.BankAccount.PaymentType.AccountType(), 0) ||
                            ko.validation.rules.equal.validator(self.BankAccount.PaymentType.AccountType(), null) ||
                            ko.validation.rules.equal.validator(self.BankAccount.PaymentType.AccountType(), "");
                    },
                    message: 'Account type is required'
                }
            }).isModified(false);
        };

        self.AccountTypeExtendForMoneyTransferNewBankAccount = function () {
            self.NewBankAccount.PaymentType.AccountType.extend({
                equal: {
                    onlyIf: function () {
                        return (self.ShowAccountTypeForNewBankAccount()
                            && (ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), 0) ||
                            ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), null) ||
                            ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), "")));
                    },
                    message: 'Account type is required'
                }
            }).isModified(false);
        };

        self.HasDeliveryOption = ko.computed(function () {
            var recipientDestinations = self.RecipientDestinations();
            self.HasAccountDeposit(false);
            self.HasCashPickup(false);
            self.HasUnidosCard(false);
            self.HasHomeDelivery(false);

            if (recipientDestinations == null || recipientDestinations.length <= 0) {
                return false;
            }

            for (var i = recipientDestinations.length - 1; i >= 0; i--) {
                var paymentType = recipientDestinations[i].PaymentType;

                if (!self.HasAccountDeposit() && paymentType.TransactionTypeId() == 14 && paymentType.PaymentTypeId() == 1) {
                    self.HasAccountDeposit(true);
                }

                if (!self.HasCashPickup() && paymentType.TransactionTypeId() == 14 && (paymentType.PaymentTypeId() == 2 ||
                    paymentType.PaymentTypeId() == 3 || paymentType.PaymentTypeId() == 6)) {
                    self.HasCashPickup(true);
                }

                if (!self.HasUnidosCard() && paymentType.TransactionTypeId() == 1 && paymentType.PaymentTypeId() == 5) {
                    self.HasUnidosCard(true);
                }

                if (!self.HasHomeDelivery() && paymentType.TransactionTypeId() == 14 && paymentType.PaymentTypeId() == 4) {
                    self.HasHomeDelivery(true);
                }
            }

            if (!self.HasAccountDeposit() && !self.HasCashPickup() && !self.HasUnidosCard() && !self.HasHomeDelivery()) {
                return false;
            }

            return true;
        });

        self.ShowAccountTypeForNewBankAccount = ko.computed(function () {
            var accountTypes = self.NewBankAccount.PaymentType.AccountTypes();
            var correspondent = self.NewBankAccount.PaymentType.Correspondent();

            if (accountTypes == null) {
                return false;
            }

            if (correspondent != null && accountTypes != null && accountTypes.length == 0) {
                return false;
            }

            if (accountTypes != null && accountTypes.length == 1 && accountTypes[0].Value() == cs.BankAccountTypeEnum.NotUsed) {
                self.NewBankAccount.PaymentType.AccountType(accountTypes[0].Value());
                return false;
            } else {
                return true;
            }
        });

        self.ShowAccountTypeForBankAccount = ko.computed(function () {
            var accountTypes = self.BankAccount.PaymentType.AccountTypes();
            var correspondent = self.BankAccount.PaymentType.Correspondent();

            if (accountTypes == null) {
                return false;
            }

            if (correspondent != null && accountTypes != null && accountTypes.length == 0) {
                return false;
            }

            if (accountTypes != null && accountTypes.length == 1 && accountTypes[0].Value() == cs.BankAccountTypeEnum.NotUsed) {
                self.BankAccount.PaymentType.AccountType(accountTypes[0].Value());
                return false;
            } else {
                return true;
            }
        });
    }
});