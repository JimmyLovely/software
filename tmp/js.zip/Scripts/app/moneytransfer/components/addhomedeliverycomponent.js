﻿define(['knockout', 'ClientScript', 'DataModel'], function (ko, cs, dataModel) {
    return function (params) {
        var self = this;
        self.ValidType = ko.observable(false);
        self.PaymentType = null;

        //DataCapture.
        self.logActionTimeData = ko.observable({ transactionStepId: 3, label: 'DelieveryOption_ID', value: 0 });

        self.AddDeliveryOption = function (element) {
            if (self.PaymentType == null || !self.PaymentType.PaymentTypeId
                || self.PaymentType.PaymentTypeId != 4) {
                self.ValidType($("#autocomplete-homedelivery-correspondent-names").val().trim() == "" ? 1 : 2);
                return;
            }

            var tempDestination = {
                PaymentType: self.PaymentType
            };

            $.when(dataModel.AddDeliveryOption(params.Recipient.CardHolderId, tempDestination, element))
            .done(function (recipientDestination) {
                cs.closeModal();
                params.CompletedAddDeliveryOption(recipientDestination);

                //DataCapture.
                self.logActionTimeData({ transactionStepId: 3, label: 'DelieveryOption_ID', value: recipientDestination.DestinationId });
            });
        };

        self.SearchHomeDeliveryCorrespondents = function (element, focus) {
            cs.addSearchSpinner(element);

            var paymentTypeIds = [cs.PaymentType.HomeDelivery];
            $.when(dataModel.GetPaymentTypes(params.Recipient.CountryId, params.Recipient.ToCurrencyId, paymentTypeIds))
           .done(function (result) {
               self.BindHomeDeliveryCorrespondents('autocomplete-homedelivery-correspondent-names', result);
           })
            .always(function () {
                cs.removeSearchSpinner(element);
                if (focus) {
                    $("#autocomplete-homedelivery-correspondent-names").focus();
                };
            });
        };

        self.BindHomeDeliveryCorrespondents = function (autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.PaymentType = ko.mapping.toJS(suggestion.data);
                    self.ValidType(0);
                }
            });

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                if (!self.PaymentType || ($(autoCompleteElement).val().trim() != self.PaymentType.Correspondent)) {
                    self.PaymentType = null;
                    if (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, $(autoCompleteElement).val().trim(), false) > -1) {
                        self.ValidType(0);
                        return;
                    } 
                    self.ValidType(2);
                }
            });

            $(autoCompleteElement).off('blur.correspondentchanged')
                .on('blur.correspondentchanged', function () {
                if ($('.autocomplete-selected').length > 0) return;

                var matchedIndex = -1;
                if (!self.PaymentType || ($(autoCompleteElement).val().trim() != self.PaymentType.Correspondent)) {
                    if ($(autoCompleteElement).val().trim() == "") {
                        self.ValidType(1);
                    } else if ($(autoCompleteElement).autocomplete().suggestions.length > 0 && (matchedIndex = (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, $(autoCompleteElement).val().trim(), true)) > -1)) {
                        self.ValidType(0);
                        $(autoCompleteElement).autocomplete().select(matchedIndex);
                        return;
                    } else {
                        self.ValidType(2);
                    }
                }

                if ($(autoCompleteElement).autocomplete()) {
                    $(autoCompleteElement).autocomplete().hide();
                }
            })
            .off('focus.correspondentchanged')
            .on('focus.correspondentchanged', function () {
                if ($(autoCompleteElement).autocomplete().visible) {
                    self.ValidType(0);
                }
            });
        };

        self.SearchHomeDeliveryCorrespondents("button-home-delivery");
    }
});