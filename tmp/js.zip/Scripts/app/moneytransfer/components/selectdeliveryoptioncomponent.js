﻿define(['knockout', 'ClientScript'], function (ko, cs) {
    return function (params) {
        var self = this;
        self.DeliveryOptions = cs.isEmptyObject(params.DeliveryOptions) ? undefined : params.DeliveryOptions;
        self.CountryId = params.Recipient.CountryId;
        self.CurrencyId = params.Recipient.ToCurrencyId;
        self.CountryImage = params.Recipient.CountryImage;
        self.Recipient = params.Recipient;
        self.addAccountDepositFlag = ko.observable(false);
        self.addHomeDeliveryFlag = ko.observable(false);
        self.addCashPickUpFlag = ko.observable(false);
        var lastDeliveryOptionId;

        self.BackToAmountToSend = function () {
            params.BackToAmountToSend();
        };

        self.AddDestinationForUnidosCard = function () {
            return cs.AjaxByLoading(
            {
                url: '/MoneyTransfer/AddUnidosCardDestinationForReceiver',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "receiverCardHolderId": self.Recipient.CardHolderId })
            })
            .done(function (data) {
                if (data.RecipientDestinations != null) {
                    for (var i = 0; i < data.RecipientDestinations.length; i++) {
                        if (data.RecipientDestinations[i].PaymentType.PaymentTypeId == 5) {//Unidos card
                            var accountDeposit = {
                                DestinationId: -1,
                                Correspondent: '',
                                CorrespondentDetails: data.DisplayCardNumber,
                                DeliveryOptionType: 3,
                                Selected: false
                            };

                            params.completedAddDeliveryOption(accountDeposit);
                            break;
                        }
                    }
                }
            });
        }

        self.InitializeAddHomeDelivery = function () {
            cs.closeModalCallBack('modal-home-new', function () {
                self.addHomeDeliveryFlag(false);
            });
            self.addHomeDeliveryFlag(true);
            cs.openModal('modal-home-new');
        }

        self.InitializeAddPickupLocation = function () {
            cs.closeModalCallBack('modal-location-new', function () {
                self.addCashPickUpFlag(false);
            });
            self.addCashPickUpFlag(true);
            cs.openModal('modal-location-new');
        }

        self.InitializeAddBankAccount = function () {
            cs.closeModalCallBack('modal-account-deposit-new', function () {
                self.addAccountDepositFlag(false);
            });
            self.addAccountDepositFlag(true);
            cs.openModal('modal-account-deposit-new');
        }

        function ToDeliveryOptionListModel(deliveryOption) {
            var correspondent = "";
            var correspondentDetails = "";
            var deliveryOptionType = 0;
            var payout = -1;
            if (deliveryOption.PaymentType.PaymentTypeId == 1 && deliveryOption.PaymentType.TransactionTypeId == 14) {
                correspondent = deliveryOption.PaymentType.Correspondent + ' ' +
                    (((deliveryOption.PaymentType.AccountType == cs.BankAccountTypeEnum.NotUsed) || (deliveryOption.PaymentType.AccountTypeName == null)) ? '' : deliveryOption.PaymentType.AccountTypeName);
                correspondentDetails = cs.maskAccountNumber(deliveryOption.PaymentType.AccountNumber);
                deliveryOptionType = 1;
            } else if (deliveryOption.PaymentType.TransactionTypeId == 14 && ([2, 3, 6].indexOf(deliveryOption.PaymentType.PaymentTypeId) != -1)) {
                correspondent = deliveryOption.PaymentType.Correspondent;
                correspondentDetails = '';
                if (deliveryOption.PaymentType.PaymentTypeId == 6) {
                    correspondentDetails = deliveryOption.Location.Branch.BranchLocation;
                }

                deliveryOptionType = 2;
            } else if (deliveryOption.PaymentType.TransactionTypeId == 1 && deliveryOption.PaymentType.PaymentTypeId == 5) {
                correspondent = '';
                correspondentDetails = self.Recipient.DisplayCardNumber;
                deliveryOptionType = 3;
            } else if (deliveryOption.PaymentType.TransactionTypeId == 14 && deliveryOption.PaymentType.PaymentTypeId == 4) {
                correspondent = self.Recipient.Address;
                correspondentDetails = self.Recipient.City + ', ' + self.Recipient.StateName;
                deliveryOptionType = 4;
            }

            if (deliveryOption.PaymentType.Payouts && deliveryOption.PaymentType.Payouts.length >0) {
                payout = deliveryOption.PaymentType.Payouts[0];
            }

            return {
                DestinationId: deliveryOption.DestinationId,
                Correspondent: correspondent,
                CorrespondentDetails: correspondentDetails,
                DeliveryOptionType: deliveryOptionType,
                Payout: payout,
                Selected: false
            }
        };

        self.CompletedAddDeliveryOption = function (deliveryOption) {
            var accountDeposit = ToDeliveryOptionListModel(deliveryOption);

            params.completedAddDeliveryOption(accountDeposit);
        };

        self.GoToSenderPayment = function (deliveryOption) {
            params.GoToSenderPayment(deliveryOption);
        }

        self.HasDeliveryOption = function () {
            var deliveryOptions = self.DeliveryOptions;
            return deliveryOptions && deliveryOptions.length > 0;
        };

        self.HasAccountDeposit = function () {
            return ContainDeliveryOption(1);
        };

        self.HasCashPickup = function () {
            return ContainDeliveryOption(2);
        };

        self.HasUnidosCard = function () {
            return ContainDeliveryOption(3) && self.CountryId == '484';// Mexico
        };

        self.HasHomeDelivery = function () {
            return ['214', '608'].indexOf('' + self.CountryId) != -1 && ContainDeliveryOption(4);//Dominican Republic and Philippines
        };

        function ContainDeliveryOption(type) {
            var deliveryOptions = self.DeliveryOptions;
            if (!deliveryOptions || deliveryOptions.length == 0) {
                return false;
            }

            for (var i = 0; i < deliveryOptions.length; i++) {
                if (deliveryOptions[i].DeliveryOptionType == type) {
                    return true;
                }
            }

            return false;
        }

        function resetDeliveryOption() {
            if (self.DeliveryOptions) {
                $.each(self.DeliveryOptions, function (index, d) {
                    d.Selected(false);
                });
            }
            lastDeliveryOptionId = null;
        }
    }
});