﻿define(['knockout', 'ClientScript', 'Plugins', 'tinyscrollbar'], function (ko, cs) {
    return function (params) {
        var self = this;
        if (params.api) {
            params.api(this);
        }
        self.Receivers = ko.observable(null);
        self.addRecipientFlag = ko.observable(false);
        self.tempSelectReceiver;
        var selectedCardHolderId = null;

        self.GoToAmoutToSend = function (recipient, element) {
            if (self.Receivers()) {
                $.each(self.Receivers(), function (index, receiver) {
                    receiver.Selected(receiver.CardHolderId == recipient.CardHolderId);
                });
            }

            if (selectedCardHolderId != recipient.CardHolderId) {
                selectedCardHolderId = recipient.CardHolderId;
                params.GoToAmoutToSend(recipient);
            } else {
                params.GoToAmoutToSend(null);
            }
        };

        cs.BaseAjax({
            url: '/MoneyTransfer/GetReceivers',
            type: "POST",
            dataType: "json",
            contentType: "application/json"
        })
        .done(function (data) {
            if (data) {
                $.each(data, function (index, r) {
                    r.Selected = ko.observable(false);
                    r.Selected(r.CardHolderId == params.defaultValue());
                })

                if (params.defaultValue()) {
                    selectedCardHolderId = params.defaultValue();
                }
            }

            
            self.Receivers(data);
            if (data.length > 5) {
                initializeSearchRecipients(data);
            }
        });

        function initializeSearchRecipients(data) {
            var receivers = $.map(data, function (item, index) {
                return { value: item.RecipientName, data: item };
            });
            receivers.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $('#autocomplete-carrier-products').autocomplete({
                lookup: receivers,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.tempSelectReceiver = suggestion.data;
                    cs.removeDisable("button-select-receiver");
                },
                onInvalidateSelection: function () {
                    self.tempSelectReceiver = null;
                    cs.addDisable("button-select-receiver");
                }
            });
        }

        function resetAddRecipient() {
            cs.closeModalCallBack('modal-moneytransfer-recipient-new', function () {
                self.addRecipientFlag(false);
            });
        }
        self.InitializeAddRecipient = function () {
            resetAddRecipient();
            self.addRecipientFlag(true);
            cs.openModal('modal-moneytransfer-recipient-new');
        }

        self.AddRecipient = function (recipientModel) {
            var receiver = {
                CardHolderId: recipientModel.CardHolderId,
                CountryImage: recipientModel.CountryImage,
                RecipientName: cs.removeRepeatSpace(recipientModel.FirstName + ' ' + (!!recipientModel.MiddleName ? recipientModel.MiddleName.substring(0, 1) + '.' : recipientModel.MiddleName) + ' ' + recipientModel.LastName),
                LastTransactionDate: null,
                LastTransactionAmount: null,
                Selected: ko.observable(false),
                Address: recipientModel.Address,
                City: recipientModel.City,
                StateName: recipientModel.StateName,
                Zipcode: recipientModel.Zipcode,
                PhoneNumber: '+' + recipientModel.AreaCode + '-' + recipientModel.PhoneNumber,
                FromCurrencyCode: "USD",
                ToCurrencyCode: recipientModel.ToCurrencyCode,
                DisplayRate: recipientModel.DisplayRate,
                Rate: recipientModel.Rate,
                FromCountryImage: recipientModel.FromCountryImage,
                ToCountryImage: recipientModel.ToCountryImage,
                ToCurrencyId: recipientModel.ToCurrencyId,
                CountryId: recipientModel.CountryId,
                StateId: recipientModel.StateId,
                CityId: recipientModel.CityId
            }

            var tempReceivers = self.Receivers();
            if (tempReceivers == null) {
                tempReceivers == new Array();
            }
            tempReceivers.push(receiver);
            self.Receivers(tempReceivers);
            
            if (tempReceivers.length > 5) {
                initializeSearchRecipients(tempReceivers);
            }

            self.GoToAmoutToSend(receiver);
        }

        self.GoToAmoutToSendBySelectButton = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.tempSelectReceiver) {
                self.GoToAmoutToSend(self.tempSelectReceiver);
            }
        };

        self.clearSelectedRecipient = function () {
            if (self.Receivers()) {
                $.each(self.Receivers(), function (index, receiver) {
                    receiver.Selected(false);
                });
            }

            selectedCardHolderId = null;
        }
    }
});