﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;
        self.CountryImage = params.Recipient.CountryImage;
        self.ValidType = ko.observable(0);
        self.PaymentType = null;
        self.AccountType = ko.observable();
        self.AccountNumber = ko.observable();
        self.ConfirmAccountNumber = ko.observable();
        self.AccountTypes = ko.observable([]);
        self.isShowAccountType = ko.observable(false);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddNewAccountDeposit, track.PageEnum.AddNewAccountDeposit);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.AddNewAccountDeposit, track.PageEnum.AddNewAccountDeposit);

        ko.computed(function () {
            var validType = self.ValidType();
            if (validType ===1) {
                self.trackErrorMessage(commonstrings.validation.requiredfiled);
            } else if (validType === 2) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.invalidcorrespondent);
            }
        });
        // End appsflyer track event


        //DataCapture.
        self.logActionTimeData = ko.observable({ transactionStepId: 3, label: 'DelieveryOption_ID', value: 0 });

        self.SearchBankAccountCorrespondents = function (element, receiver, autocompleteElement, focus) {
            cs.addSearchSpinner(element);

            self.ValidType(0);
            var paymentTypeIds = [cs.PaymentType.AccountDeposit];
            $.when(dataModel.GetPaymentTypes(params.Recipient.CountryId, params.Recipient.ToCurrencyId, paymentTypeIds))
           .done(function (result) {
               self.BindBankAccountCorrespondents('autocomplete-accountdeposit-names', result);
           })
            .always(function () {
                cs.removeSearchSpinner(element);
                if (focus) {
                    $("#autocomplete-accountdeposit-names").focus();
                };
            });
        };

        self.BindBankAccountCorrespondents = function (autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (!self.PaymentType || (suggestion.value != self.PaymentType.Correspondent)) {
                        RemoveAccountNumberValueAndValidation();
                        var tempPaymentType = ko.mapping.toJS(suggestion.data);
                        self.AccountTypes(tempPaymentType.AccountTypes);
                        self.PaymentType = tempPaymentType;

                        var accountTypes = self.PaymentType.AccountTypes;

                        if (accountTypes.length > 0) {
                            if (accountTypes.length == 1 && accountTypes[0].Value == 3) {
                                var accountType = accountTypes[0].Value;
                                self.AccountType(accountType);
                            } else {
                                self.AccountType(null);
                            }
                        }
                        ResetShowAccountType();
                    }
                    self.ValidType(0);
                },
            });

            var value = $(autoCompleteElement).val().trim();
            if (value != '' && (tempCorrespondents == '' || tempCorrespondents == null
                || cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) < 0)) {
                self.ValidType(2);
            }

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                var value = $(autoCompleteElement).val().trim();

                if (!self.PaymentType || (value != self.PaymentType.Correspondent)) {
                    if (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) > -1) {
                        self.ValidType(0);
                        return;
                    }
                    else {
                        self.ValidType(2);
                    }
                    self.PaymentType = null;
                    self.AccountType(null);
                    RemoveAccountNumberValueAndValidation();
                    ResetShowAccountType();
                }
            });

            $(autoCompleteElement).off("blur.correspondentchanged");
            $(autoCompleteElement).on("blur.correspondentchanged", function () {
                if ($('.autocomplete-selected').length > 0) return;

                var value = $(autoCompleteElement).val().trim();
                var matchedIndex = -1;

                if (!self.PaymentType || (value != self.PaymentType.Correspondent)) {
                    if (value == "") {
                        self.ValidType(1);
                    }
                    else if ($(autoCompleteElement).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, true)) > -1) {
                        self.ValidType(0);
                        $(autoCompleteElement).autocomplete().select(matchedIndex);
                        return;
                    }
                    else {
                        self.ValidType(2);
                    }
                }

                if ($(autoCompleteElement).autocomplete()) {
                    $(autoCompleteElement).autocomplete().hide();
                }
            })
            .off('focus.correspondentchanged')
            .on('focus.correspondentchanged', function () {
                if ($(autoCompleteElement).autocomplete().visible) {
                    self.ValidType(0);
                }
            });
        }

        function RemoveAccountNumberValueAndValidation() {
            self.AccountNumber(null);
            self.AccountNumber.isModified(false);
            self.ConfirmAccountNumber(null);
            self.ConfirmAccountNumber.isModified(false);
        }

        function ResetShowAccountType() {
            if (!self.PaymentType) {
                self.isShowAccountType(false);
                return;
            }

            var accountTypes = self.PaymentType.AccountTypes;

            if (accountTypes == null) {
                self.isShowAccountType(false);
                return;
            }

            if (accountTypes && accountTypes.length == 0) {
                self.isShowAccountType(false);
                return;
            }

            if (accountTypes != null && accountTypes.length == 1 && accountTypes[0].Value == cs.BankAccountTypeEnum.NotUsed) {
                self.AccountType(accountTypes[0].Value);
                self.isShowAccountType(false);
                return;
            }

            self.isShowAccountType(true);
            self.AccountType.isModified(false);
        };

        function initialize() {
            self.SearchBankAccountCorrespondents("button-bank-account-deposit");
        }

        initialize();

        self.AccountType.extend({
            equal: {
                onlyIf: function () {
                    return self.isShowAccountType() && (!self.AccountType() || self.AccountType == 0);
                },
                //Inline message
                message: commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.accounttyperequired
            }
        }).isModified(false);

        self.AccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.accountnumberrequired
            }
        }).isModified(false);

        self.ConfirmAccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.confirmnumberrequired
            },
            equal: {
                params: self.AccountNumber,
                //Inline message
                message: commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.numbernotmatch
            }
        }).isModified(false);

        self.CheckAccountDeposit = function () {
            self.errors = ko.validation.group(self);
            if (self.isValid() && self.PaymentType &&
                self.PaymentType.AccountType) {
                return true;
            } else {
                self.errors.showAllMessages();
                if (self.PaymentType == null) {
                    self.ValidType($("#autocomplete-accountdeposit-names").val().trim() == "" ? 1 : 2);
                }
                return false;
            }
        };

        self.AddDestination = function (element) {
            trackEvent("Save");
            if (!self.CheckAccountDeposit()) {
                return;
            }

            var tempPaymentType = ko.mapping.toJS(self.PaymentType);
            delete tempPaymentType.AccountTypes;
            tempPaymentType.AccountNumber = self.AccountNumber();
            tempPaymentType.AccountType = self.AccountType();

            var tempDestination = {
                PaymentType: tempPaymentType
            };

            $.when(dataModel.AddDeliveryOption(params.Recipient.CardHolderId, tempDestination, element))
            .done(function (recipientDestination) {
                cs.closeModal();
                trackSaveTimeOnPage();
                params.CompletedAddDeliveryOption(recipientDestination);

                //DataCapture.
                self.logActionTimeData({ transactionStepId: 3, label: 'DelieveryOption_ID', value: recipientDestination.DestinationId });
            });
        };

        var trackCancelOrXTotalClicks = trackEvent;
        self.closeAccountDeposit = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCancelOrXTotalClicks));

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.AddNewAccountDeposit,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.AddNewAccountDeposit,
                    source: app.page().name
                });
            });
        };

        function trackTotalLoads() {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.AddNewAccountDeposit,
                    eventAction: T.ActionEnum.ScreenView,
                    eventLabel: "Add New Account Deposit",
                    eventPage: T.PageEnum.AddNewAccountDeposit,
                    source: app.page().name
                });
            });
        }

        trackTotalLoads();
    }
});