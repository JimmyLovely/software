﻿define(['knockout', 'ClientScript', 'DataModel', 'app', 'instant-bank-verification-component'], function (ko, cs, dataModel, app) {
    return function (params) {
        var self = this;
        self.PaymentMethods = ko.observable(params.paymentMethods);
        self.IsShow = ko.observable(false);
        self.addBankAccountFlag = ko.observable(false);
        self.addCreditDebitFlag = ko.observable(false);
        self.linkIBVAccountFlag = ko.observable(false);
        self.reLinkIBVAccountFlag = ko.observable(false);

        self.IBVStatus = ko.observable(params.IBVStatus());

        var bankFee;
        var creditDebitFee;

        var lastPaymentMethodId;
        var isAddIBV = false;

        if (params.api) {
            params.api(this);
        }

        self.IsShow(params.isShow());

        self.refreshPaymentMethods = function () {
            params.refreshPaymentMethods();
        };

        function SetSelectedPaymentMethod(data, paymentMethodCount, type1, type2) {
            $.each(data, function (index, d) {
                if (d.AccountTypeId == type1 || d.AccountTypeId == type2) {
                    paymentMethodCount += 1;
                }
            });
            if (paymentMethodCount == 1) {
                $.each(data, function (index, d) {
                    if (d.AccountTypeId == type1 || d.AccountTypeId == type2) {
                        d.Selected(true);
                    }
                });
            }
        }

        self.OpenNewModal = function () {
            self['addCreditDebitFlag'](false);
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');
        }

        function InitializePaymentMethodModel(modalId, flagName, isMoreInfo) {
            cs.closeModalCallBack(modalId, function () {
                self[flagName](false);
                if (modalId == 'modal-link-ibv-account') {
                    window.removeEventListener("message", dataModel.ibvPostMessage);
                }
            });

            self[flagName](true);
            return cs.openModal(modalId);
        }

        self.HasBankAccount = function () {
            var paymentMethods = self.PaymentMethods();
            if (!paymentMethods) {
                return false;
            }

            var result = false;

            for (var i = 0; i < paymentMethods.length; i++) {
                result = result || paymentMethods[i].IsBank;
            }

            return result;
        };

        self.HasCarditOrDebitCard = function () {
            var paymentMethods = self.PaymentMethods();
            if (!paymentMethods) {
                return false;
            }

            var result = false;
            $.each(paymentMethods, function (index, p) {
                result = result || !p.IsBank;
            });

            return result;
        };

        self.BackToDeliveryOption = function () {
            params.BackToDeliveryOption();
        }

        self.InitializeNewSenderCreditAccount = function () {
            cs.closeModalCallBack('modal-credit-debit-account', function () {
                self.addCreditDebitFlag(false);
            });
            self.addCreditDebitFlag(true);
            cs.openModal('modal-credit-debit-account');
        }

        self.InitializeNewSenderBankAccount = function () {
            $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
            .done(function (result) {
                self.IBVStatus(cs.IBVStatus.AddingPrompt);
            })
            .fail(function () {
                self.IBVStatus(cs.IBVStatus.Normal);
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            })
        }

        self.GoToTransactionDetails = function (paymentMethod) {
            isAddIBV = false;
            if (paymentMethod.IsBank) {
                $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                .done(function (result) {
                    params.GoToTransactionDetails(paymentMethod);
                })
                .fail(function () {
                    params.GoToTransactionDetails(paymentMethod, true);
                })
            } else {
                params.GoToTransactionDetails(paymentMethod);
            }
        }

        self.CancelVerification = function () {
            self.IBVStatus(cs.IBVStatus.Normal);
            params.CancelVerification();
        }

        self.CompletedAddBankAccount = function (paymentMethod) {
            var paymentMethods = self.PaymentMethods();

            var isConvert = false;
            for (var i = 0; i < paymentMethods.length; i++) {
                if (paymentMethods[i].PaymentMethodId == paymentMethod.PaymentMethodId) {
                    paymentMethods[i] = paymentMethod;
                    paymentMethods[i].IsVerifying = ko.observable(false);
                    isConvert = true;
                }
            }
            self.PaymentMethods(paymentMethods);

            if (isConvert) {
                params.GoToTransactionDetails(paymentMethod);
                return;
            }

            var tempPaymentMethod = {
                PaymentMethodId: paymentMethod.PaymentMethodId,
                CardName: paymentMethod.CardName,
                CardNickname: paymentMethod.CardNickname,
                DisplayCardNumber: paymentMethod.DisplayCardNumber,
                IsBank: paymentMethod.IsBank,
                Fee: paymentMethod.IsBank ? bankFee : creditDebitFee,
                AccountTypeId: paymentMethod.AccountTypeId,
                AccountType: paymentMethod.AccountType,
                IsIBVAccount: paymentMethod.IsIBVAccount,
                IsVerifying: ko.observable(false),
                Selected: ko.observable(true)
            };

            params.completedAddPaymentMethod(tempPaymentMethod);
        }

        self.removeVerifyingStatus = function () {
            var canceledPaymenthod = null;
            var paymentMethods = self.PaymentMethods();
            $.each(paymentMethods, function (index, paymentMethod) {
                if (paymentMethod.IsVerifying()) {
                    paymentMethod.IsVerifying(false);
                    canceledPaymenthod = paymentMethod;
                    return false;
                }
            });
            self.IBVStatus(cs.IBVStatus.Normal);
            return canceledPaymenthod;
        }

        self.addVerifyingStatus = function (paymentMethod) {
            var paymentMethods = self.PaymentMethods();
            $.each(paymentMethods, function (index, p) {
                p.Selected(p.PaymentMethodId === paymentMethod.PaymentMethodId);
                p.IsVerifying(p.PaymentMethodId === paymentMethod.PaymentMethodId);
                p.SelectedToCalculate = false;
            });
            self.IBVStatus(cs.IBVStatus.Verifying);
            self.PaymentMethods(paymentMethods);
        }

        self.DoVerificationNow = function () {
            $.when(dataModel.checkIBVNetwork())
            .done(function (result) {
                InitializePaymentMethodModel('modal-link-ibv-account', 'linkIBVAccountFlag');
                setTimeout(function () {
                    dataModel.addIBVPostMessageListener();
                    $("#ibv-submit-form").empty();
                    $("#ibv-submit-form").append(result);
                    document.getElementById('rsessionPost').submit();

                    self.removeVerifyingStatus();
                }, 500);

                dataModel.setFastLinkEvent(function (data) {
                    AddIBVPaymentMethod(data);
                })
            })
            .fail(function () {
                self.removeVerifyingStatus();
            })
        }

        function AddIBVPaymentMethod(data) {
            var newAddedPaymentMethod = null;
            if (!isAddIBV) {
                var tempPaymentMethods = self.PaymentMethods();
                $.each(tempPaymentMethods, function (index, p) {
                    if (p.Selected()) {
                        newAddedPaymentMethod = ko.mapping.toJS(p);
                    }
                });
            }
            
            if (!newAddedPaymentMethod) {
                newAddedPaymentMethod = {};
            }
            newAddedPaymentMethod.CardName = data.AccountName;
            if (data.AccountType == "CHECKING") {
                newAddedPaymentMethod.AccountTypeId = 3
            } else if (data.AccountType == "SAVINGS") {
                newAddedPaymentMethod.AccountTypeId = 4
            }
            newAddedPaymentMethod.AccountRoutingNumber = data.BankTransferCode;
            newAddedPaymentMethod.CardNumber = data.AccountNumber;
            newAddedPaymentMethod.IsBank = true;
            newAddedPaymentMethod.IBVAccount = data;
            newAddedPaymentMethod.IsIBVAccount = true;
            newAddedPaymentMethod.IsDefault = false;
            newAddedPaymentMethod.PaymentProviderId = !!app.senderInfo() ? !!app.senderInfo().PosPaymentConfig() ? app.senderInfo().PosPaymentConfig().BankAccountProviderId : 2 : 2;

            cs.AjaxByLoading({
                url: '/PaymentMethod/AddPaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(newAddedPaymentMethod))
            })
            .done(function (data) {
                data.Selected = ko.observable(true);

                self.CompletedAddBankAccount(data);
            })
        }

        self.credentialChangedReLink = function(paymentMethodId){
            $.when(dataModel.reVerify(paymentMethodId))
            .done(function (result) {
                var timerHander = 0;
                var test = function () {
                    if (timerHander != 0) {
                        timerHander = 0;
                    }
                    var element = $("#modal-link-ibv-account")[0];
                    if (element) {
                        InitializePaymentMethodModel('modal-link-ibv-account', 'reLinkIBVAccountFlag');
                        setTimeout(function () {
                            dataModel.addIBVPostMessageListener();
                            $("#ibv-submit-form").empty();
                            $("#ibv-submit-form").append(result);
                            document.getElementById('rsessionPost').submit();

                            var paymentMethods = self.PaymentMethods();
                            $.each(paymentMethods, function (index, paymentMethod) {
                                if (paymentMethod.IsVerifying()) {
                                    paymentMethod.IsVerifying(false);
                                }
                                if (paymentMethodId == paymentMethod.PaymentMethodId) {
                                    paymentMethod.Selected(true);
                                }

                                paymentMethod.SelectedToCalculate = false;
                            });
                        }, 500);
                    } else {
                        timerHander = setTimeout(function () { test(); }, 100);
                    }
                }
                test();

                dataModel.setFastLinkEvent(function (data) {
                    AddIBVPaymentMethod(data);
                })
            })
            .fail(function () {
                self.removeVerifyingStatus();
            })
        }

        

        self.promptIBVResult = function (isIBV) {
            if (isIBV) {
                self.IBVStatus(cs.IBVStatus.Normal);
                self.DoVerificationNow();
                isAddIBV = true;
            } else {
                self.IBVStatus(cs.IBVStatus.Normal);
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
        }

        self.continueAddBankAccount = function (isContinue) {
            if (isContinue) {
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
            self.IBVStatus(cs.IBVStatus.Normal);
        }

        if (!!params.reLinkPaymentMethod()) {
            var paymentMethod = params.reLinkPaymentMethod();
            params.reLinkPaymentMethod(null);
            self.credentialChangedReLink(paymentMethod.PaymentMethodId);
        }
    }
});