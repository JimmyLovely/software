﻿define(['knockout', 'ClientScript', 'DataModel', 'R', 'TrackEvent'], function (ko, cs, dataModel, R, track) {
    return function (params) {
        var self = this;
        self.DeliveryOptions = cs.isEmptyObject(params.DeliveryOptions) ? undefined : params.DeliveryOptions;
        self.AddedCashPickUps = getCashPickUpsFromDeliveryOptions(self.DeliveryOptions);
        self.SearchCityOutSideCities = ko.observable(false);
        self.ShouldShowLocation = ko.observable(true);
        self.PaymentTypes = ko.observable();
        self.PaymentType = ko.observable();
        self.LocationStores = ko.observable();
        self.BranchName;

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddNewCashPickup, track.PageEnum.AddNewCashPickup);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };
        // End appsflyer track event

        //DataCapture.
        self.logActionTimeData = ko.observable({ transactionStepId: 3, label: 'DelieveryOption_ID', value: 0 });

        self.SearchCityChangedForNew = function (element) {
            var checkBoxChecked = $(element).is(":checked");
            self.SearchCityOutSideCities(checkBoxChecked);
            self.ShouldShowLocation(false);
            $("#location-store-error-message").hide();
            $('#correspondents-note').hide();
            self.PaymentTypes(null);
            InitializePickUpLocationCities(self.TobeUpdatedReceiver, null);
            $.when(checkBoxChecked ? dataModel.LoadPayments(params.Recipient.CountryId, params.Recipient.ToCurrencyId)
                : dataModel.GetPaymentsByCity(params.Recipient.CountryId, params.Recipient.StateId, params.Recipient.CityId, params.Recipient.City, params.Recipient.ToCurrencyId))
            .done(function (paymentTypes) {
                paymentTypes = dataModel.deleteAddedCashPickUps(paymentTypes, self.AddedCashPickUps);

                $.each(paymentTypes, function (index, p) {
                    p.Selected = ko.observable(false);
                });

                self.PaymentTypes(paymentTypes);
            });

            trackEvent("Search Cities Outside Recipient's Location");
        };

        function InitializeLocationStores(stateId, CityName) {
            if (self.PaymentType() && self.PaymentType().PaymentTypeId == 6) {
                self.LocationStores(null);
                $("#location-stores").show();
                $.when(dataModel.GetPaymentTypeLocationsByCityId(params.Recipient.CountryId, stateId, CityName, self.PaymentType().Payouts[0]))
                 .done(function (data) {
                     if (data.length > 0) {
                         $.each(data, function (index, s) {
                             s.Selected = ko.observable(false);
                         });
                         self.LocationStores(data);
                     }
                 })
                .always(function () {
                    $("#location-stores").hide();
                });
            }
        }

        var originalSearchCityOutSideCities = false;
        self.AddPickupLocationForReceiver = function (paymentType) {
            var trackSelectCorrespondentTotalClicks = trackEvent;
            trackSelectCorrespondentTotalClicks("Select");

            $("#location-stores").hide();
            if (self.PaymentType() && self.PaymentType().CurrencyId == paymentType.CurrencyId &&
                    self.PaymentType().TransactionTypeId == paymentType.TransactionTypeId &&
                    self.PaymentType().Payouts[0] == paymentType.Payouts[0] &&
                    self.PaymentType().PaymentTypeId == paymentType.PaymentTypeId && originalSearchCityOutSideCities == self.SearchCityOutSideCities()) {
                return;
            }
            self.PaymentType(ko.mapping.toJS(paymentType));
            self.PaymentType().SearchCityOutSideCities = self.SearchCityOutSideCities();
            $.each(self.PaymentTypes(), function (index, p) {
                p.Selected(p.CurrencyId == paymentType.CurrencyId &&
                    p.TransactionTypeId == paymentType.TransactionTypeId &&
                    p.Payouts[0] == paymentType.Payouts[0] &&
                    p.PaymentTypeId == paymentType.PaymentTypeId);
                self.ShouldShowLocation(true);
                originalSearchCityOutSideCities = self.SearchCityOutSideCities();
            });

            if (self.PaymentType().PaymentTypeId == 6) {
                $.when(InitializePickUpLocationCities(self.TobeUpdatedReceiver, null))
                .done(function () {
                    if (self.SearchCityOutSideCities()) {
                        $("#autocomplete-pickup-location-city").val("");
                        self.LocationStores(null);
                    } else {
                        $("#autocomplete-pickup-location-city").val(params.Recipient.City);
                        InitializeLocationStores(params.Recipient.StateId, params.Recipient.City);
                    }
                });
            } else {
                var tempPaymentType = ko.mapping.toJS(self.PaymentType);
                delete tempPaymentType.AccountTypes;

                var deliveryOption = {
                    PaymentType: tempPaymentType,
                }

                AddDeliveryOtion(deliveryOption);
            }
        };

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewCashPickup,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddNewCashPickup
            });
        }

        self.AddPickupBranchForReceiver = function (location) {
            var tempPaymentType = ko.mapping.toJS(self.PaymentType);
            delete tempPaymentType.AccountTypes;

            var deliveryOption = {
                PaymentType: tempPaymentType,
                Location: ko.mapping.toJS(location)
            }

            AddDeliveryOtion(deliveryOption);

            var trackSelectBranchTotalClicks = trackEvent;
            trackSelectBranchTotalClicks("Select Branch");
        };

        function AddDeliveryOtion(deliveryOption) {
            $.when(dataModel.AddDeliveryOption(params.Recipient.CardHolderId, deliveryOption))
            .done(function (recipientDestination) {
                trackSaveTimeOnPage();

                cs.closeModal();
                params.CompletedAddDeliveryOption(recipientDestination);

                //DataCapture.
                self.logActionTimeData({ transactionStepId: 3, label: 'DelieveryOption_ID', value: recipientDestination.DestinationId });
            });
        }

        self.GetPickUpLocationForSearchCities = function (element, isFocus) {
            cs.addSearchSpinner(element);

            var receiver = params.Recipient.CountryId == null ? self.TobeAddedReceiver : self.TobeUpdatedReceiver;
            $.when(InitializePickUpLocationCities(receiver, null, true))
            .done(function () {
                cs.removeSearchSpinner(element);
                if (isFocus) {
                    $("#autocomplete-pickup-location-city").focus();
                }
            });
        }

        var tempCity = "";
        function InitializePickUpLocationCities(receiver, element, clearCity) {
            if (!clearCity) {
                tempCity = "";
            }
            return $.when(dataModel.GetPickUpLocationCities(params.Recipient.CountryId, element))
             .done(function (cities) {
                 $("#autocomplete-pickup-location-city").autocomplete({
                     lookup: cities,
                     triggerSelectOnValidInput: true,
                     minChars: 1,
                     onSelect: function (suggestion) {
                         var cityName = suggestion.value;
                         if (cityName != tempCity) {
                             tempCity = cityName;
                             InitializeLocationStores(suggestion.data, cityName);
                         }
                     }
                 });
                 $("#autocomplete-pickup-location-city").autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                 $("#autocomplete-pickup-location-city").off("input.pickup.location");
                 $("#autocomplete-pickup-location-city").on("input.pickup.location", function () {
                     if ($("#autocomplete-pickup-location-city").val() == "" || $("#autocomplete-pickup-location-city").val() != tempCity) {
                         tempCity = $("#autocomplete-pickup-location-city").val();
                         self.LocationStores(null);
                         self.BranchName = null;
                     }
                 });
             });
        }

        function initialize() {
            $.when(dataModel.GetPaymentsByCity(params.Recipient.CountryId, params.Recipient.StateId, params.Recipient.CityId, params.Recipient.City, params.Recipient.ToCurrencyId))
            .done(function (paymentTypes) {
                paymentTypes = dataModel.deleteAddedCashPickUps(paymentTypes, self.AddedCashPickUps);
                $.each(paymentTypes, function (index, p) {
                    p.Selected = ko.observable(false);
                });

                self.PaymentTypes(paymentTypes);
            });
        }

        initialize();

        function getCashPickUpsFromDeliveryOptions(deliveryOptions) {
            if (!deliveryOptions || deliveryOptions.length == 0) {
                return [];
            }

            var addedCashPickUps = new Array();
            for (var i = 0; i < deliveryOptions.length; i++) {
                if (deliveryOptions[i].DeliveryOptionType == 2) {
                    addedCashPickUps.push(deliveryOptions[i].Payout);
                }
            }
            return addedCashPickUps;
        };

        self.closeCashPick = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackEvent));

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewCashPickup,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add New Cash Pickup",
                eventPage: track.PageEnum.AddNewCashPickup
            });
        }

        trackTotalLoads();
    }
});