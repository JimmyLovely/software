﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;

        self.ValidType = ko.observable(0);
        self.ValidTypeForEdit = ko.observable(0);
        self.ValidAddress = ko.observable(0);
        self.ValidCity = ko.observable(0);

        var defaultReceiver = ko.mapping.toJS(params.recipient);
        defaultReceiver.NewBankAccount = ko.mapping.toJS(defaultReceiver.BankAccount);
        defaultReceiver.NewPickupLocation = ko.mapping.toJS(defaultReceiver.BankAccount);
        defaultReceiver.SelectedDestination = ko.mapping.toJS(defaultReceiver.BankAccount);

        ko.mapping.fromJS(defaultReceiver, {}, self);
        self.DestinationStates = ko.observable();
        self.PaymentTypes = ko.observable();
        self.PickUpLocationPaymentTypes = ko.observable();
        self.LocationStores = ko.observable();
        // 0 means empty
        // 1 means cell phone
        // 2 means home phone
        self.PhoneType = ko.observable(self.CellPhoneNumber() ? '1' : '2');

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.EditNewRecipient, track.PageEnum.EditNewRecipient);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.EditNewRecipient, track.PageEnum.EditNewRecipient);

        ko.computed(function () {
            var cityValidationType = self.CityValidateType();
            if (cityValidationType === 1) {
                self.trackErrorMessage(commonstrings.validation.addressvalidation.cityrequired);
            } else if (cityValidationType === 2) {
                self.trackErrorMessage(commonstrings.validation.addressvalidation.cityinvalid);
            }
        });

        ko.computed(function () {
            var validTypeForEdit = self.ValidTypeForEdit();

            if (validTypeForEdit === 1) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.bankrequired);
            } else if (validTypeForEdit === 2) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.invalidcorrespondent);
            }
        });

        ko.computed(function () {
            var validType = self.ValidType();

            if (validType === 1) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.bankrequired);
            } else if (validType === 2) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.invalidcorrespondent);
            }
        });
        // End appsflyer track event

        function InitializeDestinationStates(countryId) {
            $.when(dataModel.GetStatesByCountryId(countryId))
            .done(function (data) {
                ko.mapping.fromJS(data, {}, self.DestinationStates);
            })
        }

        InitializeDestinationStates(self.CountryId());

        self.GetFormatPhoneNumber = function (phoneNumber) {
            if (!phoneNumber) {
                return phoneNumber;
            }

            phoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10) {
                if (self.CellPhoneNumber()) {
                    if (self.AreaCode()) {
                        var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                        return '-' + phoneNumber.replace(reg, "$1-$2-$3");
                    }
                } else if (self.HomePhoneNumber()) {
                    if (self.AreaCode()) {
                        var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                        return '-' + phoneNumber.replace(reg, "($1) $2-$3");
                    }
                }
            }
            else {
               if (self.AreaCode()) {
                    return '-' + phoneNumber;
                }
                else {
                    return phoneNumber;
                }
            }
        };

        self.PhoneNumber(self.GetFormatPhoneNumber(self.PhoneNumber()));

        // the whole number including the country must be minimum 10 digits and maximun 17 digits. 
        self.PhoneNumberInValidReason = ko.observable('');

        self.ShowAccountTypeForBankAccount = ko.computed(function () {
            var accountTypes = self.BankAccount.PaymentType.AccountTypes();
            var correspondent = self.BankAccount.PaymentType.Correspondent();

            if (accountTypes == null) {
                return false;
            }

            if (correspondent != null && accountTypes != null && accountTypes.length == 0) {
                return false;
            }

            if (accountTypes != null && accountTypes.length == 1 && accountTypes[0].Value() == cs.BankAccountTypeEnum.NotUsed) {
                self.BankAccount.PaymentType.AccountType(accountTypes[0].Value());
                return false;
            } else {
                return true;
            }
        });

        self.ShowAccountTypeForNewBankAccount = ko.computed(function () {
            var accountTypes = self.NewBankAccount.PaymentType.AccountTypes();
            var correspondent = self.NewBankAccount.PaymentType.Correspondent();

            if (accountTypes == null) {
                return false;
            }

            if (correspondent != null && accountTypes != null && accountTypes.length == 0) {
                return false;
            }

            if (accountTypes != null && accountTypes.length == 1 && accountTypes[0].Value() == cs.BankAccountTypeEnum.NotUsed) {
                self.NewBankAccount.PaymentType.AccountType(accountTypes[0].Value());
                return false;
            } else {
                return true;
            }
        });

        self.FirstName.extend({
            //Inline message
            required: { params: true, message: commonstrings.validation.namevalidation.firstnamerequired },
            minTrimLength: { params: 2, message: commonstrings.validation.namevalidation.firstnameminlength },
            maxLength: { params: 50, message: commonstrings.validation.namevalidation.firstnamemaxlength },
            equal: {
                onlyIf: function () { return cs.IsInvalidName(self.FirstName()) != 0 },
                message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.validation.namevalidation.firstnamestartwithletter : commonstrings.validation.namevalidation.firstnameinvalid }
            }
        }).isModified(false);
        self.MiddleName.extend({
            //Inline message
            maxLength: { params: 50, message: commonstrings.validation.namevalidation.middlenamemaxlength },
            equal: {
                onlyIf: function () { return self.MiddleName() != "" && cs.IsInvalidName(self.MiddleName()) != 0 },
                message: function () { return cs.IsInvalidName(self.MiddleName()) == 1 ? commonstrings.validation.namevalidation.middlenamestartwithletter : commonstrings.validation.namevalidation.middlenameinvalid }
            }
        }).isModified(false);
        self.LastName.extend({
            //Inline message
            required: { params: true, message: commonstrings.validation.namevalidation.lastnamerequired },
            minTrimLength: { params: 2, message: commonstrings.validation.namevalidation.lastnameminlength },
            maxLength: { params: 50, message: commonstrings.validation.namevalidation.lastnamemaxlength },
            equal: {
                onlyIf: function () { return cs.IsInvalidName(self.LastName()) != 0 },
                message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.validation.namevalidation.lastnamestartwithletter : commonstrings.validation.namevalidation.lastnameinvalid }
            }
        }).isModified(false);
        //Inline message
        self.Address.extend({ required: { params: true, message: commonstrings.validation.addressvalidation.addressrequired } }).isModified(false);
        self.StateId.extend({ required: { params: true, message: commonstrings.validation.addressvalidation.staterequired } }).isModified(false);
        self.PaymentType.AccountNumber.extend({ required: { params: true, message: commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.accountnumberrequired } }).isModified(false);
        self.Zipcode.extend({
            number: {
                params: true,
                //Inline message
                message: commonstrings.validation.addressvalidation.zipcodeinvalid
            },
            maxLength: {
                params: 12,
                //Inline message
                message: commonstrings.validation.addressvalidation.zipcodeinvalid
            }
        }).isModified(false);


        self.PhoneNumberIsInValid = ko.computed(function () {
            self.PhoneNumberInValidReason('');
            var phoneNumber = self.PhoneNumber();
            if (!phoneNumber) {
                return;
            }

            var areaCodeLength = self.AreaCode() ? self.AreaCode().length : 0;
            if (self.PhoneNumber().length + areaCodeLength < 10) {
                self.PhoneNumberInValidReason('limitMinLength');;
                return true;
            }

            var tempPhoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (cs.IsInvalidPhoneNumber(tempPhoneNumber)) {
                return true;
            }

            if (tempPhoneNumber.length + areaCodeLength <= 17) {
                return false;
            } else {
                self.PhoneNumberInValidReason('limitMaxLength');
                return true;
            }
        });

        self.PhoneNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.addnewrecipient.validation.phonerequired
            },
            equal: {
                onlyIf: self.PhoneNumberIsInValid,
                //Inline message
                message: function () {
                    if (self.PhoneNumberInValidReason() == 'limitMinLength') {
                        return commonstrings.addnewrecipient.validation.phoneminimumlength;
                    } else if (self.PhoneNumberInValidReason() == 'limitMaxLength') {
                        return commonstrings.addnewrecipient.validation.phonemaximumlength;
                    }
                    else {
                        return commonstrings.addnewrecipient.validation.phoneinvalid;
                    }
                }
            }
        }).isModified(false);

        self.RelationShipId.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.addnewrecipient.validation.relationshiprequired
            }
        }).isModified(false);

        self.EmailAddress.extend({
            email: {
                params: true,
                //Inline message
                message: commonstrings.addnewrecipient.validation.emailinvalid
            }
        }).isModified(false);

        self.CountryId.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.validation.addressvalidation.countryrequired
            }
        }).isModified(false);


        // Validate updated bank account
        self.BankAccount.PaymentType.AccountNumber.extend({
            required: {
                onlyIf: function () { return (self.BankAccountPickupType() == 2) },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumberrequired
            },
            number: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumbervalid
            }
        }).isModified(false);

        self.BankAccount.PaymentType.ConfirmAccountNumber.extend({
            required: {
                onlyIf: function () { return (self.BankAccountPickupType() == 2) },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumberrequired
            },
            equal: {
                params: self.BankAccount.PaymentType.AccountNumber,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumbernotmatch
            }
        }).isModified(false);

        self.BankAccount.PaymentType.AccountType.extend({
            required: {
                onlyIf: function () { return !(self.ShowAccountTypeForBankAccount() && (self.BankAccount.PaymentType.AccountType() === null || self.BankAccount.PaymentType.AccountType() === "" || self.BankAccount.PaymentType.AccountType() == -1)) },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accounttyperequired
            }
        }).isModified(false);

        self.SelectedDestination.Location.StateId.extend({
            required: {
                onlyIf: function () { return (self.BankAccountPickupType() == 2) },
                //Inline message
                message: commonstrings.validation.addressvalidation.staterequired
            },
            required: {
                onlyIf: function () { return (self.LocationPickupType() == 2) },
                //Inline message
                message: commonstrings.validation.addressvalidation.staterequired
            }
        }).isModified(false);

        self.NewBankAccount.PaymentType.AccountNumber.extend({
            required: {
                onlyIf: function () {
                    return (self.BankAccountPickupType() == 1)
                },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumberrequired
            },
            number: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnoinvalid
            }
        }).isModified(false);

        self.NewBankAccount.PaymentType.ConfirmAccountNumber.extend({
            required: {
                onlyIf: function () {
                    return (self.BankAccountPickupType() == 1)
                },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumberrequired
            },
            equal: {
                params: self.NewBankAccount.PaymentType.AccountNumber,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumbernotmatch
            }
        }).isModified(false);

        self.NewPickupLocation.Location.StateId.extend({
            required: {
                onlyIf: function () { return (self.LocationPickupType() == 1) },
                //Inline message
                message: commonstrings.validation.addressvalidation.staterequired
            }
        }).isModified(false);

        self.NewBankAccount.PaymentType.AccountType.extend({
            equal: {
                onlyIf: function () {
                    if (self.BankAccountPickupType() != 1) {
                        return false;
                    }

                    return (self.ShowAccountTypeForNewBankAccount() && (ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), undefined) ||
                        ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), null) ||
                        ko.validation.rules.equal.validator(self.NewBankAccount.PaymentType.AccountType(), "")));
                },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accounttyperequired
            }
        }).isModified(false);

        self.BankAccount.PaymentType.AccountType.extend({
            equal: {
                onlyIf: function () {
                    if (self.BankAccountPickupType() != 2) {
                        return false;
                    }

                    return ko.validation.rules.equal.validator(self.BankAccount.PaymentType.AccountType(), 0) ||
                        ko.validation.rules.equal.validator(self.BankAccount.PaymentType.AccountType(), null) ||
                        ko.validation.rules.equal.validator(self.BankAccount.PaymentType.AccountType(), "");
                },
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accounttyperequired
            }
        }).isModified(false);

        //new code  
        self.stateChanged = function (element) {
            var stateId = element.value;
            self.City("");
            self.CityValidateType(0);
            ResetUpdateCorrespondent();

            InitializeDestinationCities(stateId, self.CountryId(), false)
        }

        var cities;
        var orginalCityForUpdate = "";
        function InitializeDestinationCities(stateId, countryId, showDefaultCity) {
            return $.when(dataModel.GetCitiesByStateId(countryId, stateId))
            .done(function (data) {
                cities = data;
                var cityEle = $('#autocomplete-city-names-updaterecipient');
                if (showDefaultCity) {
                    cityEle.val(self.City());
                } else {
                    cityEle.val("");
                }
                cityEle.autocomplete({
                    lookup: data,
                    triggerSelectOnValidInput: false,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        if (suggestion.value != orginalCityForUpdate) {
                            orginalCityForUpdate = suggestion.value;
                            self.City(suggestion.value);
                            self.CityId(suggestion.data.Value);
                            self.CityValidateType(0);
                            GetCorrespondentsBySelectedRecipientCity();
                        }
                    },
                    lookupFilter: function (k, j, l) {
                        var inputValue = (cs.removeDiacritics(l).toLowerCase());
                        return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1
                    }
                });
                cityEle.autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                cityEle.off("keyup.city.addrecipient");
                cityEle.on("keyup.city.addrecipient", function () {
                    var value = cityEle.val();
                    if (value != orginalCityForUpdate) {
                        if (value == "") {
                            self.CityValidateType(1);
                        }
                        else if (cs.isMatchSuggestion(cityEle.autocomplete().suggestions, value, false) > -1) {
                            self.CityValidateType(0);
                            return;
                        }
                        else {
                            self.CityValidateType(2);
                        }
                        orginalCityForUpdate = null;
                        ResetUpdateCorrespondent();
                    }
                });

                cityEle.off('blur.validation.city');
                cityEle.on('blur.validation.city', function () {
                    if ($('.autocomplete-selected').length > 0) return;

                    var matchedIndex = -1;
                    var value = cityEle.val();

                    if (value == "") {
                        self.CityValidateType(1);
                    }
                    else if (cityEle.autocomplete().suggestions.length > 0
                        && (matchedIndex = cs.isMatchSuggestion(cityEle.autocomplete().suggestions, value, true)) > -1) {
                        self.CityValidateType(0);
                        cityEle.autocomplete().select(matchedIndex);
                        return;
                    } else {
                        self.CityValidateType(2);
                    }
                    orginalCityForUpdate = null;
                });
            });
        }

        InitializeDestinationCities(self.StateId(), self.CountryId(), true);

        function ResetUpdateCorrespondent() {
            self.CityId("");
            if (self.LocationPickupType() == 2) {
                if (!self.SelectedDestination.PaymentType.SearchCityOutSideCities()) {
                    ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
                    self.ShouldShowLocation(false);
                    $("#location-store-error-message").hide();
                    $("#correspondent-error-message").hide();
                    $('#payment-types').hide();
                }
            } else if (self.LocationPickupType() == 1) {
                if (!self.PaymentType.SearchCityOutSideCities()) {
                    ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
                    self.ShouldShowLocation(false);
                    $("#location-store-error-message").hide();
                    $("#correspondent-error-message").hide();
                    $('#payment-types').hide();
                }
            }
        }

        self.SearchCityOutSideCities = ko.observable(false);

        function GetCorrespondentsBySelectedRecipientCity() {
            if (self.LocationPickupType() == 2) {
                if (!self.SearchCityOutSideCities()) {
                    initializePaymentTypeList(self.SelectedDestination);
                    InitializePickUpLocationCities(null, false);
                }
            } else if (self.LocationPickupType() == 1) {
                if (!self.SearchCityOutSideCities()) {
                    ResetUpdatePaymentType();
                    initializePaymentTypeList(null);
                    InitializePickUpLocationCities(null, false);
                }
            }
        }

        function ResetUpdatePaymentType() {
            ko.mapping.fromJS(null, {}, self.PaymentTypes);
            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
            ResetUpdateLocation();
        }

        function ResetUpdateLocation() {
            ko.mapping.fromJS(null, {}, self.LocationStores);
            $("#autocomplete-updatepaymenttype-city").val(null);
        }

        self.ShouldShowLocation = ko.observable(false);
        self.SearchCityChanged = function (receiver, searchCityOutSideCities, location) {
            self.ShouldShowLocation(false);
            $("#location-store-error-message").hide();
            $("#correspondent-error-message").hide();
            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
            self.PaymentType.SearchCityOutSideCities(searchCityOutSideCities);
            $.when(searchCityOutSideCities ? self.LoadPayments(null, self.CountryId(), self.ToCurrencyId())
                : self.GetPaymentsByCity(receiver, self.City(), receiver.ToCurrencyId(), searchCityOutSideCities))
            .done(function () {
                ResetLocation(receiver);
                InitializePickUpLocationCities(receiver, null);
                if (location != null) {
                    self.PaymentTypeSelectIndexChange(ko.mapping.toJS(location.PaymentType));
                }
            });
        };

        self.PhoneNumberFocus = function (element) {
            if (!($(element).val())) {
                return;
            }

            $(element).val(cs.GetRemoveFormatPhoneNumber($(element).val()));
        };

        self.EditPhoneNumberBlur = function (element) {
            self.AddPhoneNumberBlur(element);
        };

        self.AddPhoneNumberBlur = function (element) {
            var phoneNumber = $(element).val();
            if (!phoneNumber) {
                return;
            }

            phoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10 && !cs.IsInvalidPhoneNumber(phoneNumber)) {
                var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                if (self.PhoneType() == 1) {
                    if (self.AreaCode()) {
                        phoneNumber = '-' + phoneNumber.replace(reg, "$1-$2-$3");
                    } else {
                        phoneNumber = phoneNumber.replace(reg, "$1-$2-$3");
                    }
                } else if (self.PhoneType() == 2) {
                    if (self.AreaCode()) {
                        phoneNumber = '-' + phoneNumber.replace(reg, "($1) $2-$3");
                    }
                    else {
                        phoneNumber = phoneNumber.replace(reg, "($1) $2-$3");
                    }
                } else {
                    phoneNumber = phoneNumber.replace(reg, "$1-$2-$3");
                }
            }
            else {
                if (self.AreaCode()) {
                    phoneNumber = '-' + phoneNumber;
                }
            }

            $(element).val(phoneNumber);
        };
        self.ResetBankAccountDepositForNewBankAccount = function (autoCompleteElement) {
            autoCompleteElement = cs.GetElementIdWithSymbol(autoCompleteElement);
            ko.mapping.fromJS(defaultReceiver.NewBankAccount, {}, self.NewBankAccount);
            $(autoCompleteElement).val("");
            $(autoCompleteElement).autocomplete({
                lookup: [],
            });
            self.ValidType(0);
            self.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.AccountType.isModified(false);
            self.BankAccountPickupType(0);
        };

        //Bank account deposit
        self.BankAccountChanged = function (bankAccount, element, isEdit) {
            for (var i = 0; i < self.RecipientDestinations().length; i++) {
                if (self.RecipientDestinations()[i].DestinationId() == self.BankAccount.DestinationId()) {
                    var originalAccount = ko.mapping.toJS(self.BankAccount);
                    ko.mapping.fromJS(originalAccount, {}, self.RecipientDestinations()[i]);
                    break;
                }
            }
            self.ValidType(0);

            if (isEdit) {
                if ($(element).parent().hasClass("active")) {
                    self.ResetBankAccountDepositForBankAccount("autocomplete-bank-names-old");
                }
                else {
                    var tempBankAccount = ko.mapping.toJS(bankAccount);
                    self.ValidTypeForEdit(0);
                    ko.mapping.fromJS(tempBankAccount, {}, self.BankAccount);
                    $("#autocomplete-bank-names-old").val(self.BankAccount.PaymentType.Correspondent());
                    self.BankAccount.PaymentType.ConfirmAccountNumber(self.BankAccount.PaymentType.AccountNumber());

                    self.SearchBankAccountCorrespondentsForEdit();

                    self.BankAccountPickupType(2);
                }
            }
            else {
                if ($(element).parent().hasClass("active")) {
                    self.ResetBankAccountDepositForNewBankAccount("autocomplete-bank-names-new");
                }
                else {
                    bankAccounts = null;

                    self.InitializeAddBankAccountDeposit("autocomplete-bank-names-new");

                    self.SearchBankAccountCorrespondents("button-bank-account-deposit-new", self, "autocomplete-bank-names-new");
                }
            }

            return true;
        }

        self.SearchBankAccountCorrespondentsForEdit = function (isFocus, isShowError) {
            cs.addSearchSpinner("button-bank-account-deposit-old");
            self.ValidTypeForEdit(0);
            $.when(self.GetBankAccountCorrespondents(self.CountryId, self.ToCurrencyId()))
            .done(function (correspondents) {
                self.BindBankAccountCorrespondentsForEdit("autocomplete-bank-names-old", correspondents, isShowError);
            })
            .always(function () {
                cs.removeSearchSpinner("button-bank-account-deposit-old");
                if (isFocus) {
                    $("#autocomplete-bank-names-old").focus();
                }
            });
        };

        self.GetBankAccountCorrespondents = function (countryId, currencyId) {
            return GetCorrespondentsByPaymentTypeIds(countryId, [1], currencyId);
        }

        function GetCorrespondentsByPaymentTypeIds(countryId, paymentTypeIdArray, currencyId) {
            var deferred = $.Deferred();
            $.when(dataModel.GetPaymentTypes(cs.getValue(countryId), currencyId, paymentTypeIdArray))
            .done(function (result) {
                var paymentTypes = ko.mapping.toJS(result);
                ko.mapping.fromJS(paymentTypes, {}, self.PaymentTypes);

                deferred.resolve(paymentTypes);
            });

            return deferred;
        };

        self.SearchBankAccountCorrespondents = function (element, receiver, autocompleteElement, focus) {
            var tempAutocompleteElement = '';
            if (typeof autocompleteElement == "string") {
                if (autocompleteElement.indexOf("#") != 0) {
                    tempAutocompleteElement = "#" + autocompleteElement;
                }
                else {
                    tempAutocompleteElement = autocompleteElement;
                }
            }

            cs.addSearchSpinner(element);
            self.ValidType(0);
            $.when(self.GetBankAccountCorrespondents(receiver.CountryId, receiver.ToCurrencyId()))
            .done(function (correspondents) {
                self.BindBankAccountCorrespondents(autocompleteElement, correspondents);
            })
            .always(function () {
                cs.removeSearchSpinner(element);
                if (focus) {
                    $(tempAutocompleteElement).focus();
                };
            });
        };

        self.ResetBankAccountDepositForBankAccount = function (autoCompleteElement) {
            autoCompleteElement = cs.GetElementIdWithSymbol(autoCompleteElement);
            self.ValidTypeForEdit(0);
            ko.mapping.fromJS(defaultReceiver.BankAccount, {}, self.BankAccount);
            $(autoCompleteElement).val("");
            $(autoCompleteElement).autocomplete({
                lookup: [],
            });
            self.ValidTypeForEdit(0);
            self.BankAccount.PaymentType.AccountNumber.isModified(false);
            self.BankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
            self.BankAccount.PaymentType.AccountType.isModified(false);
            self.BankAccountPickupType(0);
        };
        self.InitializeAddBankAccountDeposit = function (correspondentElement) {
            correspondentElement = cs.GetElementIdWithSymbol(correspondentElement);
            self.ResetValidType();
            ko.mapping.fromJS(defaultReceiver.NewBankAccount, {}, self.NewBankAccount);
            $(correspondentElement).val("");
            self.BankAccountPickupType(1);
            self.NewBankAccount.PaymentType.AccountType.isModified(false);
            self.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
        };

        self.ResetValidType = function () {
            self.ValidType(0);
            self.ValidCity(0);
            self.ValidAddress(0);
        };

        //End bank account deposit
        //add pickup location

        self.InitializeAddPickUpLocationForEditingRecipient = function (deliveryOption, element) {
            if ($(element).parent().hasClass("active")) {
                ResetPickupLocation(self);
            } else {
                ResetPickupLocation(self);
                self.PaymentType.SearchCityOutSideCities(false);
                self.LocationPickupType(1);
                initializePaymentTypeList();
                InitializePickUpLocationCities(self.TobeUpdatedReceiver, null);
            }

            return true;
        };

        self.SearchCityChangedForNew = function (element) {
            var checkBoxChecked = $(element).is(":checked");
            ResetPaymentType();
            self.SearchCityOutSideCities(checkBoxChecked);
            initializePaymentTypeList();
            return true;
        }

        function ResetPaymentType() {
            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
            self.PaymentTypeSelected(false);
            ko.mapping.fromJSON(defaultReceiver.PaymentType, {}, self.PaymentType);
        }

        function initializePaymentTypeList(payment) {
            var addedCashPickUps = getAddedCashPickUps(self.RecipientDestinations());
            if (payment && payment.PaymentType.PaymentTypeId() != 6) {
                if (addedCashPickUps.indexOf(payment.PaymentType.Payouts()[0]) > -1) {
                    addedCashPickUps.splice(addedCashPickUps.indexOf(payment.PaymentType.Payouts()[0]), 1);
                }
            }

            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
            var pickUp = new dataModel.CashPickUp();
            $.when(pickUp.getPayments(self.SearchCityOutSideCities(), self.CountryId(), self.ToCurrencyId(), self.StateId(), self.CityId(), self.City(), addedCashPickUps))
            .done(function (paymentTypes) {
                ko.mapping.fromJS(paymentTypes, {}, self.PickUpLocationPaymentTypes);
                if (payment) {
                    self.PaymentTypeSelectIndexChange(payment.PaymentType);
                }
            })
            .fail(function () {
                ko.mapping.fromJS([], {}, self.PickUpLocationPaymentTypes);
            });
        }

        function getAddedCashPickUps(RecipientDestinations) {
            if (!RecipientDestinations || RecipientDestinations.length == 0) {
                return [];
            }

            var addedCashPickUps = new Array();
            for (var i = 0; i < RecipientDestinations.length; i++) {
                if ([2, 3].indexOf(RecipientDestinations[i].PaymentType.PaymentTypeId()) != -1) {
                    addedCashPickUps.push(RecipientDestinations[i].PaymentType.Payouts()[0]);
                }
            }
            return addedCashPickUps;
        };


        //end add pickup location

        //edit pickup location
        self.InitailizeEditPickUpLocationForEditingRecipient = function (location, element) {
            if ($(element).parent().hasClass("active")) {
                ResetPickupLocation();
            } else {
                var tempLocation = ko.mapping.toJS(location);
                ko.mapping.fromJS(tempLocation, {}, self.SelectedDestination);

                ResetPickupLocation();
                location.IsEdit(true);

                self.LocationPickupType(2);
                self.SearchCityOutSideCities(location.PaymentType.SearchCityOutSideCities());
                initializePaymentTypeList(location);
                InitializePickUpLocationCities(null, false);
            }

            return true;
        }

        self.SearchCityChangedForEdit = function (location, element) {
            var checkBoxChecked = $(element).is(":checked");
            self.SearchCityOutSideCities(checkBoxChecked);
            self.ShouldShowLocation(false);
            initializePaymentTypeList(location);
            return true;
        }

        self.PaymentTypeSelectIndexChange = function (paymentType) {
            var searchCityOutSideCities = self.SearchCityOutSideCities();
            SetPaymentTypeStatus(paymentType);
            self.SearchCityOutSideCities(searchCityOutSideCities);

            var tempPaymentType = ko.mapping.fromJS(ko.mapping.toJS(paymentType));
            $("#correspondent-error-message").hide();
            $("#location-stores").hide();
            if (tempPaymentType.PaymentTypeId() == 6) {
                ko.mapping.fromJSON(defaultReceiver.Branch, {}, self.Branch);
                self.NewPickupLocation.Location.City(self.City());
                self.NewPickupLocation.Location.State(self.StateName());
                if (self.SearchCityOutSideCities()) {
                    $("#autocomplete-pickup-location-city").val("");
                } else {
                    $("#autocomplete-pickup-location-city").val(self.City());
                }
                tempCity = $("#autocomplete-pickup-location-city").val();
                initLocations(self.CountryId(), self.StateId(), tempCity, tempPaymentType);
            } else {
                $("#location-store-error-message").hide();
            }
        }

        function SetPaymentTypeStatus(paymentType) {
            paymentType = ko.mapping.toJS(paymentType);
            ko.mapping.fromJS(paymentType, {}, self.PaymentType);
            self.PaymentType.Selected(true);
            self.PaymentType.AccountNumber.isModified(false);

            if (self.PaymentType.IsPaymentTypeAccount()) {
                var accountTypes = self.PaymentType.AccountTypes();
                if (accountTypes.length > 0) {
                    var accountType = accountTypes[0].Value;
                    ko.mapping.fromJS(accountType, {}, self.PaymentType.AccountType);
                }
            }

            var tempPayments = self.PickUpLocationPaymentTypes();
            for (var i = 0; i < tempPayments.length; i++) {
                if (tempPayments[i].CurrencyId() == paymentType.CurrencyId &&
                    tempPayments[i].TransactionTypeId() == paymentType.TransactionTypeId &&
                    tempPayments[i].Payouts()[0] == paymentType.Payouts[0] &&
                    tempPayments[i].PaymentTypeId() == paymentType.PaymentTypeId) {
                    self.ShouldShowLocation(true);
                    tempPayments[i].Selected(true);
                } else {
                    tempPayments[i].Selected(false);
                }
            }

            ResetLocation();
        }

        function GetPaymentTypeLocationsByCityId(countryId, stateId, cityName, paymentType) {
            if (!cityName) {
                return;
            }
            ko.mapping.fromJS(null, {}, self.LocationStores);
            var transactionType = 14;
            $("#location-stores").show();
            return cs.BaseAjax(
            {
                url: '/MoneyTransfer/GetLocationsByCity',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": countryId, "stateId": stateId, "cityName": cityName, "correspondentId": paymentType.Payouts()[0], "transactionTypeId": transactionType })
            })
            .done(function (data) {
                var stores = ko.mapping.toJS(data);
                ko.mapping.fromJS(stores, {}, self.LocationStores);
            })
            .always(function () {
                $("#location-stores").hide();
            });
        };
        //end edit pickup location


        //common
        function ResetPickupLocation() {
            self.SearchCityOutSideCities(false);
            if (self.RecipientDestinations()) {
                $.each(self.RecipientDestinations(), function (index, d) {
                    d.IsEdit(false);
                });
            }

            $("#autocomplete-pickup-location-city").val("");
            $("#autocomplete-pickup-location-city").error(false, '');
            $('#autocomplete-pickup-location-city').autocomplete({
                lookup: new Array()
            });

            self.NewPickupLocation.Location.StateId("");
            locations = null;

            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);

            ResetLocation();

            $("#pickup-location-detail").addClass("hide");
            $("#location-store-error-message").hide();
            $('#correspondent-error-message').hide();
            self.LocationPickupType(0);
            self.PaymentType.PaymentTypeId(0);
        }

        function ResetLocation() {
            ko.mapping.fromJSON(defaultReceiver.Branch, {}, self.Branch);
            ko.mapping.fromJS(null, {}, self.LocationStores);
            $("#autocomplete-pickup-location-city").val(null);
        }


        var tempCity = "";
        var locationCities;
        function InitializePickUpLocationCities(element, clearCity) {
            if (!clearCity) {
                tempCity = "";
            }
            return $.when(new dataModel.CashPickUp().getCities(self.CountryId(), element))
             .done(function (cities) {
                 locationCities = cities;
                 $("#autocomplete-pickup-location-city").autocomplete({
                     lookup: cities,
                     triggerSelectOnValidInput: false,
                     minChars: 1,
                     onSelect: function (suggestion) {
                         var cityName = suggestion.value;
                         if (cityName != tempCity) {
                             tempCity = cityName;
                             var countryId = self.CountryId();
                             var correspondentId = self.PaymentType.Payouts()[0];

                             GetPaymentTypeLocationsByCityId(self.CountryId(), suggestion.data, cityName, self.PaymentType);
                         }
                     }
                 });
                 $("#autocomplete-pickup-location-city").autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                 $("#autocomplete-pickup-location-city").off("input.pickup.location");
                 $("#autocomplete-pickup-location-city").on("input.pickup.location", function () {
                     if ($("#autocomplete-pickup-location-city").val() == "" || $("#autocomplete-pickup-location-city").val() != tempCity) {
                         ko.mapping.fromJS(null, {}, self.MatchingCities);
                         ko.mapping.fromJS(null, {}, self.LocationStores);
                         $("#location-stores").hide();
                         self.Branch.BranchName(null);
                     }
                 });
             });
        }

        function initLocations(countryId, stateId, cityName, paymentType) {
            if (!cityName) {
                return;
            }
            ko.mapping.fromJS(null, {}, self.LocationStores);
            var transactionType = 14;
            $("#location-stores").show();
            $.when(new dataModel.CashPickUp().getLocations(countryId, stateId, cityName, paymentType))
            .done(function (data) {
                var stores = ko.mapping.toJS(data);
                ko.mapping.fromJS(stores, {}, self.LocationStores);
            })
            .always(function () {
                $("#location-stores").hide();
            });
        };
        //end common

        self.SelectPaymentType = function (receiver, paymentType) {
            if (paymentType.Selected() == true) {
                return;
            }
            paymentType.SearchCityOutSideCities(self.SearchCityOutSideCities());
            self.PaymentTypeSelectIndexChange(paymentType);
        };

        self.GetPickUpLocationForSearchCities = function (element, isFocus) {
            cs.addSearchSpinner(element);

            var receiver = self.CountryId() == null ? self.TobeAddedReceiver : self.TobeUpdatedReceiver;
            $.when(InitializePickUpLocationCities(receiver, null, true))
            .done(function () {
                cs.removeSearchSpinner(element);
                if (isFocus) {
                    $("#autocomplete-pickup-location-city").focus();
                }
            });
        }


        //Update receiver

        var updateReceiverStatus = new cs.executeStatus();
        self.UpdateReceiver = function (element) {
            if (updateReceiverStatus.isExecuting()) {
                return;
            }

            var trackSaveTotalClick = trackEvent;
            trackCloseTotalClick("Save");

            if (cs.isDisabled(element)) {
                return;
            }

            updateReceiverStatus.setExecuting();
            var validationBranch = true;
            if ([1, 2].indexOf(self.LocationPickupType()) != -1) {
                if ((self.PaymentType.PaymentTypeId() == 6 && !(self.Branch.BranchName()))
                    ) {
                    //cs.showErrorMessage("Error", "Please select location.");
                    if (self.ShouldShowLocation()) {
                        $("#location-store-error-message").show();
                        self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addcashpickup.selectlocation);
                        validationBranch = false;
                    }
                } else if (self.PaymentType.PaymentTypeId() < 1) {
                    $('#correspondent-error-message').show();
                    self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addcashpickup.selectcorrespondent);
                    validationBranch = false;
                }
            }

            if (self.LocationPickupType() == 2) {//edit
                var tempPaymentType = ko.mapping.toJS(self.PaymentType);
                ko.mapping.fromJS(tempPaymentType, {}, self.SelectedDestination.PaymentType);

                var tempBranch = ko.mapping.toJS(self.Branch);
                ko.mapping.fromJS(tempBranch, {}, self.SelectedDestination.Location.Branch);
            }

            var destinationValid = IsDestinationValid();
            var accountTypes = self.BankAccount.PaymentType.AccountTypes;
            self.errors = ko.validation.group(self);
            self.NewBankAccount.PaymentType.errors = ko.validation.group(self.NewBankAccountPaymentTypeGroup);
            self.BankAccount.PaymentType.errors = ko.validation.group(self.BankAccountPaymentTypeGroup);
            self.SelectedDestination.Location.errors = ko.validation.group(self.SelectedDestination.Location);
            var validAutocompleteCity = cs.setCityValidateType(self.CityValidateType, $('#autocomplete-city-names-updaterecipient'), cities)
            var isValid = validAutocompleteCity[0];


            if (self.isValid() && self.NewBankAccountPaymentTypeGroup.isValid() && isValid && destinationValid
                    && self.BankAccountPaymentTypeGroup.isValid() && self.ValidAddress() == 0
                    && IsAccountTypeValid() && validationBranch) {
                var phoneType = $("#input-phone-type").val();
                if (phoneType == 1) {
                    self.CellPhoneNumber(cs.GetRemoveFormatPhoneNumber(self.PhoneNumber()));
                    self.HomePhoneNumber("");
                } else if (phoneType == 2) {
                    self.HomePhoneNumber(cs.GetRemoveFormatPhoneNumber(self.PhoneNumber()));
                    self.CellPhoneNumber("");
                }
                UpdateReceiver(element);

            } else {
                updateReceiverStatus.complete();
                self.errors.showAllMessages();
                self.NewBankAccount.PaymentType.errors.showAllMessages();
                self.BankAccount.PaymentType.errors.showAllMessages();
                self.SelectedDestination.Location.errors.showAllMessages();
            }
        }

        self.NewBankAccountPaymentTypeGroup = {
            Correspondent: self.NewBankAccount.PaymentType.Correspondent,
            AccountNumber: self.NewBankAccount.PaymentType.AccountNumber,
            ConfirmAccountNumber: self.NewBankAccount.PaymentType.ConfirmAccountNumber,
            AccountType: self.NewBankAccount.PaymentType.AccountType
        };
        self.BankAccountPaymentTypeGroup = {
            Correspondent: self.BankAccount.PaymentType.Correspondent,
            AccountNumber: self.BankAccount.PaymentType.AccountNumber,
            ConfirmAccountNumber: self.BankAccount.PaymentType.ConfirmAccountNumber,
            AccountType: self.BankAccount.PaymentType.AccountType
        };

        function IsAccountTypeValid() {
            var paymentType = self.BankAccount.PaymentType;
            var newPaymentType = self.NewBankAccount.PaymentType;

            if (paymentType.AccountTypes() == null || newPaymentType.AccountTypes() == null) {
                return true;
            }

            return paymentType.AccountTypes || newPaymentType.AccountTypes || paymentType.AccountTypes().length == 0 || paymentType.AccountType() != 0
                || newPaymentType.AccountTypes().length == 0 || newPaymentType.AccountType() != 0;
        }

        function IsDestinationValid() {
            if (self.BankAccountPickupType() == 1) {
                var newBankName = $('#autocomplete-bank-names-new').val();
                if (newBankName == '' || newBankName == null) {
                    self.ValidType(1);
                    return false;
                } else if ($('#autocomplete-bank-names-new').length > 0 && self.ValidType() != 0) {
                    return false;
                }
            } else if (self.BankAccountPickupType() == 2) {
                var bankName = $('#autocomplete-bank-names-old').val();
                if (bankName == '' || bankName == null) {
                    self.ValidTypeForEdit(1);
                    return false;
                } else if ($('#autocomplete-bank-names-old').length > 0 && self.ValidTypeForEdit() != 0) {
                    return false;
                }
            }

            return true;
        }

        function UpdateReceiver(element) {
            var tempUpdatedReceiver = ko.toJS(ko.utils.unwrapObservable(self));
            tempUpdatedReceiver.PhoneNumber = cs.GetRemoveFormatPhoneNumber(tempUpdatedReceiver.PhoneNumber);
            delete tempUpdatedReceiver.PaymentTypes;
            delete tempUpdatedReceiver.PickUpLocationPaymentTypes;
            delete tempUpdatedReceiver.LocationStores;
            delete tempUpdatedReceiver.DestinationStates;
            delete tempUpdatedReceiver.RecipientDestinations;

            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/UpdateSelfServiceReceiver',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(tempUpdatedReceiver))
            }, element, true)
            .done(function (data) {
                if (params.done) {
                    params.done(data);
                }
                $.when(cs.closeModal())
                .done(function () {
                    updateReceiverStatus.complete();
                });

                trackSaveTimeOnPage();
            })
            .fail(function (xhr, status) {
                updateReceiverStatus.complete();
                if ($.parseJSON(xhr.responseText).Priority != null) {
                    if ($.parseJSON(xhr.responseText).Priority == 1) {
                        ModelSessionTimeOut$RevealAndLogout();
                        return;
                    }
                }
                var errorCode = parseInt(xhr.responseText);
                if (errorCode == 16842753) {
                    AddPayments();
                }
                else {
                    cs.showErrorMessage($.parseJSON(xhr.responseText).Caption, $.parseJSON(xhr.responseText).Message);
                }
            });
        }

        //End update receiver
        self.BindBankAccountCorrespondents = function (autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (suggestion.value != self.NewBankAccount.PaymentType.Correspondent()) {
                        ko.mapping.fromJS(suggestion.data, {}, self.NewBankAccount.PaymentType);
                        self.NewBankAccount.PaymentType.ConfirmAccountNumber(null);
                        RemoveNewBankAccountValidationMessage();

                        if (self.NewBankAccount.PaymentType.IsPaymentTypeAccount()) {
                            var accountTypes = self.NewBankAccount.PaymentType.AccountTypes();
                            if (accountTypes.length > 0) {
                                if (accountTypes.length == 1 && accountTypes[0].Value() == 3) {
                                    var accountType = accountTypes[0].Value;
                                    ko.mapping.fromJS(accountType, {}, self.NewBankAccount.PaymentType.AccountType);
                                } else {
                                    self.NewBankAccount.PaymentType.AccountType("");
                                    self.NewBankAccount.PaymentType.AccountType.isModified(false);
                                }
                            }
                        }
                    }
                    self.ValidType(0);
                },
            });

            var value = $(autoCompleteElement).val().trim();
            if (value != '' && (tempCorrespondents == '' || tempCorrespondents == null
                || cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) < 0)) {
                self.ValidType(2);
            }

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                if (!IsCurrentInput(this)) {
                    return;
                }
                var value = $(autoCompleteElement).val().trim();
                if (value != self.NewBankAccount.PaymentType.Correspondent()) {
                    if (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) > -1) {
                        self.ValidType(0);
                        return;
                    }
                    else {
                        self.ValidType(2);
                    }

                    ko.mapping.fromJS(defaultReceiver.NewBankAccount, {}, self.NewBankAccount);
                    RemoveNewBankAccountValidationMessage();
                }
            });

            $(autoCompleteElement).off("blur.correspondentchanged");
            $(autoCompleteElement).on("blur.correspondentchanged", function () {
                if ($('.autocomplete-selected').length > 0) return;

                var value = $(autoCompleteElement).val().trim();
                var matchedIndex = -1;

                if (value != self.NewBankAccount.PaymentType.Correspondent()) {
                    if (value == "") {
                        self.ValidType(1);
                    }
                    else if ($(autoCompleteElement).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, true)) > -1) {
                        self.ValidType(0);
                        $(autoCompleteElement).autocomplete().select(matchedIndex);
                        return;
                    }
                    else {
                        self.ValidType(2);
                    }
                }
            })
            .off('focus.correspondentchanged')
            .on('focus.correspondentchanged', function () {
                if ($(autoCompleteElement).autocomplete().visible) {
                    self.ValidType(0);
                }
            });
        }

        self.BindBankAccountCorrespondentsForEdit = function (autoCompleteElement, correspondents, isShowError) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (suggestion.value != self.BankAccount.PaymentType.Correspondent()) {
                        ko.mapping.fromJS(suggestion.data, {}, self.BankAccount.PaymentType);
                        self.BankAccount.PaymentType.ConfirmAccountNumber("");
                        RemoveBankAccountValidationMessage();
                        if (self.BankAccount.PaymentType.IsPaymentTypeAccount()) {
                            var accountTypes = self.BankAccount.PaymentType.AccountTypes();
                            if (accountTypes.length > 0) {
                                if (accountTypes.length == 1 && accountTypes[0].Value() == 3) {
                                    var accountType = accountTypes[0].Value;
                                    ko.mapping.fromJS(accountType, {}, self.BankAccount.PaymentType.AccountType);
                                } else {
                                    self.BankAccount.PaymentType.AccountType("");
                                    self.BankAccount.PaymentType.AccountType.isModified(false);
                                }
                            }
                        }
                    }

                    self.ValidTypeForEdit(0);
                }
            });

            if (isShowError == true) {
                var value = $(autoCompleteElement).val().trim();
                if (value != null && (tempCorrespondents == '' || tempCorrespondents == null
                    || cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) < 0)) {
                    self.ValidTypeForEdit(2);
                }
            }

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                if (!IsCurrentInput(this)) {
                    return;
                }
                var value = $(autoCompleteElement).val().trim();
                if (value != self.BankAccount.PaymentType.Correspondent()) {
                    if (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, false) > -1) {
                        self.ValidTypeForEdit(0);
                        return;
                    }
                    else {
                        self.ValidTypeForEdit(2);
                    }

                    ko.mapping.fromJS(defaultReceiver.BankAccount, {}, self.BankAccount);
                    RemoveBankAccountValidationMessage();
                }
            });

            $(autoCompleteElement).off("blur.correspondentchanged");
            $(autoCompleteElement).on("blur.correspondentchanged", function () {
                if ($('.autocomplete-selected').length > 0) return;

                var value = $(autoCompleteElement).val().trim();
                var matchedIndex = -1;

                if (value != self.BankAccount.PaymentType.Correspondent()) {
                    if (value == "") {
                        self.ValidTypeForEdit(1);
                    }
                    else if ($(autoCompleteElement).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, true)) > -1) {
                        self.ValidTypeForEdit(0);
                        $(autoCompleteElement).autocomplete().select(matchedIndex);
                        return;
                    }
                    else {
                        self.ValidTypeForEdit(2);
                    }
                }
            })
            .off('focus.correspondentchanged')
            .on('focus.correspondentchanged', function () {
                if ($(autoCompleteElement).autocomplete().visible) {
                    self.ValidTypeForEdit(0);
                }
            });
        }

        //judge if focus input is current input
        function IsCurrentInput(element) {
            var a = $("input:focus");
            return a[0] == element;
        }

        function RemoveBankAccountValidationMessage() {
            self.BankAccount.PaymentType.AccountType.isModified(false);
            self.BankAccount.PaymentType.AccountNumber.isModified(false);
            self.BankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
        };

        function RemoveNewBankAccountValidationMessage() {
            self.NewBankAccount.PaymentType.AccountType.isModified(false);
            self.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
        };


        self.LocationSelectIndexChange = function (index, receiver, location) {
            ko.mapping.fromJS(location.Branch, {}, receiver.Branch);
            SetSelectedLocation(index, location);
            $("#location-store-error-message").hide();
        }

        function SetSelectedLocation(index, location) {
            var templocation = self.LocationStores();
            for (var i = 0; i < templocation.length; i++) {
                if (i == index()) {
                    templocation[i].Selected(true);
                } else {
                    templocation[i].Selected(false);
                }
            }
            ko.mapping.fromJS(templocation, {}, self.LocationStores);
        }

        var trackCloseTotalClick = trackEvent;
        self.closeEditRecipient = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.EditNewRecipient,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.EditNewRecipient,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.EditNewRecipient,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Edit New Recipient",
                eventPage: track.PageEnum.EditNewRecipient,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});