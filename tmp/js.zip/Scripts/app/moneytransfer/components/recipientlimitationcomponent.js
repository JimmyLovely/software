﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths[require('app').page().name + '-strings'], 'Foundation.DatePicker'], function (ko, cs, app, dataModel, modulestring) {
    return function (params) {
        var self = this;
        ko.mapping.fromJS(params.PayoutLimitAdditionalFields, {}, self);
        self.defaultModel = params.PayoutLimitAdditionalFields;

        self.IsVisible = function (value) {
            if (value == null) {
                return false;
            }

            return true;
        }

        self.isMobile = function () {
            return cs.IsMobileDevice();
        };

        function initializeValidation() {
            self.SenderIdTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdTypeId); },
                    //Inline message
                    message: modulestring.additionalinforequired.idtyperequired
                }
            });
            self.SenderIdNumber.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdNumber); },
                    //Inline message
                    message: modulestring.additionalinforequired.senderidnumberrequired
                }
            });
            self.SenderIdExpiration.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdExpiration); },
                    //Inline message
                    message: modulestring.additionalinforequired.senderidexpirationrequired
                },
                equal: {
                    onlyIf: function () {
                        if (!self.IsVisible(self.defaultModel.SenderIdExpiration)) {
                            return false;
                        }

                        return !cs.ValidateDate(self.SenderIdExpiration(), "Expiration");
                    },
                    //Inline message
                    message: modulestring.additionalinforequired.invaliddate
                }
            });
            self.SenderIdIssuingCountry.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdIssuingCountry); },
                    //Inline message
                    message: modulestring.additionalinforequired.countryrequired
                }
            });
            self.SenderIdIssuingState.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdIssuingState); },
                    //Inline message
                    message: modulestring.additionalinforequired.staterequired
                }
            });
            self.SenderIdDateOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdDateOfBirth); },
                    //Inline message
                    message: modulestring.additionalinforequired.senderdateofbirthrequired
                },
                isValidDate: {
                    params: 'DateOfBirth',
                    //Inline message
                    message: modulestring.additionalinforequired.atleast18yearsofage
                }
            });
            self.SenderIdCountryOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderIdCountryOfBirth); },
                    //Inline message
                    message: modulestring.additionalinforequired.countryrequired
                }
            });
            self.SenderSSN.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderSSN); },
                    //Inline message
                    message: modulestring.additionalinforequired.senderssnrequired
                }
            });
            self.SenderOccupation.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderOccupation); },
                    //Inline message
                    message: modulestring.additionalinforequired.senderoccupationrequired
                }
            });
            self.Relationship.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.Relationship); },
                    //Inline message
                    message: modulestring.additionalinforequired.relationshipwithrecipientrequired
                }
            });
            self.SourceOfFunds.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SourceOfFunds); },
                    //Inline message
                    message: modulestring.additionalinforequired.sourceoffundsrequired
                }
            });
            self.PurposeOfFunds.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.PurposeOfFunds); },
                    //Inline message
                    message: modulestring.additionalinforequired.purposeoffundsrequired
                }
            });
            self.RecipientIdTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdTypeId); },
                    //Inline message
                    message: modulestring.additionalinforequired.idtyperequired
                }
            });
            self.RecipientIdNumber.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdNumber); },
                    //Inline message
                    message: modulestring.additionalinforequired.recipientidnumberrequired
                }
            });
            self.RecipientIdExpiration.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdExpiration); },
                    //Inline message
                    message: modulestring.additionalinforequired.recipientidexpirationrequired
                },
                equal: {
                    onlyIf: function () {
                        if (!self.IsVisible(self.defaultModel.RecipientIdExpiration)) {
                            return false;
                        }

                        return !cs.ValidateDate(self.RecipientIdExpiration(), "Expiration");
                    },
                    //Inline message
                    message: modulestring.additionalinforequired.invaliddate
                }
            });
            self.RecipientIdIssuingCountry.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdIssuingCountry); },
                    //Inline message
                    message: modulestring.additionalinforequired.countryrequired
                }
            });
            self.RecipientIdIssuingState.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdIssuingState); },
                    //Inline message
                    message: modulestring.additionalinforequired.staterequired
                }
            });
            self.RecipientIdDateOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdDateOfBirth); },
                    //Inline message
                    message: modulestring.additionalinforequired.recipientdateofbirthrequired
                },
                isValidDate: {
                    params: 'DateOfBirth',
                    //Inline message
                    message: modulestring.additionalinforequired.atleast18yearsofage
                }
            });
            self.RecipientIdCountryOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdCountryOfBirth); },
                    //Inline message
                    message: modulestring.additionalinforequired.countryrequired
                }
            });

            self.RecipientSSN.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientSSN); },
                    //Inline message
                    message: modulestring.additionalinforequired.recipientssnrequired
                }
            });
            self.RecipientOccupation.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientOccupation); },
                    //Inline message
                    message: modulestring.additionalinforequired.recipientoccupationrequired
                }
            });
            self.RecipientTaxIdentificationTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientTaxIdentificationTypeId); },
                    //Inline message
                    message: modulestring.additionalinforequired.taxidtyperequired
                }
            });
            self.RecipientIdCountryOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.RecipientIdCountryOfBirth); },
                    //Inline message
                    message: modulestring.additionalinforequired.countryrequired
                }
            });
            self.SenderTaxIdentificationTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.defaultModel.SenderTaxIdentificationTypeId); },
                    //Inline message
                    message: modulestring.additionalinforequired.taxidtyperequired
                }
            });
        }

        initializeValidation();

        function InitModalPayoutLimitAdditionalFields() {
            if (self.SenderIdExpiration() == "01/01/1753") {
                self.SenderIdExpiration("");
                self.SenderIdExpiration.isModified(false);
            }

            if (self.SenderIdDateOfBirth() == "01/01/1753") {
                self.SenderIdDateOfBirth("");
                self.SenderIdDateOfBirth.isModified(false);
            }

            if (self.RecipientIdExpiration() == "01/01/1753") {
                self.RecipientIdExpiration("");
                self.RecipientIdExpiration.isModified(false);
            }

            if (self.RecipientIdDateOfBirth() == "01/01/1753") {
                self.RecipientIdDateOfBirth("");
                self.RecipientIdDateOfBirth.isModified(false);
            }

            if (!self.isMobile()) {
                var enterToNext = cs.enterToNext,
                    senderEx = $('#input-sender-expiration'),
                    senderDOB = $('#input-sender-dateofbirth'),
                    recipientEx = $('#input-recipient-expiration'),
                    recipientDOB = $('#input-recipient-dateofbirth');
                senderEx.fdatepicker({
                    appendElement: senderEx.parents()[1],
                    container: senderEx.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });

                senderDOB.fdatepicker({
                    appendElement: senderDOB.parents()[1],
                    container: senderDOB.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });

                recipientEx.fdatepicker({
                    appendElement: recipientEx.parents()[1],
                    container: recipientEx.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });

                recipientDOB.fdatepicker({
                    appendElement: recipientDOB.parents()[1],
                    container: recipientDOB.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });
            } else {
                cs.addPlaceHolderToDate();
            }

            if (self.SenderIdTypeId() == '-1') {
                self.SenderIdTypeId(null);
                self.SenderIdTypeId.isModified(false);
            }

            if (self.SenderIdIssuingCountry() == '-1') {
                self.SenderIdIssuingCountry(null);
                self.SenderIdIssuingCountry.isModified(false);
            }

            if (self.SenderIdIssuingState() == '-1') {
                self.SenderIdIssuingState(null);
                self.SenderIdIssuingState.isModified(false);
            }

            if (self.SenderIdCountryOfBirth() == '-1') {
                self.SenderIdCountryOfBirth(null);
                self.SenderIdCountryOfBirth.isModified(false);
            }

            if (self.RecipientIdTypeId() == '-1') {
                self.RecipientIdTypeId(null);
                self.RecipientIdTypeId.isModified(false);
            }

            if (self.RecipientIdIssuingCountry() == '-1') {
                self.RecipientIdIssuingCountry(null);
                self.RecipientIdIssuingCountry.isModified(false);
            }

            if (self.RecipientIdIssuingState() == '-1') {
                self.RecipientIdIssuingState(null);
                self.RecipientIdIssuingState.isModified(false);
            }

            if (self.RecipientIdCountryOfBirth() == '-1') {
                self.RecipientIdCountryOfBirth(null);
                self.RecipientIdCountryOfBirth.isModified(false);
            }

            if (self.SenderTaxIdentificationTypeId() == '-1') {
                self.SenderTaxIdentificationTypeId(null);
                self.SenderTaxIdentificationTypeId.isModified(false);
            }

            if (self.RecipientTaxIdentificationTypeId() == '-1') {
                self.RecipientTaxIdentificationTypeId(null);
                self.RecipientTaxIdentificationTypeId.isModified(false);
            }
        }

        self.initdate = function (templateNodes) {
            $(templateNodes[1]).fdatepicker();
        };

        InitModalPayoutLimitAdditionalFields();

        function convertDateInMobile(date) {
            if (!date()) return;
            date(date().substr(5, 2) + '/' + date().substr(8, 2) + '/' + date().substr(0, 4));
        };

        var additionalDetailStatus = new cs.executeStatus();
        self.UpdateAdditionalDetail = function (element) {
            if (additionalDetailStatus.isExecuting()) {
                return;
            }
            additionalDetailStatus.setExecuting();
            self.errors = ko.validation.group(self);
            if (self.isMobile() && self.isValid()) {
                if (self.IsVisible(self.defaultModel.SenderIdExpiration)) {
                    convertDateInMobile(self.SenderIdExpiration);
                };
                if (self.IsVisible(self.defaultModel.SenderIdDateOfBirth)) {
                    convertDateInMobile(self.SenderIdDateOfBirth);
                };
                if (self.IsVisible(self.defaultModel.RecipientIdExpiration)) {
                    convertDateInMobile(self.RecipientIdExpiration);
                };
                if (self.IsVisible(self.defaultModel.RecipientIdDateOfBirth)) {
                    convertDateInMobile(self.RecipientIdDateOfBirth);
                };
            };

            if (self.isValid()) {
                var tempModel = ko.mapping.toJS(self);
                delete tempModel.IDTypes;
                delete tempModel.Countries;
                delete tempModel.States;
                delete tempModel.TaxIdTypes;

                var tempTransactionModel = ko.toJS(params.transactionModel);
                tempTransactionModel.PayoutLimitAdditionalFields = tempModel;

                cs.AjaxBySpinner({
                    url: '/MoneyTransfer/UpdateSelfServicePayoutLimitAdditionalFields',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ 'transactionModel': ko.mapping.toJS(tempTransactionModel) })
                }, element)
                .done(function (data) {
                    if (data.Caption) {
                        $("#NotificationHead").html(data.Caption);
                        $("#NotificationMessage").html(data.Message);
                        $("#NotificationConfirmOK").unbind('click');
                        var calculateLimitStatus = new cs.executeStatus();
                        $("#NotificationConfirmOK").click(function () {
                            if (calculateLimitStatus.isExecuting()) {
                                return;
                            }
                            calculateLimitStatus.setExecuting();

                            $.when(cs.closeModal())
                            .done(function () {
                                calculateLimitStatus.complete();
                            });

                            params.RecipientLimitationCalculate();
                        });
                        $.when(cs.openModal("modal-notification"))
                        .done(function () {
                            additionalDetailStatus.complete();
                        });
                    }
                    else {
                        $.when(cs.closeModal())
                        .done(function () {
                            additionalDetailStatus.complete();
                        });
                        params.RecipientLimitationCalculate();
                    }
                })
                .fail(function () {
                    additionalDetailStatus.complete();
                });
            }
            else {
                additionalDetailStatus.complete();
                self.errors.showAllMessages();
            }
        };

        self.GetStatesByCountryId = function (data) {
            var countryId;
            if (data.SenderIdIssuingCountry() != undefined
                && self.IsVisible(self.defaultModel.SenderIdIssuingCountry)) {
                countryId = data.SenderIdIssuingCountry();
            }
            else if (data.RecipientIdIssuingCountry() != undefined
                && self.IsVisible(self.defaultModel.SenderIdIssuingCountry)) {
                countryId = data.RecipientIdIssuingCountry();
            }

            if (countryId != undefined && (
                    self.IsVisible(self.defaultModel.RecipientIdIssuingState) ||
                    self.IsVisible(self.defaultModel.SenderIdIssuingState))) {
                $.when(dataModel.GetStatesByCountryId(countryId))
                .done(function (result) {
                    ko.mapping.fromJS(result, {}, self.States);
                });
            }
        }
    }
});