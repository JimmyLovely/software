﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;
        self.FirstName = ko.observable(null);
        self.MiddleName = ko.observable(null);
        self.LastName = ko.observable(null);
        self.SecondLastName = ko.observable(null);
        self.RelationShipId = ko.observable(null);
        self.Relationships = ko.observable(['Relationship']);
        self.CountryId = ko.observable(null);
        self.Countries = ko.observable([]);
        self.Address = ko.observable(null);
        self.Address2 = ko.observable(null);
        self.StateId = ko.observable(null);
        self.States = ko.observable(null);
        self.CityId = ko.observable(null);
        self.CityValidateType = ko.observable(0);
        self.City = null;
        self.Zipcode = ko.observable(null);
        self.PhoneNumber = ko.observable(null);
        self.PhoneType = ko.observable(null);
        self.EmailAddress = ko.observable(null);
        self.AreaCode = ko.observable(null);
        self.CellPhoneNumber = null;
        self.HomePhoneNumber = null;
        self.IsMaternalLastName = ko.observable(true);

        // the whole number including the country must be minimum 10 digits and maximun 17 digits. 
        self.PhoneNumberInValidReason = ko.observable('');

        //DataCapture.
        self.logActionTimeData = ko.observable({ transactionStepId: 1, label: 'Card_Holder_ID', value: 0 });

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddNewRecipient, track.PageEnum.AddNewRecipient);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.AddNewRecipient, track.PageEnum.AddNewRecipient);

        ko.computed(function () {
            var cityValidationType = self.CityValidateType();
            if (cityValidationType === 1) {
                self.trackErrorMessage(commonstrings.validation.addressvalidation.cityrequired);
            } else if (cityValidationType === 2) {
                self.trackErrorMessage(commonstrings.validation.addressvalidation.cityinvalid);
            }
        });
        // End appsflyer track event

        function getAreaCode() {
            if (!self.Countries() || !self.CountryId()) {
                return null;
            }

            $.each(self.Countries(), function (index, c) {
                if (c.Value == self.CountryId()) {
                    return c.Code;
                }
            });

            return null;
        }

        self.FormatAreaCode = ko.observable("");
        ko.computed(function(){
            if (self.AreaCode()) {
                self.FormatAreaCode('+' + self.AreaCode());
            } else {
                self.AreaCode("");
            }
        });

        self.PhoneNumberIsInValid = ko.computed(function () {
            self.PhoneNumberInValidReason('');
            var phoneNumber = self.PhoneNumber();
            if (!phoneNumber) {
                return;
            }
            var areaCodeLength = self.AreaCode() ? self.AreaCode().length : 0;
            if (self.PhoneNumber().length + areaCodeLength < 10) {
                self.PhoneNumberInValidReason('limitMinLength');
                return true;
            }

            var tempPhoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (cs.IsInvalidPhoneNumber(tempPhoneNumber)) {
                return true;
            }

            if (tempPhoneNumber.length + areaCodeLength <= 17) {
                return false;
            } else {
                self.PhoneNumberInValidReason('limitMaxLength');
                return true;
            }
        });

        function applyReceiverValidation() {
            self.FirstName.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.namevalidation.firstnamerequired },
                minTrimLength: { params: 2, message: commonstrings.validation.namevalidation.firstnameminlength },
                maxLength: { params: 50, message: commonstrings.validation.namevalidation.firstnamemaxlength },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.FirstName()) != 0 },
                    message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.validation.namevalidation.firstnamestartwithletter : commonstrings.validation.namevalidation.firstnameinvalid }
                }
            }).isModified(false);
            self.MiddleName.extend({
                //Inline message
                maxLength: { params: 50, message: commonstrings.validation.namevalidation.middlenamemaxlength },
                equal: {
                    onlyIf: function () { return self.MiddleName() != "" && cs.IsInvalidName(self.MiddleName()) != 0 },
                    message: function () { return cs.IsInvalidName(self.MiddleName()) == 1 ? commonstrings.validation.namevalidation.middlenamestartwithletter : commonstrings.validation.namevalidation.middlenameinvalid }
                }
            }).isModified(false);
            self.LastName.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.namevalidation.lastnamerequired },
                minTrimLength: { params: 2, message: commonstrings.validation.namevalidation.lastnameminlength },
                maxLength: { params: 50, message: commonstrings.validation.namevalidation.lastnamemaxlength },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.LastName()) != 0 },
                    message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.validation.namevalidation.lastnamestartwithletter : commonstrings.validation.namevalidation.lastnameinvalid }
                }
            }).isModified(false);
            self.SecondLastName.extend({
                minTrimLength: {
                    params: 2, message: function () {
                        if (self.IsMaternalLastName()) {
                            return commonstrings.validation.namevalidation.maternallastnameminlength;
                        } else {
                            return commonstrings.validation.namevalidation.secondlastnameminlength;
                        }
                    }
                },
                maxLength: {
                    params: 50, message: function () {
                        if (self.IsMaternalLastName()) {
                            return commonstrings.validation.namevalidation.middlenamemaxlength;
                        }
                        else {
                            return commonstrings.validation.namevalidation.secondlastnamemaxlength;
                        }
                    }
                },
                equal: {
                    onlyIf: function () { return self.SecondLastName() != "" && cs.IsInvalidName(self.SecondLastName()) != 0 },
                    message: function () {
                        if (self.IsMaternalLastName()) {
                            return cs.IsInvalidName(self.SecondLastName()) == 1 ? commonstrings.validation.namevalidation.maternallastnamestartwithletter : commonstrings.validation.namevalidation.maternallastnameinvalid
                        }
                        else {
                            return cs.IsInvalidName(self.SecondLastName()) == 1 ? commonstrings.validation.namevalidation.secondlastnamestartwithletter : commonstrings.validation.namevalidation.secondlastnamesinvalid
                        }
                    }
                }
            }).isModified(false);
            //Inline message
            self.Address.extend({ required: { params: true, message: commonstrings.validation.addressvalidation.addressrequired } }).isModified(false);
            self.StateId.extend({ required: { params: true, message: commonstrings.address.validations.staterequired } }).isModified(false);
            self.Zipcode.extend({
                number: {
                    params: true,
                    //Inline message
                    message: commonstrings.address.validations.zipcodeinvalid
                },
                maxLength: {
                    params: 12,
                    //Inline message
                    message: commonstrings.address.validations.zipcodeinvalid
                }
            }).isModified(false);

            self.PhoneNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.phonerequired
                },
                equal: {
                    onlyIf: self.PhoneNumberIsInValid,
                    //Inline message
                    message: function () {
                        if (self.PhoneNumberInValidReason() == 'limitMinLength') {
                            return commonstrings.addnewrecipient.validation.phoneminimumlength;
                        } else if (self.PhoneNumberInValidReason() == 'limitMaxLength') {
                            return commonstrings.addnewrecipient.validation.phonemaximumlength;
                        }
                        else {
                            return commonstrings.addnewrecipient.validation.phoneinvalid;
                        }
                    }
                }
            }).isModified(false);

            self.RelationShipId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.relationshiprequired
                }
            }).isModified(false);

            self.EmailAddress.extend({
                email: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.emailinvalid
                }
            }).isModified(false);

            self.CountryId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.validation.addressvalidation.countryrequired
                }
            }).isModified(false);

            self.PhoneType.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.phonetyperequired
                }
            }).isModified(false);
        }

        function InitializeDestinationCountries(element) {
            $.when(dataModel.InitializeDestinationsCountries(14, element))
            .done(function (data) {
                self.Countries(data);
                self.States([]);
            })
        }

        function InitializeDestinationCountry() {
            $.when(dataModel.getLastSendMoneyFeeCalculator())
            .done(function (data) {
                if (!data) return;

                var countryId = data.ToCountryId;

                //init Areacode for countryid
                ResetAreaCodeForCountryId(countryId);

                self.CountryId(countryId);
                InitializeDestinationStates(countryId);
                SetSecondLastName(countryId);
            });
        }

        function InitializeRelationShips() {
            $.when(dataModel.GetRelationShips())
            .done(function (data) {
                self.Relationships(data);
            });
        }

        applyReceiverValidation();
        InitializeRelationShips();

        InitializeDestinationCountries();
        InitializeDestinationCountry();

        self.CountryChanged = function (countryId) {
            InitializeDestinationStates(countryId);
            ResetZipCode();
            ResetAddress2();
            ResetAddress();
            ResetState();
            ResetCity();
            RestAreaCodeForAddReceiver(countryId);

            SetSecondLastName(countryId);
        };

        function SetSecondLastName(countryId) {
            // Mexico 484, Peru 604
            if (countryId == 484 || countryId == 604) {
                self.IsMaternalLastName(false);
            }
            else {
                self.IsMaternalLastName(true);
            }
        }

        function ResetZipCode() {
            self.Zipcode(null);
        }

        function ResetAddress2() {
            self.Address2(null);
        }

        function ResetAddress() {
            self.Address(null);
            self.Address.isModified(false);
        }
        function RestAreaCodeForAddReceiver(countryId) {
            if (!countryId || !self.Countries()) {
                self.AreaCode("");
                return;
            }
            ResetAreaCodeForCountryId(countryId);

            self.AddPhoneNumberBlur($("#input-home-phone"));
        }

        function ResetAreaCodeForCountryId(countryId) {
            var countries = ko.mapping.toJS(self.Countries());

            if (!countries || countries.length == 0) {
                return;
            }

            for (var i = 0; i < countries.length; i++) {
                var country = countries[i];
                if (country.Value == countryId.toString()) {
                    self.AreaCode(country.Code);
                    break;
                }
            }
        }

        function ResetState() {
            self.StateId(null);
            self.StateId.isModified(false);
        }

        function ResetCity() {
            AutoCompleteCitys('#autocomplete-moneytransfer-city-names-addrecipient', null);
            self.CityId(null)
        }

        function InitializeDestinationStates(countryId) {
            $.when(dataModel.GetStatesByCountryId(countryId))
            .done(function (data) {
                self.States(data);
            })
            .fail(function () {
                self.states([]);
            });
        }

        self.StateChanged = function (stateId) {
            var countryId = self.CountryId();
            $.when(dataModel.GetCitiesByStateId(countryId, stateId))
            .done(function (result) {
                AutoCompleteCitys('#autocomplete-moneytransfer-city-names-addrecipient', result);
            });
        };

        function AutoCompleteCitys(element, lookup) {// using now
            self.CityValidateType(0);
            $(element).val("");
            self.CityId(null);
            self.City = null;
            $(element).autocomplete({
                lookup: lookup,
                triggerSelectOnValidInput: false,
                minChars: 1,
                onSelect: function (suggestion) {
                    self.CityId(suggestion.data.Value);
                    self.City = suggestion.value;
                    self.CityValidateType(0);
                },
                lookupFilter: function (k, j, l) {
                    var inputValue = (cs.removeDiacritics(l).toLowerCase());
                    return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1
                }
            });
            $(element).autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
            $(element).off('keyup.validation.city');
            $(element).on('keyup.validation.city', function () {
                var value = $(this).val();

                if (!self.City && value == "") {
                    return;
                }

                if (value != self.City) {
                    if (value == "") {
                        self.CityValidateType(1);
                    }
                    else if (cs.isMatchSuggestion($(element).autocomplete().suggestions, value, false) > -1) {
                        self.CityValidateType(0);
                        return;
                    }
                    else {
                        self.CityValidateType(2);
                    }
                    self.CityId(null);
                    self.City = null;
                }
            });

            $(element).off('blur.validation.city');
            $(element).on('blur.validation.city', function () {
                if ($('.autocomplete-selected').length > 0) return;

                var matchedIndex = -1;
                var value = $(this).val();

                if (value == "") {
                    self.CityValidateType(1);
                }
                else if ($(element).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(element).autocomplete().suggestions, value, true)) > -1) {
                    self.CityValidateType(0);
                    $(element).autocomplete().select(matchedIndex);
                    return;
                } else {
                    self.CityValidateType(2);
                }
            });

        }

        self.ValidateCityForAddRecipient = function () {

        }

        self.PhoneNumberFocus = function (element) {
            if (!($(element).val())) {
                return;
            }

            $(element).val(cs.GetRemoveFormatPhoneNumber($(element).val()));
        }

        self.AddPhoneNumberBlur = function (element) {
            var phoneNumber = $(element).val();
            if (!phoneNumber) {
                return;
            }

            phoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10 && !cs.IsInvalidPhoneNumber(phoneNumber)) {
                var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                if (self.PhoneType() == 2) {
                    if (self.AreaCode()) {
                        phoneNumber = '-' + phoneNumber.replace(reg, "($1) $2-$3");
                    }
                    else {
                        phoneNumber = phoneNumber.replace(reg, "($1) $2-$3");
                    }
                } else {
                    if (self.AreaCode()) {
                        phoneNumber = '-' + phoneNumber.replace(reg, "$1-$2-$3");
                    } else {
                        phoneNumber = phoneNumber.replace(reg, "$1-$2-$3");
                    }
                }
            }
            else {
                if (self.AreaCode()) {
                    phoneNumber = '-' + phoneNumber;
                }
            }

            $(element).val(phoneNumber);
        }

        var addReceiverStatus = new cs.executeStatus();
        function AddSelfServiceReceiver(element) {
            if (addReceiverStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            addReceiverStatus.setExecuting();

            var tempRecipeintModel = ko.mapping.toJS(self);
            delete tempRecipeintModel.Countries;
            delete tempRecipeintModel.States;
            delete tempRecipeintModel.Relationships;

            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/AddSelfServiceReceiver',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempRecipeintModel)
            }, element)
            .done(function (data) {
                trackSaveTimeOnPage();

                params.AddRecipient(data);
                cs.closeModal();
                addReceiverStatus.complete();

                //DataCapture.
                self.logActionTimeData({ transactionStepId: 1, label: 'Card_Holder_ID', value: data.CardHolderId });
            })
            .fail(function () {
                addReceiverStatus.complete();
            });
        }

        self.AddReceiver = function (element) {
            var isValidDestination = true;
            self.errors = ko.validation.group(self);
            var isValidCity = self.CityValidateType() == 0 && !!($('#autocomplete-moneytransfer-city-names-addrecipient').val());
            if (self.isValid() && isValidCity) {
                var phoneType = $("#input-phone-type").val();
                if (phoneType == 1) {
                    self.CellPhoneNumber = cs.GetRemoveFormatPhoneNumber(self.PhoneNumber());
                } else if (phoneType == 2) {
                    self.HomePhoneNumber = cs.GetRemoveFormatPhoneNumber(self.PhoneNumber());
                }

                AddSelfServiceReceiver(element);
            }
            else {
                if (!$('#autocomplete-moneytransfer-city-names-addrecipient').val()) {
                    self.CityValidateType(1);
                }
                self.errors.showAllMessages();
            }

            var trackSaveTotalClick = trackEvent;
            trackSaveTotalClick("Save");
        };

        var trackCloseTotalClick = trackEvent;
        self.closeAddRecipient = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewRecipient,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddNewRecipient,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewRecipient,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add New Recipient",
                eventPage: track.PageEnum.AddNewRecipient,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});