﻿define(['knockout', 'ClientScript', 'app', 'DataModel'], function (ko, cs, app, dataModel) {
    return function (params) {
        var self = this;
        self.type = params.type;
        self.transactionDetails = ko.mapping.toJS(params.transactionDetails);
        self.transactionDetails.AmountToSend.Value = ko.observable(cs.keepAmountDecimalPlaces(self.transactionDetails.AmountToSend.Value));
        self.transactionDetails.AmountToBeDispensed.Value = ko.observable(cs.keepAmountDecimalPlaces(self.transactionDetails.AmountToBeDispensed.Value));

        var originalSendAmount = cs.GetOriginalNumber(self.transactionDetails.AmountToSend.Value());
        var originalReceiverAmount = cs.GetOriginalNumber(self.transactionDetails.AmountToBeDispensed.Value());

        self.senderLevel = ko.mapping.toJS(params.senderLevel);
        self.uploadDocumentTypes = params.uploadDocumentTypes;
        self.refreshDocumentTypes = params.refreshDocumentTypes;
        self.submitDocuments = params.submitDocuments;
        self.clickAmountAndReceiver = params.recordFirstClickTimeForAmount.ClickAmountAndReceiver;

        var checkAmountTimer;

        self.checkAmount = function (element, amount, isSend, isDirectCall) {
            if (!amount) {
                return;
            }
            if (checkAmountTimer) {
                clearTimeout(checkAmountTimer);
            }
            //select Original Number
            if (isSend) {
                originalAmount = cs.GetOriginalNumber(self.transactionDetails.AmountToSend.Value());
            } else {
                originalAmount = cs.GetOriginalNumber(self.transactionDetails.AmountToBeDispensed.Value());
            }
            rate = self.transactionDetails.Rate;
            amount = cs.LimitNumber(element, isSend, originalAmount,rate);
            if (cs.IsMobileDevice()) {
                mobileFormatAmount(amount, isSend);
            } else {
                formatAmount(amount, isSend);
            }
            checkAmountTimer = setTimeout(function () {
                $(element).blur();
            }, 1000);
        }

        self.checkAmountBlur = function (amount, isSend) {
            if (params.type == 'qp') {

                var amountToSend = 0;

                if (isSend) {
                    amountToSend = (parseFloat(cs.GetOriginalNumber(amount))).toFixed(2);
                } else {
                    amountToSend = (parseFloat(cs.GetOriginalNumber(amount)) / self.transactionDetails.Rate).toFixed(2)
                }

                params.recordFirstClickTimeForAmount.NextStep(amountToSend);
            }

            if (!checkValueChanged(amount, isSend)) {
                return;
            }

            originalSendAmount = cs.GetOriginalNumber(self.transactionDetails.AmountToSend.Value());
            originalReceiverAmount = cs.GetOriginalNumber(self.transactionDetails.AmountToBeDispensed.Value());
            checkAmount(amount, isSend);
        };  

        function checkValueChanged(amount, isSend) {
            if (isSend) {
                if (Number(cs.GetOriginalNumber(amount)) === Number(originalSendAmount)) {
                    return false;
                }
            } else {
                if (Number(cs.GetOriginalNumber(amount)) === Number(originalReceiverAmount)) {
                    return false;
                }
            }

            return true;
        }

        function checkAmount(amount, isSend) {
            amount = cs.GetOriginalNumber(amount);
            var sendAmount = 0;
            if (isSend) {
                sendAmount = amount;
                self.transactionDetails.AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.transactionDetails.Rate));
                self.transactionDetails.DominantControl = 'AmountToBeSent';
            } else {
                sendAmount = 1.0 * amount / self.transactionDetails.Rate;
                self.transactionDetails.AmountToBeDispensed.Value(amount);
                self.transactionDetails.DominantControl = 'AmountToBeReceived';
            }
            self.transactionDetails.AmountToSend.Value(cs.keepAmountDecimalPlaces(sendAmount));

            params.checkLimitAmount(ko.mapping.toJS(self.transactionDetails));
        }

        function mobileFormatAmount(amount, isSend) {
            if (isSend) {
                self.transactionDetails.AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount));
                self.transactionDetails.AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.transactionDetails.Rate));
            } else {
                self.transactionDetails.AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount / self.transactionDetails.Rate));
                self.transactionDetails.AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount));
            }
        }

        function formatAmount(amount, isSend) {
            if (isSend) {
                self.transactionDetails.AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.transactionDetails.Rate));
            } else {
                self.transactionDetails.AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount / self.transactionDetails.Rate));
            }
        }

        self.upgradeNow = function () {
            self.senderLevel.IsUpgrading = true;

            if (params.upgradeNow) {
                params.upgradeNow(self.senderLevel);
            }
        };

        self.upgradeLater = function () {
            var isEmailLater = !self.senderLevel.IsUpgrading;
            self.transactionDetails.TransactionStatusCode = 'O';
            self.senderLevel.IsDocumentSubmited = false;
            self.senderLevel.IsUpgrading = false;
            self.senderLevel.IsUpgradeLater = true;
            if (params.upgradeLater) {
                params.upgradeLater(ko.mapping.toJS(self.transactionDetails), self.senderLevel, isEmailLater);
            }
        }.bind(this);

        if (self.type == 'qp') {
            cs.scrollToElement($('.quick-pay-href #input-amount-to-send'));
        }
    }
});