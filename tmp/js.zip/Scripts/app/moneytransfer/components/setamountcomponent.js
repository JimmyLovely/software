﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths[require('app').page().name + '-strings'], 'upgrade-component'], function (ko, cs, app, dataModel, modulestring) {
    return function (params) {
        var self = this;
        self.TransactionDetails = ko.observable();
        var lastSendAmount;
        var lastReceiverAmount;
        var lastTransactionSendAmount;
        var lastTransactionReceiverAmount;

        self.SenderLevel = ko.observable(params.senderLevel);

        self.TransactionDetails(ko.mapping.toJS(params.transactionDetails));

        self.uploadDocumentTypes = params.uploadDocumentTypes;

        self.refreshDocumentTypes = params.refreshDocumentTypes;
        self.submitDocuments = params.submitDocuments;

        self.recordFirstClickTimeForAmount = params.recordFirstClickTimeForAmount;

        self.BackToSelectReceiver = function () {
            params.BackToSelectReceiver();
        }

        self.GoToDeliveryOption = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            params.GoToDeliveryOption(null);
        };

        self.upgradeNow = function (senderLevel) {
            if (params.upgradeNow) {
                params.upgradeNow(senderLevel);
            }
        }.bind(this);

        self.upgradeLater = function (transactionModel, senderLevel, isEmailLater) {
            if (params.upgradeLater) {
                params.upgradeLater(transactionModel, senderLevel, isEmailLater);
            }
        }.bind(this);

        self.updateSenderLevel = function (transactionModel, senderLevel) {
            self.SenderLevel(senderLevel);
        }

        self.checkLimitAmount = function (transactionModel) {
            params.checkLimitAmount(transactionModel);
        }
    }
});