﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation', 'knockout.validation.extended'], function (ko, cs, app, dataModel) {
    return function MoneyTransferTransactionModel(data) {
        var self = this;
        var defaultSenderModel;
        var defaultCardHolderId;
        var originalToBeUpdatedBranch;
        var originalToBeUpdatedPaymentType;
        var originalAmountToSend;
        var originalAmountToBeDispensed;

        self.VerifySelected = ko.observable(false);
        self.SelectFromCurrencyCode = ko.observable("");
        self.SelectToCurrencyCode = ko.observable("");
        self.IsAgree = ko.observable(false);

        self.AgreeChange = ko.computed(function () {
            if (self.IsAgree()) {
                $("#confirmError").fadeOut();
            }
        });

        self.ApplyPromotionCodeSuccessful = ko.observable(false);
        self.IsAddedPromotionCode = ko.observable(false);
        self.TempPromotionCode = ko.observable("");
        ko.mapping.fromJS(data, {}, self);

        self.TempSendToAmount = ko.observable(self.AmountToSend.Value());
        self.TempAmountToBeDispensed = ko.observable(self.AmountToBeDispensed.Value());

        self.ResetAmount = function () {
            self.TempSendToAmount(self.AmountToSend.Value());
            self.TempAmountToBeDispensed(self.AmountToBeDispensed.Value());
        };

        self.ClearAmount = function () {
            self.TempSendToAmount("");
            self.TempAmountToBeDispensed("");
            self.AmountToSend.Value("");
            self.AmountToBeDispensed.Value("");
        }

        self.PayoutLimitAdditionalFields.defaultModel = ko.mapping.fromJSON(ko.mapping.toJSON(self.PayoutLimitAdditionalFields));

        ApplyModalMoneyTransferLimitFieldsValidation();
        ApplyModalPayoutLimitAdditionalFieldsValidation();

        var defaultTransaction = ko.mapping.toJSON(self);

        self.MoneyTransfer$Detailfunction = function (receiverCardHolderId, element) {
            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/SelfServiceTransactionDetail',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "selectedReceiverId": receiverCardHolderId })
            }, element)
            .done(function (result) {
                ko.mapping.fromJS(result, {}, self);
                defaultSenderModel = ko.mapping.toJSON(self.SenderModel);
                defaultCardHolderId = ko.mapping.toJSON(self.CardHolderIdModel);
                defaultPayoutLimitAdditionalFieleds = ko.mapping.toJSON(self.PayoutLimitAdditionalFields);
                originalToBeUpdatedBranch = ko.mapping.toJSON(self.Branch);
                originalToBeUpdatedPaymentType = ko.mapping.toJSON(self.PaymentType);

                self.ApplyPromotionCodeSuccessful(false);
                self.IsAddedPromotionCode(false);
                self.TempPromotionCode("");
                self.TempAmountToBeDispensed("");
                self.TempSendToAmount("");
            })
        };

        self.ValidateConfirmSend = function () {
            if (!self.IsAgree()) {
                $("#confirmError").fadeIn();
                return false;
            }

            return true;
        };

        self.MoneyTransfer$ReviewConfirm = function (element) {
            return cs.AjaxByLoading({
                url: '/MoneyTransfer/SelfServiceTransaction',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
             .done(function (result) {
                 var tempTransaction = ko.mapping.toJS(result);
                 ko.mapping.fromJS(tempTransaction, {}, self);
             })
            .fail(function (xhr, status) {
                try {
                    var obj = $.parseJSON(xhr.responseText);
                    if (obj.returnCode == -460) { //Exceed sender level limitation.
                        $.when(app.senderInfo().SenderLevel().CheckTransactionAmount(1, self.AmountToSend.Value(), true, false, false, element))
                        .done(function () {
                            self.TransactionStatusCode('O');
                        });
                    } else if (obj.returnCode == -462) { //Exceed sender level limitation.
                        return;
                    } else {
                        cs.handleAjaxError(xhr.responseText);
                    };
                } catch (e) {
                    cs.handleAjaxError(xhr.responseText);
                }
            });
        };

        self.FinishMoneyTransferTransaction = function (element) {
            app.navigateToCustomerDashboardBySpinner(element);
        }

        //begin: calculate
        self.SetAmountCalculate = function (value, isSend) {
            self.SetDominantControl(isSend);
            return self.AmountBlur(value);
        };

        self.SetDominantControl = function (isSend) {
            self.DominantControl(isSend == true ? 'AmountToBeSent' : 'AmountToBeReceived');
        };

        self.CheckAmount = function () {
            if (self.DominantControl() == 'AmountToBeSent') {
                if (!cs.isAmountValid(self.AmountToSend.Value())) {
                    cs.showErrorMessage("Error", "Please input a valid send amount");
                    return false;
                }
            } else {
                if (!cs.isAmountValid(self.AmountToBeDispensed.Value())) {
                    cs.showErrorMessage("Error", "Please input a valid receive amount");
                    return false;
                }
            }

            return true;
        };

        self.AmountBlur = function (value) {
            var amount = "-1";
            if (self.DominantControl() == 'AmountToBeSent') {
                amount = value;
            }
            else if (self.DominantControl() == 'AmountToBeReceived') {
                amount = value;
            }
            else {
                amount = "-1";
            }

            if (amount == null) {
                amount = "-1";
            }

            if (amount && parseFloat(cs.GetOriginalNumber(amount.toString())) > 0) {
                amount = parseFloat(cs.GetOriginalNumber(amount.toString()));
                if (self.DominantControl() == "AmountToBeSent") {
                    self.AmountToSend.Value(amount.toFixed(2));
                    var result = 1.0 * amount * self.Rate();
                    if (!isNaN(result)) {
                        self.AmountToBeDispensed.Value(result.toFixed(2));
                        var amountToBeDispensed = cs.keepAmountDecimalPlaces(result);
                        if ($("#input-amount-to-be-dispensed") && $("#input-amount-to-be-dispensed").length > 0 && $("#input-amount-to-be-dispensed").val() != amountToBeDispensed) {
                            self.TempAmountToBeDispensed(amountToBeDispensed);
                            cs.fitTextAmountField($("#input-amount-to-be-dispensed"), amountToBeDispensed);
                        }
                        if ($("#receiver-amount-input") && $("#receiver-amount-input").length > 0 && $("#receiver-amount-input").val() != amountToBeDispensed) {
                            self.TempAmountToBeDispensed(amountToBeDispensed);
                            cs.fitTextAmountField($("#receiver-amount-input"), amountToBeDispensed);
                        }
                        return;
                    }
                } else {
                    self.AmountToBeDispensed.Value(amount.toFixed(2));
                    var result = 1.0 * amount / self.Rate();
                    if (!isNaN(result)) {
                        self.AmountToSend.Value(result.toFixed(2));
                        var sendToAmount = cs.keepAmountDecimalPlaces(result);
                        if ($("#input-amount-to-send") && $("#input-amount-to-send").length > 0 && $("#input-amount-to-send").val() != sendToAmount) {
                            self.TempSendToAmount(sendToAmount);
                            cs.fitTextAmountField($("#input-amount-to-send"), sendToAmount);
                        }
                        if ($("#send-amount-input") && $("#send-amount-input").length > 0 && $("#send-amount-input").val() != sendToAmount) {
                            self.TempSendToAmount(sendToAmount);
                            cs.fitTextAmountField($("#send-amount-input"), sendToAmount);
                        }
                        return;
                    }
                }
            } else {
                if (self.DominantControl() == 'AmountToBeSent') {
                    self.AmountToSend.Value(0);
                    if (value == "" || value == null || value == '0.00') {
                        self.AmountToBeDispensed.Value(0);
                        if (cs.IsMobileDevice()) {
                            $("#input-amount-to-be-dispensed").val("0.00");
                            $("#receiver-amount-input").val("0.00");
                        } else {
                            $("#input-amount-to-be-dispensed").val("");
                            $("#receiver-amount-input").val("");
                        }
                    }
                }
                else if (self.DominantControl() == 'AmountToBeReceived') {
                    self.AmountToBeDispensed.Value(0);
                    if (value == "" || value == null || value == '0.00') {
                        self.AmountToSend.Value(0);
                        if (cs.IsMobileDevice()) {
                            $("#input-amount-to-send").val("0.00");
                            $("#send-amount-input").val("0.00");
                        }
                        else {
                            $("#input-amount-to-send").val("");
                            $("#send-amount-input").val("");
                        }
                    }
                }
            }
        }

        self.MoneyTransfer$Calculate = function (receiverCardHolderId, deliveryOption, element) {

            var amountToSend = parseFloat(cs.GetOriginalNumber(self.AmountToSend.Value()));
            var amountToBeDispensed = parseFloat(cs.GetOriginalNumber(self.AmountToBeDispensed.Value()));
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            if ((!isNaN(amountToSend) && amountToSend != 0)
               || (!isNaN(amountToBeDispensed) && amountToBeDispensed != 0)) {
                return cs.AjaxByLoading({
                    url: '/MoneyTransfer/SelfServiceCalculator',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "receiverCardHolderId": receiverCardHolderId, "transactionModel": ko.mapping.toJS(self), "recipientDestinationModel": ko.mapping.toJS(deliveryOption) })
                }, true)
                .done(function (result) {
                    var r = ko.mapping.toJS(result);
                    ko.mapping.fromJS(r, {}, self);
                })
                .fail(function (xhr, status) {
                    if ($.parseJSON(xhr.responseText).Priority != null) {
                        if ($.parseJSON(xhr.responseText).Priority == 1) {
                            ModelSessionTimeOut$RevealAndLogout();
                            return;
                        }
                    }

                    var data = $.parseJSON(xhr.responseText);

                    if (data.returnCode != null) {
                        ExceedLimitHandler(data);
                    } else {
                        cs.showError($.parseJSON(xhr.responseText));
                    }
                });
            }
        }

        self.UpdateTransactionPaymentMethod = function (paymentMethod) {
            var tempPaymentMethod = ko.mapping.toJS(paymentMethod);
            self.PaymentMethodId(tempPaymentMethod.PaymentMethodId);
        };

        function ExceedLimitHandler(data) {
            var errorCode = parseInt(data.returnCode);
            if (errorCode == -118) { //DAILY_SEND_MONEY_LIMIT_EXCEEDED
                InitModalErrorMoneyTransferLimitFieldsModel();
                cs.openModal('modal-error-money-transfer-limit');
            }
            else if (errorCode == -335 // SEND_MONEY_SENDER_LIMIT_EXCEEDED_ADDITIONAL_FIELDS
                || errorCode == -336) { // SEND_MONEY_RECIPIENT_LIMIT_EXCEEDED_ADDITIONAL_FIELDS
                ko.mapping.fromJS(data.limitAdditionalFields, {}, self.PayoutLimitAdditionalFields);
                ko.mapping.fromJS(data.limitAdditionalFields, {}, self.PayoutLimitAdditionalFields.defaultModel);

                $("#ConfirmCaption").html(data.Caption);
                $("#ConfirmMessage").html(data.Message);
                $("#ConfirmOk").html("<span class='button-text'>OK</span>");
                $("#ConfirmCancel").hide();

                if ($("#ConfirmOk").hasClass('close-reveal-modal')) {
                    $("#ConfirmOk").removeClass('close-reveal-modal');
                }

                $("#ConfirmOk").off('click');
                $("#ConfirmOk").on('click', function () {
                    InitModalPayoutLimitAdditionalFields();
                    cs.openModal('modal-payoutlimit-additional-fields');
                    $("#ConfirmOk").off('click');
                });

                cs.openModal('modal-confirm');
            }
        }

        function InitModalErrorMoneyTransferLimitFieldsModel() {
            self.CardHolderIdModel.IdDateOfBirth.isModified(false);
            self.CardHolderIdModel.IdNumber.isModified(false);
            self.CardHolderIdModel.IdExpiration.isModified(false);
            self.CardHolderIdModel.States("");
            self.GetStatesByIssuingCountryId();
        }

        self.GetStatesByIssuingCountryId = function () {
            self.CardHolderIdModel.States("");
            $("#issuingStateLimit").empty();

            if (cs.isDisabled("issuingStateLimit")) {
                return;
            }

            var countryId = $("#issuingCountryLimit").val();

            if (countryId != undefined && countryId != "") {
                $.when(dataModel.GetStatesByCountryId(countryId))
                .done(function (result) {
                    ko.mapping.fromJS(result, {}, self.CardHolderIdModel.States);
                })
            }
        }

        function EnableAmountControl() {
            cs.removeDisable("input-amount-to-send");
            cs.removeDisable("input-amount-to-be-dispensed");
        }

        function DisableAmountControl() {
            cs.addDisable("input-amount-to-send");
            cs.addDisable("input-amount-to-be-dispensed");
        }

        //begin: apply promotion
        var applyPromoStatus = new cs.executeStatus();
        self.MoneyTransfer$ApplyPromo = function (element, receiverCardHolderId, deliveryOption) {
            if (applyPromoStatus.isExecuting()) {
                return;
            }
            if (!this.CheckAmount()) {
                return;
            }

            if (!self.PromotionCode() || self.PromotionCode().trim().length <= 0) {
                self.PromotionCode("");
                cs.showErrorMessage("Error", "Please input valid Promo Code");
                return;
            }
            applyPromoStatus.setExecuting();
            $(element).children().last().css("position", "relative");
            $(element).children().last().css("right", "auto");
            $(element).children().last().css("top", "auto");
            $(element).children().last().css("margin-top", "auto");
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            return cs.AjaxByLoading({
                url: '/MoneyTransfer/SelfServiceCalculateToApplyPromo',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "transactionModel": ko.mapping.toJS(self), "recipientDestinationModel": ko.mapping.toJS(deliveryOption) })
            }, true)
            .done(function (result) {
                var tempTransaction = ko.mapping.toJS(result);
                ko.mapping.fromJS(tempTransaction, {}, self);
                self.TempPromotionCode(self.PromotionCode());
                self.IsAddedPromotionCode(true);
                self.ApplyPromotionCodeSuccessful(true);
                applyPromoStatus.complete();
                //DataCapture
                require("MoneyTransferMoneyTransferConsumer").UpdateDataCaptureTransactionFee();
            })
            .fail(function (xhr, status) {
                applyPromoStatus.complete();
                if ($.parseJSON(xhr.responseText).Priority != null) {
                    if ($.parseJSON(xhr.responseText).Priority == 1) {
                        ModelSessionTimeOut$RevealAndLogout();
                        return;
                    }
                }

                var data = $.parseJSON(xhr.responseText);

                if (data.returnCode != null) {
                    ExceedLimitHandler(data);
                } else {
                    self.TempPromotionCode(self.PromotionCode());
                    self.PromotionCode("");
                    self.MoneyTransfer$Calculate(receiverCardHolderId, deliveryOption);
                    self.ApplyPromotionCodeSuccessful(false);
                }
            });
        }

        self.RemovePromotionCode = function (receiverCardHolderId, deliveryOption) {
            self.PromotionCode("");
            $.when(self.MoneyTransfer$Calculate(receiverCardHolderId, deliveryOption))
            .always(function () {
                self.IsAddedPromotionCode(false);
                self.ApplyPromotionCodeSuccessful(false);
                self.TempPromotionCode("");
                //DataCapture
                require("MoneyTransferMoneyTransferConsumer").UpdateDataCaptureTransactionFee();
            });
        }

        self.ResetPromotionCode = function () {
            self.IsAddedPromotionCode(false);
            self.ApplyPromotionCodeSuccessful(false);
            self.PromotionCode("");
            self.TempPromotionCode("");
        };

        self.ClearTransactionExternalCondation = function () {
            self.ResetPromotionCode();
            self.IsAgree(false);
        };
        //end: apply promotion

        //end: calculate

        // begin: payout limit additional fields
        self.GetStatesByCountryId = function (data) {
            var countryId;
            if (data.SenderIdIssuingCountry() != undefined
                && self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdIssuingCountry())) {
                countryId = data.SenderIdIssuingCountry();
            }
            else if (data.RecipientIdIssuingCountry() != undefined
                && self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdIssuingCountry())) {
                countryId = data.RecipientIdIssuingCountry();
            }

            if (countryId != undefined && (
                    self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdIssuingState()) ||
                    self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdIssuingState()))) {
                $.when(dataModel.GetStatesByCountryId(countryId))
                .done(function (result) {
                    ko.mapping.fromJS(result, {}, self.PayoutLimitAdditionalFields.States);
                });
            }
        }

        function ApplyModalPayoutLimitAdditionalFieldsValidation() {
            self.PayoutLimitAdditionalFields.SenderIdTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdTypeId()); },
                    message: 'Id type is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderIdNumber.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdNumber()); },
                    message: 'Sender id number is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderIdExpiration.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdExpiration()); },
                    message: 'Sender id expiration is required.'
                },
                equal: {
                    onlyIf: function () {
                        if (!self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdExpiration())) {
                            return false;
                        }

                        return !cs.ValidateDate(self.PayoutLimitAdditionalFields.SenderIdExpiration(), "Expiration");
                    },
                    message: 'Invalid date!'
                }
            });
            self.PayoutLimitAdditionalFields.SenderIdIssuingCountry.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdIssuingCountry()); },
                    message: 'Country is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderIdIssuingState.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdIssuingState()); },
                    message: 'State is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderIdDateOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdDateOfBirth()); },
                    message: 'Sender date of birth is required.'
                },
                isValidDate: {
                    params: 'DateOfBirth',
                    message: 'User is required to be at least 18 years of age'
                }
            });
            self.PayoutLimitAdditionalFields.SenderIdCountryOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdCountryOfBirth()); },
                    message: 'Country is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderSSN.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderSSN()); },
                    message: 'Sender ssn is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderOccupation.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderOccupation()); },
                    message: 'Sender occupation is required.'
                }
            });
            self.PayoutLimitAdditionalFields.Relationship.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.Relationship()); },
                    message: 'Relationship with recipient is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SourceOfFunds.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SourceOfFunds()); },
                    message: 'Source of funds is required.'
                }
            });
            self.PayoutLimitAdditionalFields.PurposeOfFunds.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.PurposeOfFunds()); },
                    message: 'Purpose of funds is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdTypeId()); },
                    message: 'Id type is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdNumber.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdNumber()); },
                    message: 'Recipient id number is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdExpiration.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdExpiration()); },
                    message: 'Recipient id expiration is required.'
                },
                equal: {
                    onlyIf: function () {
                        if (!self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdExpiration())) {
                            return false;
                        }

                        return !cs.ValidateDate(self.PayoutLimitAdditionalFields.RecipientIdExpiration(), "Expiration");
                    },
                    message: 'Invalid date!'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdIssuingCountry.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdIssuingCountry()); },
                    message: 'Country is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdIssuingState.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdIssuingState()); },
                    message: 'State is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdDateOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdDateOfBirth()); },
                    message: 'Recipient date of birth is required.'
                },
                isValidDate: {
                    params: 'DateOfBirth',
                    message: 'User is required to be at least 18 years of age'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdCountryOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdCountryOfBirth()); },
                    message: 'Country is required.'
                }
            });

            self.PayoutLimitAdditionalFields.RecipientSSN.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientSSN()); },
                    message: 'Recipient ssn is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientOccupation.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientOccupation()); },
                    message: 'Recipient occupation is required.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientTaxIdentificationTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientTaxIdentificationTypeId()); },
                    message: 'Tax id type is equired.'
                }
            });
            self.PayoutLimitAdditionalFields.RecipientIdCountryOfBirth.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdCountryOfBirth()); },
                    message: 'Country is required.'
                }
            });
            self.PayoutLimitAdditionalFields.SenderTaxIdentificationTypeId.extend({
                required: {
                    onlyIf: function () { return self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderTaxIdentificationTypeId()); },
                    message: 'Tax id type is required.'
                }
            });
        }

        
        function InitModalPayoutLimitAdditionalFields() {
            if (self.PayoutLimitAdditionalFields.SenderIdExpiration() == "01/01/1753") {
                self.PayoutLimitAdditionalFields.SenderIdExpiration("");
            }

            if (self.PayoutLimitAdditionalFields.SenderIdDateOfBirth() == "01/01/1753") {
                self.PayoutLimitAdditionalFields.SenderIdDateOfBirth("");
            }

            if (self.PayoutLimitAdditionalFields.RecipientIdExpiration() == "01/01/1753") {
                self.PayoutLimitAdditionalFields.RecipientIdExpiration("");
            }

            if (self.PayoutLimitAdditionalFields.RecipientIdDateOfBirth() == "01/01/1753") {
                self.PayoutLimitAdditionalFields.RecipientIdDateOfBirth("");
            }

            if (!self.isMobile()) {
                var enterToNext = cs.enterToNext,
                    senderEx = $('#input-sender-expiration'),
                    senderDOB = $('#input-sender-dateofbirth'),
                    recipientEx = $('#input-recipient-expiration'),
                    recipientDOB = $('#input-recipient-dateofbirth');
                senderEx.fdatepicker({
                    appendElement: senderEx.parents()[1],
                    container: senderEx.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });

                senderDOB.fdatepicker({
                    appendElement: senderDOB.parents()[1],
                    container: senderDOB.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });

                recipientEx.fdatepicker({
                    appendElement: recipientEx.parents()[1],
                    container: recipientEx.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });

                recipientDOB.fdatepicker({
                    appendElement: recipientDOB.parents()[1],
                    container: recipientDOB.closest(".reveal-modal"),
                    startDate: new Date('01/01/1920')
                })
                .off("changeDate.moveToNext").on('changeDate.moveToNext', function () {
                    enterToNext.moveToNext(this, enterToNext.findNextElement(this));
                });
            } else {
                cs.addPlaceHolderToDate();
            }

            self.PayoutLimitAdditionalFields.SenderIdTypeId.isModified(false);
            self.PayoutLimitAdditionalFields.SenderIdNumber.isModified(false);
            self.PayoutLimitAdditionalFields.SenderIdExpiration.isModified(false);
            self.PayoutLimitAdditionalFields.SenderIdIssuingCountry.isModified(false);
            self.PayoutLimitAdditionalFields.SenderIdIssuingState.isModified(false);
            self.PayoutLimitAdditionalFields.SenderIdDateOfBirth.isModified(false);
            self.PayoutLimitAdditionalFields.SenderIdCountryOfBirth.isModified(false);
            self.PayoutLimitAdditionalFields.SenderSSN.isModified(false);
            self.PayoutLimitAdditionalFields.SenderOccupation.isModified(false);
            self.PayoutLimitAdditionalFields.Relationship.isModified(false);
            self.PayoutLimitAdditionalFields.SourceOfFunds.isModified(false);
            self.PayoutLimitAdditionalFields.PurposeOfFunds.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdTypeId.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdNumber.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdExpiration.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdIssuingCountry.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdIssuingState.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdDateOfBirth.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdCountryOfBirth.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientSSN.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientOccupation.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientTaxIdentificationTypeId.isModified(false);
            self.PayoutLimitAdditionalFields.RecipientIdCountryOfBirth.isModified(false);
            self.PayoutLimitAdditionalFields.SenderTaxIdentificationTypeId.isModified(false);
        }

        self.IsVisible = function (value) {
            if (value == null) {
                return false;
            }

            return true;
        }

        var additionalDetailStatus = new cs.executeStatus();
        var calculateLimitStatus = new cs.executeStatus();
        self.UpdateAdditionalDetail = function (element) {
            if (additionalDetailStatus.isExecuting()) {
                return;
            }
            additionalDetailStatus.setExecuting();
            self.PayoutLimitAdditionalFields.errors = ko.validation.group(self.PayoutLimitAdditionalFields);
            if (self.isMobile() && self.PayoutLimitAdditionalFields.isValid() ) {
                if (self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdExpiration())) {
                    convertDateInMobile(self.PayoutLimitAdditionalFields.SenderIdExpiration);
                };
                if (self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.SenderIdDateOfBirth())) {
                    convertDateInMobile(self.PayoutLimitAdditionalFields.SenderIdDateOfBirth);
                };
                if (self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdExpiration())) {
                    convertDateInMobile(self.PayoutLimitAdditionalFields.RecipientIdExpiration);
                };
                if (self.IsVisible(self.PayoutLimitAdditionalFields.defaultModel.RecipientIdDateOfBirth())) {
                    convertDateInMobile(self.PayoutLimitAdditionalFields.RecipientIdDateOfBirth);
                };
            };

            if (self.PayoutLimitAdditionalFields.isValid()) {
                cs.AjaxBySpinner({
                    url: '/MoneyTransfer/UpdatePayoutLimitAdditionalFields',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(ko.mapping.toJS(self.PayoutLimitAdditionalFields))
                }, element)
                .done(function (data) {
                    if (data.Caption) {
                        $("#NotificationHead").html(data.Caption);
                        $("#NotificationMessage").html(data.Message);
                        $("#NotificationConfirmOK").unbind('click');
                        $("#NotificationConfirmOK").click(function () {
                            if (calculateLimitStatus.isExecuting()) {
                                return;
                            }
                            calculateLimitStatus.setExecuting();

                            $.when(cs.closeModal())
                            .done(function () {
                                calculateLimitStatus.complete();
                            });
                            CalculateTransactionPayoutLimit(element);
                        });
                        $.when(cs.openModal("modal-notification"))
                        .done(function () {
                            additionalDetailStatus.complete();
                        });
                    }
                    else {
                        $.when(cs.closeModal())
                        .done(function () {
                            additionalDetailStatus.complete();
                        });
                        CalculateTransactionPayoutLimit(element);
                    }
                })
                .fail(function () {
                    additionalDetailStatus.complete();
                });
            }
            else {
                additionalDetailStatus.complete();
                self.PayoutLimitAdditionalFields.errors.showAllMessages();
            }
        };

        function convertDateInMobile(date) {
            if (!date()) return;
            date(date().substr(5, 2) + '/' + date().substr(8, 2) + '/' + date().substr(0, 4));
        };

        function CalculateTransactionPayoutLimit(element) {
            cs.AjaxBySpinner({
                url: '/MoneyTransfer/SelfServiceCalculateTransactionPayoutLimit',
                type: "POST",
                dataType: "json",
                contentType: "application/json"
            }, element, true)
            .done(function (data) {
                var r = ko.mapping.toJS(data);
                ko.mapping.fromJS(r, {}, self);
            })
            .fail(function (xhr, status) {
                var data = $.parseJSON(xhr.responseText);
                if (data.returnCode != null) {
                    var errorCode = parseInt(data.returnCode);
                    if (errorCode == -335 || errorCode == -336) {
                        ko.mapping.fromJS(data.limitAdditionalFields, {}, self.PayoutLimitAdditionalFields);
                    }
                }
                cs.handleAjaxError(xhr.responseText);
            });
        }

        self.CancelUpdateUpdateAdditionalDetail = function () {
            cs.removeDisable("input-amount-to-send");
            cs.removeDisable("input-amount-to-be-dispensed");
            cs.closeModal();
        }

        // end: payout limit additional fields

        //begin: error money transfer limit
        self.MoneyTransfer$CancelCalculateTransactionExceedeLimit = function () {
            ko.mapping.fromJSON(defaultSenderModel, {}, self.SenderModel);
            ko.mapping.fromJSON(defaultCardHolderId, {}, self.CardHolderIdModel);

            $("#expirationDateLimit").val("");
            $("#dateOfBirthLimit").val(self.CardHolderIdModel.IdDateOfBirth());
            cs.closeModal();
        }

        var exceedLimitStatus = new cs.executeStatus();
        self.MoneyTransfer$CalculateTransactionExceedeLimit = function (element) {
            if (exceedLimitStatus.isExecuting()) {
                return;
            }
            exceedLimitStatus.setExecuting();

            self.CardHolderIdModel.errors = ko.validation.group(self.CardHolderIdModel);
            if (self.CardHolderIdModel.isValid()) {
                if (cs.isDisabled("issuingStateLimit")) {
                    self.CardHolderIdModel.IdIssuingState("-1");
                }

                cs.AjaxBySpinner({
                    url: '/MoneyTransfer/SelfServiceCalculateTransactionExceedeLimit',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(ko.mapping.toJS(self))
                }, element, true)
                .done(function (result) {
                    var r = ko.mapping.toJS(result);
                    ko.mapping.fromJS(r, {}, self);
                    $.when(cs.closeModal())
                    .done(function () {
                        exceedLimitStatus.complete();
                    });
                })
                .fail(function (xhr, status) {
                    exceedLimitStatus.complete();
                    if ($.parseJSON(xhr.responseText).Priority != null) {
                        if ($.parseJSON(xhr.responseText).Priority == 1) {
                            ModelSessionTimeOut$RevealAndLogout();
                            return;
                        }
                    }

                    var data = $.parseJSON(xhr.responseText);

                    ko.mapping.fromJSON(defaultSenderModel, {}, self.SenderModel);
                    ko.mapping.fromJSON(defaultCardHolderId, {}, self.CardHolderIdModel);

                    $("#expirationDateLimit").val("");
                    $("#dateOfBirthLimit").val(self.CardHolderIdModel.IdDateOfBirth());

                    if (data.returnCode != null) {
                        var errorCode = parseInt(data.returnCode);
                        alert(errorCode);
                        if (errorCode == -118) {
                            InitModalErrorMoneyTransferLimitFieldsModel();
                            cs.openModal('modal-error-money-transfer-limit');
                        }
                    } else {
                        $("#ErrorCaption").html($.parseJSON(xhr.responseText).Caption);
                        $("#ErrorMessage").html($.parseJSON(xhr.responseText).Message);
                        cs.openModal('modal-error', true, true, true);
                    }
                });

            }
            else {
                exceedLimitStatus.complete();
                self.CardHolderIdModel.errors.showAllMessages();
            }
        }

        self.IdTypeSelectedIndexChanged = function () {
            $("#issuingCountryLimit").val("");
            var idType = self.CardHolderIdModel.IdTypeId();

            if (idType == "" || idType == null || idType == undefined || idType == "-1") {
                //no need to do anything when the id type is not selected yet
                return;
            }

            cs.BaseAjax({
                url: '/MoneyTransfer/GetIDTypeInfo',
                type: "POST",
                contentType: "application/json",
                dataType: "json",
                data: JSON.stringify({ "idTypeId": idType })
            })
            .done(function (result) {
                if (result.DefaultCountryId != null && result.DefaultCountryId != "") {
                    self.CardHolderIdModel.IdIssuingCountry(result.DefaultCountryId);
                    $("#issuingCountryLimit").val(result.DefaultCountryId);
                    cs.addDisable("issuingCountryLimit");
                }
                else {
                    cs.removeDisable("issuingCountryLimit");
                }

                if (result.StateRequired) {
                    cs.removeDisable("issuingCountryLimit");
                    self.GetStatesByIssuingCountryId();
                }
                else {
                    $("#issuingStateLimit").empty();
                    self.CardHolderIdModel.IdIssuingState("");
                    cs.addDisable("issuingCountryLimit");
                }
            });
        }

        function ApplyModalMoneyTransferLimitFieldsValidation() {
            self.CardHolderIdModel.IdDateOfBirth.extend({
                required: {
                    message: 'Date of birth is required'
                },
                pattern: {
                    params: /(\d{2})(\/)(\d{2})\2(\d{4})/,
                    message: 'Date is invalid'
                },
                equal: {
                    onlyIf: function () {
                        return !cs.ValidateDate(self.CardHolderIdModel.IdDateOfBirth(), "DateOfBirth");
                    },
                    message: 'Date is invalid'
                }
            });
            self.CardHolderIdModel.IdTypeId.extend({
                required: {
                    message: 'Id type is required'
                }
            });
            self.CardHolderIdModel.IdNumber.extend({
                required: {
                    message: 'Number is required'
                }
            });

            self.CardHolderIdModel.IdIssuingCountry.extend({
                required: {
                    message: 'Country is required'
                }
            });
            self.CardHolderIdModel.IdExpiration.extend({
                required: {
                    message: 'Expiration is required'
                },
                pattern: {
                    params: /(\d{2})(\/)(\d{2})\2(\d{4})/,
                    message: 'Date is invalid'
                },
                equal: {
                    onlyIf: function () {
                        return !cs.ValidateDate(self.CardHolderIdModel.IdExpiration(), "Expiration");
                    },
                    message: 'Date is invalid'
                }
            });
        }

        //end: error money transfer limit

        //set payment type


        self.FindUpdateCities = function () {
            var isDisplay = false;
            var obj = $(".autocomplete-suggestions");
            for (var i = 0; i < obj.length; i++) {
                if (obj[i].style.display != "none") {
                    isDisplay = true;
                }
            }

            if (isDisplay) {

            } else {
                var cityName = $("#autocomplete-updatepaymenttype-city").val();
                var countryId = self.CountryId();
                var correspondentId = self.PaymentType.Payouts()[0];

                if (cityName == null || cityName == "") {
                    ko.mapping.fromJS(null, {}, self.SenderLookUp.MatchingCities);
                    ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
                } else {
                    GetMatchingCities(countryId, cityName, correspondentId);
                }
            }
        }

        self.ResetTransaction = function () {
            ko.mapping.fromJSON(defaultTransaction, {}, self);

            self.ResetPromotionCode();
        };

        self.InitializeTransaction = function (transaction) {
            var tempTransaction = ko.mapping.toJS(transaction);
            ko.mapping.fromJS(tempTransaction, {}, self);
        };

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.ReceiptNumber(), element);
        };

        self.PrintMoneyTransferReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/MoneyTransfer/SelfServicePrintMoneyTransactionStandardReceipt',
                dataType: "html",
                cache: false
            }, element)
           .done(function (result) {
               cs.PrintTransaction(result, element);
           });
        };

        self.isMobile = function () {
            return cs.IsMobileDevice();
        }
    }
});