﻿define(['knockout', 'ClientScript', 'app', 'ReceiverModel', 'DataModel', 'knockout.validation', 'Plugins'], function (ko, cs, app, ReceiverModel, dataModel) {
    return function SenderModel(data) {
        var self = this;
        var defaultTobeUpdatedReceiver;
        var mapping = {
            'TobeAddedReceiver': {
                create: function (options) {
                    return new ReceiverModel(options.data);
                }
            },
            'TobeUpdatedReceiver': {
                create: function (options) {
                    return new ReceiverModel(options.data);
                }
            }
        };
        ko.mapping.fromJS(data, mapping, self);
        defaultTobeUpdatedReceiver = ko.mapping.toJS(self.TobeUpdatedReceiver);

        //moneytransfer
        self.SortType = ko.observable('sortby');
        self.IsAscending = ko.observable(true);
        self.SortedReceivers = ko.computed(function () {
            var tempReceivers = self.Receivers();
            if (tempReceivers == null || tempReceivers == undefined) {
                return tempReceivers;
            }

            var sortType = self.SortType();
            var isAscending = self.IsAscending();
            if (sortType == 'sortby') {
                return tempReceivers;
            }
            else {
                return tempReceivers.sort(cs.compare(sortType, null, isAscending, 'CardHolderId'));
            }
        });

        // Sort
        self.RecipientSort = function (value, element) {
            if ($(element).find('i').hasClass('entypo-icon-arrow-down')) {
                $(element).find('i').removeClass('entypo-icon-arrow-down');
                $(element).find('i').addClass('entypo-icon-arrow-up');
                var sortby = value;
                self.SortType(sortby);
                self.IsAscending(true);
            } else {
                $(element).find('i').removeClass('entypo-icon-arrow-up');
                $(element).find('i').addClass('entypo-icon-arrow-down');
                var sortby = value;
                self.SortType(sortby);
                self.IsAscending(false);
            }
        }

        var defaultToBeAddedReceiver;
        var defaultToBeAddedPaymentType;
        var defaultToBeAddedBranch;
        defaultToBeAddedReceiver = ko.mapping.toJSON(self.TobeAddedReceiver);
        defaultToBeAddedPaymentType = ko.mapping.toJSON(self.TobeAddedReceiver.PaymentType);
        defaultToBeAddedBranch = ko.mapping.toJSON(self.TobeAddedReceiver.Branch);

        function ResetPaymentType() {
            ko.mapping.fromJS(null, {}, self.SenderLookUp.PaymentTypes);
            ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
            self.TobeAddedReceiver.PaymentTypeSelected(false);
            ko.mapping.fromJSON(defaultToBeAddedPaymentType, {}, self.TobeAddedReceiver.PaymentType);
        }

        function ResetLocation(receiver) {
            ko.mapping.fromJSON(defaultToBeAddedBranch, {}, receiver.Branch);
            ko.mapping.fromJS(null, {}, self.SenderLookUp.MatchingCities);
            ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
            $("#autocomplete-pickup-location-city").val(null);
        }

        function ResetCity() {
            $('#autocomplete-city-names-addrecipient').val("");
            $('#autocomplete-city-names-addrecipient').autocomplete({
                lookup: [],
            });

            $('#autocomplete-moneytransfer-city-names-addrecipient').val("");
            $('#autocomplete-moneytransfer-city-names-addrecipient').autocomplete({
                lookup: [],
            });
        }

        function ResetState() {
            self.TobeAddedReceiver.StateId(null);
        }

        //Add Receiver
        function LogToAddReceiver(tobeAddedReceiver) {
            var message = new Array();

            if (!tobeAddedReceiver.Zipcode.isValid()) {
                message.push("ZipCode: " + tobeAddedReceiver.Zipcode.error);
            }
            if (!tobeAddedReceiver.PhoneNumber.isValid()) {
                message.push("PhoneNumber: " + tobeAddedReceiver.PhoneNumber.error);
            }

            cs.logException("MoneyTransferReceiverPicker", JSON.stringify(message));
        }

        // Initialize Update recipient

        var originalToBeUpdatedReceiver;
        var originalToBeUpdatedPaymentType;
        var originalToBeUpdatedBranch;
        var originalToBeUpdatedShippingInfo;

        self.UpdateCountrySelectIndexChange = function (id) {
            ResetUpdatePaymentType();
            InitializeDestinationStates(id, self.SenderLookUp);
            InitializeDestinationCities(self.TobeUpdatedReceiver.StateId(), id);
        }

        function InitializeUpdateReceiver(countries) {
            originalToBeUpdatedReceiver = ko.mapping.toJSON(self.TobeUpdatedReceiver);

            return cs.BaseAjax({
                url: '/MoneyTransfer/InitializeUpdateReceiver',
                type: "Get",
                cache: false,
                dataType: "json",
                contentType: "application/json",
                data: { "receiverCardHolderId": self.TobeUpdatedReceiver.CardHolderId() }
            })
            .done(function (data) {
                //$("#input-moneytransfer-receiverpicker-updatedetails").removeClass('now-loading');
                var tempReceiver = ko.mapping.toJS(data);
                ko.mapping.fromJS(tempReceiver, {}, self.TobeUpdatedReceiver);

                originalToBeUpdatedBranch = ko.mapping.toJSON(self.TobeUpdatedReceiver.Branch);
                originalToBeUpdatedPaymentType = ko.mapping.toJSON(self.TobeUpdatedReceiver.PaymentType);
                originalToBeUpdatedShippingInfo = ko.mapping.toJSON(self.TobeUpdatedReceiver.ShippingInfo);

                if (countries.length > 0) {
                    var countryId = countries[0].Value;
                    for (var i = 0; i < countries.length; i++) {
                        if (countries[i].Value == self.TobeUpdatedReceiver.CountryId()) {
                            countryId = countries[i].Value;
                            break;
                        }
                    }
                    ko.mapping.fromJS(countryId, {}, self.TobeUpdatedReceiver.CountryId);
                    self.UpdateCountrySelectIndexChange(countryId);
                }

                //$("#autocomplete-updatepaymenttype-city").val(sender.TobeUpdatedReceiver.City());
                //cs.openModal('modal-update-recipient', true, true);
                $('.panel-flow.my-money-transfer').trigger('owl.next');
            });
        }

        function ResetUpdatePaymentType() {
            ko.mapping.fromJS(null, {}, self.SenderLookUp.PaymentTypes);
            ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
            ko.mapping.fromJSON(originalToBeUpdatedPaymentType, {}, self.TobeUpdatedReceiver.PaymentType);
            ResetUpdateLocation();
        }

        var cities;
        var orginalCityForUpdate = "";
        function InitializeDestinationCities(stateId, id) {
            return $.when(dataModel.GetCitiesByStateId(id, stateId))
            .done(function (data) {
                cities = data;
                var cityEle = $('#autocomplete-city-names-updaterecipient');
                if (showDefaultCity) {
                    cityEle.val(self.TobeUpdatedReceiver.City());
                    showDefaultCity = false;
                } else {
                    cityEle.val("");
                }
                cityEle.autocomplete({
                    lookup: data,
                    triggerSelectOnValidInput: true,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        if (suggestion.value != orginalCityForUpdate) {
                            orginalCityForUpdate = suggestion.value;
                            self.TobeUpdatedReceiver.City(suggestion.value);
                            self.TobeUpdatedReceiver.CityId(suggestion.data.Value);
                            self.TobeUpdatedReceiver.CityValidateType(0);
                            GetCorrespondentsBySelectedRecipientCity();
                        }
                    },
                    lookupFilter: function (k, j, l) {
                        var inputValue = (cs.removeDiacritics(l).toLowerCase());
                        return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1
                    },
                    onInvalidateSelection: function () {
                        if (cityEle.val() == "" || cityEle.val() != orginalCityForUpdate) {
                            orginalCityForUpdate = cityEle.val();
                            self.TobeUpdatedReceiver.City(cityEle.val());
                            ResetUpdateCorrespondent();
                        }
                    }
                });

                cityEle.off("blur.city.addrecipient");
                cityEle.on("blur.city.addrecipient", function () {
                    if (cityEle.val() == "" || cityEle.val() != orginalCityForUpdate) {
                        ResetUpdateCorrespondent();
                    }
                });
            });
        }

        function ResetUpdateCorrespondent() {
            self.TobeUpdatedReceiver.CityId("");
            if (self.TobeUpdatedReceiver.LocationPickupType() == 2) {
                if (!self.TobeUpdatedReceiver.SelectedDestination.PaymentType.SearchCityOutSideCities()) {
                    ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
                    self.TobeUpdatedReceiver.ShouldShowLocation(false);
                    $("#location-store-error-message").hide();
                    $("#correspondent-error-message").hide();
                    $('#payment-types').hide();
                }
            } else if (self.TobeUpdatedReceiver.LocationPickupType() == 1) {
                if (!self.TobeUpdatedReceiver.PaymentType.SearchCityOutSideCities()) {
                    ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
                    self.TobeUpdatedReceiver.ShouldShowLocation(false);
                    $("#location-store-error-message").hide();
                    $("#correspondent-error-message").hide();
                    $('#payment-types').hide();
                }
            }
        }

        function GetCorrespondentsBySelectedRecipientCity() {
            if (self.TobeUpdatedReceiver.LocationPickupType() == 2) {
                if (!self.TobeUpdatedReceiver.SelectedDestination.PaymentType.SearchCityOutSideCities()) {
                    self.SearchCityChanged(self.TobeUpdatedReceiver, self.TobeUpdatedReceiver.SelectedDestination.PaymentType.SearchCityOutSideCities(), self.TobeUpdatedReceiver.SelectedDestination);
                }
            } else if (self.TobeUpdatedReceiver.LocationPickupType() == 1) {
                if (!self.TobeUpdatedReceiver.PaymentType.SearchCityOutSideCities()) {
                    ResetUpdatePaymentType();
                    self.SearchCityChanged(self.TobeUpdatedReceiver, self.TobeUpdatedReceiver.PaymentType.SearchCityOutSideCities(), null);
                }
            }
        }

        function ResetUpdateLocation() {
            ko.mapping.fromJS(null, {}, self.SenderLookUp.MatchingCities);
            ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
            ko.mapping.fromJSON(originalToBeUpdatedBranch, {}, self.TobeUpdatedReceiver.Branch);
            $("#autocomplete-updatepaymenttype-city").val(null);
        }

        self.GetSelected = function (element, receiver) {
            var tempReceiver = ko.mapping.toJS(receiver);
            self.SetReceiversSelected(tempReceiver);
            ko.mapping.fromJS(tempReceiver, {}, self.TobeUpdatedReceiver);
        }

        self.SetReceiversSelected = function (receiver) {
            var tempReceiver = ko.mapping.toJS(receiver);
            if (self.Receivers() != null) {
                for (var i = 0; i < self.Receivers().length; i++) {
                    self.Receivers()[i].Selected(self.Receivers()[i].CardHolderId() == tempReceiver.CardHolderId);
                }
            }
        }

        //BackToReceiver
        self.BackToReceiver = function () {
            if (self.TobeUpdatedReceiver.IsQuickToPay) {
                app.navigateToCustomerDashboardByLoading();
            } else {
                app.moneytransferconsumer().FlowPrev();
            }
        };

        self.AddCountrySelectIndexChange = function (id) {
            ResetPaymentType();
            ResetLocation(self.TobeAddedReceiver);
            ResetCity();
            GetCountryImage(id);
            InitializeDestinationStates(id, self.SenderLookUp);
            ResetState();
            ResetPickupLocation(self.TobeAddedReceiver);
        }

        self.ResetPaymentForAddReceiverContryChanged = function (id) {
            if (!id) {
                ko.mapping.fromJS([], {}, self.SenderLookUp.DestinationStates);
                return;
            }

            ResetPaymentType();
            ResetLocation(self.TobeAddedReceiver);
            ResetState();
            //GetCountryImage(id);
            InitializeDestinationStates(id, self.SenderLookUp);
            ResetCity();
            ResetPickupLocation(self.TobeAddedReceiver);
            RestAreaCodeForAddReceiver(id);

            var currencyId = 0;
            for (var i = 0; i < self.SenderLookUp.DestinationCountries().length ; i++) {
                if (self.TobeAddedReceiver.CountryId() == self.SenderLookUp.DestinationCountries()[i].Value()) {
                    currencyId = self.SenderLookUp.DestinationCountries()[i].CurrencyId();
                    self.TobeAddedReceiver.ToCurrencyId(currencyId);
                    break;
                }
            }

            if (self.TobeAddedReceiver.BankAccountPickupType() != 0) {
                self.TobeAddedReceiver.InitializeAddBankAccountDeposit($("#autocomplete-bank-names"));
                self.SearchBankAccountCorrespondents("button-bank-account-deposit", self.TobeAddedReceiver, "autocomplete-bank-names");
            }

            // Reset bank account diposit.
            if ($('#panel_bank1').hasClass('active')) {
                $('a[href=#panel_bank1]').click();
            }

            // Reset pick up location.
            self.TobeAddedReceiver.CityId();
            if ($('#panel_cash1').hasClass('active')) {
                $('a[href=#panel_cash1]').click();
            }
        }

        self.ResetPaymentForAddReceiverContryChangedForMoneyTransfer = function (id) {
            if (!id) {
                ko.mapping.fromJS([], {}, self.SenderLookUp.DestinationStates);
                return;
            }

            ResetPaymentType();
            ResetLocation(self.TobeAddedReceiver);
            RestAreaCodeForAddReceiver(id);
            ResetState();
            //GetCountryImage(id);
            InitializeDestinationStates(id, self.SenderLookUp);
            ResetCity();
            RestAreaCodeForAddReceiver(id);
        }

        function RestAreaCodeForAddReceiver(countryId) {
            if (!countryId || !self.SenderLookUp.DestinationCountries) {
                self.TobeAddedReceiver.AreaCode("");
                return;
            }

            var countries = ko.mapping.toJS(self.SenderLookUp.DestinationCountries);

            if (!countries || countries.length == 0) {
                return;
            }

            for (var i = 0; i < countries.length; i++) {
                var country = countries[i];
                if (country.Value == countryId.toString()) {
                    self.TobeAddedReceiver.AreaCode(country.Code);
                    break;
                }
            }

            self.TobeAddedReceiver.AddPhoneNumberBlur($("#input-home-phone"));
        }

        function GetCountryImage(countryId) {
            return cs.BaseAjax(
       {
           url: '/MoneyTransfer/GetCountryImage',
           type: "Post",
           dataType: "json",
           contentType: "application/json",
           data: JSON.stringify({ "countryId": countryId })
       })
       .done(function (data) {
           ko.mapping.fromJS(data, {}, self.TobeAddedReceiver.CountryImage);
       })
        }

        function InitializeDestinationStates(countryId, model) {
            $.when(dataModel.GetStatesByCountryId(countryId))
        .done(function (data) {
            var states = ko.mapping.toJS(data);
            ko.mapping.fromJS(states, {}, model.DestinationStates);
        })
        }

        function resetUpdateReceiver() {
            ko.mapping.fromJSON(originalToBeUpdatedReceiver, {}, self.TobeUpdatedReceiver);
            self.TobeUpdatedReceiver.EditRecipientFlag(false);

            cs.closeModalCallBack('modal-recipient-edit', function () {
                self.TobeUpdatedReceiver.EditRecipientFlag(false);
            });
        };

        var showDefaultCity = false;
        var editReceiverStatus = new cs.executeStatus();
        self.GetSelectedReceiverToEdit = function (receiver) {
            if (editReceiverStatus.isExecuting()) {
                return;
            }
            resetUpdateReceiver();

            editReceiverStatus.setExecuting();
            try {
                self.TobeUpdatedReceiver.EditRecipientFlag(true);
                $("input[name=account-select-edit]").val("0");
                $("input[name=account-select-edit]").attr("checked", false);
                $("input[name=pickup-select-edit]").val("0");
                $("input[name=pickup-select-edit]").attr("checked", false);
                $("#bank-account-detail-new").addClass("hide");
                $("#bank-account-detail-old").addClass("hide");
                $("#pickup-location-detail-old").addClass("hide");
                $('#account-edit-new').attr("checked", false);
                $('#location-edit-new').attr("checked", false);

                $("#autocomplete-bank-names-new").val("");
                $('#autocomplete-bank-names-new').autocomplete({
                    lookup: new Array()
                });
                bankAccounts = null;

                locations = null;
                $("#autocomplete-correspondent-names-new").val("");
                $('#autocomplete-correspondent-names-new').autocomplete({
                    lookup: new Array()
                });
                $("#autocomplete-correspondent-names-new").error(false, '');
                $("#autocomplete-city-names-new").error(false, '');
                $('#autocomplete-city-names-new').autocomplete({
                    lookup: new Array()
                });
                $.when(InitializeDestinationStates(receiver.CountryId(), self.SenderLookUp))
                .done(function () {
                    var tempReceiver = ko.mapping.toJS(receiver);
                    ko.mapping.fromJS(tempReceiver, {}, self.TobeUpdatedReceiver);
                    $.when(self.TobeUpdatedReceiver.GetRecipientDestinationsForManagement())
                       .done(function () {
                           $.when(InitializeDestinationCities(receiver.StateId(), receiver.CountryId()))
                           .done(function () {
                               FormatPhoneNumberForEdit(self.TobeUpdatedReceiver);
                               self.TobeUpdatedReceiver.NewBankAccount.PaymentType.AccountNumber.isModified(false);
                               self.TobeUpdatedReceiver.NewBankAccount.PaymentType.ConfirmAccountNumber.isModified(false);
                               originalToBeUpdatedReceiver = ko.mapping.toJSON(self.TobeUpdatedReceiver);
                               originalToBeUpdatedBranch = ko.mapping.toJSON(self.TobeUpdatedReceiver.Branch);
                               originalToBeUpdatedPaymentType = ko.mapping.toJSON(self.TobeUpdatedReceiver.PaymentType);
                               showDefaultCity = true;

                               self.TobeUpdatedReceiver.NewPickupLocation.Location.StateId("");
                               self.TobeUpdatedReceiver.NewPickupLocation.Location.StateId.isModified(false);
                               self.TobeUpdatedReceiver.CityValidateType(0);

                               if (self.TobeUpdatedReceiver.CellPhoneNumber() != "" && self.TobeUpdatedReceiver.CellPhoneNumber() != null) {
                                   $("#input-phone-type").val("1");
                                   self.TobeUpdatedReceiver.PhoneType(1);

                               }
                               else if (self.TobeUpdatedReceiver.HomePhoneNumber() != "" && self.TobeUpdatedReceiver.HomePhoneNumber() != null) {
                                   $("#input-phone-type").val("2");
                                   self.TobeUpdatedReceiver.PhoneType(2);
                               }

                               $("#autocomplete-city-names-updaterecipient").val(self.TobeUpdatedReceiver.City());
                               orginalCityForUpdate = self.TobeUpdatedReceiver.City();
                               $.when(cs.openModal("modal-recipient-edit"))
                               .done(function () {
                                   editReceiverStatus.complete();
                               });
                           })
                               .fail(function () {
                                   editReceiverStatus.complete();
                               });
                       })
                    .fail(function () {
                        editReceiverStatus.complete();
                    });
                })
                .fail(function () {
                    editReceiverStatus.complete();
                });
            } catch (e) {
                editReceiverStatus.complete();
            }
        };

        function FormatPhoneNumberForEdit(receiver) {
            if (!(receiver.PhoneNumber())) {
                return;
            }


            receiver.PhoneNumber(receiver.GetFormatPhoneNumber(receiver.PhoneNumber()));
            receiver.PhoneNumber.isModified(false);
        };

        function RemoveFormatPhoneNumberForEdit(receiver) {
            receiver.PhoneNumber(receiver.GetRemoveFormatPhoneNumber(receiver.PhoneNumber()));
        };

        // TODO delete receiver
        var removeReceiverStatus = new cs.executeStatus();
        self.ConfirmToRemove = function (receiver) {
            ko.mapping.fromJS(receiver, {}, self.TobeUpdatedReceiver);

            $("#ConfirmToRemove").unbind('click');
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove receiver
                cs.AddActivityInfo(19);

                if (removeReceiverStatus.isExecuting()) {
                    return;
                }

                if (cs.isDisabled("#ConfirmToRemove")) {
                    return;
                }

                removeReceiverStatus.setExecuting();
                $.when(RemoveReceiver("#ConfirmToRemove"))
                .done(function () {
                    $.when(cs.closeModal())
                    .done(function () { 
                        removeReceiverStatus.complete();
                    })
                })
                .fail(function () {
                    removeReceiverStatus.complete();
                });
            });
            cs.openModal('modal-remove', true, true, true);
        }

        function RemoveReceiver(element) {
            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/DeleteReceiver',
                contentType: "application/json",
                type: "Get",
                cache: false,
                data: { "cardHolderId": self.TobeUpdatedReceiver.CardHolderId() }
            }, element)
       .done(function () {
           var receivers = self.Receivers();
           for (var i = 0; i < receivers.length; i++) {
               if (receivers[i].CardHolderId() == self.TobeUpdatedReceiver.CardHolderId()) {
                   receivers.splice(i, 1);
               }
           }
           ko.mapping.fromJS(receivers, {}, self.Receivers);
       })
        }

        // begin: Add Receiver
        self.ResetToBeAddedReceiver = function () {
            ko.mapping.fromJSON(defaultToBeAddedReceiver, {}, self.TobeAddedReceiver);
            self.TobeAddedReceiver.PhoneType("0");
            self.TobeAddedReceiver.PhoneType.isModified(false);
            self.TobeAddedReceiver.RelationShipId.isModified(false);
            self.TobeAddedReceiver.CountryId("");
        }

        // end: Add Receiver
        // begin: Add Payment Type
        self.CancelAddPaymentType = function () {
            ResetPaymentType();
            cs.closeModal(true);
        }

        // end: Add Payment Type 

        //begin: Add Destination for receiver

        self.InitializePickUpLocationStates = function (countryId) {
            return $.when(InitializeDestinationStates(countryId, self.SenderLookUp));
        };

        self.SelfServiceSearchCorrespondent = function (receiver) {
            var countryId = receiver.CountryId();
            var stateName = receiver.NewPickupLocation.Location.State();
            var city = receiver.NewPickupLocation.Location.City();
            if (city != "" && city != null) {
                cs.BaseAjax(
              {
                  url: '/MoneyTransfer/GetCorrespondentsForPickupLocation',
                  type: "Post",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({ "countryId": countryId, "stateName": stateName, "city": city })
              })
              .done(function (data) {
                  // Delete this after finished search correspondent.
                  var result = new Array();
                  for (var i = 0; i < data.length; i++) {
                      if ((data[i].PaymentTypeId == 2 || data[i].PaymentTypeId == 3 || data[i].PaymentTypeId == 6) && data[i].CurrencyId == data[i].CountryId) {
                          result.push(data[i]);
                      }
                  }
                  // End
                  var tempCorrespondents = $.map(ko.mapping.toJS(result), function (item, index) { return { value: item.Correspondent, data: item }; });
                  tempCorrespondents.sort(function (x, y) {
                      return cs.sortByString(x.value, y.value, true);
                  });
                  $('#autocomplete-correspondent-names').autocomplete({
                      lookup: tempCorrespondents,
                      triggerSelectOnValidInput: true,
                      minChars: 0,
                      onSelect: function (suggestion) {
                          ko.mapping.fromJS(suggestion.data, {}, receiver.NewPickupLocation.PaymentType);
                          SelfServiceGetLocations();
                      }
                  });
              });
            }
        }

        function SelfServiceGetLocations(receiver) {
            var countryId = receiver.CountryId();
            var transactionType = 14;
            var city = {
                CorrespondentId: receiver.NewPickupLocation.PaymentType.Payouts()[0],
                CityName: receiver.NewPickupLocation.Location.City(),
                StateName: receiver.NewPickupLocation.Location.State(),
                ItemCount: 0
            }
            $("#loading-icon").css({ "display": "block", "margin-top": "0.6rem" });
            $("#search-icon").fadeOut();
            $("#loading-icon").fadeIn();

            cs.BaseAjax({
                url: '/MoneyTransfer/GetLocations',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": countryId, "matchingCity": city, "transactionTypeId": transactionType })
            })
            .done(function (data) {
                // TODO
                //var stores = ko.mapping.toJS(data);
                //ko.mapping.fromJS(stores, {}, self.SenderLookUp.LocationStores);
                $("#search-icon").fadeIn();
                $("#loading-icon").fadeOut();
                var tempAddresses = new Array();
                for (var i = 0; i < data.length; i++) {
                    tempAddresses.push(data[i].Address);
                }

                var locations = $.map(ko.mapping.toJS(data), function (item, index) { return { value: item.Address, data: item }; });;
                locations.sort(function (x, y) {
                    return cs.sortByString(x.value, y.value, true);
                });
                $('#input-address-01-new').autocomplete({
                    lookup: locations,
                    triggerSelectOnValidInput: true,
                    minChars: 0,
                    onSelect: function (suggestion) {
                        receiver.NewPickupLocation.Location.Zipcode(suggestion.data.Zipcode);
                        receiver.NewPickupLocation.Location.Branch.BranchCode(suggestion.data.Branch.BranchCode);
                        receiver.NewPickupLocation.Location.Branch.BranchName(suggestion.data.Branch.BranchName);
                    }
                });
            }).fail(function (xhr, status) {
                $("#search-icon").fadeIn();
                $("#loading-icon").fadeOut();
            });
        }

        self.GetBankAccountCorrespondents = function (countryId, currencyId) {
            return GetCorrespondentsByPaymentTypeIds(countryId, [1], currencyId);
        }

        function GetCorrespondentsByPaymentTypeIds(countryId, paymentTypeIdArray, currencyId) {
            var deferred = $.Deferred();
            $.when(dataModel.GetPaymentTypes(countryId))
            .done(function (result) {
                var tempResult = new Array();
                for (var i = 0; i < result.length; i++) {
                    if (result[i].CurrencyId == currencyId) {
                        tempResult.push(result[i]);
                    }
                }

                var paymentTypes = ko.mapping.toJS(tempResult);
                ko.mapping.fromJS(paymentTypes, {}, self.SenderLookUp.PaymentTypes);
                var tempPaymentTypes = new Array();
                for (var i = 0; i < self.SenderLookUp.PaymentTypes().length; i++) {
                    if (paymentTypeIdArray.indexOf(self.SenderLookUp.PaymentTypes()[i].PaymentTypeId()) != -1 && self.SenderLookUp.PaymentTypes()[i].Correspondent() != "") {
                        tempPaymentTypes.push(self.SenderLookUp.PaymentTypes()[i]);
                    }
                }

                deferred.resolve(tempPaymentTypes);
            });

            return deferred;
        };

        self.GetHomeDeliveryCorrespondents = function (countryId, currencyId) {
            return GetCorrespondentsByPaymentTypeIds(countryId, [4], currencyId);
        }
        // end: Add Destination for receiver

        // begin: Load Payment Type for add recipient.
        function GetPaymentTypeFromCache(countryId, currencyId) {
            try {
                if (sessionStorage && sessionStorage.CachePaymentTypes) {
                    var paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypes);
                    if (paymentTypesCache) {
                        for (var i = 0; i < paymentTypesCache.length; i++) {
                            if (paymentTypesCache[i].CountryId == countryId && paymentTypesCache[i].CurrencyId == currencyId) {
                                if (paymentTypesCache[i].PaymentTypes.length == 0) {
                                    return null;
                                }
                                return paymentTypesCache[i].PaymentTypes;
                            }
                        }
                    }
                }
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypes');
            }

            return null;
        };

        function addPaymentTypesToCache(countryId, currencyId, paymentTypes) {
            try {
                var paymentTypesCache;
                if (!sessionStorage) {
                    return;
                }

                if (sessionStorage && sessionStorage.CachePaymentTypes) {
                    paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypes);
                } else {
                    paymentTypesCache = new Array();
                }

                paymentTypesCache.push({
                    CountryId: countryId,
                    CurrencyId: currencyId,
                    PaymentTypes: paymentTypes
                });

                cs.SetSessionStorage('CachePaymentTypes', JSON.stringify(paymentTypesCache));
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypes');
            }
        }

        self.LoadPayments = function (element, countryId, currencyId) {
            var cachePaymentType = GetPaymentTypeFromCache(countryId, currencyId);
            if (cachePaymentType) {
                ko.mapping.fromJS(cachePaymentType, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
                if (!(self.SenderLookUp.PickUpLocationPaymentTypes() && self.SenderLookUp.PickUpLocationPaymentTypes().length > 0)) {
                    $('#correspondents-note').show();
                }
                $('#payment-types').hide();
                return;
            }
            $('#payment-types').show();
            $('#correspondents-note').hide();
            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/SelfServiceGetPayments',
                type: "Get",
                cache: false,
                dataType: "json",
                data: { "countryId": countryId }
            }, element)
        .done(function (result) {
            var tempPaymentTypes = new Array();
            for (var i = 0; i < result.length; i++) {
                if (result[i].CurrencyId == currencyId && [2, 3, 6].indexOf(result[i].PaymentTypeId) != -1) {
                    tempPaymentTypes.push(result[i]);
                }
            }

            var paymentTypes = ko.mapping.toJS(tempPaymentTypes);
            ko.mapping.fromJS(paymentTypes, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
            if (!(self.SenderLookUp.PickUpLocationPaymentTypes() && self.SenderLookUp.PickUpLocationPaymentTypes().length > 0)) {
                $('#correspondents-note').show();
            }
            addPaymentTypesToCache(countryId, currencyId, paymentTypes);
        })
         .fail(function () {
             $('#correspondents-note').show();
         })
            .always(function () {
                $('#payment-types').hide();
            });
        }

        function GetPaymentTypesByCityFromCache(countryId, currencyId, city) {
            try {
                if (sessionStorage && sessionStorage.CachePaymentTypesByCity) {
                    var paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypesByCity);
                    if (paymentTypesCache) {
                        for (var i = 0; i < paymentTypesCache.length; i++) {
                            if (paymentTypesCache[i].CountryId == countryId && paymentTypesCache[i].CurrencyId == currencyId && paymentTypesCache[i].City == city) {
                                if (paymentTypesCache[i].PaymentTypes.length == 0) {
                                    return null;
                                }
                                return paymentTypesCache[i].PaymentTypes;
                            }
                        }
                    }
                }
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypesByCity');
            }

            return null;
        };

        function addPaymentTypesByCityToCache(countryId, currencyId, city, paymentTypes) {
            try {
                var paymentTypesCache;
                if (!sessionStorage) {
                    return;
                }

                if (sessionStorage && sessionStorage.CachePaymentTypesByCity) {
                    paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypesByCity);
                } else {
                    paymentTypesCache = new Array();
                }

                paymentTypesCache.push({
                    CountryId: countryId,
                    CurrencyId: currencyId,
                    City: city,
                    PaymentTypes: paymentTypes
                });

                cs.SetSessionStorage('CachePaymentTypesByCity', JSON.stringify(paymentTypesCache));
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypesByCity');
            }
        }

        self.GetPaymentsByCity = function (receiver, cityName, currencyId, searchCityOutSideCities) {
            var cachePaymentType = GetPaymentTypesByCityFromCache(receiver.CountryId(), currencyId, cityName);
            if (cachePaymentType) {
                ko.mapping.fromJS(cachePaymentType, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
                if (!(self.SenderLookUp.PickUpLocationPaymentTypes() && self.SenderLookUp.PickUpLocationPaymentTypes().length > 0)) {
                    $('#correspondents-note').show();
                }
                $('#payment-types').hide();
                return;
            }
            $('#payment-types').show();
            $('#correspondents-note').hide();
            return $.ajax({
                url: "/MoneyTransfer/GetSelfServicePaymentDestinationsByCity",
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                    "countryId": receiver.CountryId(),
                    "paymentTypeId": -1,
                    "currency": -1,
                    "state": receiver.StateId(),
                    "city": receiver.CityId(),
                    "cityName": cityName
                })
            })
               .success(function (result) {
                   var tempPaymentTypes = new Array();
                   for (var i = 0; i < result.length; i++) {
                       if (result[i].CurrencyId == currencyId && [2, 3, 6].indexOf(result[i].PaymentTypeId) != -1) {
                           tempPaymentTypes.push(result[i]);
                       }
                   }

                   var paymentTypes = ko.mapping.toJS(tempPaymentTypes);
                   ko.mapping.fromJS(paymentTypes, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
                   if (!(self.SenderLookUp.PickUpLocationPaymentTypes() && self.SenderLookUp.PickUpLocationPaymentTypes().length > 0)) {
                       $('#correspondents-note').show();
                   }
                   addPaymentTypesByCityToCache(receiver.CountryId(), currencyId, cityName, paymentTypes);
               })
               .fail(function () {
                   $('#correspondents-note').show();
               })
               .always(function () {
                   $('#payment-types').hide();
               });
        }

        self.GetCitiesByStateIdForAddReceiver = function (element) { //using now
            var stateId = element.value;
            self.TobeAddedReceiver.City("");
            ResetAddCorrespondent();
            self.TobeAddedReceiver.StateId.isModified(false);
            if (!stateId) {
                return;
            }
            var countryId = self.TobeAddedReceiver.CountryId();
            return $.when(dataModel.GetCitiesByStateId(countryId, stateId))
                .done(function (result) {
                    self.TobeAddedReceiver.cities = result;
                    var cityEle = $("#autocomplete-city-names-addrecipient:visible");
                    var mtCityEle = $("#autocomplete-moneytransfer-city-names-addrecipient:visible");

                    if (cityEle.length > 0) {
                        AutoCompleteCitys(cityEle, result);
                        cityEle.trigger('focus');
                    }

                    if (mtCityEle.length > 0) {
                        AutoCompleteCitys(mtCityEle, result);
                        mtCityEle.trigger("focus");
                    }
                })
        }

        // begin: delivery option
        var orginalCityForAdd = "";
        function AutoCompleteCitys(element, lookup) {// using now
            orginalCityForAdd = "";
            $(element).val("");
            var manageNewRecipient = ($(element).attr('id') == 'autocomplete-city-names-addrecipient');
            $(element).autocomplete({
                lookup: lookup,
                triggerSelectOnValidInput: false,
                minChars: 1,
                onSelect: function (suggestion) {
                    if (suggestion.value != orginalCityForAdd) {
                        orginalCityForAdd = suggestion.value;
                        self.TobeAddedReceiver.City(suggestion.value);
                        self.TobeAddedReceiver.CityId(suggestion.data.Value);
                        self.TobeAddedReceiver.CityValidateType(0);
                        if (!self.TobeAddedReceiver.PaymentType.SearchCityOutSideCities() && manageNewRecipient) {
                            ResetPaymentType();
                            self.SearchCityChanged(self.TobeAddedReceiver, self.TobeAddedReceiver.PaymentType.SearchCityOutSideCities(), null);
                        } 
                    }
                },
                lookupFilter: function (k, j, l) {
                    var inputValue = (cs.removeDiacritics(l).toLowerCase());
                    return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1
                },
                onInvalidateSelection: function () {
                    if ($(element).val() == "" || $(element).val() != orginalCityForAdd) {
                        orginalCityForAdd = $(element).val();
                        self.TobeAddedReceiver.City($(element).val());
                        ResetAddCorrespondent();
                    }
                }
            });

            $(element).off('input.city.updaterecipient');
            $(element).on('input.city.updaterecipient', function () {
                var value = $(this).val();

                if (value == "") {
                    self.TobeAddedReceiver.CityValidateType(1);
                }
                else if (cs.isMatchSuggestion($(element).autocomplete().suggestions, value, false) > -1) {
                    self.TobeAddedReceiver.CityValidateType(0);
                    return;
                }
                else {
                    self.TobeAddedReceiver.CityValidateType(2);
                }

                ResetAddCorrespondent();
            });

            $(element).off("blur.city.updaterecipient");
            $(element).on("blur.city.updaterecipient", function () {
                if ($('.autocomplete-selected').length > 0) return;

                var matchedIndex = -1;
                var value = $(this).val();

                if (value == "") {
                    self.TobeAddedReceiver.CityValidateType(1);
                }
                else if ($(element).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(element).autocomplete().suggestions, value, true)) > -1) {
                    self.TobeAddedReceiver.CityValidateType(0);
                    $(element).autocomplete().select(matchedIndex);
                    return;
                }
                else {
                    self.TobeAddedReceiver.CityValidateType(2);
                }
            });
        }

        function ResetAddCorrespondent() {
            self.TobeAddedReceiver.CityId("");
            if (!self.TobeAddedReceiver.PaymentType.SearchCityOutSideCities()) {
                self.TobeAddedReceiver.ShouldShowLocation(false);
                $("#location-store-error-message").hide();
                $("#correspondent-error-message").hide();
                ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
                $('#payment-types').hide();
            }
        }

        function getPickUpLocationCitiesFromCache(countryId) {
            try {
                if (sessionStorage && sessionStorage.CachePickUpLocationCities) {
                    var Cities = JSON.parse(sessionStorage.CachePickUpLocationCities);
                    if (Cities) {
                        for (var i = 0; i < Cities.length; i++) {
                            if (Cities[i].CountryId == countryId) {
                                return Cities[i].Cities;
                            }
                        }
                    }
                }
            } catch (e) {
                sessionStorage.removeItem('CachePickUpLocationCities');
            }

            return null;
        };

        function addPickUpLocationCitiesToCache(countryId, cities) {
            try {
                if (!sessionStorage) {
                    return;
                }

                var citiesCache;
                if (sessionStorage && sessionStorage.CachePickUpLocationCities) {
                    citiesCache = JSON.parse(sessionStorage.CachePickUpLocationCities);
                } else {
                    citiesCache = new Array();
                }

                citiesCache.push({
                    CountryId: countryId,
                    Cities: cities
                });

                cs.SetSessionStorage('CachePickUpLocationCities', JSON.stringify(citiesCache));
            } catch (e) {
                sessionStorage.removeItem('CachePickUpLocationCities');
            }
        }

        function GetPickUpLocationCities(countryId, element) {
            var cities = getPickUpLocationCitiesFromCache(countryId, element);
            if (cities) {
                return $.Deferred().resolve(cities);
            }

            return $.when(dataModel.GetLookUpCitiesByCountryId(countryId, element))
            .done(function (cities) {
                addPickUpLocationCitiesToCache(countryId, cities);
            });
        }

        var tempCity = "";
        var locationCities;
        function InitializePickUpLocationCities(receiver, element, clearCity) {
            if(!clearCity){
                tempCity = "";
            }
            return $.when(GetPickUpLocationCities(receiver.CountryId(), element))
             .done(function (cities) {
                 locationCities = cities;
                 $("#autocomplete-pickup-location-city").autocomplete({
                     lookup: cities,
                     triggerSelectOnValidInput: true,
                     minChars: 1,
                     onSelect: function (suggestion) {
                         var cityName = suggestion.value;
                         if (cityName != tempCity) {
                             tempCity = cityName;
                             var countryId = receiver.CountryId();
                             var correspondentId = receiver.PaymentType.Payouts()[0];

                             GetPaymentTypeLocationsByCityId(receiver.CountryId(), suggestion.data, cityName, receiver.PaymentType);
                         }
                     },
                     onInvalidateSelection: function () {
                         if ($("#autocomplete-pickup-location-city").val() == "" || $("#autocomplete-pickup-location-city").val() != tempCity) {
                             tempCity = $("#autocomplete-pickup-location-city").val();
                             ko.mapping.fromJS(null, {}, self.SenderLookUp.MatchingCities);
                             ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
                             $("#location-stores").hide();
                             receiver.Branch.BranchName(null);
                         }
                     }
                 });

                 $("#autocomplete-pickup-location-city").off("blur.pickup.location");
                 $("#autocomplete-pickup-location-city").on("blur.pickup.location", function () {
                     if ($("#autocomplete-pickup-location-city").val() == "" || $("#autocomplete-pickup-location-city").val() != tempCity) {
                         ko.mapping.fromJS(null, {}, self.SenderLookUp.MatchingCities);
                         ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
                         $("#location-stores").hide();
                         receiver.Branch.BranchName(null);
                     }
                 });
             });
        }

        self.SearchCityChangedForNew = function (receiver, location, element) {
            var checkBoxChecked = $(element).is(":checked");
            ResetPaymentType();
            ResetUpdatePaymentType();
            receiver.PaymentType.SearchCityOutSideCities(checkBoxChecked);
            self.SearchCityChanged(receiver, checkBoxChecked, location);
        }

        self.SearchCityChangedForEdit = function (receiver, location, element) {
            var checkBoxChecked = $(element).is(":checked");
            receiver.SelectedDestination.PaymentType.SearchCityOutSideCities(checkBoxChecked);
            self.SearchCityChanged(receiver, checkBoxChecked, location);
        }

        self.SearchCityChanged = function (receiver, searchCityOutSideCities, location) {
            receiver.ShouldShowLocation(false);
            $("#location-store-error-message").hide();
            $("#correspondent-error-message").hide();
            ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);
            receiver.PaymentType.SearchCityOutSideCities(searchCityOutSideCities);
            $.when(searchCityOutSideCities ? self.LoadPayments(null, receiver.CountryId(), receiver.ToCurrencyId())
                : self.GetPaymentsByCity(receiver, receiver.City(), receiver.ToCurrencyId(), searchCityOutSideCities))
            .done(function () {
                ResetLocation(receiver);
                InitializePickUpLocationCities(receiver, null);
                if (location != null) {
                    self.PaymentTypeSelectIndexChange(receiver, ko.mapping.toJS(location.PaymentType));
                }
            });
        };

        function GetMatchingCities(countryId, cityName, correspondentId, receiver) {
            var transactionType = 14;

            return cs.BaseAjax(
            {
                url: '/MoneyTransfer/GetMatchingCitiesWithCorrespondentId',
                type: "Get",
                cache: false,
                dataType: "json",
                data: { "countryId": countryId, "cityName": cityName, "transactionTypeId": transactionType, "correspondentId": correspondentId }
            }, true)
            .done(function (data) {
                $("#p-updatepaymenttype-errormessage").html("");
                $("#p-addpaymenttype-errormessage").html("");
                var matchCities = ko.mapping.toJS(data.matchCities);
                var stores = ko.mapping.toJS(data.locationStores);
                ko.mapping.fromJS(matchCities, {}, self.SenderLookUp.MatchingCities);
                ko.mapping.fromJS(stores, {}, self.SenderLookUp.LocationStores);

                if (matchCities.length > 0) {
                    self.SenderLookUp.MatchingCities()[0].Selected(true);
                }
            })
            .fail(function (xhr, status) {
                ResetLocation(receiver);

                $("#p-updatepaymenttype-errormessage").html($.parseJSON(xhr.responseText).Message);
                $("#p-addpaymenttype-errormessage").html($.parseJSON(xhr.responseText).Message);
            });
        }


        self.SelectPaymentType = function (receiver, paymentType) {
            if (paymentType.Selected() == true) {
                return;
            }
            paymentType.SearchCityOutSideCities(receiver.PaymentType.SearchCityOutSideCities());
            self.PaymentTypeSelectIndexChange(receiver, paymentType);
        };

        function SetPaymentTypeStatus(receiver, paymentType) {
            paymentType = ko.mapping.toJS(paymentType);
            ko.mapping.fromJS(paymentType, {}, receiver.PaymentType);
            receiver.PaymentType.Selected(true);
            receiver.PaymentType.AccountNumber.isModified(false);

            if (receiver.PaymentType.IsPaymentTypeAccount()) {
                var accountTypes = receiver.PaymentType.AccountTypes();
                if (accountTypes.length > 0) {
                    var accountType = accountTypes[0].Value;
                    ko.mapping.fromJS(accountType, {}, receiver.PaymentType.AccountType);
                }
            }

            var tempPayments = self.SenderLookUp.PickUpLocationPaymentTypes();
            for (var i = 0; i < tempPayments.length; i++) {
                if (tempPayments[i].CurrencyId() == paymentType.CurrencyId &&
                    tempPayments[i].TransactionTypeId() == paymentType.TransactionTypeId &&
                    tempPayments[i].Payouts()[0] == paymentType.Payouts[0] &&
                    tempPayments[i].PaymentTypeId() == paymentType.PaymentTypeId) {
                    receiver.ShouldShowLocation(true);
                    tempPayments[i].Selected(true);
                } else {
                    tempPayments[i].Selected(false);
                }
            }
            ko.mapping.fromJS(tempPayments, {}, self.SenderLookUp.PickUpLocationPaymentTypes);

            ResetLocation(receiver);
        }

        self.PaymentTypeSelectIndexChange = function (receiver, paymentType) {
            var searchCityOutSideCities = receiver.PaymentType.SearchCityOutSideCities();
            SetPaymentTypeStatus(receiver, paymentType);
            receiver.PaymentType.SearchCityOutSideCities(searchCityOutSideCities);

            var tempPaymentType = ko.mapping.fromJS(ko.mapping.toJS(paymentType));
            $("#correspondent-error-message").hide();
            $("#location-stores").hide();
            if (tempPaymentType.PaymentTypeId() == 6) {
                ko.mapping.fromJSON(defaultToBeAddedBranch, {}, receiver.Branch);
                receiver.NewPickupLocation.Location.City(receiver.City());
                receiver.NewPickupLocation.Location.State(receiver.StateName());
                if (receiver.PaymentType.SearchCityOutSideCities()) {
                    $("#autocomplete-pickup-location-city").val("");
                } else {
                    $("#autocomplete-pickup-location-city").val(receiver.City());
                }
                tempCity = $("#autocomplete-pickup-location-city").val();
                GetPaymentTypeLocationsByCityId(receiver.CountryId(), receiver.StateId(), tempCity, tempPaymentType);
            } else {
                $("#location-store-error-message").hide();
            }
        }

        function GetPaymentTypeLocationsByCityId(countryId, stateId, cityName, paymentType) {
            if (!cityName) {
                return;
            }
            ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
            var transactionType = 14;
            $("#location-stores").show();
            return cs.BaseAjax(
        {
            url: '/MoneyTransfer/GetLocationsByCity',
            type: "Post",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "countryId": countryId, "stateId": stateId, "cityName": cityName, "correspondentId": paymentType.Payouts()[0], "transactionTypeId": transactionType })
        })
        .done(function (data) {
            var stores = ko.mapping.toJS(data);
            ko.mapping.fromJS(stores, {}, self.SenderLookUp.LocationStores);
        })
        .always(function () {
            $("#location-stores").hide();
        });
        };

        self.FindCities = function (cityName, receiver) {
            var countryId = receiver.CountryId();

            if (!receiver.PaymentType.Payouts()) {
                return;
            }

            var correspondentId = receiver.PaymentType.Payouts()[0];

            if (cityName == null || cityName == "") {
                ko.mapping.fromJS(null, {}, self.SenderLookUp.MatchingCities);
                ko.mapping.fromJS(null, {}, self.SenderLookUp.LocationStores);
            } else {
                GetMatchingCities(countryId, cityName, correspondentId, receiver);
            }
        }

        self.PaymentTypeCitySelectIndexChange = function (index, receiver, city) {
            receiver.NewPickupLocation.Location.City(city.CityName());
            receiver.NewPickupLocation.Location.State(city.StateName());
            GetPaymentTypeLocations(index, city, receiver.CountryId());
        }

        self.LocationSelectIndexChange = function (index, receiver, location) {
            ko.mapping.fromJS(location.Branch, {}, receiver.Branch);
            SetSelectedLocation(index, location);
            $("#location-store-error-message").hide();
        }

        function SetSelectedLocation(index, location) {
            var templocation = self.SenderLookUp.LocationStores();
            for (var i = 0; i < templocation.length; i++) {
                if (i == index()) {
                    templocation[i].Selected(true);
                } else {
                    templocation[i].Selected(false);
                }
            }
            ko.mapping.fromJS(templocation, {}, self.SenderLookUp.LocationStores);
        }
        // end: Load Payment Type for add recipient.

        //Initialize add recipient

        function resetAddReceiver(modalId) {
            self.RemoveValidErrorMessage();
            self.TobeAddedReceiver.CityValidateType(0);
            self.TobeAddedReceiver.CountryId(null);
            self.TobeAddedReceiver.layoutAddRecipientFlag(false);
            self.ResetToBeAddedReceiver();
            cs.closeModalCallBack(modalId, function () {
                self.TobeAddedReceiver.layoutAddRecipientFlag(false);
            });
        };

        function resetAddReceiverInManagment() {
            resetAddReceiver('modal-recipient-new');
        }

        function resetAddReceiverInMoneyTransfer() {
            resetAddReceiver('modal-moneytransfer-recipient-new');
        }

        var addRecipientStatus = new cs.executeStatus();
        self.InitializeAddRecipient = function (element) {
            if (addRecipientStatus.isExecuting()) {
                return;
            }

            resetAddReceiverInManagment();
            cs.openModal("modal-recipient-new");
            addRecipientStatus.setExecuting();
            try {
                ResetLocation(self.TobeAddedReceiver);
                self.TobeAddedReceiver.layoutAddRecipientFlag(true);
                $("#bank-account-detail").addClass("hide");
                $("#pickup-location-detail").addClass("hide");
                $.when(InitializeDestinationCountries(element))
                .done(function () {
                    RestAreaCodeForAddReceiver(self.TobeAddedReceiver.CountryId());
                    addRecipientStatus.complete();
                })
                .fail(function () {
                    addRecipientStatus.complete();
                    if (!element.hasAttribute) {
                        cs.hideLoading();
                    }
                });
            } catch (e) {
                console.log(e.stack);
                addRecipientStatus.complete();
            }
        }

        self.InitializeAddRecipientForMoneyTransfer = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            resetAddReceiverInMoneyTransfer();

            self.TobeAddedReceiver.layoutAddRecipientFlag(true);
            cs.openModal("modal-moneytransfer-recipient-new");
            $.when(InitializeDestinationCountries(element))
            .done(function () {
                RestAreaCodeForAddReceiver(self.TobeAddedReceiver.CountryId());
            });
        };

        self.RemoveValidErrorMessage = function () {
            self.TobeAddedReceiver.RelationShipId("");
            self.TobeAddedReceiver.FirstName.isModified(false);
            self.TobeAddedReceiver.LastName.isModified(false);
            self.TobeAddedReceiver.Address.isModified(false);
            self.TobeAddedReceiver.StateId.isModified(false);
            self.TobeAddedReceiver.PhoneNumber.isModified(false);
            self.TobeAddedReceiver.PhoneType.isModified(false);
            self.TobeAddedReceiver.RelationShipId.isModified(false);
            self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountNumber.isModified(false);
            self.TobeAddedReceiver.CountryId.isModified(false);
        };

        function InitializeDestinationCountries(element) {
            var transactionType = 14;
            self.TobeAddedReceiver.TransactionType(transactionType);

            return $.when(dataModel.InitializeDestinationsCountries(transactionType, element))
        .done(function (data) {
            var countries = ko.mapping.toJS(data);
            ko.mapping.fromJS(countries, {}, self.SenderLookUp.DestinationCountries);
                ko.mapping.fromJS([], {}, self.SenderLookUp.DestinationStates);
            if (countries.length > 0) {
                var countryId = countries[0].Value;

                for (var i = 0; i < countries.length; i++) {
                    if (countries[i].Value == 484) {
                        countryId = countries[i].Value;
                    }
                }
            }
        })
        }

        // Updates recipient.

        function IsDestinationValid() {
            if (self.TobeUpdatedReceiver.BankAccountPickupType() == 1) {
                var newBankName = $('#autocomplete-bank-names-new').val();
                if (newBankName == '' || newBankName == null) {
                    self.TobeUpdatedReceiver.ValidType(1);
                    return false;
                } else if ($('#autocomplete-bank-names-new').length > 0 && self.TobeUpdatedReceiver.ValidType() != 0) {
                    return false;
                }
            } else if (self.TobeUpdatedReceiver.BankAccountPickupType() == 2) {
                var bankName = $('#autocomplete-bank-names-old').val();
                if (bankName == '' || bankName == null) {
                    self.TobeUpdatedReceiver.ValidTypeForEdit(1);
                    return false;
                } else if ($('#autocomplete-bank-names-old').length > 0 && self.TobeUpdatedReceiver.ValidTypeForEdit() != 0) {
                    return false;
                }
            }

            return true;
        }

        self.UpdateSelfServiceReceiver = function (element) {
            UpdateReceiver(element);
        }

        self.IsUpdated = ko.observable(false);

        function IsAllDestinationDeleted() {
            for (var i = 0; i < self.TobeUpdatedReceiver.RecipientDestinations().length; i++) {
                if (!self.TobeUpdatedReceiver.RecipientDestinations()[i].IsDelete()) {
                    return false;
                }
            }

            return true;
        }

        self.NewBankAccountPaymentTypeGroup = {
            Correspondent: self.TobeUpdatedReceiver.NewBankAccount.PaymentType.Correspondent,
            AccountNumber: self.TobeUpdatedReceiver.NewBankAccount.PaymentType.AccountNumber,
            ConfirmAccountNumber: self.TobeUpdatedReceiver.NewBankAccount.PaymentType.ConfirmAccountNumber,
            AccountType: self.TobeUpdatedReceiver.NewBankAccount.PaymentType.AccountType
        };
        self.BankAccountPaymentTypeGroup = {
            Correspondent: self.TobeUpdatedReceiver.BankAccount.PaymentType.Correspondent,
            AccountNumber: self.TobeUpdatedReceiver.BankAccount.PaymentType.AccountNumber,
            ConfirmAccountNumber: self.TobeUpdatedReceiver.BankAccount.PaymentType.ConfirmAccountNumber,
            AccountType: self.TobeUpdatedReceiver.BankAccount.PaymentType.AccountType
        };

        var updateReceiverStatus = new cs.executeStatus();
        self.UpdateReceiver = function (element) {
            if (updateReceiverStatus.isExecuting()) {
                return;
            }

            if (cs.isDisabled(element)) {
                return;
            }

            updateReceiverStatus.setExecuting();
            var validationBranch = true;
            if ([1, 2].indexOf(self.TobeUpdatedReceiver.LocationPickupType()) != -1) {
                if ((self.TobeUpdatedReceiver.PaymentType.PaymentTypeId() == 6 && !(self.TobeUpdatedReceiver.Branch.BranchName()))
                    ) {
                    //cs.showErrorMessage("Error", "Please select location.");
                    if (self.TobeUpdatedReceiver.ShouldShowLocation()) {
                        $("#location-store-error-message").show();
                        validationBranch = false;
                    }
                } else if (self.TobeUpdatedReceiver.PaymentType.PaymentTypeId() < 1) {
                    $('#correspondent-error-message').show();
                    validationBranch = false;
                }
            }

            if (self.TobeUpdatedReceiver.LocationPickupType() == 2) {//edit
                var tempPaymentType = ko.mapping.toJS(self.TobeUpdatedReceiver.PaymentType);
                ko.mapping.fromJS(tempPaymentType, {}, self.TobeUpdatedReceiver.SelectedDestination.PaymentType);

                var tempBranch = ko.mapping.toJS(self.TobeUpdatedReceiver.Branch);
                ko.mapping.fromJS(tempBranch, {}, self.TobeUpdatedReceiver.SelectedDestination.Location.Branch);
            }

            var destinationValid = IsDestinationValid();
            var accountTypes = self.TobeUpdatedReceiver.BankAccount.PaymentType.AccountTypes;
            self.TobeUpdatedReceiver.errors = ko.validation.group(self.TobeUpdatedReceiver);
            self.TobeUpdatedReceiver.NewBankAccount.PaymentType.errors = ko.validation.group(self.NewBankAccountPaymentTypeGroup);
            self.TobeUpdatedReceiver.BankAccount.PaymentType.errors = ko.validation.group(self.BankAccountPaymentTypeGroup);
            self.TobeUpdatedReceiver.SelectedDestination.Location.errors = ko.validation.group(self.TobeUpdatedReceiver.SelectedDestination.Location);
            var validAutocompleteCity = cs.setCityValidateType(self.TobeUpdatedReceiver.CityValidateType, $('#autocomplete-city-names-updaterecipient'), cities)
            var isValid = validAutocompleteCity[0];


            if (self.TobeUpdatedReceiver.isValid() && self.NewBankAccountPaymentTypeGroup.isValid() && isValid && destinationValid
                    && self.BankAccountPaymentTypeGroup.isValid() && self.TobeUpdatedReceiver.ValidAddress() == 0
                    && IsAccountTypeValid() && validationBranch) {
                var phoneType = $("#input-phone-type").val();
                if (phoneType == 1) {
                    self.TobeUpdatedReceiver.CellPhoneNumber(self.TobeUpdatedReceiver.GetRemoveFormatPhoneNumber(self.TobeUpdatedReceiver.PhoneNumber()));
                    self.TobeUpdatedReceiver.HomePhoneNumber("");
                } else if (phoneType == 2) {
                    self.TobeUpdatedReceiver.HomePhoneNumber(self.TobeUpdatedReceiver.GetRemoveFormatPhoneNumber(self.TobeUpdatedReceiver.PhoneNumber()));
                    self.TobeUpdatedReceiver.CellPhoneNumber("");
                }
                UpdateReceiver(element);

            } else {
                updateReceiverStatus.complete();
                self.TobeUpdatedReceiver.errors.showAllMessages();
                self.TobeUpdatedReceiver.NewBankAccount.PaymentType.errors.showAllMessages();
                self.TobeUpdatedReceiver.BankAccount.PaymentType.errors.showAllMessages();
                self.TobeUpdatedReceiver.SelectedDestination.Location.errors.showAllMessages();
            }
        }

        function UpdateReceiver(element) {
            var tempUpdatedReceiver = ko.toJS(ko.utils.unwrapObservable(self.TobeUpdatedReceiver));
            tempUpdatedReceiver.PhoneNumber = self.TobeUpdatedReceiver.GetRemoveFormatPhoneNumber(tempUpdatedReceiver.PhoneNumber);

            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/UpdateSelfServiceReceiver',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(tempUpdatedReceiver))
            }, element, true)
            .done(function (data) {
                for (var i = 0; i < self.Receivers().length; i++) {
                    if (self.Receivers()[i].CardHolderId() == data.CardHolderId) {
                        var currencyId = self.Receivers()[i].ToCurrencyId();
                        ko.mapping.fromJS(data, {}, self.Receivers()[i]);
                        self.Receivers()[i].ToCurrencyId(currencyId);
                        break;
                    }
                }
                $.when(cs.closeModal())
                .done(function () {
                    updateReceiverStatus.complete();
                });
            })
            .fail(function (xhr, status) {
                updateReceiverStatus.complete();
                if ($.parseJSON(xhr.responseText).Priority != null) {
                    if ($.parseJSON(xhr.responseText).Priority == 1) {
                        ModelSessionTimeOut$RevealAndLogout();
                        return;
                    }
                }
                var errorCode = parseInt(xhr.responseText);
                if (errorCode == 16842753) {
                    AddPayments();
                }
                else {
                    cs.showErrorMessage($.parseJSON(xhr.responseText).Caption, $.parseJSON(xhr.responseText).Message);
                }
            });
        }

        function IsAccountTypeValid() {
            var paymentType = self.TobeUpdatedReceiver.BankAccount.PaymentType;
            var newPaymentType = self.TobeUpdatedReceiver.NewBankAccount.PaymentType;

            if (paymentType.AccountTypes() == null || newPaymentType.AccountTypes() == null) {
                return true;
            }

            return paymentType.AccountTypes || newPaymentType.AccountTypes || paymentType.AccountTypes().length == 0 || paymentType.AccountType() != 0
                || newPaymentType.AccountTypes().length == 0 || newPaymentType.AccountType() != 0;
        }

        self.ValidateCityForUpdateRecipient = function () {
            if (!cities) {
                return;
            }
            var validAutocompleteCity = cs.setCityValidateType(self.TobeUpdatedReceiver.CityValidateType, $('#autocomplete-city-names-updaterecipient'), cities);
            self.TobeUpdatedReceiver.CityId(validAutocompleteCity[1]);
        }

        self.UpdateReceiverFavorites = function (receiver) {
            return cs.BaseAjax(
                    {
                        url: '/MoneyTransfer/SetFavoriteRecipient',
                        type: "POST",
                        contentType: "application/json",
                        data: JSON.stringify({ "receiverCardHolderId": receiver.CardHolderId(), "isFavorite": !receiver.IsFavorite() })
                    })
                   .done(function () {
                       receiver.IsFavorite(!receiver.IsFavorite());
                   })
        }

        // Search recipient

        self.RecipientSearchText = ko.observable("");
        var timerHandler = 0;
        self.UpdateAndSearchRecipient = function (value) {
            var oldValue = self.RecipientSearchText();
            self.RecipientSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.RecipientSearchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 3) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.SearchReceivers("#search-money-transfer-recipient"); }, 500);
            }
        }

        self.SearchRecipientOnEnter = function () {
            self.SearchReceivers("#search-money-transfer-recipient");
        };

        self.SearchReceivers = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            var searchCriteria = $("#input-search-for-manager-recipients").val().trim();
            return cs.AjaxBySpinner(
            {
                url: '/MoneyTransfer/SearchReceivers',
                dataType: "json",
                type: "Get",
                cache: false,
                data: { "searchCriteria": searchCriteria }
            }, element)
            .done(function (data) {
                var receivers = ko.mapping.fromJS(data);
                ko.mapping.fromJS(receivers, {}, self.Receivers);
                cs.closeFoundationDropdown();
            });
        }

        self.OpenBankAccountDetail = function (element) {
            var isActive = $(element).parent().hasClass("active");
            setTimeout(function () {
                if (!(self.TobeAddedReceiver.CountryId())) {
                    return false;
                }

                if (isActive) {
                    self.TobeAddedReceiver.ResetBankAccountDepositForNewBankAccount("autocomplete-bank-names");
                }
                else {
                    self.TobeAddedReceiver.InitializeAddBankAccountDeposit($("#autocomplete-bank-names"));
                    self.SearchBankAccountCorrespondents("button-bank-account-deposit", self.TobeAddedReceiver, "autocomplete-bank-names");
                }
            }, 300);

            return true;
        }

        var bankAccounts;

        self.SearchBankAccountCorrespondents = function (element, receiver, autocompleteElement, focus) {
            var tempAutocompleteElement = '';
            if (typeof autocompleteElement == "string") {
                if (autocompleteElement.indexOf("#") != 0) {
                    tempAutocompleteElement = "#" + autocompleteElement;
                }
            }

            cs.addSearchSpinner(element);
            $.when(self.GetBankAccountCorrespondents(receiver.CountryId, receiver.ToCurrencyId()))
            .done(function (correspondents) {
                receiver.BindBankAccountCorrespondents(autocompleteElement, correspondents);
            })
            .always(function () {
                cs.removeSearchSpinner(element);
                if (focus) {
                    $(tempAutocompleteElement).focus();
                };
            });
        };

        self.SearchBankAccountCorrespondentsForEdit = function (isFocus) {
            cs.addSearchSpinner("button-bank-account-deposit-old");
            $.when(self.GetBankAccountCorrespondents(self.TobeUpdatedReceiver.CountryId, self.TobeUpdatedReceiver.ToCurrencyId()))
            .done(function (correspondents) {
                self.TobeUpdatedReceiver.BindBankAccountCorrespondentsForEdit("autocomplete-bank-names-old", correspondents);
            })
            .always(function () {
                cs.removeSearchSpinner("button-bank-account-deposit-old");
                if (isFocus) {
                    $("#autocomplete-bank-names-old").focus();
                }
            });
        };

        self.GetPickUpLocationForSearchCities = function (element, isFocus) {
            cs.addSearchSpinner(element);
            
            var receiver = self.TobeUpdatedReceiver.CountryId() == null ? self.TobeAddedReceiver : self.TobeUpdatedReceiver;
            $.when(InitializePickUpLocationCities(receiver, null, true))
            .done(function () {
                cs.removeSearchSpinner(element);
                if (isFocus) {
                    $("#autocomplete-pickup-location-city").focus();
                }
            });
        }

        self.OpenPickupLocationDetail = function (element) {
            if ($(element).parent().hasClass("active")) {
                ResetPickupLocation(self.TobeAddedReceiver);
            }
            else {
                ResetPickupLocation(self.TobeAddedReceiver);
                self.TobeAddedReceiver.LocationPickupType(1);

                var currencyId = 0;
                for (var i = 0; i < self.SenderLookUp.DestinationCountries().length ; i++) {
                    if (self.TobeAddedReceiver.CountryId() == self.SenderLookUp.DestinationCountries()[i].Value()) {
                        currencyId = self.SenderLookUp.DestinationCountries()[i].CurrencyId()
                        break;
                    }
                }

                self.GetPaymentsByCity(self.TobeAddedReceiver, $("#autocomplete-city-names-addrecipient").val(), currencyId, false);
                self.TobeAddedReceiver.PaymentType.SearchCityOutSideCities(false);
                InitializePickUpLocationCities(self.TobeAddedReceiver, null);
            }

            return true;
        }

        function ResetPickupLocation(receiver) {
            if (receiver.RecipientDestinations()) {
                $.each(receiver.RecipientDestinations(), function (index, d) {
                    d.IsEdit(false);
                });
            }

            $("#autocomplete-pickup-location-city").val("");
            $("#autocomplete-pickup-location-city").error(false, '');
            $('#autocomplete-pickup-location-city').autocomplete({
                lookup: new Array()
            });

            receiver.NewPickupLocation.Location.StateId("");
            locations = null;

            ko.mapping.fromJS(null, {}, self.SenderLookUp.PickUpLocationPaymentTypes);

            ResetLocation(receiver);

            $("#pickup-location-detail").addClass("hide");
            $("#location-store-error-message").hide();
            receiver.LocationPickupType(0);
            receiver.PaymentType.PaymentTypeId(0);
        }

        var locations;
        self.SearchCorrespondent = function (countryId, destination, stateElement, correspondentElement, addressElement, searchElement) {
            var stateName = $(stateElement).find("option:selected").text();
            var city = destination.Location.City();
            if (city != "" && city != null) {
                $(searchElement).find('span').css({ "display": "block", "margin-top": "0.6rem" });
                $(searchElement).find('i').fadeOut();
                $(searchElement).find('span').fadeIn();
                cs.BaseAjax(
              {
                  url: '/MoneyTransfer/GetCorrespondentsForPickupLocation',
                  type: "Post",
                  dataType: "json",
                  contentType: "application/json",
                  data: JSON.stringify({ "countryId": countryId, "stateName": stateName, "city": city })
              })
              .done(function (data) {
                  var resultCorrespondents = new Array();
                  for (var i = 0; i < data.length; i++) {
                      if (data[i].CurrencyId == data[i].CountryId) {
                          resultCorrespondents.push(data[i]);
                      }
                  }
                  locations = resultCorrespondents;

                  var tempCorrespondents = $.map(ko.mapping.toJS(resultCorrespondents), function (item, index) { return { value: item.Correspondent, data: item }; });
                  tempCorrespondents.sort(function (x, y) {
                      return cs.sortByString(x.value, y.value, true);
                  });
                  $(correspondentElement).autocomplete({
                      lookup: tempCorrespondents,
                      triggerSelectOnValidInput: true,
                      minChars: 0,
                      onSelect: function (suggestion) {
                          ko.mapping.fromJS(suggestion.data, {}, destination.PaymentType);
                          if (destination.PaymentType.PaymentTypeId() == 6) {
                              self.SearchLocations(countryId, destination, stateName, addressElement);
                          }
                          $(correspondentElement).error(false, '');
                      },
                      onInvalidateSelection: function () {
                          if ($(correspondentElement).val() == "") {
                              $(correspondentElement).error(true, 'Bank is required');
                          } else {
                              $(correspondentElement).error(true, 'Enter a valid correspondent');
                          }
                      }
                  });
                  $(correspondentElement).focus();
              })
                .always(function () {
                    $(searchElement).find('i').fadeIn();
                    $(searchElement).find('span').fadeOut();
                });
            }
        }

        self.SearchLocations = function (countryId, destination, stateName, addressElement) {
            var city = {
                CorrespondentId: destination.PaymentType.Payouts()[0],
                CityName: destination.Location.City(),
                StateName: stateName,
                ItemCount: 0
            }
            GetLocations(countryId, city, destination.Location, addressElement, null);
        }

        function GetLocations(countryId, city, location, element, branchName) {
            var transactionType = 14;

            return cs.BaseAjax({
                url: '/MoneyTransfer/GetLocations',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": countryId, "matchingCity": city, "transactionTypeId": transactionType })
            })
             .done(function (data) {
                 if (branchName != null) {
                     for (var i = 0; i < data.length; i++) {
                         if (data[i].Branch.BranchName == branchName) {
                             location.Address(data[i].Address);
                             location.Zipcode(data[i].Zipcode);
                         }
                     }
                 }

                 var locations = $.map(ko.mapping.toJS(data), function (item, index) { return { value: item.Address, data: item }; });;
                 locations.sort(function (x, y) {
                     return cs.sortByString(x.value, y.value, true);
                 });
                 $(element).autocomplete({
                     lookup: locations,
                     triggerSelectOnValidInput: true,
                     minChars: 0,
                     onSelect: function (suggestion) {
                         if (location.Address() != suggestion.data.Address) {
                             location.Address(suggestion.data.Address);
                             location.Zipcode(suggestion.data.Zipcode);
                             location.Branch.BranchCode(suggestion.data.Branch.BranchCode);
                             location.Branch.BranchName(suggestion.data.Branch.BranchName);
                         }
                         self.TobeUpdatedReceiver.ValidAddress(0);
                     },
                     onInvalidateSelection: function () {
                         if ($('#input-address-01-old').val().trim() != location.Address() || $('#input-address-01-old').val().trim() == "") {
                             location.Address("");
                             self.TobeUpdatedReceiver.ValidAddress($('#input-address-01-old').val() == "" ? 1 : 2);
                             location.Zipcode("");
                         }
                     }
                 });
             });
        }

        function GetPaymentTypeLocations(index, city, countryId) {
            var city = ko.mapping.toJS(city);
            var transactionType = 14;

            cs.BaseAjax({
                url: "/MoneyTransfer/GetLocations",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": countryId, "matchingCity": city, "transactionTypeId": transactionType })
            })
        .done(function (data) {
            var stores = ko.mapping.toJS(data);
            ko.mapping.fromJS(stores, {}, self.SenderLookUp.LocationStores);

            var tempCities = self.SenderLookUp.MatchingCities();
            for (var i = 0; i < tempCities.length; i++) {
                if (i == index()) {
                    tempCities[i].Selected(true);
                } else {
                    tempCities[i].Selected(false);
                }
            }
            ko.mapping.fromJS(tempCities, {}, self.SenderLookUp.MatchingCities);
        });
        }

        // Changes option in update recipient.

        var defaultBankAccount = ko.mapping.toJS(self.TobeUpdatedReceiver.NewBankAccount);
        var defaultPickupLocation = ko.mapping.toJS(self.TobeUpdatedReceiver.NewPickupLocation);

        self.BankAccountChanged = function (bankAccount, element, isEdit) {
            for (var i = 0; i < self.TobeUpdatedReceiver.RecipientDestinations().length; i++) {
                if (self.TobeUpdatedReceiver.RecipientDestinations()[i].DestinationId() == self.TobeUpdatedReceiver.BankAccount.DestinationId()) {
                    var originalAccount = ko.mapping.toJS(self.TobeUpdatedReceiver.BankAccount);
                    ko.mapping.fromJS(originalAccount, {}, self.TobeUpdatedReceiver.RecipientDestinations()[i]);
                    break;
                }
            }
            self.TobeUpdatedReceiver.ValidType(0);

            if (isEdit) {
                if ($(element).parent().hasClass("active")) {
                    self.TobeUpdatedReceiver.ResetBankAccountDepositForBankAccount("autocomplete-bank-names-old");
                }
                else {
                    var tempBankAccount = ko.mapping.toJS(bankAccount);
                    self.TobeUpdatedReceiver.ValidTypeForEdit(0);
                    ko.mapping.fromJS(tempBankAccount, {}, self.TobeUpdatedReceiver.BankAccount);
                    $("#autocomplete-bank-names-old").val(self.TobeUpdatedReceiver.BankAccount.PaymentType.Correspondent());
                    self.TobeUpdatedReceiver.BankAccount.PaymentType.ConfirmAccountNumber(self.TobeUpdatedReceiver.BankAccount.PaymentType.AccountNumber());

                    self.SearchBankAccountCorrespondentsForEdit();

                    self.TobeUpdatedReceiver.BankAccountPickupType(2);
                }
            }
            else {
                if ($(element).parent().hasClass("active")) {
                    self.TobeUpdatedReceiver.ResetBankAccountDepositForNewBankAccount("autocomplete-bank-names-new");
                }
                else {
                    bankAccounts = null;

                    self.TobeUpdatedReceiver.InitializeAddBankAccountDeposit("autocomplete-bank-names-new");

                    self.SearchBankAccountCorrespondents("button-bank-account-deposit-new", self.TobeUpdatedReceiver, "autocomplete-bank-names-new");
                }
            }

            return true;
        }

        self.InitailizeEditPickUpLocationForEditingRecipient = function (location, element) {
            if ($(element).parent().hasClass("active")) {
                ResetPickupLocation(self.TobeUpdatedReceiver);
            } else {

                var tempLocation = ko.mapping.toJS(location);
                ko.mapping.fromJS(tempLocation, {}, self.TobeUpdatedReceiver.SelectedDestination);

                ResetPickupLocation(self.TobeUpdatedReceiver);
                location.IsEdit(true);

                self.TobeUpdatedReceiver.LocationPickupType(2);
                InitializePickUpLocationCities(self.TobeUpdatedReceiver, null);
                self.SearchCityChanged(self.TobeUpdatedReceiver, tempLocation.PaymentType.SearchCityOutSideCities, location);
            }

            return true;
        }

        self.InitializeAddPickUpLocationForEditingRecipient = function (deliveryOption, element) {
            //$('a[href=#panel_cash_old]').attr('href', "#panel_cash_old_temp");
            //$(element).attr('href', '#panel_cash_old');

            if ($(element).parent().hasClass("active")) {
                ResetPickupLocation(self.TobeUpdatedReceiver);
            } else {
                ResetPickupLocation(self.TobeUpdatedReceiver);
                self.TobeUpdatedReceiver.PaymentType.SearchCityOutSideCities(false);
                self.InitializeAddPickUpLocation(self.TobeUpdatedReceiver.CountryId(), self.TobeUpdatedReceiver.ToCurrencyId());
            }

            return true;
        };

        self.InitializeAddPickUpLocation = function (countryId, currencyId) {
            //ko.mapping.fromJS(defaultPickupLocation, {}, self.TobeUpdatedReceiver.SelectedDestination);
            ResetPickupLocation(self.TobeUpdatedReceiver);

            self.TobeUpdatedReceiver.LocationPickupType(1);

            InitializePickUpLocationCities(self.TobeUpdatedReceiver, null);
            return self.GetPaymentsByCity(self.TobeUpdatedReceiver, self.TobeUpdatedReceiver.City(), currencyId, false);
        }

        var showDefaultCity = false;
        var addReceiverStatus = new cs.executeStatus();
        self.AddSelfServiceReceiver = function (element) {
            if (addReceiverStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            addReceiverStatus.setExecuting();
            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/AddSelfServiceReceiver',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self.TobeAddedReceiver))
            }, element)
           .done(function (data) {
               var tempReceivers = ko.mapping.toJS(self.Receivers);
               if (self.Receivers() == null || self.Receivers().length < 1) {
                   tempReceivers = new Array();
               }
               tempReceivers.push(data);
               ko.mapping.fromJS(tempReceivers, {}, self.Receivers);
               self.Ready();
               $.when(cs.closeModal())
               .done(function () {
                   addReceiverStatus.complete();
                   ko.mapping.fromJSON(defaultToBeAddedReceiver, {}, self.TobeAddedReceiver);
               });
           })
            .fail(function () {
                addReceiverStatus.complete();
           });
        }

        self.ValidationReceiver = function (city) {
            var isValidDestination = true;
            if (self.TobeAddedReceiver.BankAccountPickupType() == 1) {
                var bankName = $('#autocomplete-bank-names').val();
                if ($('#autocomplete-bank-names').length > 0 && (bankName == '' || bankName == null)) {
                    self.TobeAddedReceiver.ValidType(1);
                    isValidDestination = false;
                } else if ($('#autocomplete-bank-names').length > 0 && self.TobeAddedReceiver.ValidType() != 0) {
                    isValidDestination = false;
                }
            }

            if (self.TobeAddedReceiver.LocationPickupType() == 1) {
                if ((self.TobeAddedReceiver.PaymentType.PaymentTypeId() == 6 && !(self.TobeAddedReceiver.Branch.BranchName())
                    )) {
                    //cs.showErrorMessage("Error", "Please select location.");
                    $('#location-store-error-message').show();
                    isValidDestination = false;
                } else if (self.TobeAddedReceiver.PaymentType.PaymentTypeId() < 1) {
                    $('#correspondent-error-message').show();
                    isValidDestination = false;
                }
            }

            var phoneType = $("#input-phone-type").val();
            var PaymentTypeGroup = {
                Correspondent: self.TobeAddedReceiver.NewBankAccount.PaymentType.Correspondent,
                AccountType: self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountType,
                AccountNumber: self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountNumber,
                ConfirmAccountNumber: self.TobeAddedReceiver.NewBankAccount.PaymentType.ConfirmAccountNumber
            };
            self.TobeAddedReceiver.errors = ko.validation.group(self.TobeAddedReceiver);
            self.TobeAddedReceiver.NewBankAccount.PaymentType.errors = ko.validation.group(PaymentTypeGroup);
            self.TobeAddedReceiver.NewPickupLocation.Location.errors = ko.validation.group(self.TobeAddedReceiver.NewPickupLocation.Location);
            var cities = self.TobeAddedReceiver.cities ? ko.mapping.toJS(self.TobeAddedReceiver.cities) : self.TobeAddedReceiver.cities;
            var validAutocompleteCity = cs.setCityValidateType(self.TobeAddedReceiver.CityValidateType, city, cities)
            var isValid = validAutocompleteCity[0];
            if (self.TobeAddedReceiver.isValid() && PaymentTypeGroup.isValid() && isValid && isValidDestination &&
                (self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountTypes.length == 0 || self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountType() != 0)) {
                if (phoneType == 1) {
                    self.TobeAddedReceiver.CellPhoneNumber(self.TobeAddedReceiver.GetRemoveFormatPhoneNumber(self.TobeAddedReceiver.PhoneNumber()));
                } else if (phoneType == 2) {
                    self.TobeAddedReceiver.HomePhoneNumber(self.TobeAddedReceiver.GetRemoveFormatPhoneNumber(self.TobeAddedReceiver.PhoneNumber()));
                }

                self.TobeAddedReceiver.CityId(validAutocompleteCity[1]);

                return true;
            }
            else {
                //LogToAddReceiver(self.TobeAddedReceiver);
                self.TobeAddedReceiver.errors.showAllMessages();
                self.TobeAddedReceiver.NewBankAccount.PaymentType.errors.showAllMessages();
                self.TobeAddedReceiver.NewPickupLocation.Location.errors.showAllMessages();
                return false;
            }
        };

        self.ValidateCityForAddRecipient = function (element) {
            if (!self.TobeAddedReceiver.cities) {
                return;
            }
            var validAutocompleteCity = cs.setCityValidateType(self.TobeAddedReceiver.CityValidateType, $('#' + element.id), self.TobeAddedReceiver.cities);
            self.TobeAddedReceiver.CityId(validAutocompleteCity[1]);
        }

        // Delete option in update recipient.

        self.DeleteOption = function (destination) {
            for (var i = 0; i < self.TobeUpdatedReceiver.RecipientDestinations().length; i++) {
                if (self.TobeUpdatedReceiver.RecipientDestinations()[i].DestinationId() == destination.DestinationId()) {
                    self.TobeUpdatedReceiver.RecipientDestinations()[i].IsDelete(true);
                    if (self.TobeUpdatedReceiver.BankAccount.DestinationId() == destination.DestinationId()) {
                        $("#bank-account-detail-old").addClass("hide");
                        self.TobeUpdatedReceiver.BankAccountPickupType(0);
                        ko.mapping.fromJS(defaultBankAccount, {}, self.TobeUpdatedReceiver.BankAccount);
                    } else if (self.TobeUpdatedReceiver.SelectedDestination.DestinationId() == destination.DestinationId()) {
                        $("#pickup-location-detail-old").addClass("hide");
                        self.TobeUpdatedReceiver.LocationPickupType(0);
                        ko.mapping.fromJS(defaultPickupLocation, {}, self.TobeUpdatedReceiver.SelectedDestination);
                    }
                }
            }
        }

        // Gets states and cities of new location in update recipient.
        self.GetCitiesByStateIdForUpdateReceiver = function (element) {
            stateId = element.value;
            self.TobeUpdatedReceiver.City("");
            ResetUpdateCorrespondent();
            showDefaultCity = false;
            $.when(InitializeDestinationCities(stateId, self.TobeUpdatedReceiver.CountryId()))
            .done(function () {
                $("#autocomplete-city-names-updaterecipient").trigger('focus');
            });
        }

        // Validate new bank account
        self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountNumber.extend({
            required: {
                onlyIf: function () { return (self.TobeAddedReceiver.BankAccountPickupType() == 1) },
                message: 'Account number is required'
            }
        }).isModified(false);

        self.TobeAddedReceiver.NewBankAccount.PaymentType.ConfirmAccountNumber.extend({
            required: {
                onlyIf: function () { return (self.TobeAddedReceiver.BankAccountPickupType() == 1) },
                message: 'Confirm number is required'
            },
            equal: {
                params: self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountNumber,
                message: "Values of account no. and confirm account no. don't match"
            }
        }).isModified(false);

        self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountType.extend({
            required: {
                onlyIf: function () { return (self.TobeAddedReceiver.ShowAccountTypeForNewBankAccount() && (self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountType() == null || self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountType() == "" || self.TobeAddedReceiver.NewBankAccount.PaymentType.AccountType() == -1)) },
                message: 'Account type is required'
            }
        }).isModified(false);

        self.TobeAddedReceiver.PhoneType.extend({
            equal: {
                onlyIf: function () { return self.TobeAddedReceiver.PhoneType() == 0; },
                message: 'Phone type is required'
            }
        }).isModified(false);

        // Validate updated bank account
        self.TobeUpdatedReceiver.BankAccount.PaymentType.AccountNumber.extend({
            required: {
                onlyIf: function () { return (self.TobeUpdatedReceiver.BankAccountPickupType() == 2) },
                message: 'Account number is required'
            },
            number: {
                params: true,
                message: 'Enter a valid account number'
            }
        }).isModified(false);

        self.TobeUpdatedReceiver.BankAccount.PaymentType.ConfirmAccountNumber.extend({
            required: {
                onlyIf: function () { return (self.TobeUpdatedReceiver.BankAccountPickupType() == 2) },
                message: 'Confirm number is required'
            },
            equal: {
                params: self.TobeUpdatedReceiver.BankAccount.PaymentType.AccountNumber,
                message: "Values of Account no. and Confirm Account no. don't match"
            }
        }).isModified(false);

        self.TobeAddedReceiver.BankAccount.PaymentType.AccountType.extend({
            required: {
                onlyIf: function () { return !(self.TobeUpdatedReceiver.ShowAccountTypeForBankAccount() && (self.TobeAddedReceiver.BankAccount.PaymentType.AccountType() === null || self.TobeAddedReceiver.BankAccount.PaymentType.AccountType() === "" || self.TobeAddedReceiver.BankAccount.PaymentType.AccountType() == -1)) },
                message: 'Account type is required'
            }
        }).isModified(false);

        self.TobeUpdatedReceiver.SelectedDestination.Location.StateId.extend({
            required: {
                onlyIf: function () { return (self.TobeUpdatedReceiver.BankAccountPickupType() == 2) },
                message: 'State is required'
            },
            required: {
                onlyIf: function () { return (self.TobeUpdatedReceiver.LocationPickupType() == 2) },
                message: 'State is required'
            }
        }).isModified(false);

        self.TobeUpdatedReceiver.NewBankAccount.PaymentType.AccountNumber.extend({
            required: {
                onlyIf: function () {
                    return (self.TobeUpdatedReceiver.BankAccountPickupType() == 1)
                },
                message: 'Account number is required'
            },
            number: {
                params: true,
                message: 'Enter a valid Account no.'
            }
        }).isModified(false);

        self.TobeUpdatedReceiver.NewBankAccount.PaymentType.ConfirmAccountNumber.extend({
            required: {
                onlyIf: function () {
                    return (self.TobeUpdatedReceiver.BankAccountPickupType() == 1)
                },
                message: 'Confirm number is required'
            },
            equal: {
                params: self.TobeUpdatedReceiver.NewBankAccount.PaymentType.AccountNumber,
                message: "Values of account no. and confirm account no. don't match"
            }
        }).isModified(false);

        self.TobeUpdatedReceiver.NewPickupLocation.Location.StateId.extend({
            required: {
                onlyIf: function () { return (self.TobeUpdatedReceiver.LocationPickupType() == 1) },
                message: 'State is required'
            }
        }).isModified(false);

        //new code  
        self.ResetToBeUpdateReceiver = function () {
            ko.mapping.fromJS(defaultTobeUpdatedReceiver, {}, self.TobeUpdatedReceiver);
            if (self.Receivers() != null) {
                for (var i = 0; i < self.Receivers().length; i++) {
                    self.Receivers()[i].Selected(false);
                }
            }
        };

        self.tempSelectReceiver;

        self.Ready = function () {
            if (self.tempSelectReceiver) {
                $("#input-search-for-recipients").val(self.tempSelectReceiver.FirstName() + ' ' + self.tempSelectReceiver.MiddleName() + ' ' + self.tempSelectReceiver.LastName());
                cs.removeDisable("button-select-receiver");
            }
        };

        self.InitializeSearchRecipients = function () {
            if (!(self.Receivers())) {
                return;
            }
            var receivers = $.map(ko.mapping.toJS(self.Receivers), function (item, index) {
                if (item.MiddleName) {
                    return { value: item.FirstName + ' ' + item.MiddleName[0] + '. ' + item.LastName, data: item };
                } else {
                    return { value: item.FirstName + ' ' + item.LastName, data: item };
                }
            });
            receivers.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            $('#autocomplete-carrier-products').autocomplete({
                lookup: receivers,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.tempSelectReceiver = ko.mapping.fromJS(suggestion.data);
                    cs.removeDisable("button-select-receiver");
                },
                onInvalidateSelection: function () {
                    self.tempSelectReceiver = null;
                    cs.addDisable("button-select-receiver");
                }
            });
        }

        self.SelectReceiver = function () {
            if ($("#button-select-receiver").attr("disabled") != "disabled" && tempSelectReceiver != null) {
                self.GetSelected(tempSelectReceiver);
            }
        }

        self.UpdateReceivers = function (receiver) {
            receiver = ko.mapping.toJS(receiver);
            for (var i = 0; i < self.Receivers().length; i++) {
                if (self.Receivers()[i].CardHolderId() == receiver.CardHolderId) {
                    ko.mapping.fromJS(receiver, {}, self.Receivers()[i]);
                    break;
                }
            }
        };

        self.GetStateName = function (stateId) {
            if (self.SenderLookUp.DestinationStates() == null) {
                return "";
            }

            for (var i = 0; i < self.SenderLookUp.DestinationStates().length; i++) {
                if (true) {
                    if (self.SenderLookUp.DestinationStates()[i].Value() == stateId) {
                        return self.SenderLookUp.DestinationStates()[i].Text();
                    }
                }
            }

            return "";
        };

        function GetDestinationCountriesCurrency() {
            cs.BaseAjax({
                url: '/Home/GetAllExchangeRates',
                type: "POST",
                dataType: "json",
                contentType: "application/json"
            }).done(function (data) {
                self.DestinationCurrencyAll = data;
            })
        }

        self.afterRenderNewReceiverPage = function (element) {
            self.ResetToBeAddedReceiver();
            self.RemoveValidErrorMessage();
        }
    
        self.UpdateDeliveryOptionsForReceiverList = function () {
            if (self.Receivers() != null) {
                for (var i = 0; i < self.Receivers().length; i++) {
                    if (self.Receivers()[i].CardHolderId() == self.TobeUpdatedReceiver.CardHolderId()) {
                        var deliveryOptions = ko.mapping.toJS(self.TobeUpdatedReceiver.RecipientDestinations);
                        ko.mapping.fromJS(deliveryOptions, {}, self.Receivers()[i].RecipientDestinations);
                        break;
                    }
                }
            }
        };
    }
});