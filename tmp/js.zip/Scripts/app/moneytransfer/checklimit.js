﻿/// <reference path="../../../Views/Shared/_includes/modals/_ModalMemberLevelStatus.cshtml" />
function CheckLimit(data, dataModel) {
    var self = this;
    self.showQuickPayCheckMesssage = ko.observable(false);
    ko.mapping.fromJS(data, {}, self);

    self.SetQuickPayOnHold = function (isShow) {
        self.showQuickPayCheckMesssage(isShow);
        if (isShow) {
            self.IsOnHold(false);
        }
    };

    self.CheckTransactionAmount = function (transactionTypeId, amountToSend, isQuickPay, element) {
        var deferred = $.Deferred();
        AjaxBySpinner({
            url: urlPaths.CheckTransactionAmount,
            datType: "json",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ "transactionTypeId": transactionTypeId, "amountToSend": amountToSend })
        }, element)
        .done(function (data) {
            if (transactionTypeId == 11 && transactionTypeId == 5) {// for bill pay

                return;
            }

            ko.mapping.fromJS(data, {}, self);
            if (self.showQuickPayCheckMesssage() == true) {
                self.IsOnHold(false);
            }
            if (self.OverMaxLimitAmount() > 0) {
                showErrorMessage("Error", 'You’ve exceeded your sending limits. Please Call 1-888-8888 for more information');
                deferred.reject();
            } else if (!self.showQuickPayCheckMesssage() && !self.IsOnHold()) {
                deferred.resolve();
            } else if (self.NeedToUpgradeLevelTwo() && !self.NeedToUpgradeLevelThree()) {// need to upgrade level 2
                openModal("modal-m-status", true);
                $("#button-email-done,#button-upload-done").off("click.transaction");
                $("#button-email-done,#button-upload-done").one("click.transaction", function () {
                    if (isQuickPay == true) {
                        self.showQuickPayCheckMesssage(false);
                        self.IsOnHold(true);
                    }

                    deferred.resolve();
                });
            } else if (self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {//need to upgrade level 3
                openModal("modal-m-status", true);
                $("#button-email-done,#button-upload-done").off("click.transaction");
                $("#button-email-done,#button-upload-done").one("click.transaction", function () {
                    if (isQuickPay == true) {
                        self.showQuickPayCheckMesssage();
                        self.IsOnHold(true);
                    }

                    deferred.resolve();
                });
            } else if (!self.NeedToUpgradeLevelTwo() && self.NeedToUpgradeLevelThree()) {// Current level is 2 ,need to upgrade level 3
                $.when(openModal("modal-m-status", true))
                .done(function () {
                    addDisable("upload-passport");
                });
                $("#button-email-done,#button-upload-done").off("click.transaction");
                $("#button-email-done,#button-upload-done").one("click.transaction", function () {
                    if (isQuickPay == true) {
                        self.showQuickPayCheckMesssage();
                        self.IsOnHold(true);
                    }

                    deferred.resolve();
                });
            }
        });

        return deferred;
    }
}