﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], paths['MoneyTransferConsumer-strings'], 'R', 'TrackEvent', paths['SettingsConsumer-strings'], 'upgrade-component'], function (ko, cs, app, dataModel, commonstrings, moneytransferstrings, R, track) {
    var defaultTransactionModel = {
        AmountToSend: { Symbol: null, Value: null },
        AmountToBeDispensed: { Symbol: null, Value: null },
        PromotionCode: null,
        DisplayPromotionCode: null,
        FromCurrencyCode: "USD",
        ToCurrencyCode: null,
        DisplayRate: null,
        Rate: null,
        FromCountryImage: null,
        ToCountryImage: null,
        PaymentTypeName: null,
        Correspondent: null,
        FeeCharged: { Symbol: null, Value: null },
        FeeTaxes: { Symbol: null, Value: null },
        FeeShipping: { Symbol: null, Value: null },
        FeeDiscount: { Symbol: null, Value: null },
        TotalFee: { Symbol: null, Value: null },
        AmountCollected: { Symbol: null, Value: null },
        DominantControl: null,
        DisplaySenderName: null,
        DisplayReveiverName: null,
        EnableSendEmail: null,
        SenderEmailAddress: null,
        ConfirmationNumber: null,
        IsShow: null,
        IsCard: null,
        TransactionType: null,
        PaymentType: null,
        Branch: null,
        CountryId: null,
        CountryName: null,
        IsCheckout: null,
        ReceiptNumber: null,
        TransactionDate: null,
        PaymentMethodId: null,
        SenderLevelOnHold: null,
        TransactionStatusCode: null,
        IsQuickPay: null,
        IsAgree: ko.observable(false),
        SelfServiceLimitHold: false
    };

    var defaultSenderLevel = {
        SenderLevelId: null,
        TargetLevelId: null,
        SourceLevelId: null,
        SenderLevelTypeId: null,

        SenderLevelType: null,

        AvailableAmount: null,

        //If OverLimitAmount > 0  then exceed level 3;   if OverLimitAmount == 0 then not exceed level3
        OverMaxLimitAmount: null,

        ExceedCurrentLevelAmount: null,

        IsUpgrading: null,

        IsDocumentSubmited: null,

        IsUpgradeLater: null,
        IsShowAttachedSuccessMessage: false,
        isInitialize: true
    };

    var UpgradeLater = {
        None: 0,
        EamilLater: 1,
        UpgradeLater: 2
    }

    var UpgradePromptOnDatetime = null;

    function MoneyTransferConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.moneytransfer;
        self.TransactionStart = ko.observable(false);
        self.ShowPickUpReceiver = ko.observable(false);
        self.ShowTransactionDetails = ko.observable(false);
        self.ShowTransactionDone = ko.observable(false);
        self.ShowQuickPay = ko.observable(false);

        self.SelectRecipientCompleted = ko.observable(false);
        self.AmountToSendCompleted = ko.observable(false);
        self.DeliveryOptionCompleted = ko.observable(false);
        self.SenderPaymentCompleted = ko.observable(false);
        self.PaymentMethodAPI = ko.observable();

        self.recipientLimitionFlag = ko.observable(false);
        self.calculateAgain = false;

        self.upgradeLaterStatus = UpgradeLater.None;
        self.IBVStatus = ko.observable(cs.IBVStatus.Normal);

        self.selectRecipientComponent = ko.observable();

        app.registerComponents(['moneytrasnfer-set-amount', 'delivery-option', 'payment-method', 'mt-add-recipient', 'add-account-deposit', 'add-home-delivery',
        'add-cash-pickup', 'recipient-limitation', 'moneytransfer-input-amount']);

        self.init = function () {
            //prevent visit without permission
            dataModel.checkStatePermision();
        };

        self.dispose = function () {
        };

        self.SelectedReceiver = ko.observable(null);
        self.PaymentMethod = ko.observable(null);
        self.MoneyTransferTransaction = ko.observable(null);
        self.IsAddedPromotionCode = ko.observable(false);
        self.ApplyPromotionCodeSuccessful = ko.observable(false);
        self.ShowPromotionCodeErrorMessage = ko.observable(true);
        self.SenderLevel = ko.observable();
        self.DeliveryOptions = ko.observable({});
        self.PaymentMethods = ko.observable({});
        self.PaymentMethodsFee = ko.observable();
        self.isShow = ko.observable(false);
        self.reLinkPaymentMethod = ko.observable(null);


        self.IsClickToPay = false;

        var initSenderInfo = true;

        self.controllers = {
            '/StartPositionCode/:startPositionCode': function (startPositionCode) {
                self.initSelectCarrierView();
                self.TransactionStart(true);
                //Data Capture: capture transaction info which start from dashboard or left bar.
                cs.CaptureTransactionInfo(startPositionCode, cs.TransactionTypes.MoneyTransfer);
            },
            '/StartPositionCode/:startPositionCode/:receiptNumber': function (startPositionCode, receiptNumber) {
                var transactionInitialPositions;
                if (startPositionCode == "FromRecentTransaction") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromRecentTransaction;
                }else if (startPositionCode == "FromTxnHistory") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromTxnHistory;
                }else if(startPositionCode == "FromManageRecipients"){
					transactionInitialPositions = cs.TransactionInitialPositions.FromManageRecipients;
				}
                cs.AddTransactionStart(
                                          transactionInitialPositions,
                                          cs.QuickWays.QuickPay,
                                          cs.TransactionTypes.MoneyTransfer,
                                          cs.GetDateTimeOffset()
                                      );

                self.ShowPickUpReceiver(false);
                self.ShowTransactionDetails(true);
                self.ShowTransactionDone(false);
                self.ShowQuickPay(true);
                setTimeout(function () {
                    return cs.BaseAjax({
                        url: '/MoneyTransfer/InitializeQuickToPayByReceiptNumber',
                        type: "POST",
                        dataType: "json",
                        contentType: "application/json",
                        data: JSON.stringify({ "receiptNumber": receiptNumber })
                    }, true)
                   .done(function (data) {
                       var paymentMethod = data.PaymentMethod;

                       // remove credit card function
                       if (!paymentMethod.IsBank) {
                           self.QuickPayGoToPaymentMethod(data);
                           return;
                       }

                       if (paymentMethod.IsIBVAccount) {
                           $.when(dataModel.checkIBVNetwork("StartIbvBankAccount", "#VirtualElement"))
                            .done(function (result) {
                                $.when(dataModel.checkIBVBalance(paymentMethod, data.MoneyTransferTransaction.AmountCollected.Value, "#VirtualElement"))
                               .done(function (result) {
                                   //IBV Data capture.
                                   cs.IBVDataCaptureMmodel.UpdateIbvActivity(paymentMethod.PaymentMethodId);

                                   if (result.verifyPassed) {
                                       data.MoneyTransferTransaction.IsIBVVerified = true;
                                       self.InitializeTransactionQuickPay(data);
                                   } else if (!!result && result.isCredentialChanged) {
                                       self.QuickPayGoToPaymentMethod(data);
                                       self.reLinkPaymentMethod(paymentMethod);
                                   } else {
                                       var resultPaymentMethods = self.PaymentMethods();
                                       $.each(resultPaymentMethods, function (index, p) {
                                           p.Selected(p.PaymentMethodId === paymentMethod.PaymentMethodId);
                                       });
                                       self.PaymentMethods(resultPaymentMethods);

                                       self.QuickPayGoToPaymentMethod(data);
                                   }
                                   self.TransactionStart(true);
                               })
                                .fail(function () {
                                    self.InitializeTransactionQuickPay(data);
                                });
                            })
                            .fail(function () {
                                self.InitializeTransactionQuickPay(data);
                            })
                       } else {
                           self.InitializeTransactionQuickPay(data);
                       }
                   })
                   .fail(function (xhr, status) {
                       var exception = $.parseJSON(xhr.responseText);
                       if (exception.ReturnCode == 16842757) {// Receiver was not found.
                           self.initSelectCarrierView();
                       } else if (exception.ReturnCode == 16842756 && exception.ErrorCode && (exception.ErrorCode == 16842758 || exception.ErrorCode == 17170435)) {// Delivery option or Payment method was not found on upgrade.
                           self.QuickPayGoToSetAcount(exception.Data);
                       } else if (exception.ReturnCode == 16842756) { // amount is invalid.
                           self.InitializeTransactionQuickPay(exception.Data);
                       } else if (exception.ReturnCode == 16842758) {// Delivery option was not found.
                           self.QuickPayGoToDeliveryOption(exception.Data);
                       } else if (exception.ReturnCode == 17170435) {// Payment method was not found.
                           self.QuickPayGoToPaymentMethod(exception.Data);
                       } else if (xhr.responseText.indexOf("You have no permission to access it") >= 0) {
                           return app.redirectTo("/SelfService/CustomerDashboard");
                       } else {
                           cs.handleAjaxError(xhr.responseText);
                       }
                       self.TransactionStart(true);
                   });
                });
            },
            "/:receiptNumber/:receiverCardHolderId": function (receiptNumber, receiverCardHolderId) {
                self.ShowQuickPay(false);
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(false);
                self.ShowPickUpReceiver(true);

                self.SelectRecipientCompleted(true);
                self.AmountToSendCompleted(false);
                self.DeliveryOptionCompleted(false);
                self.SenderPaymentCompleted(false);
                self.IsClickToPay = true;
                setTimeout(function () {
                    cs.AjaxByLoading({
                        url: '/MoneyTransfer/InitializeQuickToPayWithNoTransaction',
                        type: "POST",
                        dataType: "json",
                        contentType: "application/json",
                        data: JSON.stringify({ "receiverCardHolderId": receiverCardHolderId })
                    })
                    .done(function (data) {
                        //Data Capture: Initialize transaction start from click to pay.
                        cs.AddTransactionStart(
                                                  cs.TransactionInitialPositions.FromClickToPay,
                                                  cs.QuickWays.NormalPay,
                                                  cs.TransactionTypes.MoneyTransfer
                                              );

                        var tempTransactioModel = ko.mapping.toJS(defaultTransactionModel);
                        tempTransactioModel.FromCurrencyCode = data.SelectedReceiver.FromCurrencyCode;
                        tempTransactioModel.ToCurrencyCode = data.SelectedReceiver.ToCurrencyCode;
                        tempTransactioModel.DisplayRate = data.SelectedReceiver.DisplayRate;
                        tempTransactioModel.Rate = data.SelectedReceiver.Rate;
                        tempTransactioModel.FromCountryImage = data.SelectedReceiver.FromCountryImage;
                        tempTransactioModel.ToCountryImage = data.SelectedReceiver.ToCountryImage;

                        if (tempTransactioModel.AmountToSend.Value) {
                            var amount = tempTransactioModel.AmountToSend.Value;
                            tempTransactioModel.AmountToBeDispensed.Value = cs.keepAmountDecimalPlaces(1.0 * cs.GetOriginalNumber(amount) * tempTransactioModel.Rate);
                            tempTransactioModel.DominantControl = 'AmountToBeSent';
                        } else {
                            tempTransactioModel.AmountToSend.Value = "0.00";
                            tempTransactioModel.AmountToBeDispensed.Value = "0.00";
                        }

                        data.MoneyTransferTransaction = tempTransactioModel;
                        self.QuickPayGoToSetAcount(data);
                        self.TransactionStart(true);

                        $("#input-amount-to-send").trigger("change.attribute.amounttosend", false);
                        var amount = $("#input-amount-to-send").val();
                        if (!amount || amount == '' || amount == 0) {
                            $("#button-set-amount-next").addClass("disabled");
                        }
                    })
                });
            }
        };

        // Start appsflyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        };

        var trackMoneyTransferPageTotalLoads = function () {
            track.trackEvent({
            sendType: track.AF,
            eventCategory: track.CategoryEnum.MTFlow,
            eventAction: track.ActionEnum.ButtonClick,
            eventLabel: "Send Money",
            eventPage: track.PageEnum.SendMoney,
            source: app.page().name,
            eventStructure: track.StructureEnum.InitiatedCheckout,
            eventName: 'af_initiated_checkout_MT'
            });
        }

        var trackViewTransactionDetailsTotalClicks = function () {
            track.trackEvent({
            sendType: track.GA + track.MP,
            eventCategory: track.CategoryEnum.TransactionReceiptPage,
            eventAction: track.ActionEnum.ButtonClick,
            eventLabel: track.LabelEnum.ViewTransactionDetails,
            eventPage: track.PageEnum.TransactionReceiptPage,
            source: app.page().name
            });
        }

        var trackTransactionSuccessfully = function (amount, receiptNumber) {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.MTFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Confirm & Send",
                eventPage: track.PageEnum.SendMoney,
                source: app.page().name,
                eventStructure: track.StructureEnum.Purchase,
                eventName: 'af_purchase_MT',
                amount: amount,
                revenue: amount,
                contentType: 'USA',
                contentId: 'MP',
                currency: 'USD',
                receiptId: receiptNumber
            });
        };

        var trackReceiptEmailTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.EmailReceipt));

        var trackPrintReceiptTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.PrintReceipt));

        var trackFinishTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.Finish));

        var trackRecipientPageTimeOnPage = function () {
            track.trackTimeOnPage({
            sendType: track.GA,
            eventCategory: track.CategoryEnum.TransactionReceiptPage,
            eventAction: track.ActionEnum.Metric,
            eventLabel: 'TimeOnPage',
            eventPage: track.PageEnum.TransactionReceiptPage
            });
        }
        // End appsflyer track event

        self.afterRender = function () {
            dataModel.checkPersonInfo();

            //DataCapture
            self.ResetFalgeForDataCapture();

            $("#main").removeClass();
            $("#main").addClass("mod-c-money-transfer");

            if (self.renderCallBack) {
                self.renderCallBack();
                self.renderCallBack = null;
            }

            app.cacheComponent([
                'select-recipient', 'moneytransfer-input-amount', 'moneytrasnfer-set-amount', 'delivery-option', 'payment-method', 'mt-add-recipient',
                'add-account-deposit', 'add-home-delivery', 'add-cash-pickup', 'recipient-limitation'
            ]);

            getDocumentTypes();
            setTimeout(function () {
                getPaymentMethods();
            });

            trackMoneyTransferPageTotalLoads();
        };

        self.initSelectCarrierView = function () {
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            self.SelectRecipientCompleted(false);
            self.AmountToSendCompleted(false);
            self.DeliveryOptionCompleted(false);
            self.SenderPaymentCompleted(false);
            cs.triggerTab("panel-recipient");
            cs.scrollToTab('panel-recipient');
        }

        self.BackToSelectReceiver = function (element) {
            removeSubmitDocumentSuccessMesssage();
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            cs.triggerTab("panel-recipient");
            cs.scrollToTab('panel-recipient');
        };

        function checkQuickPayEditFunction() {
            if ((self.SenderLevel().TargetLevelId > self.SenderLevel().SourceLevelId || !!self.SenderLevel().OverMaxLimitAmount) &&
                !(self.SenderLevel().IsDocumentSubmited || self.SenderLevel().IsUpgradeLater)) {
                return false;
            }

            return true;
        }

        self.EditReceiver = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!checkMinValue()) {
                return;
            }

            if (!self.CheckQuickPayCalculate()) {
                return;
            }

            if (!checkQuickPayEditFunction()) {
                cs.showErrorMessage("Error", "Please upgrade sender level!");
                return;
            }

            self.BackToSelectReceiver(element);
        }

        self.GoToAmoutToSend = function (recipient) {
            if (recipient) {
                recipient.SelectedDestination = ko.observable();
                self.SelectedReceiver(recipient);
                getDeliveryOptions();

                self.ShowQuickPay(false);
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(false);
                self.ShowPickUpReceiver(true);

                var tempTransactionModel = ko.mapping.toJS(defaultTransactionModel);
                tempTransactionModel.FromCurrencyCode = recipient.FromCurrencyCode;
                tempTransactionModel.ToCurrencyCode = recipient.ToCurrencyCode;
                tempTransactionModel.DisplayRate = recipient.DisplayRate;
                tempTransactionModel.Rate = recipient.Rate;
                tempTransactionModel.FromCountryImage = recipient.FromCountryImage;
                tempTransactionModel.ToCountryImage = recipient.ToCountryImage;

                tempTransactionModel.AmountToSend.Value = ko.observable("0.00");
                tempTransactionModel.AmountToBeDispensed.Value = ko.observable("0.00");
                if (recipient.LastTransactionAmount) {
                    tempTransactionModel.AmountToSend.Value(recipient.LastTransactionAmount.replace('$', ''));
                    tempTransactionModel.AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * cs.GetOriginalNumber(tempTransactionModel.AmountToSend.Value()) * tempTransactionModel.Rate));
                    tempTransactionModel.DominantControl = 'AmountToBeSent';
                }
                self.SenderLevel(defaultSenderLevel);
                transferModel(tempTransactionModel);
                self.MoneyTransferTransaction(tempTransactionModel);
                self.checkLimitAmount(self.MoneyTransferTransaction().AmountToSend.Value());

                self.SelectRecipientCompleted(true);
                self.AmountToSendCompleted(false);
                self.DeliveryOptionCompleted(false);
                self.SenderPaymentCompleted(false);
                self.SelectRecipientCompleted(true);
                $("#input-amount-to-send").trigger("change.attribute.amounttosend", false);
                cs.triggerTab("panel-amount");
                cs.scrollToTab('panel-amount');
            }
            else {
                cs.triggerTab("panel-amount");
                cs.scrollToTab('panel-amount');
            }
        };

        self.GoToAmoutToSendBySelectButton = function (element, recipient) {
            if (cs.isDisabled("button-select-receiver")) {
                return;
            }

            self.GoToAmoutToSend(element, recipient);
        }

        self.BackToAmountToSend = function (element) {
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            cs.triggerTab("panel-amount");
            cs.scrollToTab('panel-amount');
        };

        function removeSubmitDocumentSuccessMesssage() {
            if (self.SenderLevel().IsShowAttachedSuccessMessage) {
                var senderLevel = self.SenderLevel();
                senderLevel.IsShowAttachedSuccessMessage = false;
                self.SenderLevel(senderLevel);
            }
        }

        function checkMinValue() {
            if (!(cs.isAmountValid(self.MoneyTransferTransaction().AmountToSend.Value()) && cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value()) >= 10)) {
                cs.showErrorMessage(commonstrings.commonmessagebox.error, moneytransferstrings.amounttosend.minimumamount);
                return false;
            }

            return true;
        }
        self.GoToDeliveryOption = function () {
            if (!checkMinValue()) {
                return;
            }

            removeSubmitDocumentSuccessMesssage();

            if (cs.isEmptyObject(self.DeliveryOptions())) {
                getDeliveryOptions();
            }
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            self.SelectRecipientCompleted(true);
            self.AmountToSendCompleted(true);

            self.recordFirstClickTimeForAmount.NextStep();

            cs.triggerTab("panel-pickup");
            cs.scrollToTab('panel-pickup');
        };

        self.EditDeliveryOption = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!checkMinValue()) {
                return;
            }
            if (!self.CheckQuickPayCalculate()) {
                return;
            }

            if (!checkQuickPayEditFunction()) {
                cs.showErrorMessage("Error", "Please upgrade sender level!");
                return;
            }

            self.BackToDeliveryOption(null);
        };

        self.GoToSenderPayment = function (deliveryOption) {
            if (!deliveryOption.Selected) {
                self.SelectedReceiver().SelectedDestination(deliveryOption);
                self.PaymentMethod(null);
                self.ShowQuickPay(false);
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(false);
                self.ShowPickUpReceiver(true);
                if (cs.isEmptyObject(self.PaymentMethods())) {
                    getPaymentMethods();
                } else {
                    selectedPaymentMethods(0);//select nothing
                }

                self.SelectRecipientCompleted(true);
                self.AmountToSendCompleted(true);
                self.DeliveryOptionCompleted(true);
                self.SenderPaymentCompleted(false);

                selectedDeliveryOption(deliveryOption.DestinationId);
                self.isShow(false);
                getFeeFromServer(self.SelectedReceiver().CardHolderId, cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value()), self.SelectedReceiver().SelectedDestination().DestinationId);
            }

            cs.triggerTab("panel-payment");
            cs.scrollToTab('panel-payment');
        };

        function getPaymentMethods() {
            return $.when(dataModel.getPaymentMethods())
            .done(function (paymentMethods) {
                self.PaymentMethods(paymentMethods);
            })
            .fail(function () {
                self.PaymentMethods([]);
            });
        }

        self.refreshPaymentMethods = function () {
            getPaymentMethods();
        };

        self.getPaymentMethods = ko.computed(function () {
            var paymentMethods = self.PaymentMethods();
            var paymentMethodsFee = self.PaymentMethodsFee();

            if (cs.isEmptyObject(paymentMethods)) {
                return;
            }
            var bankFee = 0;
            var creditDebitFee = 0;
            if (paymentMethodsFee) {
                $.each(paymentMethodsFee, function (index, fee) {
                    if ([3, 4].indexOf(fee.PaymentMethodTypeId) != -1) {
                        bankFee = fee.Fee;
                    } else {
                        creditDebitFee = fee.Fee;
                    }
                });
            }

            $.each(paymentMethods, function (index, paymentMethod) {
                if (paymentMethod.IsBank) {
                    paymentMethod.Fee = bankFee;
                }

                if (!paymentMethod.IsBank) {
                    paymentMethod.Fee = creditDebitFee;
                }
            });

            return paymentMethods;
        });

        function getFeeFromServer(receiverCardHolderId, amountToSend, destinationId) {
            cs.BaseAjax({
                url: '/MoneyTransfer/GetMoneyTransferFees',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ receiverCardHolderId: receiverCardHolderId, amountToLoad: amountToSend, destinationId: destinationId })
            })
            .done(function (data) {
                self.isShow(true);
                self.PaymentMethodsFee(data);
            });
        }

        function selectedDeliveryOption(destinationId) {
            var deliveryOptions = self.DeliveryOptions();
            $.each(deliveryOptions, function (index, deliveryOption) {
                deliveryOption.Selected = deliveryOption.DestinationId === destinationId;
            });

            self.DeliveryOptions(deliveryOptions);
        }

        function getDeliveryOptions() {
            cs.BaseAjax({
                url: '/MoneyTransfer/GetDeliveryOptions',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ 'receiverCardHolderId': self.SelectedReceiver().CardHolderId })
            })
            .done(function (data) {
                if (data) {
                    $.each(data, function (index, d) {
                        d.Selected = false;
                        if (self.SelectedReceiver().SelectedDestination()) {
                            d.Selected = d.DestinationId == self.SelectedReceiver().SelectedDestination().DestinationId;
                        }
                    })
                }
                else {
                    data = [];
                }

                self.DeliveryOptions(data);
            })
            .fail(function () {
                self.DeliveryOptions([]);
            });
        }

        self.BackToDeliveryOption = function (element) {
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            cs.triggerTab("panel-pickup");
            cs.scrollToTab('panel-pickup');
        };

        self.BackToSenderPayment = function () {
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            cs.triggerTab("panel-payment");
            cs.scrollToTab('panel-payment');
        };

        self.CompletedAddPaymentMethod = function (paymentMethod) {
            var paymentMethods = self.PaymentMethods();
            if (!paymentMethods) {
                paymentMethods = [];
            }
            paymentMethods.push(paymentMethod);
            self.PaymentMethods(paymentMethods);

            if (paymentMethod.IsIBVAccount) {
                self.GoToTransactionDetails(paymentMethod);
            } else {
                self.GoToTransactionDetails(paymentMethod, true);
            }
        };

        self.CompletedAddDeliveryOption = function (deliveryOption) {
            var deliveryOptions = self.DeliveryOptions();
            var tempDeliveryOptions = deliveryOptions.filter(function (d) {
                if (deliveryOption.DeliveryOptionType == 1) {//Account Deposit
                    return d.DeliveryOptionType != 1;
                } else if (deliveryOption.DeliveryOptionType == 4) {//Home Delivery 
                    return d.DeliveryOptionType != 4;
                }

                return true;
            });

            tempDeliveryOptions.push(deliveryOption);

            self.DeliveryOptions(tempDeliveryOptions)

            self.GoToSenderPayment(deliveryOption);
        };

        function resetPromotionCode() {
            self.MoneyTransferTransaction().PromotionCode = null;
            self.IsAddedPromotionCode(false);
            self.ApplyPromotionCodeSuccessful(false);
        }

        self.CancelVerification = function () {
            self.GoToTransactionDetails(self.PaymentMethodAPI().removeVerifyingStatus(), true);
        }

        self.GoToTransactionDetails = function (paymentMethod, ignoreConvert, ignoreRefresh) {
            //IBV Data capture.
            cs.IBVDataCaptureMmodel.UpdateIbvActivity(paymentMethod.PaymentMethodId);

            if (!paymentMethod.SelectedToCalculate) {
                self.MoneyTransferTransaction().IsIBVVerified = false;
                if (paymentMethod.IsBank && !paymentMethod.IsIBVAccount && !ignoreConvert) {
                    self.PaymentMethodAPI().addVerifyingStatus(paymentMethod);
                    return;
                }

                if (paymentMethod.IsBank && paymentMethod.IsIBVAccount) {
                    self.PaymentMethodAPI().removeVerifyingStatus();
                }

                self.IBVStatus(cs.IBVStatus.Normal);
                self.MoneyTransferTransaction().PaymentMethodId = paymentMethod.PaymentMethodId;
                self.PaymentMethod(paymentMethod);
                if (!ignoreRefresh) {
                    selectedPaymentMethods(paymentMethod.PaymentMethodId);
                }

                resetPromotionCode();
                $.when(Calculate(self.SelectedReceiver().CardHolderId, self.SelectedReceiver().SelectedDestination()))
                .done(function () {
                    if (paymentMethod.IsIBVAccount && !ignoreConvert) {
                        $.when(dataModel.checkIBVBalance(paymentMethod, self.MoneyTransferTransaction().AmountCollected.Value))
                        .done(function (result) {
                            if (!!result && result.verifyPassed) {
                                self.MoneyTransferTransaction().IsIBVVerified = true;
                                switchTransactionDetail();
                            } else if (!!result && result.isCredentialChanged) {
                                self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                return;
                            } else {
                                var resultPaymentMethods = self.PaymentMethods();
                                $.each(resultPaymentMethods, function (index, p) {
                                    p.SelectedToCalculate = false;
                                });
                                self.PaymentMethods(resultPaymentMethods);

                                return;
                            }
                        })
                        .fail(function () {
                            switchTransactionDetail();
                        });
                    } else {
                        switchTransactionDetail();
                    }
                })
                .fail(function () {
                    resetSelectedPaymentMethod();
                });
            } else {
                self.ShowPickUpReceiver(false);
                self.ShowTransactionDetails(true);
                cs.SlideToBottom();
            }
        };

        function switchTransactionDetail() {
            self.ShowPickUpReceiver(false);
            self.ShowTransactionDone(false);
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(true);
            self.SenderPaymentCompleted(true);
            cs.SlideToBottom();

            //DataCapture
            self.UpdateDataCaptureTransactionFee();
        }

        function selectedPaymentMethods(paymentMethodId, element) {
            var paymentMethods = self.PaymentMethods();

            $.when(dataModel.getLastSendMoneyFeeCalculator(element))
            .done(function (data) {
                $.each(paymentMethods, function (index, paymentMethod) {
                    if (paymentMethodId == 0 && self.SelectedReceiver() && !self.SelectedReceiver().LastTransactionAmount) {//Fee calculate
                        var previewTransaction = data || {};
                        paymentMethodTypeId = previewTransaction.PaymentMethodTypeId;

                        if (previewTransaction) {
                            var typeArr = [];
                            if (paymentMethodTypeId) {
                                if ([cs.PaymentMethodType.CreditCard, cs.PaymentMethodType.DebitCard].indexOf(paymentMethodTypeId) != -1) {
                                    typeArr = [cs.PaymentMethodType.CreditCard, cs.PaymentMethodType.DebitCard];
                                } else {
                                    typeArr = [cs.PaymentMethodType.Checking, cs.PaymentMethodType.Savings];
                                }
                            }

                            paymentMethod.Selected((typeArr.indexOf(paymentMethod.AccountTypeId) != -1 && paymentMethod.IsDefault));
                            paymentMethod.SelectedToCalculate = false;
                        }
                    } else {
                        paymentMethod.Selected(paymentMethod.PaymentMethodId === paymentMethodId);
                        paymentMethod.SelectedToCalculate = paymentMethod.PaymentMethodId === paymentMethodId;
                        if (paymentMethod.IsBank) {
                            paymentMethod.IsVerifying(false);
                        }
                    }
                });

                self.PaymentMethods(paymentMethods);
            });
        };

        function resetSelectedPaymentMethod() {
            var paymentMethods = self.PaymentMethods();

            $.each(paymentMethods, function (index, paymentMethod) {
                paymentMethod.SelectedToCalculate = false;
            });

            self.PaymentMethods(paymentMethods);
        }

        self.RecipientLimitationCalculate = function () {
            $.when(Calculate(self.SelectedReceiver().CardHolderId, self.SelectedReceiver().SelectedDestination()))
             .done(function () {
                 self.ShowPickUpReceiver(false);
                 self.ShowTransactionDone(false);
                 self.ShowTransactionDetails(true);
                 self.SenderPaymentCompleted(true);
                 cs.SlideToBottom();
                 self.calculateAgain = false;
             })
        };

        self.BindEventToAmount = function (element, isSend) {
            var element = $(element);
            var oldValue = element.val();
            element.off("input.attribute.amount");
            element.on("input.attribute.amount", function () {
                if (cs.IsMobileDevice())
                    cs.formatAmountForInput(element, oldValue);
                if (oldValue != element.val()) {
                    oldValue = element.val();
                    dataModel.MoneyTransferCalculate(self.MoneyTransferTransaction, isSend, element.val());
                }
            });
            element.off("focus.attribute.amount");
            element.on("focus.attribute.amount", function (e) {
                oldValue = element.val();
            });
        }

        self.RefeshPaymentMethodFeesList = function (paymentMethodFees) {
            var tempPaymentMethodFees = ko.mapping.toJS(self.PaymentMethods().SelfServiceFees);
            if (!tempPaymentMethodFees) {
                tempPaymentMethodFees = new Array();
            }

            if (paymentMethodFees && paymentMethodFees.Fees.length > 0) {
                for (var i = 0; i < paymentMethodFees.Fees.length; i++) {
                    tempPaymentMethodFees.push(paymentMethodFees.Fees[i]);
                }
            }

            ko.mapping.fromJS(tempPaymentMethodFees, {}, self.PaymentMethods().SelfServiceFees);
        }

        self.EditSenderPayment = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!checkMinValue()) {
                return;
            }

            if (!self.CheckQuickPayCalculate()) {
                return;
            }

            if (!checkQuickPayEditFunction()) {
                cs.showErrorMessage("Error", "Please upgrade sender level!");
                return;
            }

            self.BackToSenderPayment();
        };

        self.GoBack = function () {
            setTimeout(function () {
                cs.fitTextAmountField($("#input-amount-to-send"), cs.keepAmountDecimalPlaces($("#input-amount-to-send").val()));
                cs.fitTextAmountField($("#input-amount-to-be-dispensed"), cs.keepAmountDecimalPlaces($("#input-amount-to-be-dispensed").val()));
            });
        }

        // begin: transaction
        function Calculate(receiverCardHolderId, deliveryOption, element, isQuickPay) {
            var amountToSend = parseFloat(cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value()));
            var amountToBeDispensed = parseFloat(cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToBeDispensed.Value()));
            if ((!isNaN(amountToSend) && amountToSend != 0)
               || (!isNaN(amountToBeDispensed) && amountToBeDispensed != 0)) {

                var transaction = ko.toJS(self.MoneyTransferTransaction());
                transaction.AmountCollected.Value = 0;
                transaction.AmountToSend.Value = amountToSend;
                transaction.AmountToBeDispensed.Value = amountToBeDispensed;
                transaction.SelectedRecipientId = receiverCardHolderId;
                transaction.DeliveryOptionId = self.SelectedReceiver().SelectedDestination().DestinationId;
                getFeeFromServer(self.SelectedReceiver().CardHolderId, cs.GetOriginalNumber(amountToSend), self.SelectedReceiver().SelectedDestination().DestinationId);

                var deferred = $.Deferred();
                cs.AjaxBySpinnerOrLoading({
                    url: '/MoneyTransfer/SelfServiceCalculator',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "transactionModel": transaction })
                }, element)
                .done(function (result) {
                    if (checkAmountChange(amountToSend)) {
                        return;
                    }

                    result.IsAgree = ko.observable(self.MoneyTransferTransaction().IsAgree());
                    transferModel(result);
                    self.MoneyTransferTransaction(result);
                    deferred.resolve();
                })
                .fail(function (xhr, status) {
                    if (checkAmountChange(amountToSend)) {
                        return;
                    }

                    self.calculateAgain = true;
                    if ($.parseJSON(xhr.responseText).Priority != null) {
                        if ($.parseJSON(xhr.responseText).Priority == 1) {
                            ModelSessionTimeOut$RevealAndLogout();
                            return;
                        }
                    }

                    var data = $.parseJSON(xhr.responseText);

                    if (data.returnCode != null) {
                        if (data.returnCode == -146) {
                            // Here will go to money transfer promo code logic.
                            self.MoneyTransferTransaction().PromotionCode('');
                            self.ApplyPromotionCodeSuccessful(false);
                            self.ShowPromotionCodeErrorMessage(element != 'virtualElement');
                            $.when(Calculate(self.SelectedReceiver().CardHolderId, self.SelectedReceiver().SelectedDestination(), element, isQuickPay))
                            .done(function () {
                                //ToDo: Set On Held

                                quickPayCalculateSuccessfully = true;

                                //DataCapture
                                self.UpdateDataCaptureTransactionFee();
                                deferred.reject(xhr, status);
                            })
                        } else {
                            ExceedLimitHandler(data);
                            deferred.reject(xhr, status);
                        }
                    } else {
                        cs.showError($.parseJSON(xhr.responseText));
                        deferred.reject(xhr, status);
                    }
                });

                return deferred;
            }
        }

        function checkAmountChange(amountToSend) {
            if (self.MoneyTransferTransaction() && Number(cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value())) != Number(cs.GetOriginalNumber(amountToSend))) {
                return true;
            }

            return false;
        }

        function ExceedLimitHandler(data) {
            var errorCode = parseInt(data.returnCode);
            if (errorCode == -336) { // SEND_MONEY_RECIPIENT_LIMIT_EXCEEDED_ADDITIONAL_FIELDS
                self.MoneyTransferTransaction().PayoutLimitAdditionalFields = data.limitAdditionalFields;
                $("#ConfirmCaption").html(data.Caption);
                $("#ConfirmMessage").html(data.Message);
                $("#ConfirmOk").html("<span class='button-text'>OK</span>");
                $("#ConfirmCancel").hide();

                if ($("#ConfirmOk").hasClass('close-reveal-modal')) {
                    $("#ConfirmOk").removeClass('close-reveal-modal');
                }

                $("#ConfirmOk").off('click');
                $("#ConfirmOk").on('click', function () {
                    self.recipientLimitionFlag(true);
                    cs.closeModalCallBack('modal-payoutlimit-additional-fields', function () {
                        self.recipientLimitionFlag(false);
                    });
                    cs.openModal('modal-payoutlimit-additional-fields');
                    $("#ConfirmOk").off('click');
                });

                cs.openModal('modal-confirm');
            }
        }

        function convertTransactionModel(data) {
            data.IsAgree = ko.observable(false);
            data.isRefreshDeliveryOption = ko.observable(false);
            data.AmountToSend.Value = ko.observable(data.AmountToSend.Value);
            data.TempSendToAmount = ko.observable(data.AmountToSend.Value);
            data.TempAmountToBeDispensed = ko.observable(data.AmountToBeDispensed.Value);
            data.AmountToBeDispensed.Value = ko.observable(data.AmountToBeDispensed.Value);
            data.PromotionCode = ko.observable(data.PromotionCode);
            data.TransactionStatusCode = ko.observable(data.TransactionStatusCode);

            return data;
        }

        self.ApplyPromo = function (element, isQuickPay) {
            if (cs.isDisabled(element)) {
                return;
            }

            self.recordApplyPromoCodeActionTime.ApplyPromoCode();

            if (!CheckAmount()) {
                return;
            }

            if (!checkMinValue()) {
                return;
            }

            if (!self.MoneyTransferTransaction().PromotionCode() || self.MoneyTransferTransaction().PromotionCode().trim().length <= 0) {
                self.MoneyTransferTransaction().PromotionCode("");
                cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.promocode.emptypromocode, function () {
                    self.IsAddedPromotionCode(false);
                    self.ApplyPromotionCodeSuccessful(false);
                    cs.closeModal();
                });
                return;
            }
            $(element).children().last().css("position", "relative");
            $(element).children().last().css("right", "auto");
            $(element).children().last().css("top", "auto");
            $(element).children().last().css("margin-top", "auto");
            self.MoneyTransferTransaction().PromotionCode(cs.CustomTrim(self.MoneyTransferTransaction().PromotionCode()));

            if (isQuickPay && element && element != 'virtualElement') {
                element = null;
            }
          
            return $.when(Calculate(self.SelectedReceiver().CardHolderId, self.SelectedReceiver().SelectedDestination(), element, isQuickPay))
            .done(function () {
                $("#input-promo-code").val('');
                self.IsAddedPromotionCode(true);
                self.ApplyPromotionCodeSuccessful(true);

                //DataCapture
                self.UpdateDataCaptureTransactionFee();
            })
            .fail(function (xhr, status) {
                var data = $.parseJSON(xhr.responseText);

                if (data.returnCode == -146) {
                    self.MoneyTransferTransaction().PromotionCode("");
                    self.IsAddedPromotionCode(true);
                    self.ApplyPromotionCodeSuccessful(false);
                }
            })
        };

        self.RemovePromotionCode = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            $.when(ClearPromo())
            .always(function () {
                self.IsAddedPromotionCode(false);
                self.ApplyPromotionCodeSuccessful(false);

                //DataCapture
                self.UpdateDataCaptureTransactionFee();
            });
        };

        function ClearPromo() {
            self.MoneyTransferTransaction().PromotionCode("");
            Calculate(self.SelectedReceiver().CardHolderId, self.SelectedReceiver().SelectedDestination());
        }

        self.QuickPayConfirm = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!self.MoneyTransferTransaction().IsAgree()) {
                $('#confirmError').fadeIn();
                return;
            }

            if (!checkMinValue()) {
                return;
            }

            if (!self.CheckQuickPayCalculate()) {
                return;
            }

            var paymentMethod = self.PaymentMethod();
            if (paymentMethod.IsIBVAccount) {
                $.when(dataModel.checkIBVNetwork())
                .done(function (result) {
                    $.when(dataModel.checkIBVBalance(paymentMethod, self.MoneyTransferTransaction().AmountCollected.Value))
                    .done(function (result) {
                        if (result.verifyPassed) {
                            self.MoneyTransferTransaction().IsIBVVerified = true;
                            self.Confirm(element);
                        } else {
                            var resultPaymentMethods = self.PaymentMethods();
                            $.each(resultPaymentMethods, function (index, p) {
                                p.SelectedToCalculate = false;
                            });
                            self.PaymentMethods(resultPaymentMethods);
                            return;
                        }
                    })
                    .fail(function () {
                        self.Confirm(element);
                    });
                })
                .fail(function () {
                    self.Confirm(element);
                })
            } else {
                self.Confirm(element);
            }
        };

        self.transStatus = new cs.executeStatus();

        self.AgreementChanged = function (element) {
            if ($(element).is(':checked')) {
                $('#confirmError').fadeOut();
            }
            return true;
        };

        self.Confirm = function (element) {
            if (self.transStatus.isExecuting()) {
                return;
            }

            if (cs.isDisabled(element)) {
                return;
            }

            if (!self.MoneyTransferTransaction().IsAgree()) {
                $('#confirmError').fadeIn();
                return;
            }

            self.transStatus.setExecuting();
            $.when(checkLimitForConfirm())
            .done(function (data) {
                if (!self.ApplyPromotionCodeSuccessful()) {
                    self.MoneyTransferTransaction().PromotionCode("");
                }
                var transaction = ko.mapping.toJS(self.MoneyTransferTransaction());
                transaction.AmountToSend.Value = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value());
                transaction.AmountToBeDispensed.Value = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToBeDispensed.Value());
                transaction.IsQuickPay = self.ShowQuickPay();
                transaction.SelectedRecipientId = self.SelectedReceiver().CardHolderId;
                transaction.DeliveryOptionId = self.SelectedReceiver().SelectedDestination().DestinationId;
                transaction.UpgradeLater = self.upgradeLaterStatus;
                transaction.IsIBVVerified = self.MoneyTransferTransaction().IsIBVVerified;

                cs.AjaxByLoading({
                    url: '/MoneyTransfer/SelfServiceTransaction',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "transactionModel": transaction })
                }, true)
                .done(function (result) {
                    cs.AddActivityInfo(28, null, true);

                    //Init components view
                    self.TransactionStart(false);
                    self.SelectRecipientCompleted(false);
                    self.DeliveryOptionCompleted(false);

                    var isAgree = self.MoneyTransferTransaction().IsAgree();
                    transferModel(result);
                    self.MoneyTransferTransaction(result);
                    self.MoneyTransferTransaction().IsAgree(isAgree);

                    //DataCapture
                    if (self.MoneyTransferTransaction().ReceiptNumber.length === 20) {
                        cs.UpdateTransactionData({
                            receiptNumber: self.MoneyTransferTransaction().ReceiptNumber,
                            transactionTypeId: self.MoneyTransferTransaction().TransactionType,
                            tax: self.MoneyTransferTransaction().FeeTaxes.Value,
                            fee: self.MoneyTransferTransaction().FeeCharged.Value,
                            total: self.MoneyTransferTransaction().AmountCollected.Value
                        })
                    }

                    app.senderInfo().SenderLevel().TargetLevelId = self.SenderLevel().TargetLevelId;
                    self.ShowQuickPay(false);
                    self.ShowPickUpReceiver(false);
                    self.ShowTransactionDetails(false);
                    self.ShowTransactionDone(true);

                    cs.RegisterExpandCollapse();
                    cs.SlideToTop();
                    if (self.SenderLevel().IsUpgradeLater && !self.SenderLevel().IsDocumentSubmited) {
                        var tempResult = dataModel.uploadDocumentNotSubmit();
                        if (!tempResult) {
                            dataModel.uploadDocuments(self.uploadDocumentTypes, false);
                        }
                    }

                    if (app.senderInfo() != null) {
                        app.senderInfo().GetSenderLevel(element);
                    }

                    self.transStatus.complete();

                    trackTransactionSuccessfully(cs.getValue(result.AmountToSend.Value), self.MoneyTransferTransaction().ReceiptNumber.trim());

                    trackRecipientPageTimeOnPage();
                    track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionReceiptPage, track.PageEnum.TransactionReceiptPage);
                })
                .fail(function (xhr, status) {
                    try {
                        self.transStatus.complete();

                        if (status == 'timeout') {
                            cs.showErrorMessage(commonstrings.messagebox.moneytransferfailed, commonstrings.messagebox.timeout);
                            return;
                        }

                        var data = $.parseJSON(xhr.responseText);
                        if (data != null && data.returnCode == -460) { //Exceed sender level limitation.
                            $.when(checkTransactionAmount(self.SelectedReceiver().CardHolderId, transaction.AmountToSend.Value, null))
                           .done(function (data) {
                               self.SenderLevel(data);
                           })
                        } else if (data != null && data.returnCode == -7) {
                            cs.showError(data, function () {
                                $.when(cs.closeModal())
                                .done(function () {
                                    self.GoToAmoutToSend(self.SelectedReceiver());
                                });
                            });
                        }
                        else if (data != null && data.returnCode == -462) {
                            cs.AddActivityInfo(29, null, true);
                            ShowPaymentsMethodFailDialog();
                        } else if (data != null && data.returnCode == -481) {
                            cs.BaseAjax({
                                url: '/PaymentMethod/GetCurrentPaymentProvider',
                                type: 'get',
                                dataType: 'json'
                            })
                            .done(function (result) {
                                app.senderInfo().PosPaymentConfig(result);
                            });
                            getPaymentMethods();

                            // Async call
                            cs.AddActivityInfo(29, null, true);
                            ShowPaymentsMethodFailDialog();
                        } else {
                            cs.handleAjaxError(xhr.responseText);
                        }
                    } catch (e) {
                        cs.handleAjaxError(xhr.responseText);
                    }
                });
            })
            .fail(function () {
                if (app.senderInfo() != null) {
                    app.senderInfo().GetSenderLevel(element);
                }

                self.transStatus.complete();
            });
        };

        function ShowPaymentsMethodFailDialog() {
            $.when(cs.showErrorMessage(commonstrings.messagebox.paymenterror, commonstrings.messagebox.paymentnotsuccess + " " + "<a id='payment-method-link'>" + commonstrings.messagebox.paymentmethod + "</a>" + " " + commonstrings.messagebox.tryagain))
            .done(function () {
                $("#payment-method-link").click(function () {
                    cs.closeModal();
                    if (self.ShowQuickPay()) {
                        self.EditSenderPayment();
                    } else {
                        self.BackToSenderPayment();
                    }
                    resetSelectedPaymentMethod();
                });
            });
        }

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.MoneyTransferTransaction().ReceiptNumber, element);

            trackReceiptEmailTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.EmailReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        };

        self.PrintMoneyTransferReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/Customers/SelfServicePrintStandardReceipt',
                dataType: "html",
                cache: false,
                data: { 'receiptNumber': self.MoneyTransferTransaction().ReceiptNumber, 'senderEmailAddress': app.senderInfo().Customer().CustomerBasic.EmailAddress() }
            }, element)
           .done(function (result) {
               cs.PrintTransaction(result, element);
           });

            trackPrintReceiptTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.PrintReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        };

        self.GetTransaction = function () {
            var transaction = ko.mapping.toJS(self.MoneyTransferTransaction());
            transaction.AmountToSend.Value = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value());
            transaction.AmountToBeDispensed.Value = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToBeDispensed.Value());
            transaction.IsQuickPay = self.ShowQuickPay();
            transaction.SelectedRecipientId = self.SelectedReceiver().CardHolderId;
            transaction.DeliveryOptionId = self.SelectedReceiver().SelectedDestination().DestinationId;

            return transaction;
        }

        // end: transaction

        // begin: Quick Pay
        self.InitializeTransactionQuickPay = function (data) {
            self.PaymentMethod(data.PaymentMethod);
            data.SelectedReceiver.SelectedDestination = ko.observable(data.SelectedReceiver.SelectedDestination);
            self.SelectedReceiver(data.SelectedReceiver);
            getDeliveryOptions();
            mergeObject(defaultTransactionModel, data.MoneyTransferTransaction);
            self.quickPayCheckLimitAmount(data.MoneyTransferTransaction);

            getFeeFromServer(self.SelectedReceiver().CardHolderId, cs.GetOriginalNumber(data.MoneyTransferTransaction.AmountToSend.Value), self.SelectedReceiver().SelectedDestination().DestinationId);
            $.when(getPaymentMethods())
            .done(function () {
                selectedPaymentMethods(data.PaymentMethod.PaymentMethodId, "#VirtualElement");
            });
            self.TransactionStart(true);
            self.SelectRecipientCompleted(true);
            self.AmountToSendCompleted(true);
            self.DeliveryOptionCompleted(true);
            self.SenderPaymentCompleted(true);
            quickPayCalculateSuccessfully = true;

            //DataCapture
            cs.UpdateTransactionData({
                transactionTypeId: data.MoneyTransferTransaction.TransactionType,
                tax: data.MoneyTransferTransaction.FeeTaxes.Value,
                fee: data.MoneyTransferTransaction.FeeCharged.Value,
                total: data.MoneyTransferTransaction.AmountCollected.Value,
                amount: data.MoneyTransferTransaction.AmountToSend.Value,
                receiverId: self.SelectedReceiver().CardHolderId,
                correspondentId: self.SelectedReceiver().SelectedDestination().DestinationId
            })
        };

        function mergeObject(source, target) {
            for (var property in source) {
                if (typeof target[property] === 'undefined') {
                    target[property] = source[property];
                }
            }
        }

        var quickPayCalculateSuccessfully = false;
        self.QuickPayCalculate = function (isSend, isQuickPayCalculate, element) {
            if (cs.isOpeningModal()) {
                return;
            }

            $("#send-amount-input").val(cs.keepAmountDecimalPlaces(cs.GetOriginalNumber($("#send-amount-input").val())));
            $("#receiver-amount-input").val(cs.keepAmountDecimalPlaces(cs.GetOriginalNumber($("#receiver-amount-input").val())));

            self.MoneyTransferTransaction().DominantControl = isSend == true ? 'AmountToBeSent' : 'AmountToBeReceived';
            if (!CheckAmount()) {
                return;
            }

            if (self.PaymentMethod().IsIBVAccount) {
                var resultPaymentMethods = self.PaymentMethods();
                $.each(resultPaymentMethods, function (index, p) {
                    p.SelectedToCalculate = false;
                });
                self.PaymentMethods(resultPaymentMethods);
            }

            quickPayCalculateSuccessfully = false;
            $("#money-transfer-quicktopay-loading-icon").fadeIn();
            if (self.MoneyTransferTransaction().PromotionCode && cs.CustomTrim(self.MoneyTransferTransaction().PromotionCode()) != "") {
                return $.when(self.ApplyPromo(element, isQuickPayCalculate))
                .done(function () {
                    quickPayCalculateSuccessfully = true;

                    //DataCapture
                    self.UpdateDataCaptureTransactionFee();
                })
                .fail(function () {
                    quickPayCalculateSuccessfully = false;
                })
                .always(function () {
                    $("#money-transfer-quicktopay-loading-icon").fadeOut();
                })
            }
            else {
                return $.when(Calculate(self.SelectedReceiver().CardHolderId, self.SelectedReceiver().SelectedDestination(), element, isQuickPayCalculate))
                .done(function () {
                    quickPayCalculateSuccessfully = true;
                    cs.scrollToElement($('.quick-pay-href #input-amount-to-send'));

                    //DataCapture
                    self.UpdateDataCaptureTransactionFee();
                })
                .fail(function () {
                    quickPayCalculateSuccessfully = false;
                })
                .always(function () {
                    $("#money-transfer-quicktopay-loading-icon").fadeOut();
                })
            }
        };

        self.QuickPayGoToDeliveryOption = function (data) {
            var temporarySenderLevel = cs.clone(defaultSenderLevel);
            temporarySenderLevel.isInitialize = false;
            self.SenderLevel(temporarySenderLevel);
            transferModel(data.MoneyTransferTransaction);
            self.MoneyTransferTransaction(data.MoneyTransferTransaction);
            data.SelectedReceiver.SelectedDestination = ko.observable();
            self.SelectedReceiver(data.SelectedReceiver);

            getDeliveryOptions();
            self.SelectedReceiver().SelectedDestination(null);
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            self.SelectRecipientCompleted(true);
            self.DeliveryOptionCompleted(false);
            self.SenderPaymentCompleted(false);

            if (data.MoneyTransferTransaction.SelfServiceLimitHold) {
                self.checkLimitAmount(data.MoneyTransferTransaction.AmountToSend.Value());
                self.AmountToSendCompleted(false);
                cs.triggerTab("panel-amount");
                cs.scrollToTab('panel-amount');
            } else {
                self.AmountToSendCompleted(true);
                cs.triggerTab("panel-pickup");
                cs.scrollToTab('panel-pickup');
            }
        };

        self.QuickPayGoToPaymentMethod = function (data) {
            var temporarySenderLevel = cs.clone(defaultSenderLevel);
            temporarySenderLevel.isInitialize = false;
            self.SenderLevel(temporarySenderLevel);
            data.SelectedReceiver.SelectedDestination = ko.observable(data.SelectedReceiver.SelectedDestination);
            self.SelectedReceiver(data.SelectedReceiver);
            getDeliveryOptions();
            getFeeFromServer(self.SelectedReceiver().CardHolderId, cs.GetOriginalNumber(data.MoneyTransferTransaction.AmountToSend.Value), self.SelectedReceiver().SelectedDestination().DestinationId);
            transferModel(data.MoneyTransferTransaction);
            self.MoneyTransferTransaction(data.MoneyTransferTransaction);

            self.PaymentMethod(null);
            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            self.SelectRecipientCompleted(true);
            self.SenderPaymentCompleted(false);

            $.when(checkTransactionAmount(self.SelectedReceiver().CardHolderId, data.MoneyTransferTransaction.AmountToSend.Value(), '#virtualElement'))
            .done(function (data) {
                self.SenderLevel(data);
                if (!(self.SenderLevel().TargetLevelId > self.SenderLevel().SourceLevelId || self.SenderLevel().OverMaxLimitAmount > 0)) {
                    self.MoneyTransferTransaction().SelfServiceLimitHold = false;
                    self.AmountToSendCompleted(true);
                    self.DeliveryOptionCompleted(true);
                    cs.triggerTab("panel-payment");
                    cs.scrollToTab('panel-payment');
                }
                else {
                    self.AmountToSendCompleted(false);
                    self.DeliveryOptionCompleted(false);
                    cs.triggerTab("panel-amount");
                    cs.scrollToTab('panel-amount');
                }
            });
        };

        self.QuickPayGoToSetAcount = function (data) {
            data.SelectedReceiver.SelectedDestination = ko.observable();
            self.SelectedReceiver(data.SelectedReceiver);
            self.SenderLevel(defaultSenderLevel);
            transferModel(data.MoneyTransferTransaction);
            self.MoneyTransferTransaction(data.MoneyTransferTransaction);
            getDeliveryOptions();

            self.ShowQuickPay(false);
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowPickUpReceiver(true);

            self.SelectRecipientCompleted(true);
            self.AmountToSendCompleted(false);
            self.DeliveryOptionCompleted(false);
            self.SenderPaymentCompleted(false);
            if (data.MoneyTransferTransaction.SelfServiceLimitHold) {
                self.checkLimitAmount(data.MoneyTransferTransaction.AmountToSend.Value());
            } else {
                var temporarySenderLevel = cs.clone(defaultSenderLevel);
                temporarySenderLevel.isInitialize = false;
                self.SenderLevel(temporarySenderLevel);
            }

            cs.triggerTab("panel-amount");
            cs.scrollToTab('panel-amount');
        };

        self.CheckQuickPayCalculate = function () {
            if (!CheckAmount()) {
                return false;
            }

            if (quickPayCalculateSuccessfully == false) {
                self.QuickPayCalculate(self.MoneyTransferTransaction().DominantControl == 'AmountToBeSent');
                return false;
            }

            return true;
        };

        self.UpdateDataCaptureTransactionFee = function () {
            //DataCapture
            cs.UpdateTransactionData({
                transactionTypeId: self.MoneyTransferTransaction().TransactionType,
                tax: self.MoneyTransferTransaction().FeeTaxes.Value,
                fee: self.MoneyTransferTransaction().FeeCharged.Value,
                total: self.MoneyTransferTransaction().AmountCollected.Value
            })
        }

        function CheckAmount() {
            if (self.MoneyTransferTransaction().DominantControl == 'AmountToBeSent') {
                if (!cs.isAmountValid(self.MoneyTransferTransaction().AmountToSend.Value())) {
                    cs.showErrorMessage(moneytransferstrings.amounttosend.error, moneytransferstrings.amounttosend.sendamountinvalid);
                    return false;
                }
            } else {
                if (!cs.isAmountValid(self.MoneyTransferTransaction().AmountToBeDispensed.Value())) {
                    cs.showErrorMessage(moneytransferstrings.amounttosend.error, moneytransferstrings.amounttosend.inputvalidreceiveamount);
                    return false;
                }
            }

            return true;
        };
        // end: Quick Pay

        self.checkLimitAmount = function (sendValue) {
            self.upgradeLaterStatus = UpgradeLater.None;

            self.AmountToSendCompleted(false);
            self.DeliveryOptionCompleted(false);
            self.SenderPaymentCompleted(false);
            self.SelectRecipientCompleted(true);

            if (sendValue < 10) {
                var temporarySenderLevel = cs.clone(defaultSenderLevel);
                temporarySenderLevel.isInitialize = false;
                self.SenderLevel(temporarySenderLevel);

                return $.Deferred().reject();
            }

            return $.when(checkTransactionAmount(self.SelectedReceiver().CardHolderId, sendValue, '#virtualElement'))
                .done(function (data) {
                    if (Number(cs.GetOriginalNumber($('#input-amount-to-send').val())) != Number(cs.GetOriginalNumber(sendValue))) {
                        return $.Deferred().reject();
                    }

                    self.SenderLevel(data);
                    if (!(self.SenderLevel().TargetLevelId > self.SenderLevel().SourceLevelId || self.SenderLevel().OverMaxLimitAmount > 0)) {
                        self.MoneyTransferTransaction().SelfServiceLimitHold = false;
                    }
                    self.SelectedReceiver().SelectedDestination(null);
                    self.PaymentMethod(null);

                    selectedDeliveryOption(0);//select nothing
                    selectedPaymentMethods(0, '#virtualElement');//select nothing

                    //DataCapture: datetime of prompt appear.
                    UpgradePromptOnDatetime = cs.GetDateTimeOffset();
                })
        }

        function checkLimitForConfirm() {
            var deffered = $.Deferred();

            $.when(checkTransactionAmount(self.SelectedReceiver().CardHolderId, self.MoneyTransferTransaction().AmountToSend.Value()))
                .done(function (data) {
                    if ((data.TargetLevelId > data.SourceLevelId || !!data.OverMaxLimitAmount) &&
                    !(data.IsDocumentSubmited || data.IsUpgradeLater) && (!self.SenderLevel().IsUpgradeLater || (self.SenderLevel().IsUpgradeLater && self.SenderLevel().TargetLevelId !== data.TargetLevelId &&
                        data.TargetLevelId !== data.SourceLevelId))) {
                        self.SenderLevel(data);
                        cs.showContinue({ Caption: moneytransferstrings.needUpgrade.error, Message: moneytransferstrings.needUpgrade.content }, function () {
                            if (!self.ShowQuickPay()) {
                                self.SelectedReceiver().SelectedDestination(null);
                                self.PaymentMethod(null);

                                selectedDeliveryOption(0);//select nothing
                                selectedPaymentMethods(0);//select nothing

                                self.SelectRecipientCompleted(true);
                                self.AmountToSendCompleted(false);
                                self.DeliveryOptionCompleted(false);
                                self.SenderPaymentCompleted(false);

                                self.BackToAmountToSend();
                            }

                            cs.closeModal();
                        });
                        deffered.reject();
                    } else {
                        deffered.resolve();
                    }
                })
            .fail(function () {
                deffered.reject();
            });
            return deffered;
        }

        self.quickPayCheckLimitAmount = function (transactionModel, element) {
            self.upgradeLaterStatus = UpgradeLater.None;

            if (transactionModel.AmountToSend.Value < 10) {
                var temporarySenderLevel = cs.clone(defaultSenderLevel);
                temporarySenderLevel.isInitialize = false;
                self.SenderLevel(temporarySenderLevel);

                transferModel(transactionModel);
                restoreIsAgree(transactionModel);
                self.MoneyTransferTransaction(transactionModel);

                cs.enableElements(['quick-pay-edit-receiver', 'quick-pay-edit-delivery-option', 'quick-pay-edit-payment', 'input-promo-code', 'promo-code-apply', 'promo-code-remove']);
                return;
            }

            return $.when(checkTransactionAmount(self.SelectedReceiver().CardHolderId, transactionModel.AmountToSend.Value, "#VirtualElement"))
             .done(function (data) {
                 if (checkAmountChange(transactionModel.AmountToSend.Value)) {
                     return;
                 }

                 self.SenderLevel(data);
                 transferModel(transactionModel);
                 restoreIsAgree(transactionModel);
                 self.MoneyTransferTransaction(transactionModel);

                 if (!data.OverMaxLimitAmount) {
                     $.when(self.QuickPayCalculate(transactionModel.DominantControl == 'AmountToBeSent', true, element))
                        .always(function () {
                            cs.enableElements(['quick-pay-edit-receiver', 'quick-pay-edit-delivery-option', 'quick-pay-edit-payment', 'input-promo-code', 'promo-code-apply', 'promo-code-remove']);
                        });
                 } else {
                     cs.enableElements(['quick-pay-edit-receiver', 'quick-pay-edit-delivery-option', 'quick-pay-edit-payment', 'input-promo-code', 'promo-code-apply', 'promo-code-remove']);
                 }

                 //DataCapture: datetime of prompt appear.
                 UpgradePromptOnDatetime = cs.GetDateTimeOffset();
             }).fail(function () {
                 cs.enableElements(['quick-pay-edit-receiver', 'quick-pay-edit-delivery-option', 'quick-pay-edit-payment', 'input-promo-code', 'promo-code-apply', 'promo-code-remove', 'money-transfer-confirm-done']);
             });
        };

        function restoreIsAgree(transactionModel) {
            if (self.MoneyTransferTransaction()) {
                transactionModel.IsAgree(self.MoneyTransferTransaction().IsAgree());
            }
            return transactionModel;
        }

        function transferModel(transactionModel) {
            transactionModel.IsAgree = ko.observable(ko.toJS(transactionModel.IsAgree));
            transactionModel.PromotionCode = ko.observable(ko.toJS(transactionModel.PromotionCode));

            // For upgrade
            if (self.MoneyTransferTransaction() && self.ShowQuickPay()) {
                transactionModel.AmountToSend.Value = ko.observable($('#input-quick-pay-amount-to-send').val());
                transactionModel.AmountToBeDispensed.Value = ko.observable($('#input-quick-pay-amount-to-be-dispensed').val());
            } else {
            transactionModel.AmountToSend.Value = ko.observable(ko.toJS(transactionModel.AmountToSend.Value));
            transactionModel.AmountToBeDispensed.Value = ko.observable(ko.toJS(transactionModel.AmountToBeDispensed.Value));
        }
        }

        function convertToTransaction(transactionModel) {
            transactionModel.IsAgree = ko.toJS(transactionModel.IsAgree);
            transactionModel.PromotionCode = ko.toJS(transactionModel.PromotionCode);

            // For upgrade
            transactionModel.AmountToSend.Value = ko.toJS(transactionModel.AmountToSend.Value);
            transactionModel.AmountToBeDispensed.Value = ko.toJS(transactionModel.AmountToBeDispensed.Value);
        }

        self.upgradeNow = function (senderLevel) {
            //Data Capture.
            cs.UpgradeDataCaptureModel.InitalIndependentUpgrade(senderLevel, "Upgrade Now", UpgradePromptOnDatetime);

            if (!dataModel.openUpgrade(senderLevel.SourceLevelId, senderLevel.TargetLevelId, true))//Open wrapper
            {
                self.SenderLevel(senderLevel);
            }
        };

        self.upgradeLater = function (transactionModel, senderLevel, isEmailLater) {
            transferModel(transactionModel);
            self.MoneyTransferTransaction(transactionModel);
            self.SenderLevel(senderLevel);
            self.GoToDeliveryOption();

            if (isEmailLater) {
                self.upgradeLaterStatus = UpgradeLater.EamilLater;
            } else {
                self.upgradeLaterStatus = UpgradeLater.UpgradeLater;
                cs.UpgradeDataCaptureModel.AbandonedUpgrade();
            }

            //Data Capture.
            if (cs.UpgradeDataCaptureModel.GetUpgradeInitiator() == "Email Later") {
                cs.UpgradeDataCaptureModel.InitalIndependentUpgrade(senderLevel, "Email Later", UpgradePromptOnDatetime);
            }
        }

        window.closeFinishUpgradeLater = function () {
            var transactionModel = self.MoneyTransferTransaction();
            var senderLevel = self.SenderLevel();
            senderLevel.IsDocumentSubmited = false;
            senderLevel.IsUpgrading = false;
            senderLevel.IsUpgradeLater = true;

            if (self.ShowQuickPay()) {
                self.quickPayUpgradeLater(transactionModel, senderLevel, false);
            } else {
                self.upgradeLater(transactionModel, senderLevel, false);
            }
        }

        window.closeEmailLater = function (result) {
            if (result) {
                var transactionModel = self.MoneyTransferTransaction();
                var senderLevel = self.SenderLevel();
                senderLevel.IsDocumentSubmited = false;
                senderLevel.IsUpgrading = false;
                senderLevel.IsUpgradeLater = true;

                if (self.ShowQuickPay()) {
                    self.quickPayUpgradeLater(transactionModel, senderLevel, true);
                } else {
                    self.upgradeLater(transactionModel, senderLevel, true);
                }
            }
        }

        self.quickPayUpgradeLater = function (transactionModel, senderLevel, isEmailLater) {
            transferModel(transactionModel);
            self.MoneyTransferTransaction(transactionModel);
            self.SenderLevel(senderLevel);

            if (isEmailLater) {
                self.upgradeLaterStatus = UpgradeLater.EamilLater;
            } else {
                self.upgradeLaterStatus = UpgradeLater.UpgradeLater;
                cs.UpgradeDataCaptureModel.AbandonedUpgrade();
            }

            //Data Capture.
            if (cs.UpgradeDataCaptureModel.GetUpgradeInitiator() == "Email Later") {
                cs.UpgradeDataCaptureModel.InitalIndependentUpgrade(senderLevel, "Email Later", UpgradePromptOnDatetime);
            }
        };

        self.uploadDocumentTypes;
        function getDocumentTypes() {
            return dataModel.getDocumentTypes(1, 3)
            .done(function (data) {
                self.uploadDocumentTypes = data;
            });
        }

        window.continueTransaction = function () {
            getDocumentTypes();
            app.senderInfo().GetSenderLevel("#VirtualElement");
            var senderLevel = self.SenderLevel();
            senderLevel.IsDocumentSubmited = true;
            senderLevel.IsUpgrading = false;
            senderLevel.IsShowAttachedSuccessMessage = true;
            self.SenderLevel(senderLevel);
            self.GoToDeliveryOption();
        }

        self.submitDocuments = function (documentTypes, element) {
            $.when(dataModel.uploadDocuments(documentTypes, true, element))
            .done(function (data) {
                getDocumentTypes();
                app.senderInfo().GetSenderLevel("#VirtualElement");
                var senderLevel = self.SenderLevel();
                senderLevel.IsDocumentSubmited = true;
                senderLevel.IsUpgrading = false;
                senderLevel.IsShowAttachedSuccessMessage = true;
                self.SenderLevel(senderLevel);

                //DataCapture.
                cs.UpgradeDataCaptureModel.UpdateSubmittedInformation(true);
            })
            .fail(function (xhr, status) {
                try {
                    var tempError = $.parseJSON(xhr.responseText);
                    if (tempError.ExceptionCode == -488) {//Document has been submited.
                        cs.showContinue(tempError, function () {
                            $.when(cs.closeModal())
                            .done(function () {
                                getDocumentTypes();
                                var senderLevel = self.SenderLevel();
                                senderLevel.IsDocumentSubmited = true;
                                senderLevel.IsUpgrading = false;
                                senderLevel.IsShowAttachedSuccessMessage = true;
                                self.SenderLevel(senderLevel);
                            });
                        });
                    }
                } catch (e) { }
            });

            self.uploadDocumentTypes = documentTypes;
        }

        self.refreshDocumentTypes = function (documentTypes) {
            self.uploadDocumentTypes = documentTypes;
        }

        //DataCapture.
        self.recordFirstClickTimeForAmount = (function () {
            var firstClickDateTime = null;
            var isAddingNew = true;
            var originAmount = null;

            return {
                ClickAmountAndReceiver: function (/*Optional Initial amount for quick pay, click to pay.*/ initAmountForQuickPay) {
                    if (firstClickDateTime == null) {
                        firstClickDateTime = cs.GetDateTimeOffset();
                    }

                    if (originAmount == null && initAmountForQuickPay != undefined && initAmountForQuickPay != null) {
                        originAmount = initAmountForQuickPay;
                    }
                },
                NextStep: function (amount) {
                    var newAmount = null;

                    if (amount != undefined && amount != null) {
                        newAmount = amount;                                                                                         //For quick pay.
                    } else {
                        newAmount = self.MoneyTransferTransaction() && self.MoneyTransferTransaction().AmountToSend.Value();          //For normal pay.
                    }

                    var isNewOne = (Number(originAmount) != Number(newAmount));

                    if (!isNewOne) {
                        isAddingNew = false;
                    } else {
                        isAddingNew = true;
                    }

                    if (self.MoneyTransferTransaction()) {
                        if (firstClickDateTime == null) { //If not change the amount, it's the same datetime for start and end.
                            cs.AddTransactionStep(/*TransactionStepId*/ 2, 'Amount', newAmount);
                        } else {
                            cs.AddTransactionStep(/*TransactionStepId*/ 2, 'Amount', newAmount, firstClickDateTime, isAddingNew);
                        }

                        //Cache the amount, it will compare with new value.
                        originAmount = newAmount;

                        //Reset the datetime for next action.
                        firstClickDateTime = null;
                    }
                },
                ResetFalg: function () {
                    firstClickDateTime = null;
                    amountChangeCount = 0;
                    isAddingNew = true;
                }
            }
        })()

        self.recordApplyPromoCodeActionTime = (function () {
            var firstClickDateTime = null;

            return {
                ClickInPromoCode: function () {
                    if (firstClickDateTime == null) {
                        firstClickDateTime = cs.GetDateTimeOffset();
                    }
                },
                ApplyPromoCode: function () {
                    cs.AddTransactionStep(/*TransactionStepId*/ 12, 'Promotion Code', self.MoneyTransferTransaction().PromotionCode(), firstClickDateTime, false);
                    firstClickDateTime = null;
                },
                ResetFalg: function () {
                    firstClickDateTime = null;
                }
            };
        })();

        self.ResetFalgeForDataCapture = function () {
            self.recordFirstClickTimeForAmount.ResetFalg();
            self.recordApplyPromoCodeActionTime.ResetFalg();
        };


        // For normal amount to send.
        self.checkAmount = function (element, amount, isSend, isDirectCall) {

            if (((isSend && self.MoneyTransferTransaction().AmountToBeDispensed.Value() == '0.00') || (!isSend && self.MoneyTransferTransaction().AmountToSend.Value() == '0.00')) && !amount) {
                $(element).val("0.00");
                $("#input-amount-to-send").trigger("change.attribute.amounttosend", false);
                    return;
                }
            self.AmountToSendCompleted(false);
            self.DeliveryOptionCompleted(false);
            self.SenderPaymentCompleted(false);

            //select Original Number
            if (isSend) {
                originalAmount = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value());
            } else {
                originalAmount = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToBeDispensed.Value());
            }
            rate = self.MoneyTransferTransaction().Rate;
            amount = cs.LimitNumber(element, isSend, originalAmount, rate);
            if (cs.IsMobileDevice()) {
                mobileFormatAmount(amount, isSend);
            } else {
                formatAmount(amount, isSend);
            }

            var temporarySenderLevel = cs.clone(defaultSenderLevel);
            temporarySenderLevel.isInitialize = true;
            self.SenderLevel(temporarySenderLevel);

            checkAmountInput(amount, isSend);
        };

        var originalSendAmount = null;
        var originalReceiverAmount = null;

        self.checkAmountBlur = function (amount, isSend) {
            if (!checkValueChanged(amount, isSend)) {
                return false;
            }

            originalSendAmount = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value());
            originalReceiverAmount = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToBeDispensed.Value());

            amount = cs.GetOriginalNumber(amount);
            if (isSend) {
                self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(amount));
                self.MoneyTransferTransaction().AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.MoneyTransferTransaction().Rate));
                setTextFit('#input-amount-to-be-dispensed');
            } else {
                self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount / self.MoneyTransferTransaction().Rate));
                self.MoneyTransferTransaction().AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(amount));
                setTextFit('#input-amount-to-send');
            }

            return true;
        };

        function checkValueChanged(amount, isSend) {
            if (isSend) {
                if (Number(cs.GetOriginalNumber(amount)) === Number(originalSendAmount)) {
                    return false;
                }
            } else {
                if (Number(cs.GetOriginalNumber(amount)) === Number(originalReceiverAmount)) {
                    return false;
                }
            }

            return true;
        };

        var checkAmountTimer;

        function checkAmountInput(amount, isSend) {
            amount = cs.GetOriginalNumber(amount);

            if (amount != "") {
                $("#input-amount-to-send").trigger("change.attribute.amounttosend", true);
            } else if (amount == "") {
                $("#input-amount-to-send").trigger("change.attribute.amounttosend", false);
                amount = "0.00";
            }

            var sendAmount = 0;
            if (isSend) {
                sendAmount = amount;
                self.MoneyTransferTransaction().AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.MoneyTransferTransaction().Rate));
                self.MoneyTransferTransaction().DominantControl = 'AmountToBeSent';
            } else {
                sendAmount = 1.0 * amount / self.MoneyTransferTransaction().Rate;
                self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(sendAmount));
                self.MoneyTransferTransaction().DominantControl = 'AmountToBeReceived';
            }

            if (cs.IsMobileDevice()) {
                self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(sendAmount));
            } else {
                if (isSend) {
                    self.MoneyTransferTransaction().AmountToSend.Value(sendAmount);
                } else {
                    self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(sendAmount));
                }
            }

            if (isSend) {
                setTextFit('#input-amount-to-be-dispensed');
            } else {
                setTextFit('#input-amount-to-send');
            }

            if (checkAmountTimer) {
                clearTimeout(checkAmountTimer);
            }

            checkAmountTimer = setTimeout(function () {
                self.checkLimitAmount(self.MoneyTransferTransaction().AmountToSend.Value());
            }, 500);
        };

        function setTextFit(element) {
            if (!element) {
                return;
            }

            element = element.indexOf('#') == 0 ? element : '#' + element;
            $(element).triggerHandler('keyup.inputfit');
        }

        function mobileFormatAmount(amount, isSend) {
            if (isSend) {
                self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount));
                self.MoneyTransferTransaction().AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.MoneyTransferTransaction().Rate));
            } else {
                self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount / self.MoneyTransferTransaction().Rate));
                self.MoneyTransferTransaction().AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount));
            }
        };

        function formatAmount(amount, isSend) {
            if (isSend) {
                $("#input-amount-to-be-dispensed").val(cs.keepAmountDecimalPlaces(1.0 * amount * self.MoneyTransferTransaction().Rate));
            } else {
                $("#input-amount-to-send").val(cs.keepAmountDecimalPlaces(1.0 * amount / self.MoneyTransferTransaction().Rate));
            }
        };

        self.upgradeNowAmountSection = function () {
            self.SenderLevel().IsUpgrading = true;
            self.upgradeNow(self.SenderLevel());
        }

        self.upgradeLaterAmountSection = function () {
            var isEmailLater = !self.SenderLevel().IsUpgrading;
            self.MoneyTransferTransaction().TransactionStatusCode = 'O';
            self.SenderLevel().IsDocumentSubmited = false;
            self.SenderLevel().IsUpgrading = false;
            self.SenderLevel().IsUpgradeLater = true;

            convertToTransaction(self.MoneyTransferTransaction());
            self.upgradeLater(self.MoneyTransferTransaction(), self.SenderLevel(), isEmailLater);
        };

        self.amountSectionNext = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            self.GoToDeliveryOption(null);
        };

        self.setDefaultSenderLevel = function (isInitialize) {
            var temporarySenderLevel = cs.clone(defaultSenderLevel);
            temporarySenderLevel.isInitialize = isInitialize;
            self.SenderLevel(temporarySenderLevel);
        }

        // For quick pay.
        var quickPayCheckAmountTimer;
        self.checkAmountQuickPaySection = function (element, amount, isSend) {
            self.ShowPromotionCodeErrorMessage(false);

            if (amount == "") {
                $("#input-quick-pay-amount-to-send").trigger("change.attribute.amounttosend", false);
                $(element).val("0.00");
            } else if (amount != "") {
                $("#input-quick-pay-amount-to-send").trigger("change.attribute.amounttosend", true);
            }
            
            amount = getSendAmount(element, isSend);
            setAmountForQuickPaySection(amount, isSend);

            if (quickPayCheckAmountTimer) {
                clearTimeout(quickPayCheckAmountTimer);
            }

            self.setDefaultSenderLevel(true);

            if (!self.ApplyPromotionCodeSuccessful()) {
                self.MoneyTransferTransaction().PromotionCode('');
            }

            cs.disableElements(['quick-pay-edit-receiver', 'quick-pay-edit-delivery-option', 'quick-pay-edit-payment', 'input-promo-code', 'promo-code-apply', 'promo-code-remove', 'money-transfer-confirm-done']);
            quickPayCheckAmountTimer = setTimeout(function () {
                self.quickPayCheckLimitAmount(ko.mapping.toJS(self.MoneyTransferTransaction), 'virtualElement');
            }, 500);
        }


        function checkAmountIsValid(amount, isSend) {
            if (isSend) {
                if (!amount && self.MoneyTransferTransaction().AmountToBeDispensed.Value() == '0.00') {
                    return false;
                }
            } else {
                if (!amount && self.MoneyTransferTransaction().AmountToSend.Value() == '0.00') {
                    return false;
                }
            }

            return true;
        };

        function getSendAmount(element, isSend) {
            if (isSend) {
                originalAmount = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToSend.Value());
            } else {
                originalAmount = cs.GetOriginalNumber(self.MoneyTransferTransaction().AmountToBeDispensed.Value());
            }
            rate = self.MoneyTransferTransaction().Rate;
            amount = cs.LimitNumber(element, isSend, originalAmount, rate);

            return amount;
        };

        function setAmountForQuickPaySection(amount, isSend) {
            if (cs.IsMobileDevice()) {
                mobileFormatAmount(amount, isSend);
            } else {
                if (isSend) {
                    self.MoneyTransferTransaction().AmountToSend.Value(amount);
                    self.MoneyTransferTransaction().AmountToBeDispensed.Value(cs.keepAmountDecimalPlaces(1.0 * amount * self.MoneyTransferTransaction().Rate));
                } else {
                    self.MoneyTransferTransaction().AmountToSend.Value(cs.keepAmountDecimalPlaces(1.0 * amount / self.MoneyTransferTransaction().Rate));
                    self.MoneyTransferTransaction().AmountToBeDispensed.Value(amount);
                }
            }

            if (isSend) {
                self.MoneyTransferTransaction().DominantControl = 'AmountToBeSent';
                setTextFit('#input-quick-pay-amount-to-be-dispensed');
            } else {
                self.MoneyTransferTransaction().DominantControl = 'AmountToBeReceived';
                setTextFit('#input-quick-pay-amount-to-send');
            }
        };

        self.checkAmountBlurForQuickPaySection = function (amount, isSend) {
            if (!self.checkAmountBlur(amount, isSend)) {
                return;
            }
            var amountToSend = 0;
            if (isSend) {
                amountToSend = (parseFloat(cs.GetOriginalNumber(amount))).toFixed(2);
            } else {
                amountToSend = (parseFloat(cs.GetOriginalNumber(amount)) / self.MoneyTransferTransaction().Rate).toFixed(2)
            }

            self.recordFirstClickTimeForAmount.NextStep(amountToSend);
        };

        self.upgradeLaterQuickPaySection = function () {
            var isEmailLater = !self.SenderLevel().IsUpgrading;
            self.MoneyTransferTransaction().TransactionStatusCode = 'O';
            self.SenderLevel().IsDocumentSubmited = false;
            self.SenderLevel().IsUpgrading = false;
            self.SenderLevel().IsUpgradeLater = true;

            self.quickPayUpgradeLater(ko.mapping.toJS(self.MoneyTransferTransaction), self.SenderLevel(), isEmailLater);
        };

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.TransactionReceiptPage,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.TransactionReceiptPage,
                    source: app.page().name
                });
            });
        };

        self.viewTransactionDetails = function () {
            var transaction = self.MoneyTransferTransaction();
            if (transaction.SelfServiceLimitHold) {
                dataModel.viewTransactionHistoryWithLimitHoldByReceiptNumber(transaction.ReceiptNumber.trim());
            } else {
                dataModel.viewTransactionHistoryByReceiptNumber(transaction.ReceiptNumber.trim());
            }

            trackViewTransactionDetailsTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.ViewTransactionDetails);
        }

        self.cancelTransaction = function () {
            app.senderInfo().GoToDashboard();

            if (self.ShowTransactionDone()) {
                trackFinishTotalClicks();
                track.trackTimeOnPageForPageLink(track.LabelEnum.Finish);
            }
        };

        function checkTransactionAmount(receiverCardHolderId, amountToSend, element) {
            if (!cs.isAmountValid(amountToSend) || amountToSend < 10) {
                return $.Deferred().reject();
            }

            return cs.AjaxBySpinnerOrLoading({
                url: '/Customers/CheckTransactionAmount',
                datType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    "amountToSend": cs.GetOriginalNumber(amountToSend),
                    "receiverCardHolderId": receiverCardHolderId
                })
            }, element, true).
            done(function (data) {
                data.isInitialize = false;
                return data;
            })
            .fail(function (xhr,status) {
                try {
                    var resultCode = $.parseJSON($.parseJSON(xhr.responseText).Message).exceptionCode

                    if (resultCode == "-498") {//Invalid recipient country
                        cs.showErrorMessage(commonstrings.commonmessagebox.error, $.parseJSON($.parseJSON(xhr.responseText).Message).reason, function () {
                            self.initSelectCarrierView();
                            self.SelectedReceiver(null);
                            if (self.selectRecipientComponent() && typeof self.selectRecipientComponent().clearSelectedRecipient === 'function')
                            {
                                self.selectRecipientComponent().clearSelectedRecipient();
                            }
                            cs.closeModal();
                        });
                    }
                    else {
                        cs.handleAjaxError($.parseJSON($.parseJSON(xhr.responseText).Message).reason, false);
                    }
                }
                catch (e) {
                    cs.handleAjaxError(xhr.responseText, false);
                }
            });
        }
    }

    return new MoneyTransferConsumerViewModel();
});