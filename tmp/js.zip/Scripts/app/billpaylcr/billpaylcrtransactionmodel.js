﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation'], function (ko, cs, app, dataModel) {
    return function BillPayLCRTransactionModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);
        var defaultSelectedServiceType = ko.mapping.toJS(self.SelectedServiceType);
        var defaultServiceTypes = ko.mapping.toJS(self.ServiceTypes);
        self.IsAgree = ko.observable(false);
        self.IsQuickToPay = false;

        self.promoCode = ko.observable("");

        var defaultTransaction = null;
        var firstLoad = 0;

        self.GetSelectedLCRBillingAccountToCalculate = function (billingAccount, element) {
            return cs.AjaxBySpinner({
                url: '/BillPayLCR/GetSeletcedToCalculate',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "selectedBillingAccountId": billingAccount.RppsBillingAccountId, "isRppsBillingAccount": billingAccount.IsRppsBillingAccount })
            }, element)
          .done(function (result) {
              ko.mapping.fromJS(result, {}, self);
              defaultTransaction = ko.mapping.toJSON(self);
          })
        }

        self.Confirm = function (element) {
            return cs.AjaxByLoading({
                url: '/BillPayLCR/SelfServiceLCRTransaction',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
                .done(function (result) {
                    var tempTransaction = ko.mapping.toJS(result);
                    ko.mapping.fromJS(tempTransaction, {}, self);
                });
        }

        self.FinishBillPayLCRTransaction = function (element) {
            var printerType = $.cookie("PrinterType");
            if (printerType == "receipt") {
                closePrinter();
            }
            closeModal();
            $("#button-modal-confirmed-billpay-done").addClass('now-loading');
            app.navigateToCustomerDashboardBySpinner(element);
        }

        self.IsPromotionCodeValid = ko.observable(false);

        self.ApplyPromo = function (element) {
            var tempPromoCode = cs.CustomTrim(self.PromotionCode());
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            return cs.AjaxByLoading({
                url: '/BillPayLCR/SelfServiceLCRCalculate',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
            .done(function (result) {
                var tempTransaction = ko.mapping.toJS(result);
                ko.mapping.fromJS(tempTransaction, {}, self);
                self.IsPromotionCodeValid(true);

                self.promoCode(tempPromoCode);

                //DataCapture.
                require("BillPayLCRBillPayLCRConsumer").UpdateDataCaptureTransactionFee();
            })
            .fail(function () {
                self.PromotionCode("");
                self.BillPayLCRCaculate(element);
                self.promoCode(tempPromoCode);
                self.IsPromotionCodeValid(false);
            });

        }

        function ClearTransaction() {
            ko.mapping.fromJSON(defaultTransaction, {}, self);
        }

        self.BillPayLCRCaculate = function (element) {
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            return cs.AjaxByLoading({
                url: '/BillPayLCR/SelfServiceLCRCalculate',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            })
             .done(function (result) {
                 var tempTransaction = ko.mapping.toJS(result);
                 ko.mapping.fromJS(tempTransaction, {}, self);

                 //DataCapture.
                 require("BillPayLCRBillPayLCRConsumer").UpdateDataCaptureTransactionFee();
             })
        }

        self.SelectedPaymentMethod = function (accountModel, element) {
            ko.mapping.fromJS(accountModel, {}, app.page().data.PaymentMethod().TobeUpdatedPaymentMethod);
            self.SelectedPaymentMethodId(accountModel.PaymentMethodId());
            app.page().data.PaymentMethod().UpdateTobeUpdatedPaymentMethod(accountModel);
            self.PromotionCode("");
            self.promoCode("");
            self.IsPromotionCodeValid(false);
            return cs.AjaxBySpinner({
                url: '/BillPayLCR/SelfServiceLCRCalculate',
                datatype: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, element)
            .done(function (result) {
                var tempTransaction = ko.mapping.toJS(result);
                ko.mapping.fromJS(tempTransaction, {}, self);
            });
        }

        self.CleanPromo = function () {
            self.PromotionCode("");
            self.promoCode("");
            self.IsPromotionCodeValid(false);
            self.BillPayLCRCaculate();
        }

        self.ClearTransactionExternalCondation = function () {
            self.IsAgree(false);

            if (self.PromotionCode() != "") {
                self.CleanPromo();
            }
        };

        self.GetLCRServiceTypes = function (RppsBillingAccountId, isRppsBillingAccount, element) {
            return cs.AjaxBySpinner({
                url: '/BillPayLCR/GetLCRServiceTypes',
                datatype: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "selectedBillingAccountId": RppsBillingAccountId, 'amountToSend': cs.GetOriginalNumber(self.AmountToSend.Value()), "isRppsBillingAccount": isRppsBillingAccount })
            }, element)
            .done(function (result) {
                ko.mapping.fromJS(result, {}, self.ServiceTypes);
                //ko.mapping.fromJS(defaultSelectedServiceType, {}, self.SelectedServiceType);
            })
        }

        self.IsBankAccountSelected = ko.observable(false);

        self.ServiceTypeSelected = function (serviceType) {
            var tempServiceType = ko.mapping.toJS(serviceType);
            ko.mapping.fromJS(tempServiceType, {}, self.SelectedServiceType);
            self.IsBankAccountSelected(false);
            self.SelectedFeeValue(serviceType.Fee.Symbol() + serviceType.Fee.Value());

            if ((serviceType.PaymentMethodTypeId() == 3 || serviceType.PaymentMethodTypeId() == 4)) {
                self.IsBankAccountSelected(true);
            }
            else {
                self.IsBankAccountSelected(false);
            }
            return;
        }

        self.AgreeChange = ko.computed(function () {
            if (self.IsAgree()) {
                $("#confirmError").fadeOut();
            }
        });

        self.CheckAmount = function () {
            if (!cs.isAmountValid(self.AmountDestination.Value())) {
                cs.showErrorMessage("Error", "Please input a valid amount");
                return false;
            }

            return true;
        };

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.ReceiptNumber(), element);
        };

        self.PrintBillPayLCRReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/BillPayLCR/SelfServicePrintBillPayLCRStandardReceipt',
                dataType: "html",
                cache: false
            }, element)
             .done(function (result) {
                 cs.PrintTransaction(result, element);
             });
        }
    }
});