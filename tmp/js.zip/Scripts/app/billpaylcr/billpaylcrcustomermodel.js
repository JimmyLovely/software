﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation', 'Plugins', 'knockout.validation.extended'], function (ko, cs, app, dataModel) {
    return function BillPayLCRCustomerModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);
        var defaultBillingAccount = ko.mapping.toJSON(self.TobeAddedBillingAccount);
        var originalBillingAccount;
        var selectedGroupId;
        var hasSelected = 0;
        self.IsDelete = false;
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.BillingAccountRequiredInfo = ko.observable();

        var searchLcrBillerModal = { OriginalSearchCondition: '', AutoCompleteList: new Array(), OriginalKey: 0, OriginalType: '', MappingOldBillerName: '' };

        self.AccountAddLCRBillingAccountFlag = ko.observable(false);
        self.LayoutAddLCRBillingAccountFlag = ko.observable(false);
        self.BillpayAddLCRBillingAccountFlag = ko.observable(false);

        //0 No error
        //1 No matched biller
        //2 Required field.
        self.billerNameValid = ko.observable(0);

        self.RecentlyBillingAccounts = ko.computed(function () {
            var newArray = new Array();
            if (self.BillingAccounts() == null) {
                return null;
            }
            for (var i = 0; i < self.BillingAccounts().length ; i++) {
                if (i < 4) {
                    newArray.push(self.BillingAccounts()[i]);
                }
                else {
                    break;
                }
            }
            return newArray;
        });

        self.ChangeStatus = function () {
            self.IsDelete = !self.IsDelete;
        }

        self.GetSelected = function (billingAccount, element) {
            var account = ko.mapping.toJS(billingAccount);
            ko.mapping.fromJS(account, {}, self.SelectedBillingAccount);
            originalBillingAccount = account;
            return app.page().data.BillPayLCRTransaction().GetSelectedLCRBillingAccountToCalculate(account, element);
        }

        self.TobeAddedBillingAccount.AccountNumber.extend({
            required: {
                params: true,
                message: 'Account no. is required'
            },
            equal: {
                onlyIf: function () { return self.TobeAddedBillingAccount.IsAccountNumberInvalid() },
                message: 'No matched biller'
            }
        }).isModified(false);

        self.TobeAddedBillingAccount.RetypeAccountNumber.extend({
            equal: {
                onlyIf: function () { return !cs.equals(self.TobeAddedBillingAccount.AccountNumber(), self.TobeAddedBillingAccount.RetypeAccountNumber(), true) },
                message: "Values of account no. and confirm account no. don't match"
            },
        });

        self.TobeAddedBillingAccount.FirstName.extend({
            minTrimLength: { params: 2, message: 'Minimum length of first name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
            equal: {
                onlyIf: function () { return self.TobeAddedBillingAccount.FirstName() != "" && cs.IsInvalidName(self.TobeAddedBillingAccount.FirstName()) != 0 },
                message: function () { return cs.IsInvalidName(self.TobeAddedBillingAccount.FirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
            }
        }).isModified(false);

        self.TobeAddedBillingAccount.LastName.extend({
            minTrimLength: { params: 2, message: 'Minimum Length of last name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
            equal: {
                onlyIf: function () { return self.TobeAddedBillingAccount.LastName() != "" && cs.IsInvalidName(self.TobeAddedBillingAccount.LastName()) != 0 },
                message: function () { return cs.IsInvalidName(self.TobeAddedBillingAccount.LastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
            }
        }).isModified(false);

        self.TobeAddedBillingAccount.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.TobeAddedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.TobeAddedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            }
        }).isModified(false);

        self.SelectedBillingAccount.AccountNumber.extend({
            required: {
                params: true,
                message: 'Account no. is required'
            },
            equal: {
                onlyIf: function () { return self.SelectedBillingAccount.IsAccountNumberInvalid() },
                message: 'No matched biller'
            }
        });

        self.SelectedBillingAccount.RetypeAccountNumber.extend({
            equal: {
                onlyIf: function () { return !cs.equals(self.SelectedBillingAccount.AccountNumber(), self.SelectedBillingAccount.RetypeAccountNumber(), true) },
                message: "Values of account no. and confirm account no. don't match"
            },
        });

        self.SelectedBillingAccount.FirstName.extend({
            minTrimLength: { params: 2, message: 'Minimum Length of first name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
            equal: {
                onlyIf: function () { return self.SelectedBillingAccount.FirstName() != "" && cs.IsInvalidName(self.SelectedBillingAccount.FirstName()) != 0 },
                message: function () { return cs.IsInvalidName(self.SelectedBillingAccount.FirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
            }
        }).isModified(false);

        self.SelectedBillingAccount.LastName.extend({
            minTrimLength: { params: 2, message: 'Minimum Length of last name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
            equal: {
                onlyIf: function () { return self.SelectedBillingAccount.LastName() != "" && cs.IsInvalidName(self.SelectedBillingAccount.LastName()) != 0 },
                message: function () { return cs.IsInvalidName(self.SelectedBillingAccount.LastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
            }
        }).isModified(false);

        self.SelectedBillingAccount.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.SelectedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.SelectedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            }
        }).isModified(false);

        function LogTobeAddedBillingAccount(billingAccountModel) {
            var message = new Array();

            if (!billingAccountModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + billingAccountModel.AccountNumber.error);
            }
            if (!billingAccountModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + billingAccountModel.RetypeAccountNumber.error);
            }

            cs.logException("BillPayLCRBillerPicker.TobeAddedBillingAccount", JSON.stringify(message));
        }

        function BillPayLCRBillingAccountDelete(billingAccount, element) {
            return cs.AjaxBySpinner({
                url: '/BillPayLCR/SelfServiceDeleteLCRBillingAccount',
                contentType: "application/json",
                type: "Get",
                cache: false,
                data: { "billingAccountId": billingAccount.RppsBillingAccountId(), "isRppsBillingAccount": billingAccount.IsRppsBillingAccount() }
            }, element)
            .done(function () {
                var tempBillingAccounts = self.BillingAccounts();
                for (var i = 0; i < tempBillingAccounts.length; i++) {
                    if (tempBillingAccounts[i].RppsBillingAccountId() == billingAccount.RppsBillingAccountId()) {
                        tempBillingAccounts.splice(i, 1);
                    }
                }
                ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);
            });
        }

        function DisabledBillingAccountValidattion(billingAccount) {
            billingAccount.AccountNumber.isModified(false);
            billingAccount.RetypeAccountNumber.isModified(false);
            billingAccount.EditablePhoneNumber.isModified(false);
            billingAccount.FirstName.isModified(false);
            billingAccount.LastName.isModified(false);
            billingAccount.IsAccountNumberInvalid(false);
            searchLcrBillerModal.MappingOldBillerName = '';
        }

        self.UpdateBillingAccount = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            $.when(self.HasBillersMatchAccountNumber(self.SelectedBillingAccount))
            .done(function () {
                UpdateLCRAccount(self.SelectedBillingAccount, element);
            })
        }

        function GetAdditionalInfo(element) {
            var tempData = ko.mapping.toJS(self.SelectedBillingAccount);
            delete tempData.Countries;

            return cs.AjaxBySpinner({
                url: "/BillPayLCR/GetSelfServiceAdditionalInfo",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountViewModel": ko.mapping.toJS(tempData) }),
            }, element)
            .done(function (data) {
                if (data.AdditionalInfoAvaliable) {
                    var tempFields = data.BillingAccountRequiredInfo.Fields;
                    self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                    cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                    self.AdditionalInfoAvaliable(true);
                    cs.isCancelCloseModalCallBack = true;
                    cs.closeModalCallBack('modal-update-additional-info', function () {
                        self.AdditionalInfoAvaliable(false);
                    });
                    $.when(cs.openModal("modal-update-additional-info"))
                    .done(function () {
                        cs.initCustomAttributes();
                        cs.isCancelCloseModalCallBack = false;
                        updateLCRAccountStatus.complete();
                        cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                    });
                } else {
                    UpdateLCRBillingAccount(element);
                }
            })
            .fail(function () {
                updateLCRAccountStatus.complete();
            });
        }

        var updateLCRAccountStatus = new cs.executeStatus();
        function UpdateLCRAccount(billingAccountModel, element) {
            if (updateLCRAccountStatus.isExecuting()) {
                return;
            }

            if (billingAccountModel.IsAccountNumberInvalid()) return;

            updateLCRAccountStatus.setExecuting();
            billingAccountModel.errors = ko.validation.group(billingAccountModel);
            if (billingAccountModel.isValid() && !self.SelectedBillingAccount.IsAccountNumberInvalid()) {
                GetAdditionalInfo(element);
            }
            else {
                updateLCRAccountStatus.complete();
                LogSelectedBillingAccount(billingAccountModel);
                billingAccountModel.errors.showAllMessages();
            }
        }

        function UpdateLCRBillingAccount(element) {
            cs.AjaxBySpinner({
                url: '/BillPayLCR/SelfServiceUpdateLCRBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self.SelectedBillingAccount))
            }, element)
                .done(function (data) {
                    var billingAccount = ko.mapping.fromJS(data.BillingAccount);
                    if (data.IsUpdate) {
                        for (var i = 0; i < self.BillingAccounts().length; i++) {
                            if (self.BillingAccounts()[i].RppsBillingAccountId() == data.BillingAccount.RppsBillingAccountId) {
                                ko.mapping.fromJS(data.BillingAccount, {}, self.BillingAccounts()[i]);
                                break;
                            }
                        }
                    } else {
                        var tempBillingAccounts = self.BillingAccounts();
                        tempBillingAccounts.push(billingAccount);
                        ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);
                    }

                    originalBillingAccount = billingAccount;
                    ko.mapping.fromJS(data.BillingAccount, {}, self.SelectedBillingAccount);
                    DisabledBillingAccountValidattion(self.SelectedBillingAccount);
                    $.when(cs.closeModal())
                    .done(function () {
                        self.AdditionalInfoAvaliable(false);
                        updateLCRAccountStatus.complete();
                    });
                })
                .fail(function () {
                    updateLCRAccountStatus.complete();
                    //for (var i = 0; i < self.BillingAccounts().length; i++) {
                    //    if (self.BillingAccounts()[i].RppsBillingAccountId() == self.SelectedBillingAccount.RppsBillingAccountId()) {
                    //        ko.mapping.fromJS(originalBillingAccount, {}, self.BillingAccounts()[i]);
                    //    }
                    //}
                });
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());
            if (validateResult) {
                if (updateLCRAccountStatus.isExecuting()) {
                    return;
                }
                updateLCRAccountStatus.setExecuting();
                var tempAdditionalFields = ko.mapping.toJS(self.BillingAccountRequiredInfo());
                self.SelectedBillingAccount.BillingAccountRequiredInfo(tempAdditionalFields);
                delete self.SelectedBillingAccount.BillingAccountRequiredInfo().States;
                self.SelectedBillingAccount.AdditionalInfoAvaliable(self.AdditionalInfoAvaliable());

                UpdateLCRBillingAccount(element)
            }
        }

        self.CancelUpdateLCRBillingAccount = function () {
            DisabledBillingAccountValidattion(self.SelectedBillingAccount);
            ko.mapping.fromJS(originalBillingAccount, {}, self.SelectedBillingAccount);
        }

        function LogSelectedBillingAccount(lcrBillingAccountModel) {
            var message = new Array();

            if (!lcrBillingAccountModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + lcrBillingAccountModel.AccountNumber.error);
            }
            if (!lcrBillingAccountModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + lcrBillingAccountModel.RetypeAccountNumber.error);
            }

            cs.logException("BillPayCustomer.SelectedBillingAccount", JSON.stringify(message));
        }

        //For Biller Management
        var deleteStatus = new cs.executeStatus();
        self.AccountConfirmDelete = function (billingAccount) {
            $("#ConfirmToRemove").unbind('click');
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove biller
                cs.AddActivityInfo(16);

                if (deleteStatus.isExecuting()) {
                    return;
                }
                if (cs.isDisabled("ConfirmToRemove")) {
                    return;
                }
                deleteStatus.setExecuting();
                $.when(BillPayLCRBillingAccountDelete(billingAccount, "#ConfirmToRemove"))
                .done(function () {
                    $.when(cs.closeModal())
                    .done(function () {
                        deleteStatus.complete();
                    });
                })
                .fail(function () {
                    deleteStatus.complete();
                });
            })
            cs.openModal("modal-remove", true, true, true);
        }

        self.UpdateLCRAccountForBillingManagement = function (billingAccountModel) {
            var tempBillingAccount = ko.mapping.toJS(billingAccountModel);
            tempBillingAccount.IsFavorite = !tempBillingAccount.IsFavorite;

            tempBillingAccount.errors = ko.validation.group(tempBillingAccount);
            if (tempBillingAccount.isValid()) {
                cs.BaseAjax({
                    url: '/BillPayLCR/SelfServiceUpdateFavoriteLCRBillingAccount',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(tempBillingAccount)
                })
                .done(function (data) {
                    var tempReceiver = ko.mapping.toJS(data.BillingAccount);
                    ko.mapping.fromJS(tempReceiver, {}, billingAccountModel);
                });
            }
        }

        self.LCRBillerSearchText = ko.observable("");
        var timerHandler = 0;
        self.AutoSearchLCRBillingAccount = function (value) {
            var oldValue = self.LCRBillerSearchText();
            self.LCRBillerSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.LCRBillerSearchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 3) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.SearchLCRBillingAccount(); }, 500);
            }
        }

        self.SearchLCRBillingAccount = function () {
            var criteria = $("#input-search-for-recipients-lcr-billers").val();

            cs.AjaxBySpinner({
                url: '/BillPayLCR/SearchLCRBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "criteria": criteria })
            }, "#search-bill-pay-lcr-biller")
            .done(function (result) {
                var billingAccount = ko.mapping.toJS(result);
                ko.mapping.fromJS(billingAccount, {}, self.BillingAccounts);

            });
        }

        //For new bill pay lcr
        var timeHandler = 0;
        self.BillPay$GetLCRBillersByBillerName = function () {
            var billerName = $("#input-biller-name").val();
            var billerType = "All Types";
            var billerCountry = $("#select-country-add-biller").find("option:selected").text();
            if (billerName.length == 0) {
                ResetForBillerNameEmpty();
            }
            if (timeHandler != 0) {
                clearTimeout(timeHandler);
                timeHandler = 0;
            }

            if (billerName.length > 2) {
                timeHandler = setTimeout(function () {
                    if (searchLcrBillerModal.OriginalSearchCondition == ''
                        || !billerName.toLowerCase().contains(searchLcrBillerModal.OriginalSearchCondition.toLowerCase())) {
                        searchLcrBillerModal.OriginalSearchCondition = billerName;
                        SearchLCRBillers(billerCountry, billerType, billerName);
                    }
                    else {
                        if (searchLcrBillerModal.AutoCompleteList.length > 0) {
                            var clearFlag = true;
                            for (var i = 0; i < searchLcrBillerModal.AutoCompleteList.length; i++) {
                                if (searchLcrBillerModal.AutoCompleteList[i].value == billerName) {
                                    $("#input-biller-name").autocomplete().selection = searchLcrBillerModal.AutoCompleteList[i];
                                    $("#input-biller-name").autocomplete().currentValue = searchLcrBillerModal.AutoCompleteList[i].value;
                                    clearFlag = false;
                                    break;
                                }
                            }

                            if (clearFlag) {
                                self.ClearLcrAccountDetailInfo();
                            }
                        }
                    }

                }, 500);
            }
        }

        self.SearchLCRBillersByBillerName = function () {
            var billerName = $("#input-biller-name").val();
            var billerType = "All Types";
            var billerCountry = $("#select-country-add-biller").find("option:selected").text();
            if (billerName.length > 2) {
                searchLcrBillerModal.MappingOldBillerName = billerName;
                SearchLCRBillers(billerCountry, billerType, billerName);
            }
            else {
                self.BillerNameValidType(3);
                $('#input-biller-name').focus();
            }
        }

        self.ClearLcrAccountDetailInfo = function () {
            ko.mapping.fromJSON(defaultBillingAccount, {}, self.TobeAddedBillingAccount);
            DisabledBillingAccountValidattion(self.TobeAddedBillingAccount);
            searchLcrBillerModal.OriginalType = "";
            searchLcrBillerModal.OriginalKey = 0;
        }

        var autoCompleteData = '';
        var synchroFlag = false;
        function SearchLCRBillers(billerCountry, billerType, billerName) {
            self.BillerNameValidType(0);
            self.ClearLcrAccountDetailInfo();
            searchLcrBillerModal.AutoCompleteList = new Array();
            selectedGroupId = 0;
            cs.addSearchSpinner("#search-lcr-billers");
            synchroFlag = false;

            cs.BaseAjax({
                url: '/BillPayLCR/SelfServiceSearchLCRBillers',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billerName": billerName, "billerType": billerType, "destinationCountryId": $("#select-country-add-biller").val(), "localDataLength": 0 })
            })
            .done(function (tempBillers) {
                if (synchroFlag) {
                    return;
                }
                synchroFlag = true;
                self.UpdateLcrBillerList(tempBillers, billerType, billerCountry, billerName);
                self.FillInAutoCompleteForLcrBiller()
                autoCompleteData = searchLcrBillerModal.AutoCompleteList;
                $('#input-biller-name').focus();
            })
            .fail(function () {
                synchroFlag = false;
            })
            .always(function () {
                cs.removeSearchSpinner("#search-lcr-billers");
            });
        }

        self.FillInAutoCompleteForLcrBiller = function () {
            $('#input-biller-name').autocomplete({
                lookup: autoCompleteData,
                lookupFilter: function (suggestion, query, queryLowerCase) {
                    return suggestion;
                },
                triggerSelectOnValidInput: false,
                minChars: 3,
                onSelect: function (suggestion) {
                    if (searchLcrBillerModal.OriginalKey != suggestion.value || searchLcrBillerModal.OriginalType != suggestion.data.GroupId) {
                        searchLcrBillerModal.OriginalKey = suggestion.value;
                        searchLcrBillerModal.OriginalType = suggestion.data.GroupId;
                        BillerNameSelected(suggestion);
                    }
                    self.BillerNameValidType(0);
                }
            }).focus(function () {
                $('.autocomplete-suggestions').on('scroll', function () {
                    var scroll = $(this);
                    var isBottom = isScrollbarBottom($(this));
                    var newDate = '';
                    if (isBottom && synchroFlag) {
                        synchroFlag = false;
                        $(this).append("<div class='autocomplete-loading' ></div>");
                        scroll.scrollTop(scroll.scrollTop() + 30);
                        cs.BaseAjax({
                            url: '/BillPayLCR/SelfServiceSearchLCRBillers',
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                            data: JSON.stringify({ "billerName": billerName, "billerType": billerType, "destinationCountryId": $("#select-country-add-biller").val(), "localDataLength": 0 })
                        })
                        .done(function (newData) {
                            if (newData.length == 0) {
                                $(".autocomplete-loading").css('display', 'none');
                                return;
                            }

                            autoCompleteData = autoCompleteData.concat(newData);
                            var option = {
                                lookup: autoCompleteData,
                                lookupFilter: function (suggestion, query, queryLowerCase) {
                                    return suggestion;
                                },
                                triggerSelectOnValidInput: false,
                                minChars: 3,
                                onSelect: function (suggestion) {
                                    if (searchLcrBillerModal.OriginalKey != suggestion.value || searchLcrBillerModal.OriginalType != suggestion.data.GroupId) {
                                        searchLcrBillerModal.OriginalKey = suggestion.value;
                                        searchLcrBillerModal.OriginalType = suggestion.data.GroupId;
                                        BillerNameSelected(suggestion);
                                    }
                                    self.BillerNameValidType(0);
                                }
                            };
                            var scrollTop = scroll.scrollTop();
                            $("#input-biller-name").autocomplete().suggestions = autoCompleteData;
                            $("#input-biller-name").autocomplete().setOptions(option);
                            $("#input-biller-name").autocomplete().customerUpdateSuggest();
                            scroll.scrollTop(scrollTop);
                            synchroFlag = true;
                        });
                    }
                });
            });

            $('#input-biller-name').autocomplete().getSuggestionsLocal = function (query) {
                return cs.GetSuggestionsLocal(this.options.lookup, query);
            };
        }

        function isScrollbarBottom(container) {
            var height = container.outerHeight();
            var scrollHeight = container[0].scrollHeight;
            var scrollTop = container.scrollTop();
            if (scrollTop >= scrollHeight - height) {
                return true;
            }
            return false;
        };

        self.UpdateLcrBillerList = function (tempBillers, billerType, billerCountry, billerName) {
            if (!tempBillers || tempBillers.length == 0) {
                self.billerNameValid(1);
            }

            var result = new Array();
            if (billerType == "All Types" && billerCountry == "Select Country") {
                result = tempBillers;
            }
            else {
                for (var i = 0; i < tempBillers.length; i++) {
                    if ((tempBillers[i].data.BillingAccount.BillerType == billerType && billerCountry == "Select Country")
                        || (tempBillers[i].data.BillingAccount.DestinationCountry == billerCountry && billerType == "All Types")
                        || (tempBillers[i].data.BillingAccount.BillerType == billerType && tempBillers[i].data.BillingAccount.DestinationCountry == billerCountry)) {
                        result.push(tempBillers[i]);
                    }
                }
            }

            searchLcrBillerModal.AutoCompleteList = result;
        }

        function BillerNameSelected(suggestion) {
            var billingAccount = suggestion.data.BillingAccount;
            searchLcrBillerModal.MappingOldBillerName = suggestion.value;
            selectedGroupId = suggestion.data.GroupId;
            billingAccount.NickName = null;
            var r = ko.mapping.toJS(billingAccount);
            ko.mapping.fromJS(r, {}, self.TobeAddedBillingAccount);

            self.BillerNameValidType(0);
        }

        // 0 means valid.
        // 1 means empty.
        // 2 means no result.
        self.BillerNameValidType = ko.observable(0);

        self.BillPay$MatchAutocompleteBillerName = function () {
            setTimeout(function () {
                var billerName = $("#input-biller-name").val();
                var billerType = "All Types";
                if (billerName != searchLcrBillerModal.MappingOldBillerName) {
                    var nameMatched = false;
                    if (searchLcrBillerModal.AutoCompleteList == null || searchLcrBillerModal.AutoCompleteList.length <= 0) {
                        nameMatched = false;
                    }
                    else {
                        for (var i = 0; i < searchLcrBillerModal.AutoCompleteList.length; i++) {
                            if ((searchLcrBillerModal.AutoCompleteList[i].value == billerName && searchLcrBillerModal.AutoCompleteList[i].data.BillingAccount.BillerType == billerType) ||
                                (searchLcrBillerModal.AutoCompleteList[i].value == billerName && "All Types" == billerType)) {
                                BillerNameSelected(searchLcrBillerModal.AutoCompleteList[i]);
                                $("#input-biller-name").autocomplete().selection = searchLcrBillerModal.AutoCompleteList[i];
                                $("#input-biller-name").autocomplete().currentValue = searchLcrBillerModal.AutoCompleteList[i].value;
                                self.BillerNameValidType(0);
                                nameMatched = true;
                                break;
                            }
                        }
                    }
                    if (!nameMatched && billerName != "") {
                        if (billerName.length > 2) {
                            self.BillerNameValidType(2);
                        }
                        else {
                            self.BillerNameValidType(3);
                        }
                    }

                    if (billerName == "") {
                        ResetForBillerNameEmpty();
                    }
                }
            }, 300);
        }

        self.ChangeFilter = function () {
            if (!($("#select-country-add-biller").find("option:selected").text() == "Select Country" || $("#select-country-add-biller").find("option:selected").text() == self.TobeAddedBillingAccount.DestinationCountry())) {
                ResetForBillerNameEmpty();
            }
        }

        self.AddNewBillingAccount = function (element) {
            $.when(dataModel.GetCountriesByTransactionType(11, true))
            .done(function (data) {
                var countries = [];
                countries = data.filter(function (item) {
                    if (item.Value != 0 && item.Value != 484 && item.Value != 840) {
                        countries.push(item);
                    }
                    return item.Value == "0" || item.Value == "484" || item.Value == "840";
                }).concat(countries);
                ko.mapping.fromJS(countries, {}, self.Countries);
                $("#select-country-add-biller").val(self.Countries()[0].Value());
            })
        }

        self.ResetAddLCRModal = function () {
            $("#select-country-add-biller").val("0");
            ResetForBillerNameEmpty();
        }

        function ResetForBillerNameEmpty() {
            $('#input-biller-name').autocomplete({
                lookup: new Array(),
            });
            searchLcrBillerModal.OriginalSearchCondition = '';
            $('#input-biller-name').val('');
            self.ClearLcrAccountDetailInfo();
            selectedGroupId = 0;
            mappingOldAccountNumber = 0;
            self.BillerNameValidType(0);
        }

        var saveBillingAccountStatus = new cs.executeStatus();
        self.BillPay$AddNewBiller = function (element) {
            if (saveBillingAccountStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            var toBeAddedBillerName = $('#input-biller-name').val();
            if (toBeAddedBillerName == '' || toBeAddedBillerName == null) {
                self.BillerNameValidType(1);
            }

            if (self.TobeAddedBillingAccount.IsAccountNumberInvalid()) {
                return false;
            }
            saveBillingAccountStatus.setExecuting();
            self.TobeAddedBillingAccount.errors = ko.validation.group(self.TobeAddedBillingAccount);
            var groupId = selectedGroupId;
            var deferred = $.Deferred();

            if (self.TobeAddedBillingAccount.isValid() && self.BillerNameValidType() == 0) {
                return cs.AjaxBySpinner({
                    url: '/BillPayLCR/SelfServiceAddLCRBillingAccount',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "billingAccountViewModel": ko.mapping.toJS(self.TobeAddedBillingAccount), "selectedGroupId": groupId }),
                }, element)
                .done(function (data) {
                    var billingAccount = ko.mapping.fromJS(data);
                    var IsLayoutLCRBillPayModalOpen = app.senderInfo().BillingAccount() != null && app.senderInfo().BillingAccount().LayoutAddLCRBillingAccountFlag();
                    var tempBillingAccounts = self.BillingAccounts();
                    tempBillingAccounts.push(billingAccount);
                    ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);

                    if (app.page().name == "BillPayLCRConsumer") {
                        app.page().data.Ready();
                    }

                    ko.mapping.fromJSON(defaultBillingAccount, {}, self.TobeAddedBillingAccount);
                    self.ResetAddLCRModal();
                    if (app.page().name == "BillPayLCRConsumer" && !IsLayoutLCRBillPayModalOpen) {
                        app.page().data.SelectBillingAccount(element, billingAccount);
                    }

                    $.when(cs.closeModal())
                    .done(function () {
                        saveBillingAccountStatus.complete();
                        self.AccountAddLCRBillingAccountFlag(false);
                        self.LayoutAddLCRBillingAccountFlag(false);
                        self.BillpayAddLCRBillingAccountFlag(false);
                        deferred.resolve();
                    });
                })
                .fail(function () {
                    saveBillingAccountStatus.complete();
                });
            }
            else {
                saveBillingAccountStatus.complete();
                LogTobeAddedBillingAccount(self.TobeAddedBillingAccount);
                self.TobeAddedBillingAccount.errors.showAllMessages();
            }
            return deferred;
        }


        self.FormateAccountNickName = function (element) {
            var accountNumber = $.trim($(element).val());
            var length = accountNumber.length;

            var billerName = $("#input-biller-name").val();

            if (selectedGroupId == null || selectedGroupId == 0) {
                return;
            }
            if (length < 4) {
                self.TobeAddedBillingAccount.NickName(billerName + " [****" + accountNumber + "]");
            } else {
                var temp = accountNumber.substr(0, length - 4).length;
                var prefix = " [****";

                self.TobeAddedBillingAccount.NickName(billerName + prefix + accountNumber.substr(length - 4, 4) + "]");
            }
        }

        self.FormateSelectedAccountName = function (element) {
            var accountNumber = $.trim($(element).val());
            var length = accountNumber.length;

            var billerName = self.SelectedBillingAccount.BillerName();

            if (length < 4) {
                self.SelectedBillingAccount.AccountName(billerName + " [****" + accountNumber + "]");
            } else {
                var temp = accountNumber.substr(0, length - 4).length;
                var prefix = " [****";

                self.SelectedBillingAccount.AccountName(billerName + prefix + accountNumber.substr(length - 4, 4) + "]");
            }
        }

        self.EditBillingAccount = function (billingAccount) {
            if (cs.isDisabled()) {
                return;
            }
            var selectedBillingAccount = ko.mapping.toJS(billingAccount);
            ko.mapping.fromJS(selectedBillingAccount, {}, self.SelectedBillingAccount);

            self.SelectedBillingAccount.IsAccountNumberInvalid(false);
            cs.openModal("#modal-LCR-biller-Edit");
            cs.AjaxByLoading({
                url: "/BillPayLCR/GetLCRGroupByAccount",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountId": billingAccount.RppsBillingAccountId() })
            })
            .done(function (data) {
                selectedGroupId = data.GroupId;
                $.when(self.GetLCRBillers(billingAccount.AccountNumber()))
                .done(function () {
                    mappingOldAccountNumber = self.SelectedBillingAccount.AccountNumber();
                });
            });
        }


        self.SortType = ko.observable('sortby');
        self.IsAscending = ko.observable(true);

        self.SortBillingAccountBy = function (value, element) {

            var classname = element.childNodes[1].className;
            ResetSort();

            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-up";
                self.SortType(value);
                self.IsAscending(true);
            }
            else {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-down";
                self.SortType(value);
                self.IsAscending(false);
            }
        }

        function ResetSort() {
            $("#bill-pay-lcr-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#bill-pay-lcr-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#bill-pay-lcr-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.SortType("sortby");
            self.IsAscending(true);
        }

        self.SortBillingAccounts = ko.computed(function () {
            if (self.BillingAccounts() != null) {
                var sortedBillingAccount = self.BillingAccounts();
                var sortType = self.SortType();
                var isAscending = self.IsAscending();
                if (sortType == "sortby") {
                    return sortedBillingAccount;
                }
                else {
                    if (sortType == "FirstName") {
                        return sortedBillingAccount.sort(dataModel.CompareCustomerName(isAscending));
                    }
                    else if (sortType == "GroupName") {
                        return sortedBillingAccount.sort(CompareBillingAccountGroupName(isAscending));
                    }
                    else {
                        return sortedBillingAccount.sort(cs.compare(sortType, null, isAscending, 'RppsBillingAccountId'));
                    }
                }
            }
            else
                return new Array();
        });

        function CompareBillingAccountGroupName(isAscending) {
            return function (x, y) {
                if (isAscending) {
                    if (x.BillerGroup.Name().toLowerCase() != y.BillerGroup.Name().toLowerCase()) {
                        return ((x.BillerGroup.Name().toLowerCase() > y.BillerGroup.Name().toLowerCase()) ? 1 : -1);
                    }
                    else {
                        return ((x.RppsBillingAccountId() > y.RppsBillingAccountId()) ? 1 : 0);
                    }
                }
                else {
                    if (x.BillerGroup.Name().toLowerCase() != y.BillerGroup.Name().toLowerCase()) {
                        return ((x.BillerGroup.Name().toLowerCase() < y.BillerGroup.Name().toLowerCase()) ? 1 : -1);
                    }
                    else {
                        return ((x.RppsBillingAccountId() < y.RppsBillingAccountId()) ? 1 : 0);
                    }
                }
            }
        }

        var mappingOldAccountNumber;
        self.HasBillersMatchAccountNumber = function (billingAccount) {
            var deffered = $.Deferred();
            var accountNumber = billingAccount.AccountNumber();
            billerName = $("#input-biller-name").val();
            //If Edit Biller, the element doesn't exist. So need to init the value of billerName
            searchLcrBillerModal.MappingOldBillerName = searchLcrBillerModal.MappingOldBillerName ? searchLcrBillerModal.MappingOldBillerName : '';
            billerName = billerName ? billerName : '';

            if (selectedGroupId == null || selectedGroupId == 0 || searchLcrBillerModal.MappingOldBillerName != billerName
                || !accountNumber) {
                return deffered.resolve();

            }

            //if (mappingOldAccountNumber == accountNumber) {
            //    return deffered.resolve();
            //}
            mappingOldAccountNumber = accountNumber;
            cs.BaseAjax({
                url: '/BillPayLCR/GetLCRBillers',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "lcrBillerGroupId": selectedGroupId, "accountNumber": accountNumber }),
            })
            .done(function (data) {
                if (data == null || data.length == 0) {
                    billingAccount.IsAccountNumberInvalid(true);
                }
                else {
                    billingAccount.IsAccountNumberInvalid(false);
                }

                deffered.resolve();
            })
            .fail(function (data) {
                billingAccount.IsAccountNumberInvalid(true);
                deffered.resolve();
            })
            return deffered;
        }

        self.ValidateAccountNumberKeyup = function (billingAccount) {
            if (!billingAccount.AccountNumber.isModified()) return;

            billingAccount.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.HasBillersMatchAccountNumber(billingAccount);
            }, 500);
        }

        self.ValidateAccountNumberBlur = function (billingAccount) {
            billingAccount.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.HasBillersMatchAccountNumber(billingAccount);
            }, 500);
        }

        self.GetLCRBillers = function (accountNumber) {
            cs.BaseAjax({
                url: "/BillPayLCR/GetLCRBillers",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "lcrBillerGroupId": selectedGroupId, "accountNumber": accountNumber })
            })
            .done(function (data) {
            });
        }

        self.AfterRenderNewBillerPage = function () {
        };
    }
});