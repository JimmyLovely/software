﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'R', 'TrackEvent', 'Plugins'], function (ko, cs, app, dataModel, commonstrings, R, track) {
    function BillPayLCRViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.billpaylcr;
        self.billingAccount = ko.observable();
        self.billPayTransaction = ko.observable();
        self.serviceType = ko.observable();
        self.paymentMethod = ko.observable();
        self.ClickPayBillingAccount = ko.observable();

        self.transactionProcess = ko.observable(false);
        self.confirmTransactionProcess = ko.observable(false);
        self.completeTransactionProcess = ko.observable(false);
        self.quickPayProcess = ko.observable(false);

        self.TransactionStart = ko.observable(false);

        self.selectBillingAccountCompleted = ko.observable(false);
        self.inputAmountCompleted = ko.observable(false);
        self.selectServiceTypeCompleted = ko.observable(false);
        self.selectPaymentMethodCompleted = ko.observable(false);

        self.isClickToPay = ko.observable(false);
        self.IsAddedPromotionCode = ko.observable(false);
        self.ApplyPromotionCodeSuccessful = ko.observable(false);
        self.ShowPromotionCodeErrorMessage = ko.observable(true);
        self.ServiceTypeAPI = ko.observable();

        self.BillingAccountRequiredInfo = ko.observable(null);
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.CustomerSaveAdditionalInfo = ko.observable(false);
        self.reLinkPaymentMethod = ko.observable(null);

        self.PaymentMethodAPI = ko.observable();

        ko.components.register('billpay-lcr-set-amount', {
            viewModel: { require: 'billpay-lcr-set-amount-js' },
            template: { require: 'text!billpay-lcr-set-amount-html' }
        });

        ko.components.register('billpay-lcr-service-type', {
            viewModel: { require: 'billpay-lcr-service-type-js' },
            template: { require: 'text!billpay-lcr-service-type-html' }
        });

        self.init = function () {
            //prevent visit without permission
            dataModel.checkStatePermision();
        };

        var isSenderInfoInit = true;
        self.calculateAgain = false;

        var isManualed = false;

        self.controllers = {
            '/StartPositionCode/:startPositionCode': function (startPositionCode) {
                self.InitSelectBillerView();
                self.TransactionStart(true);

                //Data Capture: capture transaction info which start from dashboard or left bar.
                cs.CaptureTransactionInfo(startPositionCode, cs.TransactionTypes.BillPayLCR);
            },
            '/StartPositionCode/:startPositionCode/:receiptNumber': function (startPositionCode, receiptNumber) {
                var transactionInitialPositions;
                if (startPositionCode == "FromRecentTransaction") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromRecentTransaction;
                }else if (startPositionCode == "FromTxnHistory") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromTxnHistory;
                }else if (startPositionCode == "FromManageBillers"){
					transactionInitialPositions = cs.TransactionInitialPositions.FromManageBillers;
				}
                cs.AddTransactionStart(
                                        transactionInitialPositions,
                                        cs.QuickWays.QuickPay,
                                        cs.TransactionTypes.BillPayLCR,
                                        cs.GetDateTimeOffset()
                                      );

                self.InitQickPayPage();
                var emailAddress = app.senderInfo() == null ? null : app.senderInfo().Customer().CustomerBasic.EmailAddress();
                return cs.BaseAjax({
                    url: '/BillPayLCR/InitializeQuickToPayByReceiptNumber',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "receiptNumber": receiptNumber, "emailAddress": emailAddress })
                }, true)
                  .done(function (data) {
                      var paymentMethod = data.PaymentMethod;

                      // remove credit card function
                      if (!paymentMethod.IsBank) {
                          self.QuickPayGoToServiceType(data);
                          return;
                      }

                      if (paymentMethod.IsIBVAccount) {
                          $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                           .done(function (result) {
                               $.when(dataModel.checkIBVBalance(paymentMethod, parseFloat(data.BillPayLCRTransaction.AmountToSend.Value) + parseFloat(data.BillPayLCRTransaction.TotalFee.Value)))
                              .done(function (result) {
                                  if (result.verifyPassed) {
                                      data.BillPayLCRTransaction.IsIBVVerified = true;
                                      self.InitializeTransactionQuickPay(data);

                                  } else if (!!result && result.isCredentialChanged) {
                                      SwitchPaymentMethodForQuickPayIBVFailed(data);
                                      self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                      return;
                                  } else {
                                      SwitchPaymentMethodForQuickPayIBVFailed(data);
                                      return;
                                  }
                              })
                               .fail(function () {
                                   self.InitializeTransactionQuickPay(data);
                               });
                           })
                           .fail(function () {
                               self.InitializeTransactionQuickPay(data);
                           })
                      } else {
                          self.InitializeTransactionQuickPay(data);
                      }
                  })
                  .fail(function (xhr, status) {
                      var exception = $.parseJSON(xhr.responseText);
                      if (exception.ReturnCode == 17170433) {// Bill account was not found.
                          self.InitSelectBillerView();
                      } else if (exception.ReturnCode == 16842756) { // amount is invalid.
                          self.InitializeTransactionQuickPayWithErrorMessage(exception.Data, exception.Message);
                      } else if (exception.ReturnCode == 17170434) {// Service type was not found.
                          self.QuickPayGoToServiceType(exception.Data);
                      } else if (exception.ReturnCode == 17170435) {// Payment method was not found.
                          self.QuickPayGoToPaymentMethod(exception.Data);
                      } else if (xhr.responseText.indexOf("You have no permission to access it") >= 0) {
                          return app.redirectTo("/SelfService/CustomerDashboard");
                      } else if (exception.Message) {
                          try {
                              var message = $.parseJSON(exception.Message).reason;
                              cs.showTransactionNotFoundError(message);
                          } catch (e) {
                              cs.showTransactionNotFoundError(exception.Message);
                          }
                      } else {
                          cs.handleAjaxError(xhr.responseText);
                      }
                      self.TransactionStart(true);
                  });
            },
            '/:receiptNumber/:billingAccountId': function (receiptNumber, billingAccountId) {
                self.TransactionStart(true);
                var billingAccount = {
                    RppsBillingAccountId: billingAccountId,
                };
                self.billingAccount(null);
                self.ClickPayBillingAccount(billingAccount);
                self.transactionProcess(true);

                self.selectBillingAccountCompleted(true);

                self.isClickToPay(true);

                //Data Capture: Initialize Transaction start from quick pay.
                cs.AddTransactionStart(
                                        cs.TransactionInitialPositions.FromClickToPay,
                                        cs.QuickWays.NormalPay,
                                        cs.TransactionTypes.BillPayLCR,
                                        cs.GetDateTimeOffset()
                                      );
            }
        };

        //Start appsflyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        };

        var trackBillPayTotalLoads = function () {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.BPFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Pay Bills",
                eventPage: track.PageEnum.PayBills,
                source: app.page().name,
                eventStructure: track.StructureEnum.InitiatedCheckout,
                eventName: 'af_initiated_checkout_BP'
            });
        }

        var trackTransactionSuccessfully = function (amount, receiptNumber) {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.BPFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Confirm & Send",
                eventPage: track.PageEnum.SendMoney,
                source: app.page().name,
                eventStructure: track.StructureEnum.Purchase,
                eventName: 'af_purchase_BP',
                amount: amount,
                revenue: amount,
                contentType: 'BP',
                currency: 'USD',
                receiptId: receiptNumber
            });
        }

        var trackRecipientPageTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: 'TimeOnPage',
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        }

        var trackViewTransactionDetailsTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: track.LabelEnum.ViewTransactionDetails,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        }

        var trackEmailTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.EmailReceipt));

        var trackPrintTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.PrintReceipt));

        var trackFinishLinkTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.Finish));
        // End appsflyer track event

        function SwitchPaymentMethodForQuickPayIBVFailed(data) {
            var paymentMethods = self.PaymentMethodAPI().PaymentMethods();
            if (paymentMethods) {
                $.each(paymentMethods, function (index, d) {
                    d.Selected(d.PaymentMethodId === data.PaymentMethod.PaymentMethodId);
                })
                self.paymentMethod(data.PaymentMethod);
                self.PaymentMethodAPI().PaymentMethods(paymentMethods);
            }

            self.paymentMethod(data.PaymentMethod);
            self.reLinkPaymentMethod(data.PaymentMethod);
            self.QuickPayGoToPaymentMethod(data);
        }

        self.afterRender = function () {
            dataModel.checkPersonInfo();

            $("#main").removeClass();
            $("#main").addClass("mod-c-money-transfer mod-c-bill-pay");

            app.cacheComponent(['billpay-lcr-set-amount', 'billpay-lcr-service-type', 'billpay-lcr-payment-method']);

            trackBillPayTotalLoads();
        };

        self.dispose = function () { };

        self.GoToAmountToSend = function (billingAccount) {
            if (billingAccount || self.isClickToPay() || !self.selectBillingAccountCompleted()) {
                self.billPayTransaction(null);
                self.billingAccount(billingAccount || self.billingAccount());
                self.serviceType(null);
                self.paymentMethod(null);

                if (self.isClickToPay()) {
                    cs.triggerTab("panel-amount");
                    cs.scrollToTab('panel-amount');
                    self.isClickToPay(false);
                    return;
                }

                self.selectBillingAccountCompleted(true);
                self.inputAmountCompleted(false);
                self.selectServiceTypeCompleted(false);
                self.selectPaymentMethodCompleted(false);
            }

            cs.triggerTab("panel-amount");
            cs.scrollToTab('panel-amount');
        }

        self.AmountChanged = function () {
            self.inputAmountCompleted(false);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);
            self.PaymentMethodAPI().IBVStatus(cs.IBVStatus.Normal);
        };

        self.CalculateDestinationAmount = function (amount, rate) {
            if (!amount && !rate) {
                return 0;
            }

            var destinationAmount = (amount * rate).toFixed(2);
            return destinationAmount;
        }

        self.GoBack = function () {
            setTimeout(function () {
                cs.fitTextAmountField($("#input-lcr-send-amount"), cs.keepAmountDecimalPlaces($("#input-lcr-send-amount").val()));
                cs.fitTextAmountField($("#input-send-amount"), cs.keepAmountDecimalPlaces($("#input-send-amount").val()));
            });
        }

        self.AgreementChanged = function (element) {
            if ($(element).is(':checked')) {
                $('#confirmError').fadeOut();
            }
            return true;
        };

        self.GoToServiceType = function (transactionModel) {
            if (self.billPayTransaction().isChanged) {
                self.billPayTransaction().isChanged = false;

                self.serviceType(null);
                self.selectBillingAccountCompleted(true);
                self.inputAmountCompleted(true);
                self.selectServiceTypeCompleted(false);
                self.selectPaymentMethodCompleted(false);
            }

            cs.triggerTab("panel-service-type");
            cs.scrollToTab('panel-service-type');
        }

        self.GoToSenderPayment = function (serviceType) {
            $.when((function () {
                if (serviceType || !self.selectServiceTypeCompleted()) {
                    if (!!serviceType) {
                        self.serviceType(convertServiceType(serviceType));
                    }

                    self.selectBillingAccountCompleted(true);
                    self.inputAmountCompleted(true);
                    self.selectServiceTypeCompleted(true);
                    self.selectPaymentMethodCompleted(false);
                    if (self.paymentMethod() == null) {
                        self.paymentMethod('');
                    }
                    self.paymentMethod(null);
                    self.PaymentMethodAPI().IBVStatus(cs.IBVStatus.Normal);
                    self.IsAddedPromotionCode(false);
                    self.ApplyPromotionCodeSuccessful(false);
                    self.billPayTransaction().PromotionCode("");

                    return Calculate(true);
                }
            })())
            .done(function () {
                cs.triggerTab("panel-payment");
                cs.scrollToTab('panel-payment');
            });
        }

        function ClearServiceTypeStatus() {
            self.selectBillingAccountCompleted(true);
            self.inputAmountCompleted(true);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);
            originalLCRBillPayConsumerModel.serviceType = null;
            originalLCRBillPayConsumerModel.PaymentMethodId = 0;
            isManualed = true;
        }

        self.GoToTransactionDetails = function (paymentMethod, ignoreConvert) {
            //IBV Data capture.
            cs.IBVDataCaptureMmodel.UpdateIbvActivity(paymentMethod.PaymentMethodId);

            $.when((function () {
                if (self.calculateAgain || paymentMethod) {
                    if (paymentMethod) {
                        self.paymentMethod(paymentMethod);
                        self.billPayTransaction().PromotionCode('');
                        self.IsAddedPromotionCode(false);
                    }
                    var deferred = $.Deferred();
                    $.when(Calculate())
                    .done(function () {
                        if (paymentMethod.IsBank && paymentMethod.IsIBVAccount && !ignoreConvert) {
                            $.when(dataModel.checkIBVBalance(paymentMethod, parseFloat(self.billPayTransaction().AmountToSend.Value()) + parseFloat(self.billPayTransaction().TotalFee.Value())))
                            .done(function (result) {
                                if (result.verifyPassed) {
                                    self.billPayTransaction().IsIBVVerified = true;
                                    deferred.resolve();
                                } else if (!!result && result.isCredentialChanged) {
                                    self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                    return;
                                } else {
                                    self.PaymentMethodAPI().lastPaymentMethodId = null;
                                    deferred.reject();
                                }
                            })
                            .fail(function () {
                                deferred.resolve();
                            });
                        } else {
                            deferred.resolve();
                        }

                    });
                    return deferred;
                }
            })())
            .done(function () {
                self.transactionProcess(false);
                self.confirmTransactionProcess(true);
                self.completeTransactionProcess(false);
                self.selectPaymentMethodCompleted(true);
                self.quickPayProcess(false);

                //DataCapture
                self.UpdateDataCaptureTransactionFee();

                cs.SlideToBottom();
            });
        }

        function Calculate(selectServiceType, isQuickPay, element) {
            var tempTransaction = ko.mapping.toJS(self.billPayTransaction());
            if (!tempTransaction.AmountDestination.Value || tempTransaction.AmountDestination.Value == '0.00') {
                return $.Deferred().reject();
            }

            if (selectServiceType != true) {
                tempTransaction.SelectedPaymentMethodId = self.paymentMethod().PaymentMethodId;
            }
            tempTransaction.SelectedServiceType = ko.mapping.toJS(self.serviceType());
            tempTransaction.Regular = self.billingAccount().IsRppsBillingAccount;
            tempTransaction.BillingAccountId = self.billingAccount().RppsBillingAccountId;

            var deferred = $.Deferred();
            cs.AjaxBySpinnerOrLoading({
                url: '/BillPayLCR/SelfServiceLCRCalculate',
                datatype: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(tempTransaction)
            }, element, true)
          .done(function (result) {
              if (checkAmountChange(tempTransaction.AmountDestination.Value)) {
                  return;
              }

              if (selectServiceType != true) {
                  self.serviceType().Fee.Value(result.FeeCharged.Value);
              }

              mappingTransaction(self.billPayTransaction(), result);
              var amountDestination = cs.keepAmountDecimalPlaces(self.billPayTransaction().AmountDestination.Value());
              self.billPayTransaction().lastTransactionSendAmount = amountDestination;

              self.calculateAgain = false;

              if (isQuickPay == true) {
                  GetLCRServiceType('#virtualElement');
              }

              deferred.resolve();
          })
          .fail(function (xhr, status) {
              if (checkAmountChange(tempTransaction.AmountDestination.Value)) {
                  return;
              }

              self.calculateAgain = true;
              var data = $.parseJSON(xhr.responseText);
              if (data.ReturnCode == -318) { //promotion code is not valid
                  cs.showNotification(data, function () { return UpdateLCRAdditionalInfo(data) });
                  deferred.reject(xhr, status);
              }
              else if (data.ReturnCode == -146) {
                  self.billPayTransaction().PromotionCode('');
                  self.IsAddedPromotionCode(true);
                  self.ShowPromotionCodeErrorMessage(element != '#virtualElement');
                  Calculate(selectServiceType, isQuickPay, element);
                  self.ApplyPromotionCodeSuccessful(false);
                  deferred.reject(xhr, status);
              }
              else {
                  cs.handleAjaxError(xhr.responseText, false);
                  deferred.reject(xhr, status);
              }
          });

            return deferred;
        }

        function checkAmountIsValid() {

        }

        function checkAmountChange(AmountDestination) {
            if (Number(cs.GetOriginalNumber(self.billPayTransaction().AmountDestination.Value())) != Number(cs.GetOriginalNumber(AmountDestination))) {
                return true;
            }

            return false;
        }

        function UpdateLCRAdditionalInfo(data) {
            var AdditionalInfoAvaliable = data.BillingAccountRequiredInfo && data.BillingAccountRequiredInfo.Fields.length > 0;
            if (AdditionalInfoAvaliable) {
                self.AdditionalInfoAvaliable(false);
                var tempFields = data.BillingAccountRequiredInfo.Fields;
                self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                self.AdditionalInfoAvaliable(true);
                self.CustomerSaveAdditionalInfo(true);
                cs.isCancelCloseModalCallBack = true;

                $.when(cs.openModal("modal-update-additional-info"))
                .done(function () {
                    cs.initCustomAttributes();
                    cs.isCancelCloseModalCallBack = false;
                    cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                });
            }
        }

        function mappingTransaction(transaction, data) {
            if (self.quickPayProcess() && data.AmountDestination && data.AmountDestination.Value) {
                data.AmountDestination.Value = $('#input-quickpay-lcr-send-amount').val();
            }

            $.each(data, function (key, value) {
                if (!!value && typeof value == 'object') {
                    mappingTransaction(transaction[key], value)
                } else {
                    if (typeof transaction[key] == 'function') {
                        transaction[key](value);
                    } else {
                        transaction[key] = value
                    }
                }
            });
        }

        self.ApplyPromo = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!self.billPayTransaction().PromotionCode()) {
                cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.messagebox.validpromocode, function () {
                    self.ApplyPromotionCodeSuccessful(false);
                    self.IsAddedPromotionCode(false);
                    cs.closeModal();
                });
                return $.Deferred().reject();
            }

            if (element && element != '#virtualElement' && !self.CheckAmount()) {
                return;
            }

            if (element && element != '#virtualElement') {
                element = null;
            }

            return $.when(Calculate(false, true, element))
                    .done(function (result) {
                        $("#input-promo-code").val('');
                        self.IsAddedPromotionCode(true);
                        self.ApplyPromotionCodeSuccessful(true);

                        //DataCapture.
                        self.UpdateDataCaptureTransactionFee();
                    });
        }

        self.RemovePromotionCode = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            $.when(ClearPromo())
            .always(function () {
                self.IsAddedPromotionCode(false);
                self.ApplyPromotionCodeSuccessful(false);

                //DataCapture.
                self.UpdateDataCaptureTransactionFee();
            });
        };

        function ClearPromo() {
            self.billPayTransaction().PromotionCode("");
            return Calculate();
        }

        self.InitSelectBillerView = function () {
            self.inputAmountCompleted(false);
            self.selectBillingAccountCompleted(false);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);
            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            self.quickPayProcess(false);
            cs.triggerTab("panel-recipient");
            cs.scrollToTab('panel-recipient');
        }

        self.InitAmountToSendView = function () {
            self.inputAmountCompleted(false);
            self.selectBillingAccountCompleted(false);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);
            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            self.quickPayProcess(false);
        }

        self.InitQickPayPage = function () {
            self.transactionProcess(false);
            self.confirmTransactionProcess(true);
            self.completeTransactionProcess(false);
            self.quickPayProcess(true);

            self.selectBillingAccountCompleted(true);
            self.inputAmountCompleted(true);
            self.selectServiceTypeCompleted(true);
            self.selectPaymentMethodCompleted(true);
        }

        self.BackToBiller = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            self.quickPayProcess(false);
            cs.triggerTab("panel-recipient");
            cs.scrollToTab('panel-recipient');
        }

        self.CloseAmountTab = function () {
            self.BackToBiller();
            self.selectBillingAccountCompleted(false);
        }

        self.BackToAmountInput = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            self.transactionProcess(true);
            self.quickPayProcess(false);

            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);

            cs.triggerTab("panel-amount");
            cs.scrollToTab('panel-amount');
        }

        self.BackToSelectPayment = function () {
            self.quickPayProcess(false);

            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);

            cs.triggerTab("panel-payment");
            cs.scrollToTab('panel-payment');
        }

        self.EditSenderPayment = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.CheckQuickPayCalculate()) {
                self.BackToSelectPayment();
            };
        };

        self.BackToSelectServiceType = function () {
            self.transactionProcess(true);
            self.quickPayProcess(false);

            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            cs.triggerTab("panel-service-type");
            cs.scrollToTab('panel-service-type');
        }

        self.EditServiceType = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.CheckQuickPayCalculate()) {
                self.BackToSelectServiceType();
            };
        };

        self.AmountDestinationChanged = function () {
            self.inputAmountCompleted(false);
            self.selectBillingAccountCompleted(true);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);
            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            originalLCRBillPayConsumerModel.isModified = true;
        }

        self.QuickPayConfirm = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.CheckQuickPayCalculate()) {
                var paymentMethod = self.paymentMethod();
                if (paymentMethod.IsIBVAccount) {
                    $.when(dataModel.checkIBVNetwork())
                    .done(function (result) {
                        $.when(dataModel.checkIBVBalance(paymentMethod, self.billPayTransaction().AmountDue.Value()))
                        .done(function (result) {
                            if (result.verifyPassed) {
                                self.billPayTransaction().IsIBVVerified = true;
                                self.Confirm(element);
                            } else {
                                self.PaymentMethodAPI().lastPaymentMethodId = null;
                                return;
                            }
                        })
                        .fail(function () {
                            self.Confirm(element);
                        });
                    })
                    .fail(function () {
                        self.Confirm(element);
                    })
                } else {
                    self.Confirm(element);
                }
            };
        };

        self.transStatus = new cs.executeStatus();
        self.Confirm = function (element) {
            if (!self.billPayTransaction().IsAgree()) {
                $("#confirmError").fadeIn();
                return;
            }

            if (self.transStatus.isExecuting()) {
                return;
            }

            Confirm(element);
        }

        function Confirm(element) {
            self.transStatus.setExecuting();
            if (!self.ApplyPromotionCodeSuccessful()) {
                self.billPayTransaction().PromotionCode("");
            }
            self.billPayTransaction().IsQuickPay = self.quickPayProcess();
            var tempTransactionModel = ko.mapping.toJS(self.billPayTransaction());
            tempTransactionModel.SelectedServiceType = ko.mapping.toJS(self.serviceType());
            return cs.AjaxByLoading({
                url: '/BillPayLCR/SelfServiceLCRTransaction',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempTransactionModel)
            }, true)
           .done(function (result) {
               cs.AddActivityInfo(28, null, true);
               self.transStatus.complete();
               //Init components view
               self.TransactionStart(false);
               self.selectBillingAccountCompleted(false);
               self.inputAmountCompleted(false);

               mappingTransaction(self.billPayTransaction(), result);
               self.transactionProcess(false);
               self.confirmTransactionProcess(false);
               self.completeTransactionProcess(true);
               cs.RegisterExpandCollapse();
               cs.SlideToTop();
               //DataCapture
               if (self.billPayTransaction().ConfirmationNumber.length === 20) {
                   cs.UpdateTransactionData({
                       receiptNumber: self.billPayTransaction().ConfirmationNumber,
                       transactionTypeId: self.billPayTransaction().TransactionType,
                       tax: self.billPayTransaction().FeeTaxes.Value,
                       fee: self.billPayTransaction().TotalFee.Value,
                       total: self.billPayTransaction().AmountDue.Value
                   });
               }

               if (app.senderInfo() != null) {
                   app.senderInfo().GetSenderLevel(element);
               }

               trackTransactionSuccessfully(cs.getValue(result.AmountToSend.Value), self.billPayTransaction().ConfirmationNumber.trim());

               trackRecipientPageTimeOnPage();
               track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionReceiptPage,track.PageEnum.TransactionReceiptPage);
           }).
            fail(function (xhr, status) {
                self.transStatus.complete();

                if (status == 'timeout') {
                    cs.showErrorMessage(commonstrings.messagebox.billpayfailed, commonstrings.messagebox.timeout);
                    return;
                }

                var tempError = "";
                try {
                    tempError = JSON.parse(xhr.responseText);
                } catch (e) {
                    cs.handleAjaxError(e);
                    return;
                }
                try {

                    var message = JSON.parse(tempError.Message);
                    if (message != null && message.exceptionCode == -462) {
                        cs.AddActivityInfo(29, null, true);
                        ShowPaymentsMethodFailDialog();
                    } else if (message != null && message.exceptionCode == -481) {
                        cs.BaseAjax({
                            url: '/PaymentMethod/GetCurrentPaymentProvider',
                            type: 'get',
                            dataType: 'json'
                        })
                        .done(function (result) {
                            app.senderInfo().PosPaymentConfig(result);
                        });
                        GetBillPayLCRPaymentMethods();

                        cs.AddActivityInfo(29, null, true);
                        ShowPaymentsMethodFailDialog();
                    } else {
                        cs.showErrorMessage(commonstrings.messagebox.billpayfailed, tempError.Message);
                    }
                } catch (e) {
                    cs.showErrorMessage(commonstrings.messagebox.billpayfailed, tempError.Message);
                }
            });
        }

        function ShowPaymentsMethodFailDialog() {
            $.when(cs.showErrorMessage(commonstrings.messagebox.paymenterror, commonstrings.messagebox.paymentnotsuccess + "&nbsp;<a id='payment-method-link'>" + commonstrings.messagebox.paymentmethod + "</a>&nbsp;" + commonstrings.messagebox.tryagain))
            .done(function () {
                $("#payment-method-link").click(function () {
                    cs.closeModal();
                    if (self.quickPayProcess()) {
                        self.EditSenderPayment();
                    } else {
                        self.BackToSelectPayment();
                    }
                });
            });
        }

        function convertTransactionModel(data) {
            data = ko.mapping.toJS(data);
            data.isChanged = false;
            data.AmountDestination.Value = ko.observable(data.AmountDestination.Value);
            data.AmountToSend.Value = ko.observable(data.AmountToSend.Value);
            data.PromotionCode = ko.observable(data.PromotionCode);
            data.IsAgree = ko.observable(false);
            data.isAmountLimitInValid = ko.observable(false);
            data.DisplayRate = ko.observable(data.DisplayRate);
            data.ToCurrencyCode = ko.observable(data.ToCurrencyCode);
            data.TotalFee.Value = ko.observable(data.TotalFee.Value);
            data.Discounts.Value = ko.observable(data.Discounts.Value);
            data.AmountDue.Value = ko.observable(data.AmountDue.Value);
            return data;
        }

        function convertServiceType(data) {
            data.Fee.Value = ko.observable(data.Fee.Value);
            return data;
        }

        // begin: quick pay
        self.InitializeTransactionQuickPay = function (data) {
            self.paymentMethod(data.PaymentMethod);
            data.BillPayLCRTransaction = convertTransactionModel(data.BillPayLCRTransaction);
            self.billPayTransaction(data.BillPayLCRTransaction);
            self.serviceType(convertServiceType(data.ServiceType));
            self.billingAccount(data.BillingAccount);
            self.TransactionStart(true);
            quickPayCalculateSuccessfully = true;


            //DataCapture
            cs.UpdateTransactionData({
                transactionTypeId: self.billPayTransaction().TransactionType,
                tax: self.billPayTransaction().FeeTaxes.Value,
                fee: self.billPayTransaction().TotalFee.Value,
                total: self.billPayTransaction().AmountDue.Value,
                amount: self.billPayTransaction().AmountToSend.Value()
            });

            self.transactionProcess(false);
            self.confirmTransactionProcess(true);
            self.completeTransactionProcess(false);
            self.quickPayProcess(true);

            self.selectBillingAccountCompleted(true);
            self.inputAmountCompleted(true);
            self.selectServiceTypeCompleted(true);
            self.selectPaymentMethodCompleted(true);
            cs.scrollToElement($('.quick-pay-href #input-quickpay-lcr-send-amount'));
        };

        self.InitializeTransactionQuickPayWithErrorMessage = function (billpay, errorMessage) {
            self.InitializeTransactionQuickPay(billpay);
            quickPayCalculateSuccessfully = false;
            self.inputAmountCompleted(false);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);
        };

        self.QuickPayGoToServiceType = function (data) {
            data.BillPayLCRTransaction = convertTransactionModel(data.BillPayLCRTransaction);
            self.billPayTransaction(data.BillPayLCRTransaction);
            self.billingAccount(data.BillingAccount);
            self.TransactionStart(true);

            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            self.quickPayProcess(false);

            self.selectBillingAccountCompleted(true);
            self.inputAmountCompleted(true);
            self.selectServiceTypeCompleted(false);
            self.selectPaymentMethodCompleted(false);

            cs.triggerTab("panel-service-type");
            cs.scrollToTab('panel-service-type');
        };

        self.QuickPayGoToPaymentMethod = function (data) {
            data.BillPayLCRTransaction = convertTransactionModel(data.BillPayLCRTransaction);
            self.billPayTransaction(data.BillPayLCRTransaction);
            self.serviceType(convertServiceType(data.ServiceType));

            self.billingAccount(data.BillingAccount);
            self.TransactionStart(true);

            self.transactionProcess(true);
            self.confirmTransactionProcess(false);
            self.completeTransactionProcess(false);
            self.quickPayProcess(false);

            self.selectBillingAccountCompleted(true);
            self.inputAmountCompleted(true);
            self.selectServiceTypeCompleted(true);

            cs.triggerTab("panel-payment");
            cs.scrollToTab('panel-payment');
        };

        var quickPayCalculateSuccessfully = false;
        self.QuickPayCalculate = function (element) {
            if (cs.isOpeningModal()) {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-lcr-confirm-done', 'back-to-amount-input', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
                return;
            }

            quickPayCalculateSuccessfully = false;
            self.PaymentMethodAPI().lastPaymentMethodId = null;

            if (self.billPayTransaction().PromotionCode && cs.CustomTrim(self.billPayTransaction().PromotionCode()) != "") {
                $.when(self.ApplyPromo(element))
                    .done(function () {
                        quickPayCalculateSuccessfully = true;
                        //DataCapture.
                        self.UpdateDataCaptureTransactionFee();
                    })
                    .fail(function () {
                        quickPayCalculateSuccessfully = false;
                    }).always(function () {
                        cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-lcr-confirm-done', 'back-to-amount-input', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
                    });
            }
            else {
                $.when(Calculate(false, true, element))
                    .done(function () {
                        quickPayCalculateSuccessfully = true;
                        //DataCapture.
                        self.UpdateDataCaptureTransactionFee();

                    })
                    .fail(function () {
                        quickPayCalculateSuccessfully = false;
                    }).always(function () {
                        cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-lcr-confirm-done', 'back-to-amount-input', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
                    });
            }
        };


        var quickPayCheckAmountTimer;
        var originalAmount;
        self.InputAmountQuickPaySection = function (amount) {
            if (amount == "" || $('#input-quickpay-lcr-send-amount').hasClass("placeholder-color")) {
                $("#input-quickpay-lcr-send-amount").trigger("change.attribute.amounttosend");
                amount = "0.00"; 
            }
            self.ShowPromotionCodeErrorMessage(false);
            if (!CheckAmountQuickPaySection(amount)) {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-lcr-confirm-done', 'back-to-amount-input', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
                return;
            }

            amount = setFormattedAmount(amount);
            if (originalAmount != undefined && Number(cs.GetOriginalNumber(originalAmount) == Number(cs.GetOriginalNumber(amount)))) {
                return;
            }

            if (quickPayCheckAmountTimer) {
                clearTimeout(quickPayCheckAmountTimer);
            }

            cs.disableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-lcr-confirm-done', 'back-to-amount-input', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
            quickPayCheckAmountTimer = setTimeout(function () {
                self.QuickPayCalculate('#virtualElement');
            }, 500);
        }

        function CheckAmountQuickPaySection(amount) {
            if (!cs.isAmountValid(amount)) {
                return false;
            }

            return true;
        };

        function setFormattedAmount(amount) {
            originalAmount = self.billPayTransaction().AmountDestination.Value();

            if (cs.IsMobileDevice()) {
                cs.formatAmountForInput('#input-quickpay-lcr-send-amount', originalAmount);
                self.billPayTransaction().AmountDestination.Value($('#input-quickpay-lcr-send-amount').val());
                return $('#input-quickpay-lcr-send-amount').val();
            } else {
                self.billPayTransaction().AmountDestination.Value(amount);
                return amount;
            }
        };

        // end: quick pay

        self.CheckQuickPayCalculate = function () {
            if (!self.CheckAmount()) {
                return false;
            }

            if (quickPayCalculateSuccessfully == false) {
                self.billPayTransaction().isAmountLimitInValid(false);
                self.QuickPayCalculate(null);
                return true;
            }

            return true;
        };

        self.CheckAmount = function () {
            if (!cs.isAmountValid(self.billPayTransaction().AmountDestination.Value())) {
                cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.messagebox.validamount);
                return false;
            }

            return true;
        };

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.billPayTransaction().ReceiptNumber, element);

            trackEmailTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.EmailReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        };

        self.PrintBillPayLCRReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/Customers/SelfServicePrintStandardReceipt',
                dataType: "html",
                cache: false,
                data: { 'receiptNumber': self.billPayTransaction().ReceiptNumber, 'senderEmailAddress': app.senderInfo().Customer().CustomerBasic.EmailAddress() }
            }, element)
             .done(function (result) {
                 cs.PrintTransaction(result, element);
             });

            trackPrintTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.PrintReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        }

        //DataCapture.
        self.UpdateDataCaptureTransactionFee = function () {
            cs.UpdateTransactionData({
                transactionTypeId: self.billPayTransaction().TransactionType,
                tax: self.billPayTransaction().FeeTaxes.Value,
                fee: self.billPayTransaction().TotalFee.Value,
                total: self.billPayTransaction().AmountDue.Value
            });
        }

        function GetLCRServiceType(element) {
            var accountId = self.billingAccount().RppsBillingAccountId;
            var amount = cs.GetOriginalNumber(self.billPayTransaction().AmountToSend.Value())
            if (!amount) {
                return;
            }

            cs.AjaxBySpinnerOrLoading({
                url: '/BillPayLCR/GetLCRServiceTypes',
                datatype: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "selectedBillingAccountId": accountId, 'amountToSend': amount, "isRppsBillingAccount": self.billingAccount().IsRppsBillingAccount })
            }, element)
            .done(function (result) {
                if (result) {
                    $.each(result, function (index, s) {
                        s.Selected = ko.observable(false);
                        if (self.serviceType()) {
                            s.Selected(self.ServiceTypeAPI().IsEqual(self.serviceType(), s));
                        }
                    });
                }
                self.ServiceTypeAPI().ServiceTypes(result);
            })
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());

            if (validateResult) {
                var tempBillingAccountRequiredInfo = ko.mapping.toJS(self.BillingAccountRequiredInfo);
                var tempTransaction = ko.mapping.toJS(self.billPayTransaction);
                tempTransaction.SelectedServiceType = ko.mapping.toJS(self.serviceType());
                tempTransaction.Regular = self.billingAccount().IsRppsBillingAccount;
                tempTransaction.BillingAccountId = self.billingAccount().RppsBillingAccountId;

                cs.AjaxBySpinner({
                    url: '/BillPayLCR/SelfServiceUpdateLCRAdditionalInfo',
                    datatype: "json",
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ "billPayTransactionModel": tempTransaction, 'billingAccountRequiredInfo': tempBillingAccountRequiredInfo })
                }, element)
                .done(function (result) {
                    self.AdditionalInfoAvaliable(false);
                    self.CustomerSaveAdditionalInfo(true);
                    cs.closeModal();
                    result.BillingAccountRequiredInfo.Fields = null;
                    result.BillingAccountRequiredInfo.States = null;

                    mappingTransaction(self.billPayTransaction(), result);
                    var amountDestination = cs.keepAmountDecimalPlaces(self.billPayTransaction().AmountDestination.Value());
                    self.billPayTransaction().lastTransactionSendAmount = amountDestination;
                    self.calculateAgain = false;

                    cs.triggerTab("panel-payment");
                    cs.scrollToTab('panel-payment');
                })
                .fail(function (xhr, status) {
                    cs.handleAjaxError(xhr.responseText, false);
                })
            }
        }

        self.CancelAdditionalInfo = function () {
            cs.closeModal(false);
            self.BackToSelectServiceType();
            self.selectServiceTypeCompleted(false);
        }

        function GetBillPayLCRPaymentMethods() {
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
           .done(function (result) {
               $.each(result, function (index, d) {
                   d.Selected = ko.observable(false);
               })
               self.PaymentMethodAPI().PaymentMethods(result);
           })
        }

        self.viewTransactionDetails = function () {
            var transaction = self.billPayTransaction();
            dataModel.viewTransactionHistoryByReceiptNumber(transaction.ReceiptNumber.trim());

            trackViewTransactionDetailsTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.ViewTransactionDetails);
        }

        self.cancelTransaction = function () {
            app.senderInfo().GoToDashboard();

            if (self.completeTransactionProcess()) {
                trackFinishLinkTotalClicks();
                track.trackTimeOnPageForPageLink(track.LabelEnum.Finish);
            }
        };
    }

    return new BillPayLCRViewModel();
});