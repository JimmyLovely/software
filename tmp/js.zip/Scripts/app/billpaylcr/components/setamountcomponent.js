﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings']], function (ko, cs, app, dataModel, commonstrings) {
    return function (params) {
        var self = this;
        self.TransactionDetails = ko.observable(null);
        self.BillingAccountRequiredInfo = ko.observable(null);
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.CustomerSaveAdditionalInfo = ko.observable(false);

        self.AmountDestinationBlur = function () {
            var amountDestination = cs.keepAmountDecimalPlaces(self.TransactionDetails().AmountDestination.Value());
            if (!self.TransactionDetails().lastTransactionSendAmount || self.TransactionDetails().lastTransactionSendAmount != amountDestination) {
                self.TransactionDetails().lastTransactionSendAmount = null;
                self.TransactionDetails().isChanged = true;
                app.factoryFunc('AmountChanged');
            }
        }

        self.BackToBiller = function () {
            app.factoryFunc('BackToBiller');
        };

        function CheckAmountIsValid() {
            if (!self.TransactionDetails()) return;

            var transactionDetail = self.TransactionDetails();
            var amount = transactionDetail.AmountToSend.Value();
            if (!amount || !cs.isAmountValid(amount)) {
                cs.showErrorMessage(commonstrings.billpayandbillpaylcr.messagebox.error, commonstrings.billpayandbillpaylcr.messagebox.inputvalidamount);
                return false;
            }
            return true;
        }

        self.CompleteInputAmount = function (element) {
            if (!CheckAmountIsValid()) {
                return;
            }

            var amountDestination = cs.keepAmountDecimalPlaces(self.TransactionDetails().AmountDestination.Value());
            if (!self.TransactionDetails().lastTransactionSendAmount || self.TransactionDetails().lastTransactionSendAmount != amountDestination) {
                self.TransactionDetails().lastTransactionSendAmount = amountDestination;
                app.factoryFunc('GoToServiceType', self.TransactionDetails);
            } else {
                app.factoryFunc('GoToServiceType', null);
            }
        };

        if (!params.defaultValue()) {
            GetSeletcedToCalculate();
        } else {
            self.TransactionDetails = params.defaultValue;

            self.TransactionDetails().lastTransactionSendAmount = cs.keepAmountDecimalPlaces(self.TransactionDetails().AmountDestination.Value());
        }


        function convertTransactionModel(data, needMapping) {
            data = ko.mapping.toJS(data);
            data.isChanged = false;
            if (data.AmountDestination.Value) {
                data.AmountDestination.Value = ko.observable(data.AmountDestination.Value);
            } else {
                data.AmountDestination.Value = ko.observable("0.00");
            }
            data.AmountToSend.Value = ko.observable(data.AmountToSend.Value);
            data.PromotionCode = ko.observable(data.PromotionCode);
            data.IsAgree = ko.observable(false);
            data.isAmountLimitInValid = ko.observable(false);
            data.DisplayRate = ko.observable(data.DisplayRate);
            data.ToCurrencyCode = ko.observable(data.ToCurrencyCode);
            data.TotalFee.Value = ko.observable(data.TotalFee.Value);
            data.Discounts.Value = ko.observable(data.Discounts.Value);
            data.AmountDue.Value = ko.observable(data.AmountDue.Value);
            return data;
        }

        function GetSeletcedToCalculate() {
            cs.BaseAjax({
                url: '/BillPayLCR/GetSeletcedToCalculate',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ 'selectedBillingAccountId': params.billingAccountId, "isRppsBillingAccount": params.isRppsBillingAccount })
            }, true)
            .done(function (data) {
                data = convertTransactionModel(data);
                self.TransactionDetails(data);
                self.TransactionDetails().isChanged = true;
                params.defaultValue(data);

                if (cs.IsMobileDevice()) {
                    if (!self.TransactionDetails().AmountToSend.Value()) {
                        self.TransactionDetails().AmountToSend.Value('0.00');
                    }
                    if (!self.TransactionDetails().AmountDestination.Value()) {
                        self.TransactionDetails().AmountDestination.Value('0.00');
                    }
                }
            })
            .fail(function (xhr, status) {
                var data = $.parseJSON(xhr.responseText);
                if (data.returnCode == -318) {
                    cs.showNotification(data, function () { return UpdateAdditionalInfo(data) });
                } else {
                    cs.handleAjaxError(xhr.responseText, false);
                }
            })
        }

        function UpdateAdditionalInfo(data) {
            var AdditionalInfoAvaliable = data.BillingAccountRequiredInfo && data.BillingAccountRequiredInfo.Fields.length > 0;
            if (AdditionalInfoAvaliable) {
                self.CustomerSaveAdditionalInfo(true);
                var tempFields = data.BillingAccountRequiredInfo.Fields;
                self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                self.AdditionalInfoAvaliable(true);
                cs.isCancelCloseModalCallBack = true;

                $.when(cs.openModal("modal-set-lcr-amount-additional-info"))
                .done(function () {
                    cs.initCustomAttributes();
                    cs.isCancelCloseModalCallBack = false;
                    cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                });
            }
        }

        self.AmountFormat = function (element, amount) {
            if (!cs.IsMobileDevice() && amount == "") {
                $(element).val("0.00");
                $("#input-lcr-send-amount").addClass("placeholder-color");
            }
        }
        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());

            if (validateResult) {
                var tempBillingAccountRequiredInfo = ko.mapping.toJS(self.BillingAccountRequiredInfo);
                //ko.mapping.fromJS(tempBillingAccountRequiredInfo, {}, self.BillPayTransaction().BillingAccountRequiredInfo);
                //var tempTransaction = ko.mapping.toJS(self.BillPayTransaction);

                cs.AjaxBySpinner({
                    url: '/BillPayLCR/UpdateInternationalBillingAccountAdditionalInfo',
                    datatype: "json",
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ "BillingAccountRequiredInfo": tempBillingAccountRequiredInfo })
                }, element)
                .done(function (result) {
                    self.AdditionalInfoAvaliable(false);
                    self.CustomerSaveAdditionalInfo(false);

                    cs.showNotification(result, function () { return GetSeletcedToCalculate() });
                })
                .fail(function (xhr, status) {
                    cs.handleAjaxError(xhr.responseText, false);
                })
            }
        }

        self.CancelAdditionalInfo = function () {
            cs.closeModal(false);
            app.factoryFunc("CloseAmountTab");
        }

    }
});