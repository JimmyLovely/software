﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;
        cs.deepClone(ko.mapping.toJS(params.BillingAccount), self);

        self.AccountNumber = ko.observable(self.AccountNumber);
        self.RetypeAccountNumber = ko.observable(self.AccountNumber());
        self.FirstName = ko.observable(self.FirstName);
        self.LastName = ko.observable(self.LastName);
        self.EditablePhoneNumber = ko.observable(self.EditablePhoneNumber);
        self.AccountName = ko.observable(self.AccountName);
        self.IsAccountNumberInvalid = ko.observable(self.IsAccountNumberInvalid);
        self.AdditionalInfoAvaliable = ko.observable(self.AdditionalInfoAvaliable);
        self.SelectedService = ko.observable(self.SelectedService);
        self.BillingAccountRequiredInfo = ko.observable();
        var additionalFields = new Array();
        var isInitizile = false;

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.EditNewBiller, track.PageEnum.EditNewBiller);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.EditNewBiller, track.PageEnum.EditNewBiller);
        // End appsflyer track event

        self.AccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnorequired
            },
            equal: {
                onlyIf: function () { return self.IsAccountNumberInvalid() },
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billernomatched
            }
        });

        self.RetypeAccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnorequired
            },
            equal: {
                onlyIf: function () { return !cs.equals(self.AccountNumber(), self.RetypeAccountNumber(), true) },
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnomatch
            },
        });

        self.FirstName.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.firstnamerequired
            },
            //Inline message
            minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
            maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
            equal: {
                onlyIf: function () { return self.FirstName() != "" && cs.IsInvalidName(self.FirstName()) != 0 },
                //Inline message
                message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
            }
        }).isModified(false);

        self.LastName.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.lastnamerequired
            },
            //Inline message
            minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
            maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
            equal: {
                onlyIf: function () { return self.LastName() != "" && cs.IsInvalidName(self.LastName()) != 0 },
                //Inline message
                message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
            }
        }).isModified(false);

        self.EditablePhoneNumber.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.contactphonerequired
            },
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.EditablePhoneNumber()); },
                //Inline message
                message: commonstrings.commonvalidation.contactphonevalid
            },
            minLength: {
                params: 10,
                //Inline message
                message: commonstrings.commonvalidation.contactphonevalid
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.EditablePhoneNumber()); },
                //Inline message
                message: commonstrings.commonvalidation.contactphonevalid
            }
        }).isModified(false);

        self.AccountName.extend({
            //Inline message
            maxLength: { params: 50, message: commonstrings.commonvalidation.nicknamemaxlength }
        }).isModified(false);

        var updateAccountStatus = new cs.executeStatus();
        self.UpdateBillingAccount = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            $.when(self.HasBillersMatchAccountNumber(self))
            .done(function () {
                UpdateLCRAccount(element);
            })

            var trackSaveTotalClick = trackEvent;
            trackSaveTotalClick("Save");
        }

        var billerGroupMemberId = 0;
        self.HasBillersMatchAccountNumber = function (billingAccount) {
            var deffered = $.Deferred();
            var accountNumber = self.AccountNumber();

            if (selectedGroupId == null || selectedGroupId == 0 || !accountNumber) {
                return deffered.resolve();
            }

            cs.BaseAjax({
                url: '/BillPayLCR/GetLCRBillers',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "lcrBillerGroupId": selectedGroupId, "accountNumber": accountNumber }),
            })
            .done(function (data) {
                if (data == null || data.length == 0) {
                    self.IsAccountNumberInvalid(true);
                }
                else {
                    self.IsAccountNumberInvalid(false);
                    var isExist = false;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].BillerGroupMemberId == billerGroupMemberId) {
                            isExist = true;
                        }
                    }

                    if (!isExist) {
                        self.SelectedService(data[0].ServiceId);
                        billerGroupMemberId = data[0].BillerGroupMemberId;
                        for (var i = 0; i < data.length; i++) {
                            if (data[i].ServiceId == 2) {
                                self.SelectedService(2);
                                billerGroupMemberId = data[i].BillerGroupMemberId;
                            }
                        }
                    }
                    isInitizile = true;
                }

                deffered.resolve();
            })
            .fail(function (data) {
                self.IsAccountNumberInvalid(true);
                deffered.resolve();
            })
            return deffered;
        }

        function GetAdditionalInfo(element) {
            var tempData = ko.mapping.toJS(self);
            if (tempData.SelectedService != 1) {
                delete tempData.Countries;

                return cs.AjaxBySpinner({
                    url: "/BillPayLCR/GetSelfServiceAdditionalInfo",
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "service": tempData.SelectedService, "billingAccountId": tempData.RppsBillingAccountId, "lcrGroupId": selectedGroupId, "isRppsBillingAccount": tempData.IsRppsBillingAccount, "isInitizile": isInitizile }),
                }, element)
                .done(function (data) {
                    isInitizile = false;
                    if (data.AdditionalInfoAvaliable) {
                        additionalFields.push({ BillerGroupMemberId: billerGroupMemberId, RequiredInfo: data.BillingAccountRequiredInfo });
                        var tempFields = data.BillingAccountRequiredInfo.Fields;
                        self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                        cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                        self.AdditionalInfoAvaliable(true);
                        cs.isCancelCloseModalCallBack = true;
                        cs.closeModalCallBack('modal-update-additional-info', function () {
                            self.AdditionalInfoAvaliable(false);
                        });
                        $.when(cs.openModal("modal-update-additional-info"))
                        .done(function () {
                            cs.initCustomAttributes();
                            cs.isCancelCloseModalCallBack = false;
                            updateLCRAccountStatus.complete();
                            cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                        });
                    } else {
                        UpdateLCRBillingAccount(element);
                    }
                })
                .fail(function () {
                    updateLCRAccountStatus.complete();
                });
            } else {
                UpdateLCRBillingAccount(element);
            }
        }

        var updateLCRAccountStatus = new cs.executeStatus();
        function UpdateLCRAccount(element) {
            if (updateLCRAccountStatus.isExecuting()) {
                return;
            }
            updateLCRAccountStatus.setExecuting();
            self.errors = ko.validation.group(self);
            if (self.isValid() && !self.IsAccountNumberInvalid()) {
                var result = GetRequiredInfoFromArray();

                if (result.IsExist) {
                    self.BillingAccountRequiredInfo(ko.mapping.fromJS(result.RequiredInfo));
                    cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                    self.AdditionalInfoAvaliable(true);
                    cs.isCancelCloseModalCallBack = true;
                    cs.closeModalCallBack('modal-update-additional-info', function () {
                        self.AdditionalInfoAvaliable(false);
                    });
                    $.when(cs.openModal("modal-update-additional-info"))
                    .done(function () {
                        cs.initCustomAttributes();
                        cs.isCancelCloseModalCallBack = false;
                        updateLCRAccountStatus.complete();
                        cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                    });
                } else {
                    GetAdditionalInfo(element);
                }
            }
            else {
                updateLCRAccountStatus.complete();
                LogSelectedBillingAccount(self);
                self.errors.showAllMessages();
            }
        }

        function GetRequiredInfoFromArray() {
            var isExist = false;
            var requiredInfo = null;
            if (additionalFields.length > 0) {
                for (var i = 0 ; i < additionalFields.length; i++) {
                    if (additionalFields[i].BillerGroupMemberId == billerGroupMemberId) {
                        isExist = true;
                        requiredInfo = additionalFields[i].RequiredInfo;
                    }
                }
            }

            return { IsExist: isExist, RequiredInfo: requiredInfo };
        }

        function UpdateLCRBillingAccount(element) {
            var tempData = ko.mapping.toJS(self);
            if (tempData.BillingAccountRequiredInfo) {
                delete tempData.BillingAccountRequiredInfo.States;
            }

            cs.AjaxBySpinner({
                url: '/BillPayLCR/SelfServiceUpdateLCRBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempData)
            }, element)
                .done(function (data) {
                    trackSaveTimeOnPage();
                    if (params.CompletedEditBiller) {
                        params.CompletedEditBiller(data);
                    }

                    updateLCRAccountStatus.complete();
                    cs.closeModal();
                })
                .fail(function () {
                    updateLCRAccountStatus.complete();
                });
        }

        function LogSelectedBillingAccount(lcrBillingAccountModel) {
            var message = new Array();

            if (!lcrBillingAccountModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + lcrBillingAccountModel.AccountNumber.error);
            }
            if (!lcrBillingAccountModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + lcrBillingAccountModel.RetypeAccountNumber.error);
            }

            cs.logException("BillPayCustomer.SelectedBillingAccount", JSON.stringify(message));
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());
            if (validateResult) {
                if (updateLCRAccountStatus.isExecuting()) {
                    return;
                }
                updateLCRAccountStatus.setExecuting();
                self.AdditionalInfoAvaliable(self.AdditionalInfoAvaliable());

                UpdateLCRBillingAccount(element)
            }
        }

        self.IsAccountNumberInvalid(false);
        var timeHandler = 0;
        self.ValidateAccountNumberKeyup = function (billingAccount) {
            if (!billingAccount.AccountNumber.isModified()) return;

            billingAccount.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.HasBillersMatchAccountNumber(billingAccount);
            }, 500);
        }

        self.ValidateAccountNumberBlur = function (billingAccount) {
            billingAccount.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.HasBillersMatchAccountNumber(billingAccount);
            }, 500);
        }

        var selectedGroupId;
        cs.BaseAjax({
            url: "/BillPayLCR/GetLCRGroupByAccount",
            type: "POST",
            dataType: "json",
            contentType: "application/json",
            data: JSON.stringify({ "billingAccountId": self.RppsBillingAccountId, 'isRppsBillingAccount': self.IsRppsBillingAccount })
        })
        .done(function (data) {
            selectedGroupId = data.GroupId;
            cs.BaseAjax({
                url: "/BillPayLCR/GetLCRBillers",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "lcrBillerGroupId": data.GroupId, "accountNumber": self.AccountNumber() })
            })
            .done(function (data) {
                if (data != null && data.length != 0) {
                    var isExist = false;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].ServiceId == self.SelectedService()) {
                            isExist = true;
                            billerGroupMemberId = data[i].BillerGroupMemberId;
                        }
                    }

                    if (!isExist) {
                        self.SelectedService(data[0].ServiceId);
                        billerGroupMemberId = data[0].BillerGroupMemberId;
                        for (var i = 0; i < data.length; i++) {
                            if (data[i].ServiceId == 2) {
                                self.SelectedService(2);
                                billerGroupMemberId = data[i].BillerGroupMemberId;
                            }
                        }
                    }

                    var result = GetRequiredInfoFromArray();
                    isInitizile = true;
                    if (!result.IsExist) {
                        if (self.SelectedService() != 1) {
                            cs.BaseAjax({
                                url: "/BillPayLCR/GetSelfServiceAdditionalInfo",
                                type: "POST",
                                dataType: "json",
                                contentType: "application/json",
                                data: JSON.stringify({ "service": self.SelectedService(), "billingAccountId": self.RppsBillingAccountId, "lcrGroupId": selectedGroupId, "isRppsBillingAccount": self.IsRppsBillingAccount, "isInitizile": isInitizile }),
                            }).done(function (data) {
                                isInitizile = false;
                                if (data.AdditionalInfoAvaliable) {
                                    additionalFields.push({ BillerGroupMemberId: billerGroupMemberId, RequiredInfo: data.BillingAccountRequiredInfo });
                                }
                            });
                        }
                    }
                }
            })
        });

        var trackCloseTotalClick = trackEvent;
        self.closeEditBiller = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.EditNewBiller,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.EditNewBiller,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.EditNewBiller,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Edit New Biller",
                eventPage: track.PageEnum.EditNewBiller,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});