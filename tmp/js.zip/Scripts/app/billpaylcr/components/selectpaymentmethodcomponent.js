﻿define(['knockout', 'ClientScript', 'app', 'DataModel'], function (ko, cs, app, dataModel) {
    return function (params) {
        var self = this;
        self.PaymentMethods = ko.observable(null);
        self.addBankAccountFlag = ko.observable(false);
        self.addCreditDebitFlag = ko.observable(false);
        self.IsBank = params.isBank;
        self.Fee = params.Fee;
        self.lastPaymentMethodId = null;
        self.linkIBVAccountFlag = ko.observable(false);
        self.reLinkIBVAccountFlag = ko.observable(false);
        self.IBVStatus = ko.observable(cs.IBVStatus.Normal);

        var isAddIBV = false;

        if (params.api) {
            params.api(this);
        }

        self.HasBankAccount = ko.computed(function () {
            var paymentMethods = self.PaymentMethods();
            if (!paymentMethods) {
                return false;
            }

            var result = false;

            $.each(paymentMethods, function (index, p) {
                result = result || p.IsBank;
            });

            return result;
        });

        self.HasCarditOrDebitCard = ko.computed(function () {
            var paymentMethods = self.PaymentMethods();
            if (!paymentMethods) {
                return false;
            }

            var result = false;
            $.each(paymentMethods, function (index, p) {
                result = result || !p.IsBank;
            });

            return result;
        });

        self.CompleteSelectPaymentMethod = function (paymentMethod) {
            if (paymentMethod.IsBank && paymentMethod.IsIBVAccount) {
                $.each(self.PaymentMethods(), function (index, p) {
                    p.IsVerifying(false);
                });
                self.IBVStatus(cs.IBVStatus.Normal);
            }
            if (paymentMethod.IsBank && (!self.lastPaymentMethodId || self.lastPaymentMethodId != paymentMethod.PaymentMethodId)) {
                $.each(self.PaymentMethods(), function (index, p) {
                    p.Selected(p.PaymentMethodId == paymentMethod.PaymentMethodId);
                });

                if (paymentMethod.IsBank) {
                    $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                   .done(function (result) {
                       if (!paymentMethod.IsIBVAccount) {
                           $.each(self.PaymentMethods(), function (index, p) {
                               p.IsVerifying(p.PaymentMethodId === paymentMethod.PaymentMethodId);
                           });
                           self.lastPaymentMethodId = null;
                           self.IBVStatus(cs.IBVStatus.Verifying);
                           return;
                       }
                       if (params.Done) {
                           self.lastPaymentMethodId = paymentMethod.PaymentMethodId;
                           params.Done(ko.mapping.toJS(paymentMethod));
                       }
                   })
                   .fail(function () {
                       if (params.Done) {
                           self.lastPaymentMethodId = paymentMethod.PaymentMethodId;
                           params.Done(ko.mapping.toJS(paymentMethod), true);
                       }
                   })
                }
            } else {
                self.IBVStatus(cs.IBVStatus.Normal);
                if (params.Done) {
                    params.Done(paymentMethod, true);
                }
            }
        };

        self.CancelVerification = function () {
            var canceledPaymenthod = self.removeVerifyingStatus();

            if (params.Done) {
                self.lastPaymentMethodId = canceledPaymenthod.PaymentMethodId;
                params.Done(ko.mapping.toJS(canceledPaymenthod), true);
            }
        }

        self.removeVerifyingStatus = function() {
            var canceledPaymenthod = null;

            $.each(self.PaymentMethods(), function (index, p) {
                if (p.IsVerifying()) {
                    p.IsVerifying(false);
                    canceledPaymenthod = p;
                    return false;
                }
            });
            self.IBVStatus(cs.IBVStatus.Normal);

            return canceledPaymenthod;
        }

        self.DoVerificationNow = function () {
            $.when(dataModel.checkIBVNetwork())
            .done(function (result) {
                InitializePaymentMethodModel('modal-link-ibv-account', 'linkIBVAccountFlag');
                setTimeout(function () {
                    dataModel.addIBVPostMessageListener();
                    $("#ibv-submit-form").empty();
                    $("#ibv-submit-form").append(result);
                    document.getElementById('rsessionPost').submit();

                    self.removeVerifyingStatus();
                }, 500);

                dataModel.setFastLinkEvent(function (data) {
                    AddIBVPaymentMethod(data);
                })
            })
            .fail(function () {
                self.removeVerifyingStatus();
            })
        }

        function AddIBVPaymentMethod(data) {
            var newAddedPaymentMethod = null;
            if (!isAddIBV) {
                var tempPaymentMethods = self.PaymentMethods();
                $.each(tempPaymentMethods, function (index, p) {
                    if (p.Selected()) {
                        newAddedPaymentMethod = p;
                    }
                });
            }
            if (!newAddedPaymentMethod) {
                newAddedPaymentMethod = {};
            }
            newAddedPaymentMethod.CardName = data.AccountName;
            if (data.AccountType == "CHECKING") {
                newAddedPaymentMethod.AccountTypeId = 3
            } else if (data.AccountType == "SAVINGS") {
                newAddedPaymentMethod.AccountTypeId = 4
            }
            newAddedPaymentMethod.AccountRoutingNumber = data.BankTransferCode;
            newAddedPaymentMethod.CardNumber = data.AccountNumber;
            newAddedPaymentMethod.IsBank = true;
            newAddedPaymentMethod.IBVAccount = data;
            newAddedPaymentMethod.IsIBVAccount = true;
            newAddedPaymentMethod.IsDefault = false;
            newAddedPaymentMethod.PaymentProviderId = !!app.senderInfo() ? !!app.senderInfo().PosPaymentConfig() ? app.senderInfo().PosPaymentConfig().BankAccountProviderId : 2 : 2;

            cs.AjaxByLoading({
                url: '/PaymentMethod/AddPaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(newAddedPaymentMethod))
            })
            .done(function (data) {
                data.Selected = ko.observable(true);
                self.CompletedAddBankAccount(data);
            })
        }

        self.credentialChangedReLink = function (paymentMethodId) {
            $.when(dataModel.reVerify(paymentMethodId))
            .done(function (result) {
                InitializePaymentMethodModel('modal-link-ibv-account', 'linkIBVAccountFlag');
                setTimeout(function () {
                    dataModel.addIBVPostMessageListener();
                    $("#ibv-submit-form").empty();
                    $("#ibv-submit-form").append(result);
                    document.getElementById('rsessionPost').submit();

                    self.lastPaymentMethodId = null;
                }, 500);

                dataModel.setFastLinkEvent(function (data) {
                    setTimeout(function () {
                        AddIBVPaymentMethod(data);
                    }, 500);
                })
            })
            .fail(function () {
                self.removeVerifyingStatus();
            })
        }

        self.BackToSelectServiceType = function () {
            if (params.Back) {
                params.Back();
            }
        };

        self.InitializeNewSenderCreditAccount = function () {
            cs.closeModalCallBack('modal-credit-debit-account', function () {
                self.addCreditDebitFlag(false);
            });
            self.addCreditDebitFlag(true);
            cs.openModal('modal-credit-debit-account');
        }

        self.InitializeNewSenderBankAccount = function () {
            $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
            .done(function (result) {
                self.IBVStatus(cs.IBVStatus.AddingPrompt);
            })
            .fail(function () {
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            })

            
        }

        self.promptIBVResult = function (isIBV) {
            if (isIBV) {
                self.IBVStatus(cs.IBVStatus.Normal);
                self.DoVerificationNow();
                isAddIBV = true;
            } else {
                self.IBVStatus(cs.IBVStatus.Normal);
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
        }

        self.continueAddBankAccount = function (isContinue) {
            if (isContinue) {
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
            self.IBVStatus(cs.IBVStatus.Normal);
        }


        self.CompletedAddBankAccount = function (paymentMethod) {
            var paymentMethods = self.PaymentMethods();
            var isConvert = false;

            for (var i = 0; i < paymentMethods.length; i++) {
                if (paymentMethods[i].PaymentMethodId == paymentMethod.PaymentMethodId) {
                    paymentMethods[i] = paymentMethod;
                    paymentMethods[i].IsVerifying = ko.observable(false);
                    isConvert = true;
                }
            }

            if (isConvert) {
                self.PaymentMethods(paymentMethods);
                params.Done(ko.mapping.toJS(paymentMethod));
                return;
            }

            var tempPaymentMethod = {
                PaymentMethodId: paymentMethod.PaymentMethodId,
                CardName: paymentMethod.CardName,
                CardNickname: paymentMethod.CardNickname,
                DisplayCardNumber: paymentMethod.DisplayCardNumber,
                IsBank: paymentMethod.IsBank,
                Fee: params.Fee(),
                AccountTypeId: paymentMethod.AccountTypeId,
                AccountType: paymentMethod.AccountType,
                Selected: ko.observable(false),
                IsVerifying: ko.observable(false),
                IsIBVAccount: paymentMethod.IsIBVAccount
            };

            var paymentMethods = self.PaymentMethods();
            if (!paymentMethods) {
                paymentMethods = new Array();
            }
            paymentMethods.push(tempPaymentMethod);
            self.PaymentMethods(paymentMethods);

            $.each(self.PaymentMethods(), function (index, p) {
                p.Selected(p.PaymentMethodId == paymentMethod.PaymentMethodId);
            });

            self.lastPaymentMethodId = tempPaymentMethod.PaymentMethodId;
            params.Done(ko.mapping.toJS(tempPaymentMethod));
        }

        self.GetPaymentMethods = function () {
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
           .done(function (result) {
               $.each(result, function (index, d) {
                   d.Selected = ko.observable(false);
                   d.IsVerifying = ko.observable(false);
                   if (params.defaultValue()) {
                       d.Selected(d.PaymentMethodId == params.defaultValue());
                   }
               })

               if (params.defaultValue() && !params.reLinkPaymentMethod()) {
                   self.lastPaymentMethodId = params.defaultValue();
               }
               self.PaymentMethods(result);

               if (params.reLinkPaymentMethod() && params.reLinkPaymentMethod().PaymentMethodId > 0) {
                   var paymentMethods = self.PaymentMethods();
                   $.each(paymentMethods, function (index, d) {
                       d.Selected(d.PaymentMethodId === params.reLinkPaymentMethod().PaymentMethodId);
                   });
                   self.PaymentMethods(paymentMethods);
               }
           })
        }

        self.OpenNewModal = function () {
            self['addCreditDebitFlag'](false);
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');
        }

        function InitializePaymentMethodModel(modalId, flagName) {
            cs.closeModalCallBack(modalId, function () {
                self[flagName](false);
                if (modalId == 'modal-link-ibv-account') {
                    window.removeEventListener("message", dataModel.ibvPostMessage);
                }
            });

            self[flagName](true);
            cs.openModal(modalId);
        }

        self.GetPaymentMethods();

        function clearDefaultPaymentMethod() {
            if (self.PaymentMethods()) {
                $.each(self.PaymentMethods(), function (index, d) {
                    d.Selected(false);
                    d.IsVerifying(false);
                });
            }
        }
        ko.computed(function () {
            var paymentMethod = params.defaultValue();
            if (paymentMethod == null) {
                clearDefaultPaymentMethod();
                self.lastPaymentMethodId = null;
            }
        });
    }
});