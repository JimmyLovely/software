﻿define(['knockout', 'ClientScript', 'DataModel', 'app', 'Plugins', 'tinyscrollbar'], function (ko, cs, dataModel, app) {
    return function (params) {
        var self = this;
        self.tempSelectedBillingAccount;
        self.BillingAccounts = ko.observable();
        self.BillpayAddLCRBillingAccountFlag = ko.observable(false);
        var selectedBillingAccountId, selectedBillingAccount;

        cs.BaseAjax({
            url: '/BillPayLCR/GetBillingAccounts',
            type: "GET",
            dataType: "json"
        })
       .done(function (data) {
           if (data) {
               $.each(data, function (index, r) {
                   r.Selected = ko.observable(false);
                   r.Selected(r.RppsBillingAccountId == params.defaultValue());
                   if (r.Selected()) {
                       selectedBillingAccount = r;
                   }
               })

               if (params.defaultValue) {
                   selectedBillingAccountId = params.defaultValue();
               }
           } else {
               data = [];
           }
           
           self.BillingAccounts(data);
           InitializeSearchBillingAccounts(data);

           if (params.autoNext()) {
               if (selectedBillingAccount) {
                   selectedBillingAccountId = 0;
                   self.GoToAmountToSend(selectedBillingAccount)
               } else {
                   ap.factoryFunc("InitSelectBillerView");
               }
           }
       });

        function InitializeSearchBillingAccounts(billingAccounts) {
            if (!billingAccounts || billingAccounts.length < 6) {
                return;
            }

            var tempAccounts = $.map(billingAccounts, function (item, index) { return { value: (!item.AccountName) ? item.BillerName : item.AccountName, data: item }; });
            tempAccounts.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            if (self.tempSelectedBillingAccount) {
                $("#autocomplete-LCR-Biller-products").val(!self.tempSelectedBillingAccount.AccountName ? self.tempSelectedBillingAccount.BillerName : self.tempSelectedBillingAccount.AccountName);
                cs.removeDisable("#selectbutton");
            }
            $('#autocomplete-LCR-Biller-products').autocomplete({
                lookup: tempAccounts,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.tempSelectedBillingAccount = suggestion.data;
                    cs.removeDisable("#selectbutton");
                },
                onInvalidateSelection: function () {
                    self.tempSelectedBillingAccount = null;
                    cs.addDisable('selectbutton')
                }
            });
        }

        self.GoToAmountToSendBySelectButton = function (element) {
            if (cs.isDisabled(element)) { return; }

            var tempBillingAccount = ko.mapping.toJS(self.tempSelectedBillingAccount);
            self.GoToAmountToSend(tempBillingAccount);
        }

        self.GoToAmountToSend = function (billingAccount) {
            if (self.BillingAccounts()) {
                $.each(self.BillingAccounts(), function (index, b) {
                    b.Selected(b.RppsBillingAccountId == billingAccount.RppsBillingAccountId);
                });
            }

            if (selectedBillingAccountId != billingAccount.RppsBillingAccountId) {
                selectedBillingAccountId = billingAccount.RppsBillingAccountId;
                app.factoryFunc("GoToAmountToSend", billingAccount);
            } else {
                app.factoryFunc("GoToAmountToSend");
            }
        };

        self.AddNewBillingAccount = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            cs.closeModalCallBack('modal-biller-new', function () {
                self.BillpayAddLCRBillingAccountFlag(false);
            });

            self.BillpayAddLCRBillingAccountFlag(true);

            cs.openModal('modal-biller-new');
        }

        self.completedAddBiller = function (billingAccount) {
            var tempBillingAccount = {
                RppsBillingAccountId: billingAccount.RppsBillingAccountId,
                AccountNumber: billingAccount.AccountNumber,
                BillerName: billingAccount.BillerGroup.Name,
                AccountName: billingAccount.AccountName,
                IsRppsBillingAccount: billingAccount.IsRppsBillingAccount,
                Selected: ko.observable(false)
            };
            var tempBillingAccounts = self.BillingAccounts();
            tempBillingAccounts.push(tempBillingAccount);

            self.BillingAccounts(tempBillingAccounts);
            InitializeSearchBillingAccounts(tempBillingAccounts);
            self.BillpayAddLCRBillingAccountFlag(false);
            self.GoToAmountToSend(tempBillingAccount);
        };
    }
});