﻿define(['knockout', 'app', 'ClientScript', 'DataModel', 'R', 'TrackEvent', paths['common-strings']], function (ko, app, cs, dataModel, R, track, commonstrings) {
    return function (params) {
        var self = this;
        self.Countries = ko.observable([]);
        self.AccountNumber = ko.observable(null);
        self.RetypeAccountNumber = ko.observable(null);
        self.FirstName = ko.observable(null);
        self.LastName = ko.observable(null);
        self.EditablePhoneNumber = ko.observable(null);
        self.NickName = ko.observable(null);
        self.IsRppsBillingAccount = ko.observable(false);
        self.DestinationCountry = null;
        self.IsAccountNumberInvalid = ko.observable(false);
        self.BillingAccountRequiredInfo = ko.observable(null);
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.SelectedService = ko.observable(false);
        self.AccountType;
        self.logActionTimeData = ko.observable({ transactionStepId: 4, label: 'Biller ID', value: 0 });
        var autoCompleteData = '';
        var synchroFlag = false;
        var isSelect = false;
        var searchLcrBillerModal = { OriginalSearchCondition: '', OriginalKey: 0, OriginalType: '' };
        var additionalFields = new Array();
        // 0 means valid.
        // 1 means empty.
        // 2 means no result.
        // Requires 1 characters or more for search
        self.BillerNameValidType = ko.observable(0);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddNewBiller, track.PageEnum.AddNewBiller);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.AddNewBiller, track.PageEnum.AddNewBiller);

        ko.computed(function () {
            var billerNameValidType = self.BillerNameValidType();

            if (billerNameValidType === 1) {
                self.trackErrorMessage(commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billerrequired);
            } else if (billerNameValidType === 2) {
                self.trackErrorMessage(commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billernomatched);
            } else if (billerNameValidType === 3) {
                self.trackErrorMessage(commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billerkeywordsearchlength);
            }

        });
        // End appsflyer track event

        function applyBillerValidation() {
            self.AccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnorequired
                },
                equal: {
                    onlyIf: function () {
                        return self.IsAccountNumberInvalid();
                    },
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billernomatched
                }
            }).isModified(false);

            self.RetypeAccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnorequired
                },
                equal: {
                    onlyIf: function () { return !cs.equals(self.AccountNumber(), self.RetypeAccountNumber(), true) },
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnomatch
                },
            });

            self.FirstName.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.firstnamerequired
                },

                //Inline message
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
                equal: {
                    onlyIf: function () { return self.FirstName() != "" && cs.IsInvalidName(self.FirstName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
                }
            }).isModified(false);

            self.LastName.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.lastnamerequired
                },
                //Inline message
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
                equal: {
                    onlyIf: function () { return self.LastName() != "" && cs.IsInvalidName(self.LastName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
                }
            }).isModified(false);

            self.EditablePhoneNumber.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.contactphonerequired
                },
                number: {
                    onlyIf: function () { return cs.IsInvalidPhoneNumber(self.EditablePhoneNumber()); },
                    //Inline message
                    message: commonstrings.commonvalidation.contactphonevalid
                },
                minLength: {
                    params: 10,
                    //Inline message
                    message: commonstrings.commonvalidation.contactphonevalid
                },
                maxLength: {
                    onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.EditablePhoneNumber()); },
                    //Inline message
                    message: commonstrings.commonvalidation.contactphonevalid
                }
            }).isModified(false);

            self.NickName.extend({
                //Inline message
                maxLength: { params: 50, message: commonstrings.commonvalidation.nicknamemaxlength }
            }).isModified(false);
        }

        function InitializeDestinationCountries(element) {
            $.when(dataModel.GetCountriesByTransactionType(11))
              .done(function (data) {
                  var index = data.indexOf(data.filter(function (x) {
                      return x.Value == "840";
                  })[0]);
                  data.splice(0, 0,
                  new Object({ Code: "", Text: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.selectcountry, Value: "0" }),
                  data.splice(index, 1)[0]);
                  var countries = [];
                  countries = data.filter(function (item) {
                      if (item.Value != 0 && item.Value != 484 && item.Value != 840) {
                          countries.push(item);
                      }
                      return item.Value == "0" || item.Value == "484" || item.Value == "840";
                  }).concat(countries);
                  self.Countries(countries);

                  $("#select-country-add-biller").val(self.Countries()[0].Value);
              });
        }

        applyBillerValidation();

        InitializeDestinationCountries();

        self.CountryChange = function () {
            if (!(($("#select-country-add-biller").find("option:selected").text() == commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.selectcountry && isSelect) || $("#select-country-add-biller").find("option:selected").text() == self.DestinationCountry)) {
                resetBiller();
                resetAutoComplete();

                if (self.BillerNameValidType() > 0) {
                    self.BillerNameValidType(0);
                }
            }
        }

        function resetBiller() {
            self.AccountNumber(null);
            self.RetypeAccountNumber(null);
            self.FirstName(null);
            self.LastName(null);
            self.EditablePhoneNumber(null);
            self.IsAccountNumberInvalid(false);
            self.IsRppsBillingAccount(false);
            self.NickName('');

            self.IsAccountNumberInvalid(false);
            self.AccountNumber.isModified(false);
            self.RetypeAccountNumber.isModified(false);
            self.FirstName.isModified(false);
            self.LastName.isModified(false);
            self.EditablePhoneNumber.isModified(false);
        }

        function resetAutoComplete() {
            $('#input-biller-name').val("");
            $('#input-biller-name').autocomplete({
                lookup: []
            });

            searchLcrBillerModal = { OriginalSearchCondition: '', OriginalKey: 0, OriginalType: '' };
        }
        //Search Billers
        var timeHandler = 0;
        var searchBillerName = '';
        self.AutoSearchLCRBiller = function (e) {
            if (cs.isKeyPressControlOrSelect(e.which)) {
                return;
            }

            searchBillerName = $("#input-biller-name").val().trim();
            isSelect = false;
            synchroFlag = true;

            //Reset input box's status when clear biller name.
            if (!searchBillerName) {
                self.BillerNameValidType(0);
                searchLcrBillerModal.OriginalSearchCondition = "";
                $('#input-biller-name').autocomplete({
                    lookup: []
                });

                e.stopImmediatePropagation();
                $('#input-biller-name').off('keyup.autocomplete');
                $('#input-biller-name').off('focus.search.biller');
            }

            clearTimeout(timeHandler);
            if (searchBillerName.length > 0) {
                if (searchBillerName != searchLcrBillerModal.OriginalSearchCondition ||
                    //Fixed issue: if input an invalid biller name with 3 characters, then delete the latest character, then input the deleted character,
                    //There is no validation for inputed biller name.
                    (!!$('#input-biller-name').autocomplete() && $('#input-biller-name').autocomplete().suggestions.length < 1)) {
                    resetBiller();
                }

                timeHandler = setTimeout(function () {
                    if (searchBillerName != searchLcrBillerModal.OriginalSearchCondition ||
                        //Fixed issue: if input an invalid biller name with 3 characters, then delete the latest character, then input the deleted character,
                        //There is no validation for inputed biller name.
                        (!!$('#input-biller-name').autocomplete() && $('#input-biller-name').autocomplete().suggestions.length < 1)) {
                        self.SearchLCRBillers();
                    }
                }, 500);
            }
        }

        // fixed IME issue.
        $("#input-biller-name").on('keyup.search.biller', function (e) {
            self.AutoSearchLCRBiller(e);
        });

        // initial autocomplete ui
        var initialData = [
            { value: ' ', data: 'initialData1' },
            { value: '  ', data: 'initialData2' }
        ];

        $('#input-biller-name').autocomplete({
            lookup: initialData
        });

        // focus element after modal is opened for the first time
        var isFirstOpen = false;
        $("#modal-biller-new").on("opened", function () {
            if (isFirstOpen) {
                return;
            }

            $('#input-biller-name').autocomplete().getSuggestions(" ");
            $('#input-biller-name').autocomplete().hide();
            isFirstOpen = true;
        });

        self.SearchLCRBillers = function (element) {
            var searchBillerName = $("#input-biller-name").val().trim();
            if (searchBillerName.length < 1) {
                self.BillerNameValidType(3);
                $('#input-biller-name').autocomplete({
                    lookup: []
                });
                return;
            }

            var billerType = "All Types";
            var billerCountry = $("#select-country-add-biller").find("option:selected").text();
            searchLcrBillerModal = { OriginalSearchCondition: '', OriginalKey: 0, OriginalType: '' };
            searchLcrBillerModal.OriginalSearchCondition = searchBillerName;
            $('#input-biller-name').autocomplete({
                lookup: []
            });

            if (element) {  // Move this function before setTimeout if invoke by AutoSearchLCRBiller.
                resetBiller();
            }

            autoCompleteData = '';
            cs.addSearchSpinner("#search-lcr-billers");
            self.BillerNameValidType(0);
            synchroFlag = false;
            cs.BaseAjax({
                url: '/BillPayLCR/SelfServiceSearchLCRBillers',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billerName": searchBillerName, "billerType": billerType, "destinationCountryId": $("#select-country-add-biller").val(), "localDataLength": 0 })
            })
            .done(function (data) {
                if (synchroFlag) {
                    return;
                }
                synchroFlag = true;
                data = filterLcrBillerList(data, billerType, billerCountry, searchBillerName);

                //Data Capture
                if (Object.prototype.toString.call(data).slice(8, -1) == "Array" && data.length == 0) {
                    var searchSectionTypeId;

                    if (require('app').page().name == "BillPayLCRConsumer") {
                        searchSectionTypeId = cs.LuSearchSectionType.AddBillerInBillPay;
                    } else {
                        searchSectionTypeId = cs.LuSearchSectionType.AddBillerInManagerBillers;
                    }

                    cs.LogSearchActivity(searchBillerName, searchSectionTypeId);
                }

                autoCompleteData = data;
                $('#input-biller-name').autocomplete({
                    lookup: autoCompleteData,
                    lookupFilter: function (suggestion, query, queryLowerCase) {
                        return suggestion;
                    },
                    triggerSelectOnValidInput: false,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        if (searchLcrBillerModal.OriginalKey != suggestion.value || searchLcrBillerModal.OriginalType != suggestion.data.GroupId) {
                            searchLcrBillerModal.OriginalKey = suggestion.value;
                            searchLcrBillerModal.OriginalType = suggestion.data.GroupId;

                            var billingAccount = suggestion.data.BillingAccount;

                            self.FirstName(billingAccount.FirstName);
                            self.LastName(billingAccount.LastName);
                            self.EditablePhoneNumber(billingAccount.EditablePhoneNumber);
                            self.AccountType = billingAccount.AccountType;
                            self.DestinationCountry = billingAccount.DestinationCountry;
                            self.NickName('');
                            self.IsRppsBillingAccount(billingAccount.IsRppsBillingAccount);
                            clearTimeout(timeHandler);
                        }
                        isSelect = true;
                        synchroFlag = true;
                        $(".autocomplete-loading").remove();
                        self.BillerNameValidType(0);
                    }
                }).focus(function () {
                    //reset result list's pageindex when focus on
                    synchroFlag = true;
                    $(".autocomplete-loading").remove();
                    $('.autocomplete-suggestions:visible').on('scroll', function () {
                        Pagination($(this), billerType);
                    });
                }).on('keyup', function (e) {
                    if (e.keyCode == 40 || e.keyCode == 38) {
                        Pagination($(".autocomplete-suggestions:visible"), billerType);
                    }
                });

                $('#input-biller-name').autocomplete().getSuggestionsLocal = function (query) {
                    return cs.GetSuggestionsLocal(this.options.lookup, query);
                };

                if (data == null || data.length == 0) {
                    self.BillerNameValidType(2);
                }

                // If tab to next input box before search result back, not focus on search box.
                if (document.activeElement && document.activeElement.id == "input-biller-name") {
                    $('#input-biller-name').focus();
                }

                $('#input-biller-name').off('keyup.autocomplete')
                .on('keyup.autocomplete', function (e) {
                    var value = $(this).val();
                    if (searchLcrBillerModal.OriginalKey != value || !value) {
                        if (value.length >= 1) {
                            if (e.which == 13) return;

                            if (cs.isMatchSuggestion($('#input-biller-name').autocomplete().suggestions, value, false) > -1 ||
                                //Fixed issue: If input second and third characters very fast after inputing an invalid biller name, 
                                //there's a error message for correct biller name (PC only).
                                ($("#input-biller-name").autocomplete().suggestions.length == 0 && value.length == 3)) {
                                self.BillerNameValidType(0);
                            } else {
                                self.BillerNameValidType(2);
                            }
                        }
                        else {
                            self.BillerNameValidType(1);
                        }

                        searchLcrBillerModal.OriginalKey = '';
                        resetBiller();
                    }
                })
               .off('focus.search.biller')
               .on('focus.search.biller', function () {
                   // autocomplete also need focus to show, so wait let autocomplete data show first.
                   setTimeout(function () {
                       if ($('#input-biller-name').autocomplete().visible) {
                           self.BillerNameValidType(0);
                       }
                       else {
                           if ($('#input-biller-name').val() && $('#input-biller-name').length > 0) {
                               self.BillerNameValidType(2);
                           }
                       }
                   }, 300);
               })

            })
            .fail(function () {
                synchroFlag = true;
            })
            .always(function () {
                cs.removeSearchSpinner("#search-lcr-billers");
            });
        }
        self.CheckLcrBillers = function (element) {
            if ($('.autocomplete-selected').length > 0) return;

            var matchedIndex = -1;
            var value = $(element).val();
            if (searchLcrBillerModal.OriginalKey != value || !value) {
                if (value.length >= 1) {
                    if ($('#input-biller-name').autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($('#input-biller-name').autocomplete().suggestions, value, true)) > -1) {
                        self.BillerNameValidType(0);
                        $('#input-biller-name').autocomplete().select(matchedIndex);
                    } else {
                        self.BillerNameValidType(2);
                    }
                }
                else {
                    self.BillerNameValidType(1);
                }
            }

            if ($('#input-biller-name').autocomplete()) {
                $('#input-biller-name').autocomplete().hide();
            }
        }

        function Pagination(element, billerType) {
            var scroll = element;
            var isBottom = isScrollbarBottom($(element));
            var newDate = '';
            if (isBottom && synchroFlag) {
                synchroFlag = false;
                $(element).append("<div class='autocomplete-loading' ></div>");
                scroll.scrollTop(scroll.scrollTop() + 30);
                cs.BaseAjax({
                    url: '/BillPayLCR/SelfServiceSearchLCRBillers',
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ "billerName": searchBillerName, "billerType": billerType, "destinationCountryId": $("#select-country-add-biller").val(), "localDataLength": autoCompleteData.length })
                })
                .done(function (newData) {
                    if (newData.length == 0 || isSelect) {
                        $(".autocomplete-loading").remove();
                        return;
                    }

                    autoCompleteData = autoCompleteData.concat(newData);
                    var option = {
                        lookup: autoCompleteData,
                        lookupFilter: function (suggestion, query, queryLowerCase) {
                            return suggestion;
                        },
                        triggerSelectOnValidInput: false,
                        minChars: 3,
                        onSelect: function (suggestion) {
                            if (searchLcrBillerModal.OriginalKey != suggestion.value || searchLcrBillerModal.OriginalType != suggestion.data.GroupId) {
                                searchLcrBillerModal.OriginalKey = suggestion.value;
                                searchLcrBillerModal.OriginalType = suggestion.data.GroupId;

                                var billingAccount = suggestion.data.BillingAccount;

                                self.FirstName(billingAccount.FirstName);
                                self.LastName(billingAccount.LastName);
                                self.EditablePhoneNumber(billingAccount.EditablePhoneNumber);
                                self.AccountType = billingAccount.AccountType;
                                self.DestinationCountry = billingAccount.DestinationCountry;
                                self.NickName('');
                                self.IsRppsBillingAccount(billingAccount.IsRppsBillingAccount);
                            }
                            isSelect = true;
                            synchroFlag = true;
                            $(".autocomplete-loading").remove();

                            self.BillerNameValidType(0);
                        }
                    };
                    var scrollTop = scroll.scrollTop();
                    $("#input-biller-name").autocomplete().suggestions = autoCompleteData;
                    $("#input-biller-name").autocomplete().setOptions(option);
                    $("#input-biller-name").autocomplete().customerUpdateSuggest();
                    scroll.scrollTop(scrollTop - 28);
                    synchroFlag = true;
                })
                .fail(function () {
                    $(".autocomplete-loading").remove();
                    scroll.scrollTop(scroll[0].scrollHeight - scroll.height() - 5);
                    synchroFlag = true;
                });
            }
        }

        function isScrollbarBottom(container) {
            if (container.length > 0) {
                var height = container.outerHeight();
                var scrollHeight = container[0].scrollHeight;
                var scrollTop = container.scrollTop();
                if (scrollTop >= scrollHeight - height) {
                    return true;
                }
            }
            return false;
        };

        function filterLcrBillerList(tempBillers, billerType, billerCountry, billerName) {
            var result = new Array();
            if (billerType == "All Types" && billerCountry == commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.selectcountry) {
                result = tempBillers;
            }
            else {
                for (var i = 0; i < tempBillers.length; i++) {
                    if ((tempBillers[i].data.BillingAccount.BillerType == billerType && billerCountry == commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.selectcountry)
                        || (tempBillers[i].data.BillingAccount.DestinationCountry == billerCountry && billerType == "All Types")
                        || (tempBillers[i].data.BillingAccount.BillerType == billerType && tempBillers[i].data.BillingAccount.DestinationCountry == billerCountry)) {
                        result.push(tempBillers[i]);
                    }
                }
            }

            return result;
        }
        //End Search Billers

        self.ValidateAccountNumberKeyup = function () {
            if (!self.AccountNumber.isModified()) return;

            self.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                HasBillersMatchAccountNumber();
            }, 500);
        }

        self.ValidateAccountNumberBlur = function () {
            self.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                HasBillersMatchAccountNumber();
            }, 500);
        }

        var accountId = 0;
        var billerGroupMemberId = 0;
        function HasBillersMatchAccountNumber() {
            var deffered = $.Deferred();
            var accountNumber = self.AccountNumber();
            billerName = $("#input-biller-name").val();
            if (!searchLcrBillerModal.OriginalType || searchLcrBillerModal.OriginalKey != billerName
                || !accountNumber) {
                return deffered.resolve();
            }
            cs.BaseAjax({
                url: '/BillPayLCR/GetLCRBillers',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "lcrBillerGroupId": searchLcrBillerModal.OriginalType, "accountNumber": accountNumber }),
            })
            .done(function (data) {
                if (data == null || data.length == 0) {
                    self.IsAccountNumberInvalid(true);
                }
                else {
                    self.IsAccountNumberInvalid(false);
                    self.SelectedService(data[0].ServiceId);
                    billerGroupMemberId = data[0].BillerGroupMemberId;
                    for (var i = 0; i < data.length; i++) {
                        if (data[i].ServiceId == 2) {
                            self.SelectedService(2);
                            billerGroupMemberId = data[i].BillerGroupMemberId;
                        }
                    }
                }

                deffered.resolve();
            })
            .fail(function (data) {
                self.IsAccountNumberInvalid(true);
                deffered.resolve();
            })
            return deffered;
        }

        var saveBillingAccountStatus = new cs.executeStatus();
        self.addBillingAccount = function (element) {
            if (saveBillingAccountStatus.isExecuting()) {
                return;
            }

            var trackSaveTotalClick = trackEvent;
            trackCloseTotalClick("Save");

            if (cs.isDisabled(element)) {
                return;
            }
            var toBeAddedBillerName = $('#input-biller-name').val();
            if (toBeAddedBillerName == '' || toBeAddedBillerName == null) {
                self.BillerNameValidType(1);
            }
            else if (!searchLcrBillerModal.OriginalKey || searchLcrBillerModal.OriginalKey == 0) {
                self.BillerNameValidType(2);
            }

            $.when(HasBillersMatchAccountNumber())
            .done(function () {
                if (self.IsAccountNumberInvalid()) {
                    return false;
                }
                saveBillingAccountStatus.setExecuting();
                self.errors = ko.validation.group(self);
                if (self.isValid() && self.BillerNameValidType() == 0) {
                    var result = GetRequiredInfoFromArray();

                    if (result.IsExist) {
                        self.BillingAccountRequiredInfo(ko.mapping.fromJS(result.RequiredInfo));
                        cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                        self.AdditionalInfoAvaliable(true);
                        cs.isCancelCloseModalCallBack = true;
                        cs.closeModalCallBack('modal-add-additional-info', function () {
                            self.AdditionalInfoAvaliable(false);
                        });
                        $.when(cs.openModal("modal-add-additional-info"))
                        .done(function () {
                            cs.initCustomAttributes();
                            cs.isCancelCloseModalCallBack = false;
                            saveBillingAccountStatus.complete();
                            cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                        });
                    } else {
                        GetAdditionalInfo(element);
                    }
                }
                else {
                    saveBillingAccountStatus.complete();
                    self.errors.showAllMessages();
                    cs.reRenderedOverflowy();
                }
            })
        }

        function GetRequiredInfoFromArray() {
            var isExist = false;
            var requiredInfo = null;
            if (additionalFields.length > 0) {
                for (var i = 0 ; i < additionalFields.length; i++) {
                    if (additionalFields[i].BillerGroupMemberId == billerGroupMemberId) {
                        isExist = true;
                        requiredInfo = additionalFields[i].RequiredInfo;
                    }
                }
            }

            return { IsExist: isExist, RequiredInfo: requiredInfo };
        }

        function GetAdditionalInfo(element) {
            var tempData = ko.mapping.toJS(self);
            delete tempData.Countries;

            return cs.AjaxBySpinner({
                url: "/BillPayLCR/GetSelfServiceAdditionalInfo",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "service": tempData.SelectedService, "billingAccountId": -1, "lcrGroupId": searchLcrBillerModal.OriginalType, "isRppsBillingAccount": false, "isInitizile": true }),
            }, element)
            .done(function (data) {
                if (data.AdditionalInfoAvaliable) {
                    additionalFields.push({ BillerGroupMemberId: billerGroupMemberId, RequiredInfo: data.BillingAccountRequiredInfo });
                    var tempFields = data.BillingAccountRequiredInfo.Fields;
                    self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                    cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                    self.AdditionalInfoAvaliable(true);
                    cs.isCancelCloseModalCallBack = true;
                    cs.closeModalCallBack('modal-add-additional-info', function () {
                        self.AdditionalInfoAvaliable(false);
                    });
                    $.when(cs.openModal("modal-add-additional-info"))
                    .done(function () {
                        cs.initCustomAttributes();
                        cs.isCancelCloseModalCallBack = false;
                        saveBillingAccountStatus.complete();
                        cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                    });
                } else {
                    $.when(AddLCRBillingAccount(element))
                    .done(function () {
                        cs.closeFoundationDropdown();
                    });
                }
            })
            .fail(function () {
                saveBillingAccountStatus.complete();
            });
        }

        function AddLCRBillingAccount(element) {
            var tempData = ko.mapping.toJS(self);
            delete tempData.Countries;
            if (self.AdditionalInfoAvaliable()) {
                delete tempData.BillingAccountRequiredInfo.States;
            }

            return cs.AjaxBySpinner({
                url: '/BillPayLCR/SelfServiceAddLCRBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountViewModel": ko.mapping.toJS(tempData), "selectedGroupId": searchLcrBillerModal.OriginalType }),
            }, element)
                .done(function (data) {
                    trackSaveTimeOnPage();
                    $.when(cs.closeModal())
                    .done(function () {
                        self.AdditionalInfoAvaliable(false);
                        if (typeof params.completedAddBiller === 'function') {
                            params.completedAddBiller(data);
                        }
                        saveBillingAccountStatus.complete();
                        self.logActionTimeData({ transactionStepId: 4, label: data.IsRppsBillingAccount === false ? 'Biller ID' : 'RPPS Biller ID', value: data.RppsBillingAccountId });
                    })
                })
                .fail(function () {
                    saveBillingAccountStatus.complete();
                });
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());

            if (validateResult) {
                if (saveBillingAccountStatus.isExecuting()) {
                    return;
                }
                saveBillingAccountStatus.setExecuting();
                AddLCRBillingAccount(element);
            }
        }

        var trackCloseTotalClick = trackEvent;
        self.closeAddBiller = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewBiller,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddNewBiller,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewBiller,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add New Biller",
                eventPage: track.PageEnum.AddNewBiller,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});