﻿define(['knockout', 'ClientScript', 'app', 'DataModel'], function (ko, cs, app, dataModel) {
    return function (params) {
        var self = this;
        self.ServiceTypes = ko.observable(null);

        var lastServiceType;

        if (params.api) {
            params.api(this);
        }

        self.IsEqual = function (serverType1, serviceType2) {
            if (serverType1.TransactionTypeId == serviceType2.TransactionTypeId &&
                serverType1.ServiceType == serviceType2.ServiceType &&
                serverType1.PaymentMethodTypeId == serviceType2.PaymentMethodTypeId) {
                return true;
            }

            return false;
        }

        self.CompleteSelectServiceType = function (serviceType) {
            if (!lastServiceType || !self.IsEqual(lastServiceType, serviceType)) {
                $.each(self.ServiceTypes(), function (index, s) {
                    s.Selected(self.IsEqual(serviceType, s));
                });
                app.factoryFunc('GoToSenderPayment', ko.mapping.toJS(serviceType));
            }
            else {
                app.factoryFunc('GoToSenderPayment', null);
            }
            lastServiceType = ko.mapping.toJS(serviceType);
        };

        self.BackToAmountInput = function () {
            app.factoryFunc('BackToAmountInput');
        };

        cs.BaseAjax({
            url: '/BillPayLCR/GetLCRServiceTypes',
            datatype: "json",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ "selectedBillingAccountId": params.billingAccountId(), 'amountToSend': cs.GetOriginalNumber(params.amountToSend()), "isRppsBillingAccount": params.isRppsBillingAccount() })
        })
        .done(function (result) {
            if (result) {
                $.each(result, function (index, s) {
                    s.Selected = ko.observable(false);
                    if (params.defaultValue()) {
                        s.Selected(self.IsEqual(params.defaultValue(), s));
                    }
                });
                if (params.defaultValue()) {
                    lastServiceType = ko.mapping.toJS(params.defaultValue());
                }
            }

            self.ServiceTypes(result);
        })
    }
});