﻿define(['knockout', 'ClientScript', 'DataModel', 'app', paths['common-strings'], 'R', 'TrackEvent'], function (ko, cs, dataModel, app, commonstrings, R, track) {
    return function (params) {
        var self = this;
        self.AccountTypeId = ko.observable();
        self.AccountRoutingNumber = ko.observable();
        self.CardNumber = ko.observable();
        self.CardName = ko.observable();
        self.CardNickname = ko.observable();
        self.ShouldUseNewAddress = ko.observable(false);
        self.BillingAddress = ko.observable(null);
        self.SelectedBillingAddress = null;
        self.CVV = ko.observable();
        self.Month = ko.observable();
        self.Year = ko.observable();
        self.TokenReferenceId = ko.observable();
        self.TokenServiceUrl = ko.observable();
        self.BillingAddressAPI = ko.observable();
        self.PaymentProviderId = ko.observable(!!app.senderInfo() ? !!app.senderInfo().PosPaymentConfig() ? app.senderInfo().PosPaymentConfig().CreditCardProviderId : 2 : 2);
        self.CardNumberGTB = ko.observable(null);
        self.IsValidCardName = ko.observable(true);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddCard, track.PageEnum.AddCard);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        track.generateErrorMessageTrack(track.CategoryEnum.AddCard, track.PageEnum.AddCard);
        // End appsflyer track event

        //DataCapture.
        self.logActionTimeData = ko.observable({ transactionStepId: 10, label: 'Payment_Method_ID', value: 0 });

        self.GetPaymentProviderId = function () {
            cs.BaseAjax({
                url: '/PaymentMethod/GetCurrentPaymentProvider',
                type: 'get',
                dataType: 'json'
            })
            .done(function (result) {
                self.PaymentProviderId(result.CreditCardProviderId);
                app.senderInfo().PosPaymentConfig(result);
            });
        }

        self.AccountTypeId.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.typerequired
            },
        }).isModified(false);

        self.CardName.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.nameoncardrequired
            },
            minTrimLength: {
                params: 2,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.nameoncardminlength;
                }
            },
            maxLength: {
                params: 50,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.nameoncardmaxlength
                }
            },
            equal: {
                onlyIf: function () { return (cs.IsInvalidName(self.CardName()) != 0 || !self.IsValidCardName()) },
                message: function () {
                    return (cs.IsInvalidName(self.CardName()) == 1 && self.IsValidCardName())
                        //Inline message
                        ? commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.nameoncardvalid : commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.nameoncardinvalid;
                }
            }
        }).isModified(false);

        if (self.PaymentProviderId() == 1) {
            // 0 means valid
            // 1 means required
            // 2 means invalid
            self.CardNumberValidation = ko.observable(0);
            self.CardNumber.extend({
                required: {
                    onlyIf: function () { return self.CardNumberValidation() == 1 },
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numberrequired
                },
                number: {
                    params: true,
                    message: function () {
                        //Inline message
                        return commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numbervalid
                    }
                },
                equal: {
                    onlyIf: function () { return self.CardNumberValidation() == 2 },
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numbervalid
                }
            }).isModified(false);
        }

        if (self.PaymentProviderId() != 1) {
            // 0 means valid
            // 1 means invalid
            self.CardNumberGTBValidation = ko.observable(0);
            self.CardNumberGTB.extend({
                required: {
                    params: true,
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numberrequired
                },
                number: {
                    params: true,
                    message: function () {
                        return commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numbervalid
                    }
                },
                minLength: {
                    params: 13,
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numberminlength
                },
                maxLength: {
                    params: 19,
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numbermaxlength
                },
                equal: {
                    onlyIf: function () { return self.CardNumberGTBValidation() == 1 },
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.numbervalid
                }
            }).isModified(false);
        }


        self.CVV.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.cvvrequired
            },
            number: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.cvvvalid
            },
            maxLength: {
                params: 4,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.cvvmaxlength
            }
        }).isModified(false);

        self.DateIsInValid = ko.computed(function () {
            var tempMonth = self.Month();
            var tempYear = self.Year();

            if (tempMonth && tempYear) {
                month = parseInt(tempMonth);
                year = parseInt(tempYear);
                var date = new Date();
                var currentYear = date.getFullYear();
                var currentMonth = date.getMonth();
                if (year > currentYear) {
                    return false;
                }
                else if (year == currentYear) {
                    if (month > currentMonth) {
                        return false;
                    }
                    else {
                        return true;
                    }
                }
                else {
                    return true;
                }
            } else {
                return false;
            }
        });

        self.Month.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expmonthrequired
            },
            equal: {
                onlyIf: self.DateIsInValid,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expirationdateinvalid
            },
        }).isModified(false);

        self.Year.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expyearrequired
            },
            equal: {
                onlyIf: self.DateIsInValid,
                //Inline message
                message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expirationdateinvalid
            },
        }).isModified(false);

        var cardNumberLoaded = false;
        function GetReferenceId() {
            $("#credit-loading-icon").fadeIn();
            $("#input-card-number").css("display", "block");
            $("#card-number").css("display", "none");
            cardNumberLoaded = false;
            isVerified = false;
            return cs.BaseAjax({
                url: '/PaymentMethod/GetReferenceId',
                type: "Get",
                cache: false,
                dataType: "json"
            }, true)
            .done(function (data) {
                cs.BaseAjax({
                    url: data.TokenServiceUrl,
                    dataType: "jsonp",
                    type: "HEAD",
                    timeout: 30000
                }, true).done(function () {
                    successLoad(data);
                }).fail(function (error) {
                    if (error.status == "200") {
                        successLoad(data);
                    } else {
                        cardNumberLoaded = true;
                        $("#card-number").css("display", "block");
                        $("#credit-loading-icon").fadeOut();
                        $("#input-card-number-cover").val(commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.errormessage);
                        $("#input-card-number").val(commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.errormessage);
                    }
                });

            });
        }

        function successLoad(data) {
            self.TokenServiceUrl(data.TokenServiceUrl);
            self.TokenReferenceId(data.TokenReferenceId);
            cs.IFrameTokenServiceUrl = data.TokenServiceUrl;

            var iframe = document.getElementById('card-number');

            iframe.onload = function () {
                cardNumberLoaded = true;
                $("#input-card-number").css("display", "none");
                $("#card-number").css("display", "block");
                $("#credit-loading-icon").fadeOut();
                $("#input-card-number-cover").css("display", "none");
                var language = cs.getLanguage();
                if (language == 'es-MX') {
                    iframe.contentWindow.postMessage('language_ES', self.TokenServiceUrl());
                }

                window.addEventListener('touchstart', function (e) {
                    if (iframeIsFocused) {
                        iframeIsFocused = false;
                        iframe.blur();
                        iframe.contentWindow.postMessage('txtText_Blur', self.TokenServiceUrl());
                    }
                }, false);
            }
        }

        function initialize() {
            setTimeout(function () {
                if (self.PaymentProviderId() == 1) {
                    $("#input-credit-debit").removeClass("isGTB");
                    GetReferenceId();
                } else {
                    $("#card-number-GTB").off("input.onlyNumber").on("input.onlyNumber", function () {
                        var number = $("#card-number-GTB").val();
                        if (NumberMod10Check(number)) {
                            self.CardNumberGTBValidation(0);
                        } else {
                            self.CardNumberGTBValidation(1);
                        }
                    });
                }
            }, 100);
        }
        initialize();

        $("#input-card-name").on('input propertychange', function () {
            self.IsValidCardName(true);
        });

        self.ExpiredYears = function () {
            var shortExpiredYearArray = new Array();
            var fromYear = new Date().getUTCFullYear();

            //The max value of expiration year is current year plus 30 years.
            var maxYear = fromYear + 30;

            var getShortFromYear = function (year) { return parseInt(year.toString().substr(2, 2)); };

            for (var year = fromYear; year <= maxYear; year++) {
                currentYear = { 'Text': getShortFromYear(year), 'Value': year.toString() };
                shortExpiredYearArray.push(currentYear);
            }

            return shortExpiredYearArray;
        };

        var isAddAccount = false;
        self.AddAccount = function (element) {
            if (self.PaymentProviderId() == 1) {
                AddAccountByEPayments(element);
            } else {

                AddAccountByGTB(element);
            }

            var trackSaveTotalClick = trackEvent;
            trackCloseTotalClick("Save");
        }

        function AddAccountByEPayments(element) {
            if (!cardNumberLoaded) {
                return;
            }

            if (isVerified) {
                AddAccountExt(element);
            } else {
                isVerified = false;
                isAddAccount = true;
                document.getElementById('card-number').contentWindow.postMessage('txtText_Blur', self.TokenServiceUrl());
                var func = function () {
                    if (isVerified) {
                        isAddAccount = false;
                        AddAccountExt(element);
                    } else {
                        setTimeout(function () { func(); }, 500);
                    }
                }

                func();
            };
        }

        function AddAccountByGTB(element) {
            self.errors = ko.validation.group(self);
            var isValidBillingAddress = true;
            if (self.BillingAddressAPI()) {
                isValidBillingAddress = self.BillingAddressAPI().isValidBillingAddress();
            }

            if (self.isValid() && isValidBillingAddress) {
                if ($('a[href=#panel_billing_new_add]').parent().hasClass('active')) {
                    $.when(self.BillingAddressAPI().GetAddressDetails(element))
                     .done(function () {
                         GetCustomerIdAndAccountId(element);
                     })
                } else {
                    GetCustomerIdAndAccountId(element);
                }
            } else {
                self.errors.showAllMessages();
            }
        }

        function GetCustomerIdAndAccountId(element) {
            $(element).addClass("now-loading");
            cs.BaseAjax({
                url: '/PaymentMethod/GetGoToBillingConfiguration',
                type: "Get",
                cache: false,
                dataType: "json"
            }, true)
            .done(function (data) {
                var merchantIdent = data.GoToBillingMerchantIdent;
                var formData = "";
                var x_customer_id = app.senderInfo().Customer().CustomerBasic.CardHolderId();
                var x_payment_account_id = GeneratePaymentAccountId(self.CardNumberGTB());
                var x_cc_name = self.CardName().replace(" ", "+");
                var x_cc_number = self.CardNumberGTB();
                var x_cc_exp = (self.Month().length > 1 ? self.Month() : "0" + self.Month()) + self.Year().substring(2, 4);
                var x_cc_cvv = self.CVV();
                formData = "x_customer_id=" + x_customer_id + "&x_payment_account_id=" + x_payment_account_id + "&x_cc_name=" + x_cc_name + "&x_cc_number=" + x_cc_number + "&x_cc_exp=" + x_cc_exp + "&x_cc_cvv=" + x_cc_cvv;
                formData += '&merchant_id=' + encodeURIComponent(merchantIdent);
                formData += '&x_transaction_type=' + encodeURIComponent(data.GoToBillingTransactionType);
                var jqxhr = $.post(data.GoToBillingUrl, formData, function (response) {
                    var xml = $($.parseXML(response));
                    var status = xml.find("status").text();
                    var description = xml.find("description").text();

                    if (status == 'G') {
                        var customer_id = xml.find("gtb_customer_id").text();
                        var account_id = xml.find("gtb_account_id").text();
                        self.TokenReferenceId(x_payment_account_id);
                        AddPaymentMethod(element, customer_id, account_id);
                    }
                    else {
                        if (description.indexOf("name") != -1) {
                            self.IsValidCardName(false);
                        } else if (description.indexOf("account") != -1) {
                            self.CardNumberGTBValidation(1);
                        }
                        $(element).removeClass("now-loading");
                    }

                });
            })
            .fail(function () {
                $(element).removeClass("now-loading");
            });
        }

        function GeneratePaymentAccountId(number) {
            var newNumber = "";
            if (number.length > 8) {
                // Keep start 4 digits and end 4 digits, get middle digits.
                var originalMiddleDigits = number.substring(4, number.length - 4);
                var numberArray = new Array(9, 8, 7, 6, 5, 4, 3, 2, 1, 0);
                for (var i = 0 ; i < originalMiddleDigits.length; i++) {
                    // Here we get a digit from originalMiddleDigits, make it as an index to find according number from numberArray and then add the index in originalMiddleDigits.
                    newNumber = newNumber + ((numberArray[parseInt(originalMiddleDigits[i])] + i) % 10).toString();
                }
                newNumber = number.substring(0, 4) + newNumber + number.substring(number.length - 4, number.length)
            }
            else {
                newNumber = number;
            }


            return newNumber;
        }

        function NumberMod10Check(number) {
            var isDigits = false,
                bEven = false,
                iCheckSum = 0,
                newNumber = 0;

            if (!isNaN(isDigits)) {
                isDigits = true;
            }

            if (isDigits) {
                if (CheckNumberWithIssuer(number) || CheckNumberWithCarteBlancheCard(number) || CheckNumberWithMasterAndVISACard(number)) {
                    for (i = 1 ; i <= number.length; i++) {
                        var digit = parseInt(number[number.length - i]);
                        if (bEven) {
                            var newDigit = digit * 2;
                            if (newDigit >= 10) {
                                newNumber = newNumber + parseInt(newDigit.toString()[0]) + parseInt(newDigit.toString()[1]);
                            } else {
                                newNumber = newNumber + newDigit;
                            }
                        } else {
                            newNumber = newNumber + digit;
                        }

                        bEven = !bEven;
                    }
                }
                else {
                    newNumber = -1;
                }
            } else {
                newNumber = -1;
            }

            return (newNumber % 10 == 0);
        }

        // Credit Card Issuer
        function CheckNumberWithIssuer(number) {
            if (!isNaN(number) && number.length >= 2) {
                var firstTwoNumber = number.substr(0, 2);

                // American Express
                if (['34', '37'].indexOf(firstTwoNumber) != -1) {
                    if (number.length == 15) {
                        return true;
                    }
                }
                // Diners Club - Internationa
                if (['36'].indexOf(firstTwoNumber) != -1) {
                    if (number.length == 14) {
                        return true
                    }
                }
                // Diners Club - USA & Canada
                if (['54'].indexOf(firstTwoNumber) != -1) {
                    if (number.length == 16) {
                        return true;
                    }
                }
            }
            return false;
        }

        // Credit Card Issuer: Diners Club - Carte Blanche
        function CheckNumberWithCarteBlancheCard(number) {
            if (!isNaN(number) && number.length >= 3) {
                var firstTwoNumber = number.substr(0, 3);
                if (['300', '301', '302', '303', '304', '305'].indexOf(firstTwoNumber) != -1) {
                    if (number.length == 14) {
                        return true;
                    }
                }
            }
            return false;
        }

        // Credit Card Issuer: Master card and VISA
        function CheckNumberWithMasterAndVISACard(number) {
            if (!isNaN(number) && number.length >= 1) {
                var firstTwoNumber = number.substr(0, 1);
                if (['4', '5'].indexOf(firstTwoNumber) != -1) {
                    if (number.length == 16) {
                        return true;
                    }
                }
            }
            return false;
        }

        function AddAccountExt(element) {
            self.errors = ko.validation.group(self);
            var isValidBillingAddress = true;
            if (self.BillingAddressAPI()) {
                isValidBillingAddress = self.BillingAddressAPI().isValidBillingAddress();
            }

            if (self.isValid() && isValidBillingAddress) {
                if ($('a[href=#panel_billing_new_add]').parent().hasClass('active')) {
                    $.when(self.BillingAddressAPI().GetAddressDetails(element))
                     .done(function () {
                         AddPaymentMethod(element);
                     })
                } else {
                    AddPaymentMethod(element);
                }
            } else {
                self.errors.showAllMessages();
            }
        }

        function AddPaymentMethod(element, customer_id, account_id) {
            self.ShouldUseNewAddress(self.BillingAddressAPI().ShouldUseNewAddress());
            self.SelectedBillingAddress = self.BillingAddressAPI().SelectedBillingAddress;
            if (self.BillingAddressAPI().BillingAddress()) {
                self.BillingAddress(ko.mapping.toJS(self.BillingAddressAPI().BillingAddress()));
            }

            var tempAccount = ko.mapping.toJS(self);
            tempAccount.IsBank = false;
            delete tempAccount.BillingAddressAPI;
            if (tempAccount.BillingAddress) {
                delete tempAccount.BillingAddress.States;
            }
            if (customer_id && account_id) {
                tempAccount.PaymentProviderId = (self.PaymentProviderId() == 1) ? 1 : 2;
                tempAccount.ProviderCustomerId = customer_id;
                tempAccount.ProviderAccountId = account_id;
            }
            cs.AjaxBySpinner({
                url: '/PaymentMethod/AddPaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempAccount)
            }, element, true)
            .done(function (data) {
                trackSaveTimeOnPage();

                cs.closeModal();
                params.CompletedAddBankAccount(data);

                //DataCapture.
                self.logActionTimeData({ transactionStepId: 10, label: 'Payment_Method_ID', value: data.PaymentMethodId });
            })
            .fail(function (xhr, status) {
                $(element).removeClass("now-loading");
                var exception = $.parseJSON(xhr.responseText);
                if (exception.ReturnCode && exception.ReturnCode == 17039365) {
                    self.CardNumberValidation(2);
                    ko.validation.group(self).showAllMessages();
                } else {
                    try {
                        var innerException = $.parseJSON(exception.Message);
                        if (innerException && innerException.exceptionCode == '-480') {//Switch ePayments or GoToBilling
                            self.GetPaymentProviderId();

                            cs.showErrorMessage(innerException.error, innerException.reason, function () {
                                cs.closeModal();
                                setTimeout(function () {
                                    params.OpenNewModal();
                                }, 800);
                            });
                            params.refreshPaymentMethods();
                        }
                    } catch (e) {
                        cs.handleAjaxError(xhr.responseText);
                    }

                }
            });
        }

        self.AddressDetailChanged = function (element, address) {
            $("#AddressPrompt").css("display", "none");
            if ($(element).hasClass("addressprevious")) {
                self.BillingAddress(null);
                self.ShouldUseNewAddress(false);

                if ($(element).parent().hasClass('active')) {
                    self.SelectedBillingAddress = null;
                } else {
                    self.SelectedBillingAddress = ko.mapping.toJS(address);
                    $("#AddressPrompt").hide();
                }
            } else {
                self.SelectedBillingAddress = null;
                if ($(element).parent().hasClass('active')) {
                    self.BillingAddress(null);
                    self.ShouldUseNewAddress(false);
                } else {
                    self.BillingAddress(new BillingAddress());
                    self.ShouldUseNewAddress(true);
                    $("#AddressPrompt").hide();
                }
            }
            return true;
        }

        var isVerified = false;
        var iframeIsFocused = false;
        var eventMethod = window.addEventListener ? "addEventListener" : "attachEvent";
        var eventer = window[eventMethod];

        var messageEvent = eventMethod == "attachEvent" ? "onmessage" : "message";
        eventer(messageEvent, function (e) {
            if (self.TokenServiceUrl().indexOf(e.origin) > -1) {
                if (e.data == 33947652) {
                    iframeIsFocused = true;
                    document.getElementById('card-number').focus();
                    return;
                }

                self.CardNumberValidation(0);
                self.CardNumber.isModified(false);
                if (e.data == 33947649) {
                    self.CardNumberValidation(0);
                } else if (e.data == 33947650) {
                    self.CardNumberValidation(1);
                } else if (e.data == 33947651) {
                    self.CardNumberValidation(2);
                } else if (e.data == 33947653) {
                    var enterToNext = cs.enterToNext;
                    var element = $("#input-expiration-month-new")[0];
                    element.focus();
                    enterToNext.expandSelect(element);
                }

                if (!isAddAccount) {
                    if (self.CardNumberValidation() != 0) {
                        self.CardNumber.isModified(true);
                    }
                }
                isVerified = true;
            }
        }, false);

        var trackCloseTotalClick = trackEvent;
        self.closeAddCreditCard = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddCard,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddCard,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddCard,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add Card",
                eventPage: track.PageEnum.AddCard,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});