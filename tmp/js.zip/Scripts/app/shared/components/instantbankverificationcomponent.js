﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings']], function (ko, cs, app, dataModel, commonstrings) {
    ko.components.register('verify-bank-account', {
        viewModel: function (params) {
            this.cancelVerification = function () {
                params.CancelVerification();
            }.bind(this);

            this.doVerificationNow = function (result) {
                params.DoVerificationNow();
            }.bind(this);
        },
        template: 
        '<div class="prompt-container">\
            <h6 data-bind="commonstring:\'ibv.verifyyourbankaccount\'">Do you want to verify your bank account instantly?</h6>\
            <p data-bind="commonstring:\'ibv.processyourtransaction\'">We can process your transaction faster with instant verification.</p>\
            <div class="buttons">\
                <a href="#" class="button radius even-less-pad" data-reveal-id="modal-m-more-info" data-bind="click:doVerificationNow,commonstring:\'buttons.yes\'">Yes</a>\
                <a href="../../consumer/money-transfer/money-transfer-consumer-05.html" class="button radius blue-transparent even-less-pad" data-bind="click:cancelVerification,commonstring:\'buttons.no\'">No</a>\
	        </div>\
        </div>'
    });

    ko.components.register('adding-bank-account-prompt', {
        viewModel: function (params) {
            var self = this;
            self.promptIBVResult = function (isIBV) {
                params.useIVB(isIBV);
            }
        },
        template: 
        '<div data-bind="attr:{class:$root.page().name == \'SettingsConsumer\'?\'ibv-settings small-12 medium-8 medium-centered column\':\'\'}"><div id="add-ibv" class="prompt-container" >\
            <h6 data-bind="commonstring:\'ibv.verifyyourbankaccount\'">Do you want to verify your bank account instantly?</h6>\
            <p data-bind="commonstring:\'ibv.processyourtransaction\'">We can process your transaction faster with instant verification.</p>\
            <div class="buttons">\
                <a href="#" class="button radius even-less-pad" data-reveal-id="modal-m-more-info" data-bind="click:promptIBVResult.bind($data,true),commonstring:\'buttons.yes\'">Yes</a>\
                <a href="#" class="button radius blue-transparent even-less-pad" data-bind="click:promptIBVResult.bind($data,false),commonstring:\'buttons.no\'">No</a>\
	        </div>\
        </div></div>'
    });

    ko.components.register('fast-link-account', {
        viewModel: function () {
            var self = this;
            self.closeFastlink = function () {
                cs.closeModal();
            }
        },
        template: '<div class="ibv-ios-title"></div>\
                   <div class="ibv-container" >\
                        <iframe id="ibv-iframe" scrolling="no" name="link-accounts" src="" class="ibv-iframe" style="width:100%;"></iframe>\
                        <a href="#" data-bind="click:closeFastlink.bind()" class="close-reveal-modal ibv-close-button">×</a>\
                        <div id="ibv-submit-form" style="display:none;"></div>\
                   </div>'
    });
});