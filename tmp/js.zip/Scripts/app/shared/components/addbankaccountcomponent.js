﻿define(['knockout', 'ClientScript', 'DataModel', 'app', paths['common-strings'], 'R', 'TrackEvent'], function (ko, cs, dataModel, app, commonstrings, R, track) {
    return function (params) {
        var self = this;
        self.AccountTypeId = ko.observable();
        self.AccountRoutingNumber = ko.observable();
        self.CardNumber = ko.observable();
        self.ConfirmCardNumber = ko.observable();
        self.CardName = ko.observable();
        self.CardNickname = ko.observable();
        self.PaymentProviderId = ko.observable(!!app.senderInfo() ? !!app.senderInfo().PosPaymentConfig() ? app.senderInfo().PosPaymentConfig().BankAccountProviderId : 2 : 2);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddBank, track.PageEnum.AddBank);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        track.generateErrorMessageTrack(track.CategoryEnum.AddBank, track.PageEnum.AddBank);
        // End appsflyer track event

        //DataCapture.
        self.logActionTimeData = ko.observable({ transactionStepId: 10, label: 'Payment_Method_ID', value: 0 });

        self.GetPaymentProviderId = function () {
            cs.BaseAjax({
                url: '/PaymentMethod/GetCurrentPaymentProvider',
                type: 'get',
                dataType: 'json'
            })
            .done(function (result) {
                self.PaymentProviderId(result.BankAccountProviderId);
                app.senderInfo().PosPaymentConfig(result)
            });
        }

        self.AccountTypeId.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accounttyperequired
            },
        }).isModified(false);

        self.CardName.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.banknamerequired
            },
            minTrimLength: {
                params: 2,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.banknameminlength;
                }
            },
            maxLength: {
                params: 50,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.banknamemaxlength
                }
            }
        }).isModified(false);

        self.AccountRoutingNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.routingnumbertrequired
            },
            number: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.routingnumbertvalid
            },
            minLength: {
                params: 9,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.routingnumbertvalid
            }
        }).isModified(false);

        self.IsCardNumberInvalid = ko.observable(false);
        self.CardNumber.extend({
            required: {
                params: true,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumberrequired
                }
            },
            number: {
                params: true,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumbervalid;
                }
            },
            equal: {
                onlyIf: self.IsCardNumberInvalid,
                message: function () {
                    //Inline message
                    return commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumbervalid
                }
            }
        }).isModified(false);

        self.ConfirmCardNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumberrequired
            },
            equal: {
                params: self.CardNumber,
                //Inline message
                message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumbernotmatch
            }
        }).isModified(false);

        self.AddAccount = function (element) {
            self.errors = ko.validation.group(self);

            if (self.isValid()) {
                AddPaymentMethod(element);
            } else {
                self.errors.showAllMessages();
            }

            var trackSaveTotalClick = trackEvent;
            trackCloseTotalClick("Save");
        };

        function AddPaymentMethod(element) {
            var tempAccount = ko.mapping.toJS(self);
            tempAccount.IsBank = true;
            tempAccount.PaymentProviderId = self.PaymentProviderId();

            cs.AjaxBySpinner({
                url: '/PaymentMethod/AddPaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(tempAccount))
            }, element, true)
            .done(function (data) {
                trackSaveTimeOnPage();

                cs.closeModal();
                params.CompletedAddBankAccount(data);

                //DataCapture.
                self.logActionTimeData({ transactionStepId: 10, label: 'Payment_Method_ID', value: data.PaymentMethodId });
            })
            .fail(function (xhr, status) {
                var exception = $.parseJSON(xhr.responseText);
                try {
                    var innerException = $.parseJSON(exception.Message);
                    if (innerException && innerException.exceptionCode == '-480') {//Switch epayment or gotobilling
                        self.GetPaymentProviderId();
                        cs.showErrorMessage(innerException.error, innerException.reason);
                        params.refreshPaymentMethods();
                    }
                } catch (e) {
                    cs.handleAjaxError(xhr.responseText);
                }

            });
        }

        self.ValidateRoutingNumber = function () {
            var routingNumber = $("#input-account-routing").val();
            if (!routingNumber || routingNumber.length < 9) {
                self.CardName("");
                self.CardName.isModified(false);
                return;
            }

            var url = "https://www.routingnumbers.info/api/name.json?rn=";
            url += routingNumber;
            url += '&callback=?'

            $("#add-bank-account").addClass('save-button-disabled');
            $.getJSON(url, function (data) {
                if (data.code == 200) {
                    self.CardName(data.name);
                } else {
                    self.CardName("");
                    self.CardName.isModified(false);
                }
                $("#add-bank-account").removeClass('save-button-disabled');
            })

            setTimeout(function () {
                $("#add-bank-account").removeClass('save-button-disabled');
            }, 3000);
        }

        var trackCloseTotalClick = trackEvent;
        self.closeBankAccount = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddBank,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddBank,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddBank,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add Bank",
                eventPage: track.PageEnum.AddBank,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});