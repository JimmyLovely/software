﻿define(['knockout', 'ClientScript', 'DataModel', paths['common-strings']], function (ko, cs, dataModel, commonstrings) {
    return function (params) {
        var self = this;

        self.BillingAddressAPI = ko.observable();

        if (params.PaymentMethod) {
            cs.deepClone(params.PaymentMethod(), self);
            initPaymentMethod();
        };

        self.ExpiredYears = function () {
            var shortExpiredYearArray = [];
            var fromYear = new Date().getUTCFullYear();

            //The max value of expiration year is current year plus 30 years.
            var maxYear = fromYear + 30;

            var getShortFromYear = function (year) { return parseInt(year.toString().substr(2, 2)); };

            for (var year = fromYear; year <= maxYear; year++) {
                currentYear = { 'Text': getShortFromYear(year), 'Value': year.toString() };
                shortExpiredYearArray.push(currentYear);
            }

            return shortExpiredYearArray;
        };

        var updateAccountStatus = new cs.executeStatus();
        self.Update = function (element) {
            if (updateAccountStatus.isExecuting()) {
                return;
            }
            updateAccountStatus.setExecuting();
            self.errors = ko.validation.group(self);

            
            //Add new address and Change address
            var isValidBillingAddress = true;
            if (self.BillingAddressAPI()) {
                isValidBillingAddress = self.BillingAddressAPI().isValidBillingAddress();
            }
            
            if (self.isValid() && isValidBillingAddress) {
                if (!self.BillingAddressAPI().ShouldUseNewAddress()) {
                    self.SelectedBillingAddress = self.BillingAddressAPI().SelectedBillingAddress;
					self.BillingAddress = self.SelectedBillingAddress;
                    return updatePaymentMethod(element);
                }

                self.ShouldUseNewAddress = true;
                self.BillingAddress = ko.mapping.toJS(self.BillingAddressAPI().BillingAddress());
                $.when(self.BillingAddressAPI().GetAddressDetails(element))
                .done(function () {
                    updateAccountStatus.complete()
                    updatePaymentMethod(element);
                })
                .fail(function () {
                    updateAccountStatus.complete();
                });
            } else {
                self.errors.showAllMessages();
                updateAccountStatus.complete();
            }
        }

        function updatePaymentMethod(element) {
            var tempPaymentMethod = ko.mapping.toJS(self);
            delete tempPaymentMethod.BillingAddressAPI;
            if (tempPaymentMethod.BillingAddress) {
                delete tempPaymentMethod.BillingAddress.States;
            }

            cs.AjaxBySpinner({
                url: '/PaymentMethod/UpdatePaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempPaymentMethod)
            }, element)
            .done(function (data) {
                if (params.CompletedEditCreditCard) {
                    params.CompletedEditCreditCard(data);
                }
                $.when(cs.closeModal())
               .done(function () {
                   updateAccountStatus.complete();
               });
            })
            .fail(function () {
                updateAccountStatus.complete();
            });
        }

        function initPaymentMethod() {
            self.Month = ko.observable(self.Month);
            self.Year = ko.observable(self.Year);
            self.CVV = ko.observable(self.CVV);
            self.BillingAddress = {
                Address: ko.observable(self.BillingAddress),
                StateId: ko.observable(),
                CityId: ko.observable(),
                ZipCode: ko.observable()
            }

            applyPaymentMethodValidation();
        }

        function DateIsInValid() {
            var isBank = self.IsBank;
            var tempMonth = self.Month();
            var tempYear = self.Year();

            if (!isBank && tempMonth != "" && tempYear != "") {
                month = parseInt(tempMonth);
                year = parseInt(tempYear);
                var date = new Date();
                var currentYear = date.getFullYear();
                var currentMonth = date.getMonth();
                if (year > currentYear) {
                    return false;
                }
                else if (year == currentYear) {
                    if (month > currentMonth) {
                        return false;
                    }
                    else {
                        return true;
                    }
                }
                else {
                    return true;
                }
            } else {
                return false;
            }
        }

        function applyPaymentMethodValidation() {
            self.Month.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expmonthrequired
                },
                equal: {
                    onlyIf: DateIsInValid,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expirationdateinvalid
                },
            }).isModified(false);

            self.Year.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expyearrequired
                },
                equal: {
                    onlyIf: DateIsInValid,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.expirationdateinvalid
                },
            }).isModified(false);

            self.CVV.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.cvvrequired
                },
                number: {
                    params: true,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.cvvvalid
                },
                maxLength: {
                    params: 4,
                    //Inline message
                    message: commonstrings.paymentmethod.creditanddebitcards.addcreditanddebitobject.cardinformation.validation.cvvmaxlength
                }
            }).isModified(false);
        }
    };
});