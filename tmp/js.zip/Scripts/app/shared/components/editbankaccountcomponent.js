﻿define(['knockout', 'ClientScript', 'DataModel'], function (ko, cs, dataModel) {
    return function (params) {
        var self = this;

        if(params.PaymentMethod) {
            cs.deepClone(params.PaymentMethod(), self);
            initializeBillingAddress();
            initializeStates();
            getCitiesByStateId(self.BillingAddress.StateId(), self.BillingAddress.City(), '#payment-method-input-city-edit');
        };

        self.getCitiesByStateId = function () {
            var element = $('#payment-method-input-city-edit');

            getCitiesByStateId(self.BillingAddress.StateId(), '', element);
        }

        var updateAccountStatus = new cs.executeStatus();
        self.Update = function (element) {
            self.BillingAddress.errors = ko.validation.group(self.BillingAddress);
            
            self.ShouldUseNewAddress = true;
            if (self.BillingAddress.isValid()) {
                var smartStreetIds = {
                    SelectCityId: "#payment-method-input-city-edit",
                    SelectStateId: "#payment-method-select-state-edit",
                    Address01Id: "#payment-method-input-address-01-edit",
                    Address02Id: "#payment-method-input-address-02-edit",
                    ZipcodeId: "#payment-method-input-zip-code-edit"
                };
                $.when(dataModel.GetAddressDetails(smartStreetIds, element, function () { }, self.BillingAddress, '#ValidateAddressMessageForUpdate'))
                .done(function () {
                    UpdatePaymentMethod(element);
                })
                .fail(function (stateId, cityName) {
                    updateAccountStatus.complete();
                    if (cityName && stateId) {
                        getCitiesByStateId(stateId, cityName, '#payment-method-input-city-edit');
                    }
                });
            } else {
                updateAccountStatus.complete();
                self.BillingAddress.errors.showAllMessages();
            }
        }

        function initializeBillingAddress() {
            var billingAddress = self.BillingAddress;
            billingAddress.Address = ko.observable(billingAddress.Address);
            billingAddress.Address2 = ko.observable(billingAddress.Address2);
            billingAddress.StateId = ko.observable(billingAddress.StateId);
            billingAddress.CityId = ko.observable(billingAddress.CityId);
            billingAddress.City = ko.observable(billingAddress.City);
            billingAddress.ZipCode = ko.observable(billingAddress.ZipCode);
            billingAddress.CityValidateType = ko.observable(billingAddress.CityValidateType);
            billingAddress.States = ko.observable(billingAddress.States);

            applyBillingAddressValidation();
        }

        function initializeStates() {
            $.when(dataModel.GetStatesByCountryId(840))
            .done(function (states) {
                self.BillingAddress.States(states);
            })
            .fail(function () {
                self.BillingAddress.States([]);
            });
        }

        function applyBillingAddressValidation() {
            self.BillingAddress.Address.extend({
                required: {
                    params: true,
                    //Inline message
                    message: 'Address is required'
                },
            }).isModified(false);

            self.BillingAddress.StateId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: 'State is required'
                },
            }).isModified(false);

            self.BillingAddress.CityId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: 'City is required'
                },
            }).isModified(false);

            self.BillingAddress.ZipCode.extend({
                required: {
                    params: true,
                    //Inline message
                    message: 'Zip code is required'
                },
                number: {
                    params: true,
                    //Inline message
                    message: 'Enter a valid zip code'
                },
                minLength: {
                    params: 5,
                    //Inline message
                    message: 'Enter a valid zip code'
                },
                maxLength: {
                    params: 5,
                    //Inline message
                    message: 'Enter a valid zip code'
                }
            }).isModified(false);
        }

        function getCitiesByStateId(stateId, displayCityName, element) {
            if (!stateId) {
                return;
            }
            $.when(dataModel.GetCitiesByStateId(840, stateId))
            .done(function (data) {
                cities = data;

                $(element).autocomplete({
                    lookup: data,
                    triggerSelectOnValidInput: false,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        self.BillingAddress.CityId(suggestion.data.Value);
                        self.BillingAddress.City(suggestion.value);
                        self.BillingAddress.CityValidateType(0);
                    },
                    lookupFilter: function (k, j, l) {
                        var inputValue = (cs.removeDiacritics(l).toLowerCase());
                        return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1;
                    }
                });
                $(element).autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                $(element).val(displayCityName);
                if (data && displayCityName) {
                    $.each(data, function (index, city) {
                        if (city.value == displayCityName) {
                            self.BillingAddress.CityId(city.data.Value);
                            self.BillingAddress.City(displayCityName);
                            self.BillingAddress.CityValidateType(0);
                        }
                    });
                }

                $(element).off('keyup.city.changed');
                $(element).on('keyup.city.changed', function () {
                    var value = $(element).val();

                    if (value == "") {
                        self.BillingAddress.CityValidateType(1);
                    }
                    else if (cs.isMatchSuggestion($(element).autocomplete().suggestions, value, false) > -1) {
                        self.BillingAddress.CityValidateType(0);
                        return;
                    }
                    else {
                        self.BillingAddress.CityValidateType(2);
                    }

                    self.BillingAddress.CityId(null);
                });

                $(element).off('blur.city.changed');
                $(element).on('blur.city.changed', function () {
                    if ($('.autocomplete-selected').length > 0) return;

                    var matchedIndex = -1;
                    var value = $(this).val();

                    if (value == "") {
                        self.BillingAddress.CityValidateType(1);
                    }
                    else if ($(element).autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($(element).autocomplete().suggestions, value, true)) > -1) {
                        self.BillingAddress.CityValidateType(0);
                        $(element).autocomplete().select(matchedIndex);
                        return;
                    } else {
                        self.BillingAddress.CityValidateType(2);
                    }
                    self.BillingAddress.CityId(null);
                });
            });
        }

        function UpdatePaymentMethod(element) {
            cs.AjaxBySpinner({
                url: '/PaymentMethod/UpdatePaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, element)
            .done(function (data) {
                cs.closeModal();
            });
        }

        var addressListForUpdate=[$("#payment-method-input-address-01-edit"), $("#payment-method-input-address-02-edit"), $("#payment-method-input-city-edit"),
                    $("#payment-method-select-state-edit"), $("#payment-method-input-zip-code-edit")];
        cs.RemoveBorderAndMessage(addressListForUpdate, $("#ValidateAddressMessageForUpdate"));
    }
});