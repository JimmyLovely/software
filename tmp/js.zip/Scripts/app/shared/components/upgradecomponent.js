﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['UpgradeLevelConsumer-strings'], 'TrackEvent'], function (ko, cs, app, dataModel, upgradelevelstrings, track) {
    ko.components.register('upgrade-level', {
        viewModel: function (params) {
            var self = this;
            self.type = params.type;

            self.maxDocumentSize = ko.computed(function () {
                var configurations = app.configurations();
                if (configurations) {
                    return configurations.memberLevelDocumentMaxSize;
                }

                return "";
            });
            
            self.extensionPart1 = ko.computed(function () {
                var configurations = app.configurations();

                if (configurations) {
                    return configurations.memberLevelDocumentExtensions.replace(/^(.*)(,\..*)$/, '$1');
                }

                return "";
            });

            self.extensionPart2 = ko.computed(function () {
                var configurations = app.configurations();

                if (configurations) {
                    return configurations.memberLevelDocumentExtensions.replace(/^(.*)(\..*)$/, '$2');
                }

                return "";
            });

            self.selectedDocumentType = ko.observable();
            self.uploadDocumentTypes = params.uploadDocumentTypes;
            //moduleType: 
            //            1 : MoneyTransferConsumer
            //            2 : UpgradeConsumer
            self.moduleType = params.moduleType;
            self.documentTypes = params.uploadDocumentTypes.filter(function (documentType) {
                if (documentType.SenderLevelInfoId === self.type && documentType.Selected) {
                    self.selectedDocumentType(documentType);
                }

                return documentType.SenderLevelInfoId === self.type;
            });

            self.documenTypeChanged = function (element) {
                var documentType = self.uploadDocumentTypes.filter(function (item) { return item.DocumentTypeId === parseInt($(element).val()); });
                if (documentType) {
                    self.selectedDocumentType(documentType[0]);
                    getImage(documentType[0]);

                    for (var i = 0, l = self.uploadDocumentTypes.length; i < l; i++) {
                        var tempDocumentType = self.uploadDocumentTypes[i];
                        if (documentType[0].SenderLevelInfoId === tempDocumentType.SenderLevelInfoId) {
                            tempDocumentType.Selected = (tempDocumentType.DocumentTypeId === documentType[0].DocumentTypeId);
                        }
                    }

                    params.refreshDocumentTypes(self.uploadDocumentTypes);
                }

                //DataCapture.
                cs.UpgradeDataCaptureModel.ResetDocumentUoloadInformation(documentType[0].DocumentTypeId);

            };

            function getImage(documentType, parentDocumentType) {
                if (documentType.IsImage && documentType.UploadedDocumentId > 0 && !documentType.Content) {
                    cs.AjaxDownload({
                        type: 'GET',
                        url: "/Customers/GetDocument",
                        data: { documentId: documentType.UploadedDocumentId }
                    })
                    .done(function (blob) {
                        documentType.Content = blob;
                        if (parentDocumentType) {
                            self.selectedDocumentType(parentDocumentType);
                        } else {
                            self.selectedDocumentType(documentType);
                        }
                        params.refreshDocumentTypes(self.uploadDocumentTypes);
                    })
                    .fail(function () {
                        documentType.IsImage = false;
                        self.selectedDocumentType(documentType);
                        params.refreshDocumentTypes(self.uploadDocumentTypes);
                    });
                }

                if (documentType.SubDocumentTypes && documentType.SubDocumentTypes.length > 0) {
                    for (var i = 0, l = documentType.SubDocumentTypes.length; i < l; i++) {
                        getImage(documentType.SubDocumentTypes[i], documentType);
                    }
                }
            }

            function validateFileSize(file) {
                return (file.size < app.configurations().memberLevelDocumentMaxSize * 1024 * 1024) && (file.size > 0);
            }

            function validateFileExtension(file) {
                var extension = cs.Path.getExtension(file.name);
                return app.configurations().memberLevelDocumentExtensions.indexOf(extension.toLowerCase()) !== -1;
            }

            function isImage(filePath) {
                var extension = cs.Path.getExtension(filePath);
                return app.configurations().memberLevelImageExtensions.indexOf(extension.toLowerCase()) !== -1;
            }

            self.uploadChanged = function (event, documentTypeId) {
                var files = event.currentTarget.files;

                if (!files || files.length === 0) {
                    return;
                }
                if (!validateFileExtension(files[0])) {
                    cs.showErrorMessage("Error", upgradelevelstrings.fileformat + " " + self.extensionPart1() + " " + upgradelevelstrings.or + " " + self.extensionPart2());
                    return;
                }
                if (!validateFileSize(files[0])) {
                    cs.showErrorMessage("Error", upgradelevelstrings.fileislarger + " " + self.maxDocumentSize() + " " + upgradelevelstrings.userlowerdocument);
                    return;
                }

                //DataCapture.
                cs.UpgradeDataCaptureModel.DocumentUploadInformation(documentTypeId);

                for (var i = 0, l = self.uploadDocumentTypes.length; i < l; i++) {
                    var documentType = self.uploadDocumentTypes[i];
                    if (documentType.SubDocumentTypes && documentType.SubDocumentTypes.length > 0) {
                        for (var j = 0, jl = documentType.SubDocumentTypes.length; j < jl; j++) {
                            if (documentType.SubDocumentTypes[j].DocumentTypeId == documentTypeId) {
                                documentType.SubDocumentTypes[j].Content = files[0];
                                documentType.SubDocumentTypes[j].IsImage = isImage(files[0].name);
                                documentType.SubDocumentTypes[j].Url = files[0].name;
                                self.selectedDocumentType(documentType);
                                params.refreshDocumentTypes(self.uploadDocumentTypes);
                                return;
                            }
                        }
                    } else {
                        if (documentType.DocumentTypeId === documentTypeId) {
                            documentType.Content = files[0];
                            documentType.IsImage = isImage(files[0].name);
                            documentType.Url = files[0].name;
                            self.selectedDocumentType(documentType);
                            params.refreshDocumentTypes(self.uploadDocumentTypes);
                            return;
                        }
                    }
                }
            }

            self.getFileNameFormat = function (url) {
                if (!url) {
                    return "";
                }

                var fileName = url.substring(url.lastIndexOf('/') + 1, url.length);
                fileName = fileName.substring(fileName.lastIndexOf('\\') + 1, fileName.length).replace(/^(\d*_)(.*)(_\d*)(\..*)$/, '$2$4');
                if (fileName.length > 20) {
                    fileName = fileName.replace(/^(.{10})(.*)(.{5}\..*)$/, '$1...$3');
                }

                return fileName;
            }

            self.showImg = function (img, file) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $(img).attr('src', e.target.result);
                };

                reader.readAsDataURL(file);
            }

            self.formatDocumentTypeUploadDocumentNotes = function (UploadDocumentNotes) {
                if (UploadDocumentNotes) {
                    return UploadDocumentNotes.split("\\n");
                }
                return [];
            }
        },
        template:
            '<div class="column small-12 light-gray-container">\
                    <div class="row">\
                        <div class="column small-11 large-12 small-centered" data-bind="attr:{class:(\'column small-11 large-\' + (14 - 2*moduleType) +\' small-centered\')}">\
                            <div class="row">\
                                <div class="small-12 column" data-bind="attr:{class:(\'small-12 large-\' + (7 - moduleType) +\' column\')}">\
                                    <!--ko if: type==2 -->\
                                    <label for="document-type" class="right inline" data-bind="commonstring:\'upgrade.upgradelevel.leveltitle2\'">Identification Document</label>\
                                    <!--/ko-->\
                                    <!--ko if: type==3 -->\
                                    <label for="document-type-fund" class="right inline" data-bind="commonstring:\'upgrade.upgradelevel.leveltitle3\'">Source of Funds Document</label>\
                                    <!--/ko-->\
                                </div>\
                                <div class="small-12 column" data-bind="attr:{class:(\'small-12 large-\' + (5 + moduleType) +\' column\')}">\
                                   <select data-bind="event:{change:documenTypeChanged.bind($data,$element)}">\
                                        <option value="0" disabled selected data-bind="commonstring:{ data:\'upgrade.upgradelevel.dropdown\',asHtml:true}">Choose One to Submit</option>\
                                        <!--ko foreach: documentTypes -->\
                                            <option data-bind="value:DocumentTypeId,text:DocumentTypeName,attr:{selected:Selected}"></option>\
                                        <!-- /ko -->\
                                    </select>\
                                </div>\
                            </div>\
                            <!--ko with: selectedDocumentType() -->\
                            <!--ko foreach:(SubDocumentTypes&&SubDocumentTypes.length>0)?SubDocumentTypes:[$data]-->\
                            <div class="row" data-bind="css:{\'hidden-upload-placeholder-2\': ($index() > 0)}">\
                                <div class="small-12 column"  data-bind="attr:{class:(\'small-12 large-\' + (7 - $parents[1].moduleType) +\' column\')}">\
                                    <label for="document-upload" class="right inline">\
                                        <!--ko if: DocumentTypeId !=10 -->\
                                            <!--ko commonstring: \'upgrade.upgradelevel.additionaltitle\'-->\
                                                 Upload File\
                                            <!--/ko-->\
                                        <br/><!--/ko-->\
                                        <!--ko foreach:$parents[1].formatDocumentTypeUploadDocumentNotes(UploadDocumentNotes)-->\
                                        <small data-bind="html:$data"></small>\
                                        <!--/ko-->\
                                    </label>\
                                </div>\
                                <div class="small-12 column" data-bind="attr:{class:(\'small-12 large-\' + (5 + $parents[1].moduleType) +\' column\')}">\
                                    <div class="upload-placeholder" data-bind="css:{\'attached-file\':(!IsImage && Url)||(Content)}">\
                                        <!--ko if: !Url&&!Content-->\
                                        <i class="fa fa-plus" aria-hidden="true"></i>\
                                        <p data-bind="commonstring:\'upgrade.upgradelevel.choosefile\'">Choose a File</p>\
                                        <!--ko if:$parents[1].extensionPart1()&&$parents[1].extensionPart2()&&$parents[1].maxDocumentSize() -->\
                                        <small data-bind="commonstring:{data:\'upgrade.upgradelevel.fileextension\',args:{extension1:$parents[1].extensionPart1().split(\',\').join(\', \'),extension2:$parents[1].extensionPart2(),fileSize:$parents[1].maxDocumentSize()}}">\
                                            File must have extension .png, .jpg, .jpeg, .doc, .docx or .pdf and be no larger than 10 MBs\
                                            </small>\
                                        <!--/ko-->\
                                        <!--/ko-->\
                                        <!--ko if: IsImage && Content -->\
                                         <img id="img" data-bind="template:{afterRender:$parents[1].showImg.bind($data,$element,Content)}"/>\
                                         <!--/ko-->\
                                     <!--ko if: !IsImage && (Url||Content)-->\
                                        <img src="/assets/img/file-attached.svg" class="document-picture">\
                                            <p data-bind="text:$parents[1].getFileNameFormat($data.Url)">my-driverslicense2016.pdf</p>\
                                        <!--/ko-->\
                                               <div data-bind="delayLoading: IsImage && !Content" class="small-loading-modal-loading">\
                                               </div>\
                                        <!--ko with: $root.configurations()-->\
                                        <input type="file" data-bind="event:{change:function(data,event){$parents[2].uploadChanged(event,$parent.DocumentTypeId)}},attr:{accept:memberLevelDocumentExtensions}"/>\
                                        <!--/ko-->\
                                    </div>\
                                    <!--ko if: (Url||Content)-->\
                                    <a href="#" data-bind="commonstring: \'upgrade.upgradelevel.uploadnewfile\'">Upload New File</a>\
                                    <!--/ko-->\
                                </div>\
                            </div>\
                            <!--/ko-->\
                            <!--/ko-->\
                            <!--ko if: !selectedDocumentType()-->\
                            <div class="row">\
                                <div class="small-12 large-6 column"  data-bind="attr:{class:(\'small-12 large-\' + (7 - moduleType) +\' column\')}">\
                                    <label for="document-upload" class="right inline">\
                                        <!--ko commonstring:\'upgrade.upgradelevel.additionaltitle\'-->Upload File<!--/ko-->\
                                        <br/><small data-bind="commonstring:\'upgrade.upgradelevel.additionalmessage\'">\
                                            Information must be clear and readable.\
                                        </small>\
                                    </label>\
                                </div>\
                                <div class="small-12 large-6 column"  data-bind="attr:{class:(\'small-12 large-\' + (5 + moduleType) +\' column\')}">\
                                    <div class="upload-placeholder">\
                                        <i class="fa fa-plus" aria-hidden="true"></i>\
                                        <p data-bind="commonstring:\'upgrade.upgradelevel.choosefile\'">Choose a File</p>\
                                        <!--ko if:extensionPart1()&&extensionPart2()&&maxDocumentSize() -->\
                                        <small data-bind="commonstring:{data:\'upgrade.upgradelevel.fileextension\',args:{extension1: extensionPart1().split(\',\').join(\', \'),extension2: extensionPart2(),fileSize:maxDocumentSize()}}">\
                                            File must have extension .png, .jpg, .jpeg, .doc, .docx or .pdf and be no larger than 10 MBs\
                                        </small>\
                                        <!--/ko-->\
                                    </div>\
                                </div>\
                            </div>\
                            <!--/ko-->\
                        </div>\
                    </div>\
            </div>'
    });


    ko.components.register('upgrade-prompt', {
        viewModel: function (params) {
            this.showUpgradeLaterConfirmation = ko.observable(false);
            this.emailLater = function () {
                var result = dataModel.openEmailLaterPrompt();
                if (!result) {
                    this.showUpgradeLaterConfirmation(true);
                }
            }.bind(this);
            this.upgradeNow = function () {
                //Upgrade DataCapture.
                cs.UpgradeDataCaptureModel.SetUpgradeInitiator("Upgrade Now");

                params.upgradeNow();
            }.bind(this);

            this.upgradeLater = function (result) {
                this.showUpgradeLaterConfirmation(false);
                if (result) {
                    //Upgrade DataCapture.
                    cs.UpgradeDataCaptureModel.SetUpgradeInitiator("Email Later");

                    params.emailLater();
                }
            }.bind(this);

            this.senderLevel = params.senderLevel;
        },
        template: '<!-- ko if:!showUpgradeLaterConfirmation()  -->\
                    <div class="prompt-container">\
                        <!--ko with:$root.senderInfo()&&$root.senderInfo().SenderLevel()-->\
						<h6 class="small" data-bind="modulestring:{data: \'upgrade.upgradeprompt.message\',args:{currentlevel:AvailableAmount}}">To send an amount above your current limit of $999, we require additional information for security purposes.</h6>\
						<!--/ko-->\
                        <div class="buttons">\
                            <a href="#" class="button radius blue even-less-pad spanish-text" data-bind="click: upgradeNow,modulestring:\'upgrade.upgradeprompt.upgradenow\'">Upgrade Now</a>\
							<a href="#" class="button radius blue-transparent even-less-pad spanish-text" data-bind="click: emailLater,modulestring:\'upgrade.upgradeprompt.emaillater\'">Email Later</a>\
						</div>\
					</div>\
                <!--/ko-->\
                <!-- ko if:showUpgradeLaterConfirmation()  -->\
                    <upgrade-later params="upgradeLater:upgradeLater"></upgrade-later>\
                <!--/ko-->'
    });

    ko.components.register('upgrade-later', {
        viewModel: function (params) {
            this.upgradeLater = function (result) {
                params.upgradeLater(result);
            }
        },
        template: '<div class="prompt-container">\
                        <h6 data-bind="modulestring:\'upgrade.upgradelater.message\'">Submit documents later and continue transaction?</h6>\
						<div class="buttons">\
							<a href="#" class="button radius blue slarge-pad" data-bind="click:upgradeLater.bind($data, true),commonstring:\'buttons.yes\'">Yes</a>\
							<a href="#" class="button radius blue-transparent slarge-pad" data-bind="click:upgradeLater.bind($data,false),commonstring:\'buttons.no\'"">No</a>\
						</div>\
                    </div>'
    });

    ko.components.register('attached-success-message', {
        viewModel: function (params) {
        },
        template: '<div class="prompt-container">\
                        <h6 data-bind="modulestring:\'upgrade.attachedsuccess.title\'">Upgrade Documents Submitted!</h6>\
						<p data-bind="modulestring:\'upgrade.attachedsuccess.message\'">Please continue with your transaction</p>\
                    </div>'
    });

    ko.components.register('qp-attached-success-message', {
        viewModel: function (params) {
        },
        template: '<div class="prompt-container error-prompt">\
					<h6 data-bind="modulestring:\'upgrade.qpattachedsuccess.title\'">Upgrade Documents Submitted!</h6>\
					<p data-bind="modulestring:{data:\'upgrade.qpattachedsuccess.message\',asHtml:true}">Your transaction will be <strong>pending</strong> until your upgrade documents are verified.</p>\
				</div>'
    });

    ko.components.register('summary-message', {
        viewModel: function (params) {
            if (params.slideToBottom) {
                cs.SlideToBottom();
            }
        },
        template: '<div class="prompt-container error-prompt transaction-summary-prompt-05">\
						<h6 class="small" data-bind="modulestring:\'upgrade.ugradetransactionmessage\'">Your transaction will be on hold until your upgrade documents are\
							verified.</h6>\
					</div>'
    });

    ko.components.register('qp-summary-message', {
        viewModel: function (params) { },
        template: '<div class="row">\
			        <div class="column small-12">\
				        <div class="prompt-container error-prompt">\
					        <h6 class="medium" data-bind="modulestring:\'upgrade.summarymessage\'">Your transaction will be put on hold until your documents have been submitted and verified.</h6>\
                        </div>\
                    </div>\
                   </div>'
    });

    ko.components.register('upgrade-error', {
        viewModel: function (params) {
            this.availableAmount = params.availableAmount;
        },
        template: '<div class="prompt-container error-prompt">\
					<h6 class="small"><!--ko modulestring:\'upgrade.errormessage\'-->Amount exceeds the maximum current sending limit of <!--/ko--> $<!--ko text:availableAmount--><!--/ko-->.</h6>\
				</div>'
    });

    ko.components.register('upgrade-level-title', {
        viewModel: function (params) {
        },
        template: '<header class="mod-header">\
                        <h3 data-bind="commonstring:{data:\'upgrade.upgradeleveltitle.title\'}">Submit Document(s) to Upgrade Sending Limit</h3>\
                        <p data-bind="commonstring:{data:\'upgrade.upgradeleveltitle.message\'}">\
                            To send an amount above your current limit of $999, we require additional information for\
                            security purposes.\
                        </p>\
                    </header>'
    });

    ko.components.register('moneytransfer-upgrade', {
        viewModel: function (params) {
            var self = this;
            self.type = params.type;
            self.showUpgradeLaterConfirmation = ko.observable(false);
            self.upgradeLater = function () {
                self.showUpgradeLaterConfirmation(true);
            };

            self.giveUpUpgrade = function (result) {
                if (result) {
                    if (params.upgradeLater) {
                        params.upgradeLater();
                    }
                }
                self.showUpgradeLaterConfirmation(false);
            }
            self.uploadDocumentTypes = params.uploadDocumentTypes;
            self.senderLevel = params.senderLevel;
            self.isActive = ko.observable(false);
            if (self.uploadDocumentTypes && checkChioceDocuments()) {
                self.isActive(true);
            }

            self.refreshDocumentTypes = function (documentTypes) {
                params.refreshDocumentTypes(documentTypes);
                self.uploadDocumentTypes = documentTypes;
                if (checkChioceDocuments()) {
                    self.isActive(true);
                }
                else {
                    self.isActive(false);
                }
            }

            function hasChioceFiles(targetLevelId) {
                // Check sub document types first.
                for (var i = 0, l = self.uploadDocumentTypes.length; i < l; i++) {
                    var documentType = self.uploadDocumentTypes[i];
                    if (targetLevelId == documentType.SenderLevelInfoId) {
                        if (documentType.SubDocumentTypes && documentType.SubDocumentTypes.length > 0) {
                            var hasChioceCount = 0;
                            for (var j = 0; j < documentType.SubDocumentTypes.length; j++) {
                                if (documentType.SubDocumentTypes[j].Content || documentType.SubDocumentTypes[j].Url) {
                                    hasChioceCount++;
                                }
                            }

                            if (hasChioceCount == documentType.SubDocumentTypes.length) {
                                return true;
                            }
                            else if (hasChioceCount > 0 && hasChioceCount < documentType.SubDocumentTypes.length) {
                                return false;
                            }
                        }
                    }
                }

                // Check normal document type.
                for (var i = 0, l = self.uploadDocumentTypes.length; i < l; i++) {
                    var documentType = self.uploadDocumentTypes[i];
                    if (targetLevelId == documentType.SenderLevelInfoId) {
                        if (!documentType.SubDocumentTypes || documentType.SubDocumentTypes.length == 0) {
                            if (documentType.Content || !!documentType.Url) {
                                return true;
                            }
                        }
                    }
                }

                return false;
            }

            function checkChioceDocuments() {
                if (self.senderLevel.TargetLevelId - self.senderLevel.SourceLevelId === 1) {
                    if (!hasChioceFiles(self.senderLevel.TargetLevelId)) {
                        return false;
                    }
                }
                if (self.senderLevel.TargetLevelId - self.senderLevel.SourceLevelId === 2) {
                    if (!hasChioceFiles(2) || !hasChioceFiles(3)) {
                        return false;
                    }
                }

                return true;
            }

            self.submit = function (element) {
                if ($(element).hasClass('secondary')) {
                    return;
                }

                if (!checkChioceDocuments()) {
                    return;
                }

                params.submitDocuments(self.uploadDocumentTypes, element);
            }
        },
        template: '<!--ko if: !(showUpgradeLaterConfirmation()||senderLevel.IsShowAttachedSuccessMessage)-->\
                    <div class="row">\
                      <div class="column small-12">\
                        <div class="mod-wrapper mod-upgrade mod-upgrade-levels no-graphic">\
                          <!--ko with:senderLevel-->\
                            <!--ko with:$root.senderInfo()&&$root.senderInfo().SenderLevel() -->\
                          <upgrade-level-title></upgrade-level-title>\
                            <!--/ko-->\
                            <div class="mod-body">\
                                <div class="row">\
                                    <form>\
                                        <div class="column small-11 small-centered">\
                                            <div class="row">\
                                                <!--ko if: TargetLevelId >= 2 && SourceLevelId < 2 -->\
                                                <upgrade-level params="type:2,uploadDocumentTypes:$parent.uploadDocumentTypes,refreshDocumentTypes:$parent.refreshDocumentTypes,moduleType:1" ></upgrade-level>\
                                                <!--/ko-->\
                                                <!--ko if: TargetLevelId == 3 && TargetLevelId > SourceLevelId -->\
                                                <upgrade-level params="type:3,uploadDocumentTypes:$parent.uploadDocumentTypes,refreshDocumentTypes:$parent.refreshDocumentTypes,moduleType:1"></upgrade-level>\
                                                <!--/ko-->\
                                            </div>\
                                        </div>\
                                        <div class="mod-footer">\
					                        <div class="row">\
						                        <div class="column small-10 small-centered large-12">\
                                                    <div class="buttons">\
                                                     <a href="#" class="button" data-bind="click: $parent.submit.bind($data,$element),css:{\'secondary\':!$parent.isActive()}">\
                                                        <span class="button-text spanish-text" data-bind="commonstring: \'buttons.submit\'">Submit</span>\
                                                        <span class="loading tiny light"></span>\
                                                     </a>\
                                                     <a href="#" class="button radius blue-transparent even-less-pad spanish-text" data-bind="click:$parent.upgradeLater,modulestring:\'upgrade.finishupgradelater\'">Finish Upgrade Later</a>\
                                                    </div>\
                                         </div>\
					                        </div>\
				                        </div>\
                                    </form>\
                                </div>\
                            </div>\
                            <!--/ko-->\
                        </div>\
                    </div>\
                </div>\
                <!--/ko-->\
                <!--ko if: showUpgradeLaterConfirmation() -->\
                <upgrade-later params="upgradeLater:giveUpUpgrade"></upgrade-later>\
                <!-- /ko -->\
                <!--ko if: senderLevel.IsShowAttachedSuccessMessage -->\
                <!--ko if: type == "mt" -->\
                <attached-success-message></attached-success-message>\
                <!--/ko-->\
                <!--ko if: type=="qp"-->\
                <qp-attached-success-message></qp-attached-success-message>\
                <!--/ko-->\
                <!-- /ko -->'
    });

    ko.components.register('submit-prompt', {
        viewModel: function (params) {
            this.submitNow = function () {
                track.trackTimeOnPageForPageLink(track.LabelEnum.SubmitNow);
                dataModel.GoToUpgradeLevel(app.senderInfo().SenderLevel().SourceLevelId, app.senderInfo().SenderLevel().TargetLevelId);
            };
        },
        template: '<div class="row">\
			        <div class="column small-12 small-centered">\
				        <div class="prompt-container error-prompt transaction-summary-success-prompt">\
					        <h6 data-bind="modulestring:\'upgrade.submitprompt.title\'">Your transaction is now on hold</h6>\
					        <p data-bind="modulestring:\'upgrade.submitprompt.message\'">Upon review of your documentation, we will process your transaction. An email has been sent with submission instructions.</p>\
                            <div class="buttons">\
                                <a href="#" class="button radius less-pad txt-small spanish-text" data-bind="click: submitNow,commonstring:\'upgrade.submitnow\'">Submit Now</a>\
                            </div>\
                        </div>\
                    </div>\
                </div>'
    });

    ko.components.register('confirmation-message', {
        viewModel: function (params) { },
        template: '<div class="row">\
			            <div class="column small-12 small-centered">\
				            <div class="prompt-container error-prompt transaction-summary-success-prompt">\
					            <h6 data-bind="modulestring:\'upgrade.confirmationmessage.title\'">Your transaction is now on hold</h6>\
					            <p data-bind="modulestring:\'upgrade.confirmationmessage.message\'">Upon review of your documentation, we will process your transaction.</p>\
				            </div>\
			            </div>\
		            </div>'
    });

    ko.components.register('submit-via-email', {
        viewModel: function (params) {
            self.levelstring = upgradelevelstrings.level;
            self.maxDocumentSize = ko.computed(function () {
                var configurations = app.configurations();
                if (configurations) {
                    return configurations.memberLevelDocumentMaxSize;
                }

                return "";
            });

            self.extensionPart1 = ko.computed(function () {
                var configurations = app.configurations();

                if (configurations) {
                    return configurations.memberLevelDocumentExtensions.replace(/^(.*)(,\..*)$/, '$1');
                }

                return "";
            });

            self.extensionPart2 = ko.computed(function () {
                var configurations = app.configurations();

                if (configurations) {
                    return configurations.memberLevelDocumentExtensions.replace(/^(.*)(\..*)$/, '$2');
                }

                return "";
            });
            // If level type is 0, means show level 2 and level 3 header.
            // If level type is 1, means show level 2 header.
            // If level type is 2, means show level 3 header.
            // If level type is 3, means show level 3 header.
            this.levelUpgradeType = ko.observable(0);
            if ("function" === typeof params.levelType) {
                this.levelUpgradeType(params.levelType());
            } else {
                this.levelUpgradeType(params.levelType);
            }

            this.EmailAddress = params.emailAddress();
            this.IdDocumentTypes = params.documentTypes.filter(function (documentType) {
                return documentType.SenderLevelInfoId === 2;
            });
            this.SOFDocumentTypes = params.documentTypes.filter(function (documentType) {
                return documentType.SenderLevelInfoId === 3;
            });

            var n = $(".ui-slider"),
            i = n.find(".ui-slide-header"),
            s = n.find(".mod-slidedown-container"),
            t = n.find(".ui-slide-close");
            i.find("a.trigger").click(function (e) {
                e.preventDefault(), i.hide(), s.stop(!0).slideDown(), t.stop(!0).fadeIn()
            }),
            t.click(function (e) {
                e.preventDefault(), t.stop(!0).fadeOut(), s.stop(!0).slideUp({ complete: function () { i.show() } })
            });

        },
        template: '<div class="ui-slider">\
                        <div class="ui-slide-header">\
                            <p>\
                                <!--ko commonstring: \'upgrade.prefertosendupgradeemail\' -->\
                                Prefer to email upgrade documents?\
                                 <!--/ko--><br>\
                                <a class="trigger" href="#" data-bind="commonstring:\'upgrade.upgradeviaemail.title\'">How to Submit via Email</a>\
                            </p>\
                        </div>\
                        <div class="mod-wrapper mod-slidedown-container upgrade-via-email">\
                            <header class="mod-header">\
                                <h4>\
                                    <a href="#" class="ui-slide-close"><i class="fa fa-times" aria-hidden="true"></i></a>\
                                    <!--ko with: $root.configurations -->\
                                        <!--ko commonstring:{data:"upgrade.upgradeviaemail.message",args:{productName:memberLevelProductName}}-->\
                                        Email Product.Name to Increase Sending Limit?\
                                        <!--/ko-->\
                                    <!--/ko-->\
                                </h4>\
                                <p>\
                                    <!--ko commonstring:"upgrade.upgradeviaemail.emailaddressmessage1"-->\
                                    Follow the instructions below and send to\
                                    <!--/ko-->\
                                    <a href="#"><!--ko text: EmailAddress--><!--/ko--></a> \
                                    <!--ko commonstring:"upgrade.upgradeviaemail.emailaddressmessage2"-->\
                                        using your registered email address.\
                                    <!--/ko-->\
                                </p>\
                            </header>\
                            <div class="row">\
                                <div class="column medium-11 medium-centered">\
                                    <div class="mod-body">\
                                        <div class="row">\
                                            <!-- ko if:levelUpgradeType() != 2 -->\
                                            <div class="column medium-5">\
                                                <div class="upgrade-docs">\
                                                    <p>\
                                                        <strong>\
                                                            <!--ko commonstring:"upgrade.upgradeviaemail.upgradeto"-->Upgrade to<!--/ko--> <span data-bind="text:levelstring + \'&nbsp;\' + ((levelUpgradeType() == 0||levelUpgradeType() == 1)?\'2\':\'3\'),css: (levelUpgradeType() == 0||levelUpgradeType() == 1)?\'txt-blue\':\'txt-orange\'"></span>\
                                                        </strong>\
                                                        <br>\
                                                        <span data-bind="commonstring:{data:\'upgrade.upgradeviaemail.submitidentification\',asHtml:true}">\
     Submit <u>one</u>                                      Identification Document:\
                                                        </span>\
                                                    </p>\
                                                    <ul class="bullets" data-bind="foreach: IdDocumentTypes">\
                                                        <li>\
                                                            <!--ko text:DocumentTypeName-->US Driver License<!--/ko-->\
                                                            <!-- ko if: DocumentNotes -->\
                                                            <br />\
                                                            <span class="txt-dark-gray" data-bind="html: DocumentNotes"></span>\
                                                            <!-- /ko -->\
                                                        </li>\
                                                    </ul>\
                                                </div>\
                                            </div>\
                                            <!--/ko-->\
                                            <!-- ko if:levelUpgradeType() == 3 -->\
                                            <div class="column medium-2">&nbsp;</div>\
                                            <div class="divider">+</div>\
                                            <!--/ko-->\
                                            <!-- ko if:levelUpgradeType() != 3 -->\
                                                   <div class="column large-2">&nbsp;</div>\
                                                    <div class="driver"></div>\
                                            <!--/ko-->\
                                            <!-- ko if:levelUpgradeType() != 1 -->\
                                            <div class="column medium-5"> \
                                                <div class="upgrade-docs">\
                                                    <p>\
                                                        <!-- ko if:levelUpgradeType() == 0 || levelUpgradeType() == 2-->\
                                                        <strong data-bind="commonstring:{data:\'upgrade.upgradeviaemail.upgradetolevel\',asHtml:true,args:{color:\'orange\',level:3}}">Upgrade to <span class="txt-orange">Level 3</span></strong>\
                                                        <!--/ko-->\
                                                        <br>\
                                                        <!-- ko if: levelUpgradeType() == 2 || levelUpgradeType() == 3-->\
                                                        <span data-bind="commonstring:{data:\'upgrade.upgradeviaemail.submitonesourceoffund\',asHtml:true}">\
                                                        Submit <u>one</u> Source of Funds Document:\
                                                        </span>\
                                                        <!-- /ko -->\
                                                        <!-- ko if: levelUpgradeType() != 2 && levelUpgradeType() != 3-->\
                                                        <span data-bind="commonstring:{data:\'upgrade.upgradeviaemail.submitsourceoffund\',asHtml:true}">\
                                                        Submit an Identification Document <strong>AND</strong> <u>one</u> Source of Funds Document:\
                                                        </span>\
                                                        <!-- /ko -->\
                                                    </p>\
                                                    <ul class="bullets" data-bind="foreach: SOFDocumentTypes">\
                                                        <li>\
                                                            <!--ko text:DocumentTypeName--><!--/ko-->\
                                                            <!-- ko if: DocumentNotes -->\
                                                            <span class="txt-dark-gray" data-bind="html: DocumentNotes"></span>\
                                                            <!-- /ko -->\
                                                        </li>\
                                                    </ul>\
                                                </div>\
                                            </div>\
                                            <!--/ko-->\
                                        </div>\
                                    </div>\
                                    <footer class="mod-footer text-left">\
                                        <!-- ko if:extensionPart1()&&extensionPart2()&&maxDocumentSize() -->\
                                        <div class="req-docs" data-bind="commonstring:{data:\'upgrade.upgradeviaemail.limitmessage\',args:{extension1: extensionPart1().split(\',\').join(\', \'),extension2: extensionPart2(),fileSize:maxDocumentSize()}}">\
                                            *Document cannot be expired and must be less than 10 MBs with extension: .jpeg, .jpg, .png, .doc, .docx or .pdf\
                                        </div>\
                                        <!--/ko-->\
                                    </footer>\
                                </div>\
                            </div>\
                        </div>\
                    </div>'
    });
});