﻿define(['knockout', 'ClientScript', 'DataModel', paths['common-strings'], 'TrackEvent'], function (ko, cs, dataModel, commonstrings, track) {
    return function (params) {
        var self = this;
        params.api(this);
        self.FIRST_ADDRESS = '#payment-method-input-address-01-new';
        self.CITY = '#payment-method-autocomplete-city-new';

        function BillingAddress() {
            var self = this;
            self.Address = ko.observable();
            self.Address2 = ko.observable();
            self.StateId = ko.observable();
            self.States = ko.observable([]);
            self.CityId = ko.observable();
            self.City = ko.observable();
            self.CityValidateType = ko.observable(0);
            self.Zipcode = ko.observable();
            self.CountryId = 840;
            self.cities = null;

            ko.computed(function () {
                var cityValidateType = self.CityValidateType();
                if (cityValidateType === 1) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.cityrequired);
                } else if (cityValidateType === 2) {
                    track.commonTrackErrorMessage(commonstrings.address.validations.cityvalide);
                }
            });

            self.Address.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.address.validations.addressrequired
                },
            }).isModified(false);

            self.StateId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.address.validations.staterequired
                },
            }).isModified(false);

            self.CityId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.address.validations.cityrequired
                },
            }).isModified(false);

            self.Zipcode.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.address.validations.zipcoderequired
                },
                number: {
                    params: true,
                    //Inline message
                    message: commonstrings.address.validations.zipcodevalid
                },
                minLength: {
                    params: 5,
                    //Inline message
                    message: commonstrings.address.validations.zipcodevalid
                },
                maxLength: {
                    params: 5,
                    //Inline message
                    message: commonstrings.address.validations.zipcodevalid
                }
            }).isModified(false);

            function initialize() {
                $.when(dataModel.GetStatesByCountryId(840))
                .done(function (states) {
                    self.States(states);
                })
                .fail(function () {
                    self.States([]);
                });
            }

            initialize();

            self.StateSelectIndexChangeForAdd = function () {
                self.CityValidateType(0);
                self.GetCitiesByStateId(self.StateId(), '', '#payment-method-autocomplete-city-new');
            }

            self.GetCitiesByStateId = function (stateId, displayCityName, element) {
                if (!stateId) {
                    return;
                }
                $.when(dataModel.GetCitiesByStateId(840, stateId))
                    .done(function (data) {
                        self.cities = data;

                        $(element).autocomplete({
                            lookup: data,
                            triggerSelectOnValidInput: false,
                            minChars: 1,
                            onSelect: function (suggestion) {
                                self.CityId(suggestion.data.Value);
                                self.City(suggestion.value);
                                self.CityValidateType(0);
                            },
                            lookupFilter: function (k, j, l) {
                                var inputValue = (cs.removeDiacritics(l).toLowerCase());
                                return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1
                            }
                        });

                        $(element).autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                        $(element).val(displayCityName);
                        if (data && displayCityName) {
                            data.each(function (city) {
                                if (city.value == displayCityName) {
                                    self.CityId(city.data.Value);
                                    self.City(displayCityName);
                                    self.CityValidateType(0);
                                }
                            });
                        }

                        $(element).off('keyup.city.changed');
                        $(element).on('keyup.city.changed', function () {
                            var value = $(element).val();

                            if (value == "") {
                                self.CityValidateType(1);
                            }
                            else if (cs.isMatchSuggestion($(element).autocomplete().suggestions, value, false) > -1) {
                                self.CityValidateType(0);
                                return;
                            }
                            else {
                                self.CityValidateType(2);
                            }

                            self.CityId(null);
                        });

                        $(element).off('blur.city.changed');
                        $(element).on('blur.city.changed', function () {
                            if ($('.autocomplete-selected').length > 0) return;

                            var matchedIndex = -1;
                            var value = $(this).val();

                            if (value == "") {
                                self.CityValidateType(1);
                            }
                            else if ($(element).autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($(element).autocomplete().suggestions, value, true)) > -1) {
                                self.CityValidateType(0);
                                $(element).autocomplete().select(matchedIndex);
                                return;
                            } else {
                                self.CityValidateType(2);
                            }
                            self.CityId(null);
                        });
                    });
            }
        }

        self.PreviousAddressList = ko.observable();
        self.ShouldUseNewAddress = ko.observable(false);
        self.SelectedBillingAddress;
        self.ShowSelectedBillingAddress = ko.observable(false);
        self.ShowSelectedBillingAddressLoading = ko.observable(true);
        self.BillingAddress = ko.observable();

        function GetPreviousAddress() {
            var senderInfo = require('app').senderInfo();
            var cardHolderId = senderInfo == null ? 0 : senderInfo.Customer().CustomerBasic.CardHolderId();
            cs.BaseAjax({
                url: "/PaymentMethod/GetPaymentMethodPreviousAddress",
                type: "Get",
                cache: false,
                contentType: "application/json",
                data: {
                    "senderId": cardHolderId
                }
            })
            .done(function (addresses) {
                if (params.operation === 'Update' && params.SelectedBillingAddress) {
                    for (var i = 0; i < addresses.length; i++) {
                        if (JSON.stringify(addresses[i]) == JSON.stringify(self.SelectedBillingAddress())) {
                            addresses[i].IsSelected = true;
                            if (i !== 0) {
                                var tempAddress = addresses[0];
                                addresses[0] = addresses[i];
                                addresses[i] = tempAddress;
                            }

                            break;
                        }
                    }
                }

                self.PreviousAddressList(addresses);
                self.ShowSelectedBillingAddressLoading(false);
            })
            .fail(function () {
                self.ShowSelectedBillingAddressLoading(false);
                self.PreviousAddressList([]);
            });
        }

        function initialize() {
            //Default operation is Add
            if (params.operation === 'Update' && params.SelectedBillingAddress) {
                self.SelectedBillingAddress = ko.observable(params.SelectedBillingAddress);
                GetPreviousAddress();
            } else {
                GetPreviousAddress();
            }
        }

        initialize();
        self.AddressDetailChanged = function (element, address) {
            $("#AddressPrompt").css("display", "none");
            if ($(element).hasClass("addressprevious")) {
                self.BillingAddress(null);
                self.ShouldUseNewAddress(false);

                if ($(element).parent().hasClass('active')) {
                    self.SelectedBillingAddress = null;
                } else {
                    self.SelectedBillingAddress = ko.mapping.toJS(address);
                    $("#AddressPrompt").hide();
                }
            } else {
                self.SelectedBillingAddress = null;
                if ($(element).parent().hasClass('active')) {
                    self.BillingAddress(null);
                    self.ShouldUseNewAddress(false);
                } else {
                    self.BillingAddress(new BillingAddress());
                    self.ShouldUseNewAddress(true);
                    $("#AddressPrompt").hide();

                    var addressListForAdd = new Array();
                    addressListForAdd.push($(self.FIRST_ADDRESS), $("#payment-method-input-address-02-new"), $(self.CITY),
                                $("#payment-method-select-state-new"), $("#payment-method-input-zip-code-new"));
                    cs.RemoveBorderAndMessage(addressListForAdd, $("#ValidateAddressMessage"));
                }
            }
            return true;
        }

        self.isValidBillingAddress = function () {
            var isValidBillingAddress = true;
            if (self.BillingAddress()) {
                self.BillingAddress().errors = ko.validation.group(self.BillingAddress());
                isValidBillingAddress = self.BillingAddress().isValid();
                if (!isValidBillingAddress) {
                    self.BillingAddress().errors.showAllMessages();
                    if (!self.BillingAddress().CityId()) {
                        self.BillingAddress().CityValidateType($(self.CITY).val() ? 2 : 1);
                    }
                }
            } else if (!self.SelectedBillingAddress) {
                isValidBillingAddress = false;
                $("#AddressPrompt").show();
                self.trackErrorMessage(commonstrings.address.validations.selectaddress);
            }

            return isValidBillingAddress;
        }

        self.trackErrorMessage = function (error) {
            if (typeof params.renderErrorMessage === 'function') {
                params.renderErrorMessage(error);
            }
        }

        self.GetAddressDetails = function (element) {
            if (self.ShouldUseNewAddress()) {
                var smartStreetIds = {
                    SelectCityId: self.CITY,
                    SelectStateId: "#payment-method-select-state-new",
                    Address01Id: self.FIRST_ADDRESS,
                    Address02Id: "#payment-method-input-address-02-new",
                    ZipcodeId: "#payment-method-input-zip-code-new"
                };
                return $.when(dataModel.GetAddressDetails(smartStreetIds, element, self.BillingAddress(), true))
                .fail(function (stateId, cityName) {
                    if (cityName && stateId) {
                        self.BillingAddress().GetCitiesByStateId(stateId, cityName, self.CITY);
                    }
                });
            }
        }

        self.ShowAddressControl = function (element) {
            var value = $(element).val();
            if (value && value.length > 0) {
                $("#address-clear").show();
            }
            else {
                $("#address-clear").hide();
            }
        }

        self.HideAddressControl = function (element) {
            if ($('.autocomplete-selected').length > 0) return;

            $(element).autocomplete("hide");
        }

        var timeHandler = 0;
        // 1 zip type is not standard
        // 2 city not found
        self.NoMatchSuggestionError = ko.observable(0);
        ko.computed(function () {
            var matchResult = self.NoMatchSuggestionError();

            if (matchResult === 1) {
                self.trackErrorMessage(commonstrings.address.validations.zipcodeerror);
            } else if (matchResult === 2) {
                self.trackErrorMessage(commonstrings.address.validations.citynotfound);
            }
        });

        self.AutoSearchSuggestion = function (element, data, e) {
            if (cs.isKeyPressControlOrSelect(e.which) || e.which == 13) {
                return;
            }

            $(element).autocomplete({
                lookup: [],
                showNoSuggestionNotice: false
            });
            self.NoMatchSuggestionError(0);

            var value = $(element).val();
            clearTimeout(timeHandler);

            if (value && value.length > 0) {
                timeHandler = setTimeout(function () {
                    $("#address-clear").show();
                    AutoSearchSuggestion(value, element);
                }, 500);
            }
            else {
                $("#address-clear").hide();
            }
        }

        function AutoSearchSuggestion(streetName, element) {
            $.when(dataModel.GetAutoCompleteSuggestionAddresses(streetName))
            .done(function (result) {
                /*For DataCapture*/
                if (result && result.length == 0) {
                    cs.LogInformationOfAddressSearch($(element).val(), false /*false stand for no recoeds found*/);
                }

                var containerClass = "autocomplete-bold";
                if (cs.IsMobileDevice()) {
                    if (cs.IsIpad()) {
                        containerClass += " blow-top";
                    }
                }

                var modalElement = GetPaymentMethodModalName();
                BindingAddressAutoComplete(element, result, containerClass, modalElement);
            });
        }

        self.ClearAddressInfo = function () {
            self.NoMatchSuggestionError(0);
            self.BillingAddress().Address(null);
            self.BillingAddress().Address.isModified(false);

            self.BillingAddress().StateId(null);
            self.BillingAddress().StateId.isModified(false);
            $(self.CITY).val("");
            self.BillingAddress().CityValidateType(0);

            self.BillingAddress().Zipcode(null);
            self.BillingAddress().Zipcode.isModified(false);

            $(self.FIRST_ADDRESS).autocomplete({
                lookup: []
            });

            $(self.CITY).autocomplete({
                lookup: []
            });

            // Clear error message.
            $(self.FIRST_ADDRESS).trigger('input');

            $("#address-clear").hide();
            $(self.FIRST_ADDRESS).focus();
        }

        function GetPaymentMethodModalName() {
            var modalElement = "";
            if ($("#modal-credit-debit-account").css("visibility") == 'visible') {
                modalElement = "#modal-credit-debit-account";
            }
            else if ($("#modal-credit-debit-edit").css("visibility") == 'visible') {
                modalElement = "#modal-credit-debit-edit";
            }
            else if ($("#modal-bank-account").css("visibility") == 'visible') {
                modalElement = "#modal-bank-account";
            }
            return modalElement;
        }

        function BindingAddressAutoComplete(element, lookup, containerClass, modalElement) {
            $(element).autocomplete({
                lookup: lookup,
                minChars: 1,
                showNoSuggestionNotice: true,
                containerClass: containerClass,
                triggerSelectOnValidInput: false,
                noSuggestionNotice: "No suggestions found",
                onSelect: function (suggestion) {
                    $(element).blur();
                    self.NoMatchSuggestionError(0);
                    $(element).val(suggestion.data.StreetName);
                    self.BillingAddress().Address(suggestion.data.StreetName);

                    $.when(dataModel.GetAddressAutocompleteDetails(suggestion))
                    .done(function (result) {
                        if (result && result.ResultAddress && result.ResultAddress.Analysis.DpvMatchCode != null && result.ResultAddress.Analysis.DpvMatchCode != 'N') {

                            var address = result.ResultAddress;
                            var resultStreet = address.DeliveryLine1;
                            self.BillingAddress().Address(resultStreet);
                            $(element).val(resultStreet);

                            var resultSecondStreet = address.DeliveryLine2;
                            var resultCity = address.Components.CityName;
                            var resultState = address.Components.StateAbbreviation;
                            var resultZipcode = address.Components.Zipcode;

                            var isCityMatchSuggestion = true;
                            if (address.Metadata.ZipType != 'Standard') {
                                self.trackErrorMessage(commonstrings.address.validations.zipcodeerror);
                                cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.address.validations.zipcodeerror, function () {
                                    $.when(cs.closeModal(true))
                                    .done(function () {
                                        isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, null, function () {
                                            if (resultZipcode && resultZipcode != "") {
                                                self.BillingAddress().Zipcode(resultZipcode);
                                            }
                                            $(self.CITY).focus();
                                        });

                                        setTimeout(function () {
                                            $("#payment-method-input-zip-code-new").focus();
                                        }, 300);
                                    });
                                });
                            }
                            else {
                                isCityMatchSuggestion = FillAddressStateAndCity(resultState, resultCity, function () {
                                    self.BillingAddress().Zipcode(resultZipcode);
                                    setTimeout(function () {
                                        $("#payment-method-input-address-02-new").focus();
                                    }, 100);
                                }, function () {
                                    if (resultZipcode && resultZipcode != "") {
                                        self.BillingAddress().Zipcode(resultZipcode);
                                    }
                                    $(self.CITY).focus();
                                });
                            }

                            if (!isCityMatchSuggestion) {
                                result.ResultAddress.Components.CityName = "";
                            }

                            //For datacapture. Log address validate.
                            cs.LogAddressValidate(result, true);
                        }
                        else {
                            var lastLine = cs.getSmartStreetLastLine(suggestion.data.City, suggestion.data.State, $("#payment-method-input-zip-code-new").val());
                            var message = cs.getAutoCompleteAddressInvalidMessage(suggestion.data.StreetName, $("#payment-method-input-address-02-new").val(), lastLine);
                            cs.ShowCustomMessage(function () {

                                //For datacapture. Log address validate.
                                result.ResultAddress.DeliveryLine1 = suggestion.data.StreetName;
                                result.ResultAddress.Components.CityName = suggestion.data.City;
                                result.ResultAddress.Components.StateAbbreviation = suggestion.data.State;
                                for (var i = 0; i < self.BillingAddress().States().length; i++) {
                                    var state = self.BillingAddress().States()[i];
                                    if (state.Code == suggestion.data.State) {
                                        result.ResultAddress.Metadata.CountyName = state.Text;
                                        break;
                                    }
                                }
                                
                                var isCityMatchSuggestion = FillAddressStateAndCity(suggestion.data.State, suggestion.data.City, function () {
                                    setTimeout(function () {
                                        $("#payment-method-input-address-02-new").focus();
                                    }, 100);
                                }, function () {
                                    setTimeout(function () {
                                        $(self.CITY).focus();
                                    }, 300);
                                });

                                if (!isCityMatchSuggestion) {
                                    result.ResultAddress.Components.CityName = "";
                                }

                                cs.LogAddressValidate(result, false);
                            }, function () {
                                setTimeout(function () {
                                    $(self.FIRST_ADDRESS).blur();
                                    $(self.FIRST_ADDRESS).focus();
                                }, 300);
                            }, message);
                        }
                    })
                }
            });

            $(element).autocomplete().getSuggestionsLocal = function (query) {
                return { suggestions: this.options.lookup };
            }

            if (document.activeElement && document.activeElement.id == element.id) {
                $(element).focus();
            }

        }

        function FillAddressStateAndCity(resultState, resultCity, addtionalField, addtionalFocus) {
            var isCityMatchSuggestion = true;
            var stateId = dataModel.GetStateId(resultState, self.BillingAddress().States());
            if (stateId && stateId != 0) {
                self.BillingAddress().StateId(stateId);
                $.when(self.BillingAddress().StateSelectIndexChangeForAdd())
                .done(function () {
                    if (cs.isMatchSuggestion(self.BillingAddress().cities, resultCity, true) > -1) {
                        var city = dataModel.GetCity(resultCity, self.BillingAddress().cities);
                        self.BillingAddress().CityId(city.data.Value);
                        self.BillingAddress().City(city.value);
                        self.BillingAddress().CityValidateType(0);
                        $(self.CITY).val(city.value);
                        if (typeof addtionalField == 'function') {
                            addtionalField();
                        }
                        isCityMatchSuggestion = true;
                    }
                    else {
                        self.BillingAddress().StateId(stateId);
                        if (typeof addtionalFocus == 'function') {
                            addtionalFocus();
                        }
                        isCityMatchSuggestion = false;
                    }
                })
            }
            else {
                //todo.
            }
            return isCityMatchSuggestion;
        }
    }
});