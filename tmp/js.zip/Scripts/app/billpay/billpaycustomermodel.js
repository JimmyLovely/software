﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation', 'knockout.validation.extended'], function (ko, cs, app, dataModel) {
    return function BillPayCustomerModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        var defaultBillingAccount = ko.mapping.toJSON(self.TobeAddedBillingAccount);
        var originalBillingAccount;

        self.AccountAddBillingAccountFlag = ko.observable(false);
        self.LayoutAddBillingAccountFlag = ko.observable(false);
        self.BillpayAddBillingAccountFlag = ko.observable(false);

        self.AdditionalInfoAvaliable = ko.observable(false);
        self.BillingAccountRequiredInfo = ko.observable();

        var searchBillerModal = { OriginalSearchCondition: '', AutoCompleteList: new Array(), OriginalKey: 0, OriginalType: '', OriginalBillerName: '', SelectedCountryId: 0 };

        self.SortType = ko.observable('sortby');

        self.TobeAddedBillingAccount.AccountNumber.extend({
            required: {
                params: true,
                message: 'Account no. is required'
            },
            equal: {
                onlyIf: function () {
                    return self.TobeAddedBillingAccount.IsAccountNumberInvalid();
                },
                message: "Account no. doesn't match the biller"
            }
        }).isModified(false);

        self.TobeAddedBillingAccount.RetypeAccountNumber.extend({
            equal: {
                onlyIf: function () { return !cs.equals(self.TobeAddedBillingAccount.AccountNumber(), self.TobeAddedBillingAccount.RetypeAccountNumber(), true) },
                message: "Values of account no. and confirm account no. don't match"
            },
        });

        self.TobeAddedBillingAccount.FirstName.extend({
            minTrimLength: { params: 2, message: 'Minimum Length of first name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
            equal: {
                onlyIf: function () { return self.TobeAddedBillingAccount.FirstName() != "" && cs.IsInvalidName(self.TobeAddedBillingAccount.FirstName()) != 0 },
                message: function () { return cs.IsInvalidName(self.TobeAddedBillingAccount.FirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
            }
        }).isModified(false);

        self.TobeAddedBillingAccount.LastName.extend({
            minTrimLength: { params: 2, message: 'Minimum length of last name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
            equal: {
                onlyIf: function () { return self.TobeAddedBillingAccount.LastName() != "" && cs.IsInvalidName(self.TobeAddedBillingAccount.LastName()) != 0 },
                message: function () { return cs.IsInvalidName(self.TobeAddedBillingAccount.LastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
            }
        }).isModified(false);

        self.TobeAddedBillingAccount.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.TobeAddedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.TobeAddedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            }
        }).isModified(false);

        self.SelectedBillingAccount.FirstName.extend({
            minTrimLength: { params: 2, message: 'Minimum length of first name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
            equal: {
                onlyIf: function () { return self.SelectedBillingAccount.FirstName() != "" && cs.IsInvalidName(self.SelectedBillingAccount.FirstName()) != 0 },
                message: function () { return cs.IsInvalidName(self.SelectedBillingAccount.FirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
            }
        }).isModified(false);

        self.SelectedBillingAccount.AccountNumber.extend({
            required: {
                params: true,
                message: 'Account no. is required'
            },
            equal: {
                onlyIf: function () {
                    return self.SelectedBillingAccount.IsAccountNumberInvalid();
                },
                message: "Account no. doesn't match the biller"
            }
        }).isModified(false);

        self.SelectedBillingAccount.RetypeAccountNumber.extend({
            equal: {
                onlyIf: function () { return !cs.equals(self.SelectedBillingAccount.AccountNumber(), self.SelectedBillingAccount.RetypeAccountNumber(), true) },
                message: "Values of account no. and confirm account no. don't match"
            },
        });

        self.SelectedBillingAccount.LastName.extend({
            minTrimLength: { params: 2, message: 'Minimum length of last name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
            equal: {
                onlyIf: function () { return self.SelectedBillingAccount.LastName() != "" && cs.IsInvalidName(self.SelectedBillingAccount.LastName()) != 0 },
                message: function () { return cs.IsInvalidName(self.SelectedBillingAccount.LastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
            }
        }).isModified(false);

        self.SelectedBillingAccount.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.SelectedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.SelectedBillingAccount.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            }
        }).isModified(false);

        self.tempSelectBillingAccount;
        self.Ready = function () {

        }

        self.initializeSearchBillingAccounts = function () {
            var tempAccounts = $.map(ko.mapping.toJS(self.BillingAccounts), function (item, index) { return { value: (!item.AccountName) ? item.BillerName : item.AccountName, data: item }; });
            tempAccounts.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            if (self.tempSelectReceiver) {
                $("#autocomplete-search-for-billers").val(!self.tempSelectReceiver.AccountName ? self.tempSelectReceiver.BillerName : self.tempSelectReceiver.AccountName);
                cs.removeDisable("#button-select-biller");
            }
            $('#autocomplete-search-for-billers').autocomplete({
                lookup: tempAccounts,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.tempSelectReceiver = suggestion.data;
                    cs.removeDisable('#button-select-biller');
                },
                onInvalidateSelection: function () {
                    self.tempSelectReceiver = null;
                    cs.addDisable('#button-select-biller')
                }
            });
        };

        self.GetSelected = function (billingAccount, element) {
            var account = ko.mapping.toJS(billingAccount);
            ko.mapping.fromJS(account, {}, self.SelectedBillingAccount);
            originalBillingAccount = account;
        }

        function LogTobeAddedBillingAccount(billingAccountModel) {
            var message = new Array();

            if (!billingAccountModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + billingAccountModel.AccountNumber.error);
            }
            if (!billingAccountModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + billingAccountModel.RetypeAccountNumber.error);
            }

            cs.logException("BillPayCustomer.TobeAddedBillingAccount", JSON.stringify(message));
        }

        // Manager biller:Remove Billing Account.
        var deleteStatus = new cs.executeStatus();
        self.AccountConfirmDelete = function (billingAccount) {
            $("#ConfirmToRemove").unbind()
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove biller
                cs.AddActivityInfo(16);

                if (deleteStatus.isExecuting()) {
                    return;
                }

                if (cs.isDisabled("ConfirmToRemove")) {
                    return;
                }
                deleteStatus.setExecuting();
                $.when(BillPay$Delete(billingAccount, "#ConfirmToRemove"))
                .done(function () {
                    $.when(cs.closeModal())
                    .done(function () {
                        deleteStatus.complete();
                    });
                })
                .fail(function () {
                    deleteStatus.complete();
                });
            })
            cs.openModal("modal-remove", true, true, true);
        }

        function BillPay$Delete(billingAccount, element) {
            return cs.AjaxBySpinner({
                url: '/BillPay/SelfServiceDeleteBillingAccount',
                contentType: "application/json",
                type: "Get",
                cache: false,
                data: { "billingAccountId": billingAccount.RppsBillingAccountId(), "accountType": billingAccount.AccountType() }
            }, element)
        .done(function () {
            var tempBillingAccounts = self.BillingAccounts();
            for (var i = 0; i < tempBillingAccounts.length; i++) {
                if (tempBillingAccounts[i].RppsBillingAccountId() == billingAccount.RppsBillingAccountId()) {
                    tempBillingAccounts.splice(i, 1);
                }
            }
            ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);
        })
        }

        // Update BillingAccount
        var updateAccountStatus = new cs.executeStatus();
        self.UpdateBillingAccount = function (element) {
            if (updateAccountStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            $.when(self.NormalBillerHasBillersMatchAccountNumber())
            .done(function () {
                if (self.SelectedBillingAccount.IsAccountNumberInvalid()) return;

                updateAccountStatus.setExecuting();
                self.SelectedBillingAccount.errors = ko.validation.group(self.SelectedBillingAccount);
                if (self.SelectedBillingAccount.isValid()) {
                    GetAdditionalInfo(element);
                }
                else {
                    updateAccountStatus.complete();
                    LogSelectedBillingAccount(self.SelectedBillingAccount);
                    self.SelectedBillingAccount.errors.showAllMessages();
                }
            })
        }

        function GetAdditionalInfo(element) {
            var tempData = ko.mapping.toJS(self.SelectedBillingAccount);
            delete tempData.Countries;

            return cs.AjaxBySpinner({
                url: "/BillPay/GetSelfServiceAdditionalInfo",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "accountModel": ko.mapping.toJS(tempData) }),
            }, element)
            .done(function (data) {
                if (data.AdditionalInfoAvaliable) {
                    var tempFields = data.BillingAccountRequiredInfo.Fields;
                    self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                    cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                    self.AdditionalInfoAvaliable(true);
                    cs.isCancelCloseModalCallBack = true;
                    cs.closeModalCallBack('modal-update-additional-info', function () {
                        self.AdditionalInfoAvaliable(false);
                    });
                    $.when(cs.openModal("modal-update-additional-info"))
                    .done(function () {
                        cs.initCustomAttributes();
                        cs.isCancelCloseModalCallBack = false;
                        updateAccountStatus.complete();
                        cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                    });
                } else {
                    UpdateBillingAccount(element);
                }
            })
            .fail(function () {
                updateAccountStatus.complete();
            });
        }

        function UpdateBillingAccount(element) {
            cs.AjaxBySpinner({
                url: '/BillPay/SelfServiceUpdateBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self.SelectedBillingAccount))
            }, element)
            .done(function (data) {
                var billingAccount = ko.mapping.fromJS(data);
                for (var i = 0; i < self.BillingAccounts().length; i++) {
                    if (self.BillingAccounts()[i].RppsBillingAccountId() == data.RppsBillingAccountId) {
                        ko.mapping.fromJS(data, {}, self.BillingAccounts()[i]);
                        break;
                    }
                }
                originalBillingAccount = billingAccount;
                ko.mapping.fromJS(billingAccount, {}, self.SelectedBillingAccount);
                DisabledBillingAccountValidattion(self.SelectedBillingAccount);
                $.when(cs.closeModal())
                .done(function () {
                    updateAccountStatus.complete();
                    self.AdditionalInfoAvaliable(false)
                });
            })
            .fail(function () {
                updateAccountStatus.complete();
                for (var i = 0; i < self.BillingAccounts().length; i++) {
                    if (self.BillingAccounts()[i].RppsBillingAccountId() == self.SelectedBillingAccount.RppsBillingAccountId()) {
                        ko.mapping.fromJS(originalBillingAccount, {}, self.BillingAccounts()[i]);
                    }
                }
            });
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());
            if (validateResult) {
                if (updateAccountStatus.isExecuting()) {
                    return;
                }
                updateAccountStatus.setExecuting();
                var tempAdditionalFields = ko.mapping.toJS(self.BillingAccountRequiredInfo());
                self.SelectedBillingAccount.BillingAccountRequiredInfo(tempAdditionalFields);
                delete self.SelectedBillingAccount.BillingAccountRequiredInfo().States;
                self.SelectedBillingAccount.AdditionalInfoAvaliable(self.AdditionalInfoAvaliable());
                UpdateBillingAccount(element);
            }
        }

        function LogSelectedBillingAccount(billingAccountModel) {
            var message = new Array();

            if (!billingAccountModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + billingAccountModel.AccountNumber.error);
            }
            if (!billingAccountModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + billingAccountModel.RetypeAccountNumber.error);
            }

            cs.logException("BillPayCustomer.SelectedBillingAccount", JSON.stringify(message));
        }

        self.CancelUpdateBillingAccount = function () {
            DisabledBillingAccountValidattion(self.SelectedBillingAccount);
            self.SelectedBillingAccount.AccountName.isModified(false);
            ko.mapping.fromJS(originalBillingAccount, {}, self.SelectedBillingAccount);
        }

        function DisabledBillingAccountValidattion(billingAccount) {
            billingAccount.AccountNumber.isModified(false);
            billingAccount.RetypeAccountNumber.isModified(false);
            billingAccount.EditablePhoneNumber.isModified(false);
            billingAccount.FirstName.isModified(false);
            billingAccount.LastName.isModified(false);
            billingAccount.IsAccountNumberInvalid(false);
        }

        // Manager biller:Change Favorite.
        self.ChangeFavorite = function (billingAccount) {
            var tempBillingAccount = ko.toJS(ko.utils.unwrapObservable(billingAccount));
            tempBillingAccount.IsFavorite = !tempBillingAccount.IsFavorite;
            return cs.BaseAjax(
            {
                url: '/BillPay/SelfServiceUpdateBillingAccount',
                dataType: "json",
                type: "Post",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(tempBillingAccount))
            })
            .done(function (data) {
                var tempReceiver = ko.mapping.toJS(data);
                ko.mapping.fromJS(tempReceiver, {}, billingAccount);
            })
        }

        // Initilize new billing account modal.
        self.resetAddNewBillingAccount = function () {
            self.ResetAddModal();
        };

        self.AddNewBillingAccount = function (element) {
            $.when(dataModel.GetCountriesByTransactionType(11))
            .done(function (data) {
                var countries = [];
                countries = data.filter(function (item) {
                    if (item.Value != 0 && item.Value != 484 && item.Value != 840) {
                        countries.push(item);
                    }
                    return item.Value == "0" || item.Value == "484" || item.Value == "840";
                }).concat(countries);
                ko.mapping.fromJS(countries, {}, self.Countries);

                $("#select-country-add-biller").val(self.Countries()[0].Value());
            });
        }

        // Auto search billers by biller name.
        var timeHandler = 0;
        self.BillPay$GetBillersByBillerName = function () {
            var billerName = $("#input-biller-name").val();
            if (timeHandler != 0) {
                clearTimeout(timeHandler);
                timeHandler = 0;
            }

            if (billerName.length != null && billerName.length > 2 && searchBillerModal.OriginalBillerName != billerName) {
                timeHandler = setTimeout(function () {
                    if (searchBillerModal.OriginalSearchCondition == ''
                        || !billerName.toLowerCase().contains(searchBillerModal.OriginalSearchCondition.toLowerCase())) {
                        searchBillerModal.OriginalSearchCondition = billerName;
                        BillPay$SearchBillers();
                    }
                    else {
                        if (searchBillerModal.AutoCompleteList.length > 0) {
                            var clearFlag = true;
                            for (var i = 0; i < searchBillerModal.AutoCompleteList.length; i++) {
                                if (searchBillerModal.AutoCompleteList[i].value == billerName) {
                                    $("#input-biller-name").autocomplete().selection = searchBillerModal.AutoCompleteList[i];
                                    $("#input-biller-name").autocomplete().currentValue = searchBillerModal.AutoCompleteList[i].value;
                                    clearFlag = false;
                                    break;
                                }
                            }

                            if (clearFlag) {
                                self.ClearAccountDetailsInfo();
                            }
                        }
                    }

                }, 500);
            }

            if (billerName.length != null && billerName.length == 0) {
                ResetForBillerNameEmpty();
            }
        }

        self.SearchBillers = function () {
            var billerName = $("#input-biller-name").val();
            if (billerName.length > 2) {
                BillPay$SearchBillers();
            }
            else {
                self.BillerNameValidType(3);
                $('#input-biller-name').focus();
            }
        }

        self.ChangeSearchCriteria = function () {
            if (!($("#select-country-add-biller").val() == 0
                || $("#select-country-add-biller").val() == searchBillerModal.SelectedCountryId
                || ($("#select-country-add-biller").val() == 840 && searchBillerModal.SelectedCountryId == 0))) {
                self.ClearAutoCompleteInfo();
                searchBillerModal.OriginalSearchCondition = "";
                searchBillerModal.AutoCompleteList = new Array();
                ko.mapping.fromJSON(defaultBillingAccount, {}, self.TobeAddedBillingAccount);
                DisabledBillingAccountValidattion(self.TobeAddedBillingAccount);
                $('#input-biller-name').val("");
                $('#input-biller-name').autocomplete({
                    lookup: new Array()
                });
            }
        }

        self.ClearAccountDetailsInfo = function () {
            ko.mapping.fromJSON(defaultBillingAccount, {}, self.TobeAddedBillingAccount);
            DisabledBillingAccountValidattion(self.TobeAddedBillingAccount);
            self.ClearAutoCompleteInfo();
        }

        self.ClearAutoCompleteInfo = function () {
            searchBillerModal.OriginalKey = 0;
            searchBillerModal.OriginalType = "";
            searchBillerModal.OriginalBillerName = "";
        }

        function BillPay$SearchBillers() {
            var country = $("#select-country-add-biller").val();
            var billerName = $("#input-biller-name").val();
            var billerType = 0;

            if (country == "0") {
                type = "All";
            } else if (country == "840") {
                type = "domestic";
            } else {
                type = "international";
            }
            searchBillerModal.AutoCompleteList = new Array();
            searchBillerModal.SelectedCountryId = parseInt(country);

            self.BillerNameValidType(0);
            self.ClearAccountDetailsInfo();
            cs.addSearchSpinner("#search-billers");

            return cs.BaseAjax({
                url: '/BillPay/SearchBillers',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billerName": billerName, "type": type })
            })
       .done(function (result) {
           cs.removeSearchSpinner("#search-billers");
           self.UpdateBillerList(result, billerType, billerName);

           ko.mapping.fromJS(null, {}, self.TobeAddedBillingAccount);
           self.FillInAutoCompleteForBiller();

           $('#input-biller-name').focus();
       })
         .fail(function (xhr, status) {
             cs.removeSearchSpinner("#search-billers");
         });
        }

        self.FillInAutoCompleteForBiller = function () {
            $("#input-biller-name").autocomplete({
                lookup: searchBillerModal.AutoCompleteList,
                triggerSelectOnValidInput: false,
                minChars: 3,
                onSelect: function (suggestion) {
                    if (searchBillerModal.OriginalKey != suggestion.data.Key || searchBillerModal.OriginalType != suggestion.data.BillerType) {
                        searchBillerModal.OriginalKey = suggestion.data.Key;
                        searchBillerModal.OriginalBillerName = suggestion.value;
                        searchBillerModal.OriginalType = suggestion.data.BillerType;
                        BillPay$GetDefaultBillingAccountByBillerKey(searchBillerModal.OriginalKey, searchBillerModal.OriginalType);
                    }
                    self.BillerNameValidType(0);
                }
            });

            $('#input-biller-name').autocomplete().getSuggestionsLocal = function (query) {
                return cs.GetSuggestionsLocal(this.options.lookup, query);
            }
        }

        self.UpdateBillerList = function (result, billerType, billerName) {
            var tempBillers = new Array();
            if (billerType == 0) {
                tempBillers = result;
            }
            else {
                for (var i = 0; i < result.length; i++) {
                    if (result[i].data.Class == billerType) {
                        tempBillers.push(result[i]);
                    }
                }
            }

            var resultBillers = new Array();
            if (searchBillerModal.SelectedCountryId == 0) {
                resultBillers = tempBillers;
            }
            else if (searchBillerModal.SelectedCountryId == 840) {
                for (var i = 0; i < tempBillers.length; i++) {
                    if (tempBillers[i].data.CountryId == searchBillerModal.SelectedCountryId || tempBillers[i].data.CountryId == 0) {
                        resultBillers.push(tempBillers[i]);
                    }
                }
            } else {
                for (var i = 0; i < tempBillers.length; i++) {
                    if (tempBillers[i].data.CountryId == searchBillerModal.SelectedCountryId) {
                        resultBillers.push(tempBillers[i]);
                    }
                }
            }

            searchBillerModal.AutoCompleteList = resultBillers;
        }

        // 0 means valid.
        // 1 means empty.
        // 2 means no result.
        self.BillerNameValidType = ko.observable(0);

        self.BillPay$MatchAutocompleteBillerName = function () {
            setTimeout(function () {
                var country = $("#select-country-add-biller").val();
                var billerName = $("#input-biller-name").val();
                if (searchBillerModal.OriginalBillerName != billerName) {
                    var nameMatched = false;
                    if (searchBillerModal.AutoCompleteList == null || searchBillerModal.AutoCompleteList.length <= 0) {
                        nameMatched = false;
                    }
                    else {
                        for (var i = 0; i < searchBillerModal.AutoCompleteList.length; i++) {
                            if (searchBillerModal.AutoCompleteList[i].value == billerName) {
                                searchBillerModal.OriginalKey = searchBillerModal.AutoCompleteList[i].data.Key;
                                searchBillerModal.OriginalType = searchBillerModal.AutoCompleteList[i].data.BillerType;
                                searchBillerModal.OriginalBillerName = searchBillerModal.AutoCompleteList[i].value;
                                BillPay$GetDefaultBillingAccountByBillerKey(searchBillerModal.OriginalKey, searchBillerModal.OriginalType);

                                $("#input-biller-name").autocomplete().selection = searchBillerModal.AutoCompleteList[i];
                                $("#input-biller-name").autocomplete().currentValue = searchBillerModal.AutoCompleteList[i].value;
                                self.BillerNameValidType(0);
                                nameMatched = true;
                                break;
                            }
                        }
                    }

                    if (!nameMatched && billerName != "") {
                        if (billerName.length > 2) {
                            self.BillerNameValidType(2);
                        }
                        else {
                            self.BillerNameValidType(3);
                        }
                    }

                    if (billerName == "") {
                        ResetForBillerNameEmpty();
                    }
                }
            }, 300);
        }

        function BillPay$GetDefaultBillingAccountByBillerKey(key, billerType) {
            cs.BaseAjax({
                url: '/BillPay/GetDefaultBillingAccountByBillerKey',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "key": key, "type": billerType })
            })
       .done(function (result) {
           result.NickName = null;
           var r = ko.mapping.toJS(result);
           ko.mapping.fromJS(r, {}, self.TobeAddedBillingAccount);

           self.BillerNameValidType(0);
       })
        }

        // Manager biller: Search Billing Accounts.
        self.BillerSearchText = ko.observable("");
        var timerHandler = 0;
        self.AutoSearchBillingAccount = function (value) {
            var oldValue = self.BillerSearchText();
            self.BillerSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.BillerSearchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 3) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.SearchBillingAccount(); }, 500);
            }
        }

        self.SearchBillingAccount = function () {
            var criteria = $("#input-search-for-recipients-billers").val();
            cs.AjaxBySpinner({
                url: '/BillPay/SearchBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "criteria": criteria })
            }, "#search-bill-pay-billers")
        .done(function (result) {
            var billingAccount = ko.mapping.toJS(result);
            ko.mapping.fromJS(billingAccount, {}, self.BillingAccounts);
            cs.closeFoundationDropdown();
        });
        }

        // Add New Billing Account.
        self.BillPay$AddNewBiller = function (element) {
            return BillPay$AddBillingAccount($("#input-biller-name"), element);
        }

        var saveBillingAccountStatus = new cs.executeStatus();
        function BillPay$AddBillingAccount(input, element) {
            if (saveBillingAccountStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            saveBillingAccountStatus.setExecuting();

            var toBeAddedBillerName = input.val();
            if (toBeAddedBillerName == '' || toBeAddedBillerName == null) {
                self.BillerNameValidType(1);
            }

            var tempCustomer = ko.toJS(ko.utils.unwrapObservable(self));
            self.TobeAddedBillingAccount.errors = ko.validation.group(self.TobeAddedBillingAccount);
            var deferred = $.Deferred();

            if (self.TobeAddedBillingAccount.isValid() && self.BillerNameValidType() == 0) {
                cs.AjaxBySpinner({
                    url: '/BillPay/SelfServiceAddBillingAccount',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(tempCustomer.TobeAddedBillingAccount),
                }, element)
                .done(function (data) {
                    var billingAccount = ko.mapping.fromJS(data);
                    var IsLayoutBillPayModalOpen = app.senderInfo().BillingAccount() != null && app.senderInfo().BillingAccount().LayoutAddBillingAccountFlag();
                    var tempBillingAccounts = self.BillingAccounts();
                    tempBillingAccounts.push(billingAccount);
                    ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);
                    self.Ready();

                    if (app.page().name == "BillPayConsumer" && !IsLayoutBillPayModalOpen) {
                        app.page().data.GoToAmoutToSend(element, data);
                    }
                    ko.mapping.fromJSON(defaultBillingAccount, {}, self.TobeAddedBillingAccount);
                    ResetBillerName();
                    DisabledBillingAccountValidattion(self.TobeAddedBillingAccount);
                    $.when(cs.closeModal())
                    .done(function () {
                        saveBillingAccountStatus.complete();
                        self.AccountAddBillingAccountFlag(false);
                        self.LayoutAddBillingAccountFlag(false);
                        self.BillpayAddBillingAccountFlag(false);
                        deferred.resolve();
                    });
                })
                .fail(function () {
                    saveBillingAccountStatus.complete();
                });
            }
            else {
                saveBillingAccountStatus.complete();
                LogTobeAddedBillingAccount(self.TobeAddedBillingAccount);
                self.TobeAddedBillingAccount.errors.showAllMessages();
            }
            return deferred;
        }

        function ResetBillerName() {
            $('#input-biller-name').val("");
            $('#input-biller-name').autocomplete({
                lookup: new Array()
            });
        }

        self.ResetAddModal = function () {
            $("#select-country-add-biller").val("0");
            ResetForBillerNameEmpty();
        }

        function ResetForBillerNameEmpty() {
            $('#input-biller-name').autocomplete({
                lookup: new Array()
            });
            searchBillerModal.OriginalSearchCondition = "";
            $('#input-biller-name').val('');
            self.ClearAccountDetailsInfo();
            self.BillerNameValidType(0);
        }

        self.FormateAccountNickName = function (element) {
            var accountNumber = $.trim($(element).val());
            var length = accountNumber.length;

            var billerName = $("#input-biller-name").val();
            if (self.TobeAddedBillingAccount.BillerName() == null) {
                return;
            }
            if (length < 4) {
                self.TobeAddedBillingAccount.NickName(billerName + " [****" + accountNumber + "]");
            } else {
                var temp = accountNumber.substr(0, length - 4).length;
                var prefix = " [****";

                self.TobeAddedBillingAccount.NickName(billerName + prefix + accountNumber.substr(length - 4, 4) + "]");
            }
        }

        self.FormateSelectedAccountName = function (element) {
            var accountNumber = $.trim($(element).val());
            var length = accountNumber.length;

            var billerName = self.SelectedBillingAccount.BillerName();

            if (length < 4) {
                self.SelectedBillingAccount.AccountName(billerName + " [****" + accountNumber + "]");
            } else {
                var temp = accountNumber.substr(0, length - 4).length;
                var prefix = " [****";

                self.SelectedBillingAccount.AccountName(billerName + prefix + accountNumber.substr(length - 4, 4) + "]");
            }
        }

        self.EditBillingAccount = function (billingAccount) {
            var selectedBillingAccount = ko.mapping.toJS(billingAccount);
            ko.mapping.fromJS(selectedBillingAccount, {}, self.SelectedBillingAccount);
            DisabledBillingAccountValidattion(self.SelectedBillingAccount);
            self.SelectedBillingAccount.RetypeAccountNumber.isModified(true);
            cs.openModal("#modal-biller-Edit");
        }

        self.SortType = ko.observable('sortby');
        self.IsAscending = ko.observable(true);

        self.SortBillingAccountBy = function (value, element) {

            var classname = element.childNodes[1].className;
            ResetSort();

            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-up";
                self.SortType(value);
                self.IsAscending(true);
            }
            else {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-down";
                self.SortType(value);
                self.IsAscending(false);
            }
        }

        function ResetSort() {
            $("#bill-pay-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#bill-pay-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#bill-pay-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.SortType("sortby");
            self.IsAscending(true);
        }

        self.SortBillingAccounts = ko.computed(function () {
            if (self.BillingAccounts() != null) {
                var sortedBillingAccount = self.BillingAccounts();
                var sortType = self.SortType();
                var isAscending = self.IsAscending();
                if (sortType == "sortby") {
                    return sortedBillingAccount;
                }
                else {
                    if (sortType == "FirstName") {
                        return sortedBillingAccount.sort(dataModel.CompareCustomerName(isAscending));
                    }
                    else {
                        return sortedBillingAccount.sort(cs.compare(sortType, null, isAscending, 'RppsBillingAccountId'));
                    }
                }
            }
            else
                return new Array();
        });

        self.AfterRenderNewBillerPage = function () {
        };

        self.ValidateNormalAccountNumberKeyup = function () {
            $("#input-account-no").trigger("change");

            self.SelectedBillingAccount.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.NormalBillerHasBillersMatchAccountNumber();
            }, 500);
        }

        self.ValidateNormalAccountNumberBlur = function () {
            self.SelectedBillingAccount.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.NormalBillerHasBillersMatchAccountNumber();
            }, 500);
        }

        self.NormalBillerHasBillersMatchAccountNumber = function () {
            var deffered = $.Deferred();
            var accountNumber = self.SelectedBillingAccount.AccountNumber();
            if (accountNumber == null || accountNumber == "") {
                return deffered.resolve();
            }
            var mask = self.SelectedBillingAccount.BillerMask();
            cs.BaseAjax({
                url: '/BillPay/SelfServiceIsBillersMatchAccountNumber',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "accountNumber": accountNumber, "mask": mask }),
            })
            .done(function (data) {
                if (data == false) {
                    self.SelectedBillingAccount.IsAccountNumberInvalid(true);
                }
                else {
                    self.SelectedBillingAccount.IsAccountNumberInvalid(false);
                }
                deffered.resolve();
            })
            .fail(function () {
                self.SelectedBillingAccount.IsAccountNumberInvalid(true);
                deffered.reject();
            });
            return deffered;
        }
    }
});
