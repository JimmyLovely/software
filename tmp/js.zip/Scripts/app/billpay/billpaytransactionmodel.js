﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation'], function (ko, cs, app, dataModel) {

    return function BillPayTransactionModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        var defaultSelectedServiceType = ko.mapping.toJS(self.SelectedServiceType);
        var defaultServiceTypes = ko.mapping.toJS(self.ServiceTypes);
        self.IsAgree = ko.observable(false);

        self.AgreeChange = ko.computed(function () {
            if (self.IsAgree()) {
                $("#NotAgreeError").fadeOut();
            }
        });

        self.IsQuickToPay = false;

        self.IsPromotionCodeValid = ko.observable(false);
        self.tempPromoCode = ko.observable("");

        self.ApplyPromoCode = function (element) {
            var promoCode = cs.CustomTrim(self.PromotionCode());
            var paymentMethodId = self.SelectedPaymentMethodId();
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            return cs.AjaxByLoading({
                url: '/BillPay/SelfServiceCaculate',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
            .done(function (result) {
                var tempTransaction = ko.mapping.toJS(result);
                ko.mapping.fromJS(tempTransaction, {}, self);
                self.IsPromotionCodeValid(true);
                $("#input-promo-message").removeClass("hide");
                self.tempPromoCode(promoCode);
                $("#promo-code-added").removeClass("hide");
                $("#promo-code").addClass("hide");
                //DataCapture
                require("BillPayBillPayConsumer").UpdateDataCaptureTransactionFee();
            })
            .fail(function (xhr, status) {
                self.PromotionCode("");
                self.BillPay$Caculate(true);
                self.tempPromoCode(promoCode);
                self.IsPromotionCodeValid(false);
            })
            .always(function () {
                ko.mapping.fromJS(paymentMethodId, {}, self.SelectedPaymentMethodId);
            });
        }

        self.RemovePromoCode = function () {
            $.when(CleanPromo())
           .done(function () {
               $("#promo-code-added").addClass("hide");
               $("#input-promo-message").addClass("hide");
               $("#promo-code").removeClass("hide");
               $("#input-promo-code").val("");

               //DataCapture
               require("BillPayBillPayConsumer").UpdateDataCaptureTransactionFee();
           })
        }

        function CleanPromo() {
            self.PromotionCode("");
            self.tempPromoCode("");
            self.BillPay$Caculate(true);
        }


        self.IsBankAccountSelected = ko.observable(false);

        self.ServiceTypeSelected = function (serviceType) {
            ko.mapping.fromJS(serviceType, {}, self.SelectedServiceType);
            self.IsBankAccountSelected(false);

            if (serviceType.IsPercentage()) {
                self.SelectedFeeValue(serviceType.Fee.Value());
            }
            else {
                self.SelectedFeeValue(serviceType.Fee.Symbol() + serviceType.Fee.Value());
            }

            if ((serviceType.PaymentMethodTypeId() == 3 || serviceType.PaymentMethodTypeId() == 4)) {
                self.IsBankAccountSelected(true);
            }
            else {
                self.IsBankAccountSelected(false);
            }
            return;
        }
    }
});