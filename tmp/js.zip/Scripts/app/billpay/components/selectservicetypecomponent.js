﻿define(['knockout', 'ClientScript', "app"], function (ko, cs, app) {
    return function (params) {
        var self = this,
            selectedServiceType = params.defaultValue();
        self.ServiceTypes = ko.observable(null);

        if (params.api) {
            params.api(this);
        }

        cs.BaseAjax({
            url: '/BillPay/GetServiceTypes',
            dataype: "json",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify({ "billingAccountId": params.billingAccountId(), "accountType": params.AccountType(), 'amountToSend': cs.GetOriginalNumber(params.AmountToSend()) })
        })
        .done(function (result) {
            $.each(result, function (index, r) {
                r.Selected = ko.observable(self.isEqual(r));
            });
            self.ServiceTypes(result);
        });

        self.GoToSenderPayment = function (serviceType) {
            if (!self.isEqual(serviceType)) {
                var serviceTypes = self.ServiceTypes() || [];
                $.each(serviceTypes, function (index, s) {
                    s.Selected(s.PaymentMethodTypeId == serviceType.PaymentMethodTypeId);
                });

                selectedServiceType = serviceType;
                self.ServiceTypes(serviceTypes);
                app.factoryFunc("GoToSenderPayment", ko.mapping.toJS(serviceType));
            } else {
                app.factoryFunc("GoToSenderPayment");
            }

        }

        self.BackToAmountToSend = function () {
            app.factoryFunc("BackToAmountToSend");
        }

        self.isEqual = function (serviceType) {
            if (selectedServiceType) {
                selectedServiceType = ko.mapping.toJS(selectedServiceType);
                return selectedServiceType.PaymentMethodTypeId == serviceType.PaymentMethodTypeId
                    && selectedServiceType.ServiceType == serviceType.ServiceType;
            }
            return false;
        }
    }
});