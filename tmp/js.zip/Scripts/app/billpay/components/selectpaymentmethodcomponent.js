﻿define(['knockout', 'ClientScript', "app"], function (ko, cs, app) {
    return function (params) {
        var self = this, selectedPaymentMethodId = params.defaultValue();;
        self.PaymentMethods = ko.observable(null);
        self.HasPaymentMethod = ko.observable(null);
        self.addBankAccountFlag = ko.observable(false);
        self.addCreditDebitFlag = ko.observable(false);
        self.IsBank = params.isBank;
        self.Fee = params.Fee;

        self.GetPaymentMethods = function () {
            cs.BaseAjax({
                url: '/BillPay/GetSelfServicePaymentMethod',
                contentType: 'appliaction/json',
                data: { isBank: false },
                type: 'get',
            })
            .done(function (result) {
                var paymentMethods = [];
                if (result) {
                    $.each(result, function (index, r) {
                        //3,4 is BankAccount
                        if ([3, 4].indexOf(r.PaymentMethodTypeId) != -1 == self.IsBank()) {
                            r.IsBank = ko.observable(self.IsBank());
                            r.Selected = ko.observable(r.PaymentMethodId == selectedPaymentMethodId);
                            paymentMethods.push(r);
                        }
                    });
                    self.PaymentMethods(paymentMethods);
                    self.HasPaymentMethod(paymentMethods.length > 0);
                }
            });
        }

        self.OpenNewModal = function () {
            self['addCreditDebitFlag'](false);
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');
        }

        function InitializePaymentMethodModel(modalId, flagName) {
            cs.closeModalCallBack(modalId, function () {
                self[flagName](false);
            });

            self[flagName](true);
            cs.openModal(modalId);
        }

        self.GetPaymentMethods();

        self.CompleteSelectPaymentMethod = function (selectedPaymentMethod) {
            if (selectedPaymentMethodId != selectedPaymentMethod.PaymentMethodId) {
                var paymentMethods = self.PaymentMethods() || [];
                $.each(paymentMethods, function (index, p) {
                    p.Selected(p.PaymentMethodId = selectedPaymentMethod.PaymentMethodId);
                });

                self.PaymentMethods(paymentMethods);
                selectedPaymentMethodId = selectedPaymentMethod.PaymentMethodId;
                app.factoryFunc("GoToTransactionDetails", ko.mapping.toJS(selectedPaymentMethod));
            } else {
                app.factoryFunc("GoToTransactionDetails");
            }
        }

        self.BackToServiceType = function () {
            app.factoryFunc("BackToServiceType");
        }

        self.InitializeNewSenderCreditAccount = function () {
            cs.closeModalCallBack('modal-credit-debit-account', function () {
                self.addCreditDebitFlag(false);
            });
            self.addCreditDebitFlag(true);
            cs.openModal('modal-credit-debit-account');
        }

        self.InitializeNewSenderBankAccount = function () {
            cs.closeModalCallBack('modal-bank-account', function () {
                self.addBankAccountFlag(false);
            });

            self.addBankAccountFlag(true);
            cs.openModal('modal-bank-account');
        }

        self.CompletedAddBankAccount = function (paymentMethod) {
            var tempPaymentMethod = {
                PaymentMethodId: paymentMethod.PaymentMethodId,
                CardName: paymentMethod.CardName,
                CardNickname: paymentMethod.CardNickname,
                DisplayCardNumber: paymentMethod.DisplayCardNumber,
                IsBank: paymentMethod.IsBank,
                Fee: 0,
                AccountTypeId: paymentMethod.AccountTypeId,
                AccountType: paymentMethod.AccountType,
                Selected: ko.observable(false)
            };

            var paymentMethods = self.PaymentMethods() || [];

            paymentMethods.push(tempPaymentMethod);
            self.PaymentMethods(paymentMethods);

            $.each(self.PaymentMethods(), function (index, p) {
                p.Selected(p.PaymentMethodId == paymentMethod.PaymentMethodId);
            });

            self.CompleteSelectPaymentMethod(tempPaymentMethod);
        }
    };
});