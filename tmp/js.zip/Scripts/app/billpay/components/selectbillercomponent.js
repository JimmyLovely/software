﻿define(['knockout', 'ClientScript', 'app', 'Plugins', 'tinyscrollbar'], function (ko, cs, app) {
    return function (params) {
        var self = this;
        self.BillingAccounts = ko.observable(null);
        self.BillPayAddBillingAccountFlag = ko.observable(false);
        self.selectedBillingAccount;
        var selectedBillingAccountId;

        if (params.autoNext()) {
            app.factoryFunc('GoToAmountToSend');
        }

        cs.BaseAjax({
            url: '/BillPay/GetBillingAccounts',
            type: 'GET',
            dataType: 'json'
        })
        .done(function (data) {
            if (!data) return;

            selectedBillingAccountId = params.defaultValue() && params.defaultValue().RppsBillingAccountId;
            $.each(data, function (index, b) {
                b.Selected = ko.observable(b.RppsBillingAccountId == selectedBillingAccountId);
                if (b.Selected()) {
                    self.selectedBillingAccount = b;
                }
            });
            
            self.BillingAccounts(data);
            InitializeSearchBillingAccounts(data);

            if (params.defaultValue() && params.autoNext()) {
                if (self.selectedBillingAccount) {
                    selectedBillingAccountId = 0;
                    self.GoToAmountToSend(self.selectedBillingAccount);
                } else {
                    app.factoryFunc("InitSelectBillerView");
                }
            }
        });

        function InitializeSearchBillingAccounts(billingAccounts) {
            if (!billingAccounts || billingAccounts.length < 6) {
                return;
            }
            var tempAccounts = $.map(ko.mapping.toJS(billingAccounts), function (item, index) {
                return {
                    value: (!item.AccountName) ? item.BillerName : item.AccountName, data: item
                };
            });

            tempAccounts.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            $('#autocomplete-search-for-billers').autocomplete({
                lookup: tempAccounts,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.selectedBillingAccount = suggestion.data;
                    cs.removeDisable('#button-select-biller');
                },
                onInvalidateSelection: function () {
                    self.selectedBillingAccount = null;
                    cs.addDisable('#button-select-biller')
                }
            });
        }

        self.SelectAccount = function (element) {
            if (self.selectedBillingAccount != null) {
                self.GoToAmountToSend(self.selectedBillingAccount, element);
            }
        }

        self.GoToAmountToSend = function (billingAccount, element) {
            if (billingAccount && selectedBillingAccountId != billingAccount.RppsBillingAccountId) {
                selectedBillingAccountId = billingAccount.RppsBillingAccountId;
                $.each(self.BillingAccounts(), function (index, b) {
                    b.Selected(b.RppsBillingAccountId == billingAccount.RppsBillingAccountId);
                });
                app.factoryFunc('GoToAmountToSend', ko.mapping.toJS(billingAccount));
            } else {
                app.factoryFunc('GoToAmountToSend');
            }
        }

        self.AddNewBillingAccount = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            cs.closeModalCallBack('modal-biller-new', function () {
                self.BillPayAddBillingAccountFlag(false);
            });

            self.BillPayAddBillingAccountFlag(true);
            cs.openModal('modal-biller-new');
        }

        self.completedAddBiller = function (billingAccount) {
            var billingAccounts = self.BillingAccounts() || [];

            billingAccount.Selected = ko.observable(false);
            billingAccounts.push(billingAccount);
            
            self.BillingAccounts(billingAccounts);
            self.GoToAmountToSend(billingAccount);
            InitializeSearchBillingAccounts(billingAccounts);
        }
    }
});