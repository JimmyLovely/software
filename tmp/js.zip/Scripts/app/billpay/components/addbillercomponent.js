﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;
        self.Countries = ko.observable([]);
        self.AccountNumber = ko.observable(null);
        self.RetypeAccountNumber = ko.observable(null);
        self.FirstName = ko.observable(null);
        self.LastName = ko.observable(null);
        self.EditablePhoneNumber = ko.observable(null);
        self.NickName = ko.observable(null);
        self.IsRppsBillingAccount = ko.observable(false);
        self.BillingAccountRequiredInfo = ko.observable();
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.SelectedCountryId = ko.observable(0);
        self.logActionTimeData = ko.observable({ transactionStepId: 4, label: 'Biller ID', value: 0 });
        var IsSelect = false;
        self.AccountType;
        var searchBillerModal = { OriginalSearchCondition: '', OriginalKey: 0, OriginalType: '', OriginalBillerName: '', SelectedCountryId: 0 };
        // 0 means valid.
        // 1 means empty.
        // 2 means no result.
        self.BillerNameValidType = ko.observable(0);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddNewBiller, track.PageEnum.AddNewBiller);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(track.CategoryEnum.AddNewBiller, track.PageEnum.AddNewBiller);

        ko.computed(function () {
            var billerNameValidType = self.BillerNameValidType();

            if (billerNameValidType === 1) {
                self.trackErrorMessage(commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billerrequired);
            } else if (billerNameValidType === 2) {
                self.trackErrorMessage(commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billernomatched);
            } else if (billerNameValidType === 3) {
                self.trackErrorMessage(commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.billerkeywordsearchlength);
            }

        });
        // End appsflyer track event

        function applyBillerValidation() {
            self.AccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnorequired
                },
                equal: {
                    onlyIf: function () {
                        return self.IsAccountNumberInvalid();
                    },
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnomatch
                }
            }).isModified(false);

            self.RetypeAccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnorequired
                },
                equal: {
                    onlyIf: function () { return !cs.equals(self.AccountNumber(), self.RetypeAccountNumber(), true) },
                    //Inline message
                    message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnomatch
                },
            });

            self.FirstName.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.firstnamerequired
                },
                //Inline message
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
                equal: {
                    onlyIf: function () { return self.FirstName() != "" && cs.IsInvalidName(self.FirstName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
                }
            }).isModified(false);

            self.LastName.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.lastnamerequired
                },
                //Inline message
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
                equal: {
                    onlyIf: function () { return self.LastName() != "" && cs.IsInvalidName(self.LastName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
                }
            }).isModified(false);

            self.EditablePhoneNumber.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.contactphonerequired
                },
                number: {
                    onlyIf: function () { return cs.IsInvalidPhoneNumber(self.EditablePhoneNumber()); },
                    //Inline message
                    message: commonstrings.commonvalidation.contactphonevalid
                },
                minLength: {
                    params: 10,
                    //Inline message
                    message: commonstrings.commonvalidation.contactphonevalid
                },
                maxLength: {
                    onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.EditablePhoneNumber()); },
                    //Inline message
                    message: commonstrings.commonvalidation.contactphonevalid
                }
            }).isModified(false);

            self.NickName.extend({
                //Inline message
                maxLength: { params: 50, message: commonstrings.commonvalidation.nicknamemaxlength }
            }).isModified(false);
        }


        function InitializeDestinationCountries(element) {
            $.when(dataModel.GetCountriesByTransactionType(11))
            .done(function (data) {
                var index = data.indexOf(data.filter(function (x) {
                    return x.Value == "840";
                })[0]);
                data.splice(0, 0,
                new Object({ Code: "", Text: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.selectcountry, Value: "0" }),
                data.splice(index, 1)[0]);
                var countries = [];
                countries = data.filter(function (item) {
                    if (item.Value != 0 && item.Value != 484 && item.Value != 840) {
                        countries.push(item);
                    }
                    return item.Value == "0" || item.Value == "484" || item.Value == "840";
                }).concat(countries);
                ko.mapping.fromJS(countries, {}, self.Countries);

                $("#select-country-add-biller").val(self.Countries()[0].Value());
            });
        }

        applyBillerValidation();

        InitializeDestinationCountries();

        self.CountryChange = function () {
            if (!(($("#select-country-add-biller").val() == 0 && IsSelect)
                || $("#select-country-add-biller").val() == self.SelectedCountryId() && IsSelect)) {
                resetBiller();
                resetAutoComplete();
                if (self.BillerNameValidType() > 0) {
                    self.BillerNameValidType(0);
                }
            }
        }

        function resetBiller() {
            self.AccountNumber(null);
            self.RetypeAccountNumber(null);
            self.FirstName(null);
            self.LastName(null);
            self.EditablePhoneNumber(null);
            self.NickName('');

            self.AccountNumber.isModified(false);
            self.RetypeAccountNumber.isModified(false);
            self.FirstName.isModified(false);
            self.LastName.isModified(false);
            self.EditablePhoneNumber.isModified(false);
            self.IsAccountNumberInvalid(false);
        }

        function resetAutoComplete() {
            $('#input-biller-name').val("");
            $('#input-biller-name').autocomplete({
                lookup: []
            });

            searchBillerModal = { OriginalSearchCondition: '', OriginalKey: 0, OriginalType: '', OriginalBillerName: '', SelectedCountryId: 0 };
        }

        // Search Billers
        var timeHandler = 0;
        self.AutoSearchBillers = function (data, e) {
            if (cs.isKeyPressControlOrSelect(e.which)) {
                return;
            }

            var billerName = $("#input-biller-name").val().trim();
            IsSelect = false;
            self.SelectedCountryId(0);
            clearTimeout(timeHandler);

            //Reset input box's status when clear biller name.
            if (!billerName) {
                self.BillerNameValidType(0);
                searchBillerModal.OriginalSearchCondition = "";
                $('#input-biller-name').autocomplete({
                    lookup: []
                });

                e.stopImmediatePropagation();
                $('#input-biller-name').off('keyup.autocomplete');
                $('#input-biller-name').off('focus.search.biller');
                return;
            }

            if (billerName.length != null && billerName.length > 0) {
                if (billerName != searchBillerModal.OriginalSearchCondition ||
                    //Fixed issue: if input an invalid biller name with 3 characters, then delete the latest character, then input the deleted character,
                    //There is no validation for inputed biller name.
                    (!!$('#input-biller-name').autocomplete() && $('#input-biller-name').autocomplete().suggestions.length < 1)) {
                    resetBiller();
                }
                timeHandler = setTimeout(function () {
                    if (billerName != searchBillerModal.OriginalSearchCondition ||
                        //Fixed issue: if input an invalid biller name with 3 characters, then delete the latest character, then input the deleted character,
                        //There is no validation for inputed biller name.
                        (!!$('#input-biller-name').autocomplete() && $('#input-biller-name').autocomplete().suggestions.length < 1)) {
                        self.SearchBillers();
                    }
                }, 500);
            }
        }

        self.SearchBillers = function (element) {
            var billerName = $("#input-biller-name").val().trim();
            if (billerName.length < 1) {
                self.BillerNameValidType(3);
                $('#input-biller-name').focus();
                return;
            }
            IsSelect = false;
            self.SelectedCountryId(0);
            searchBillerModal = { OriginalKey: 0, OriginalType: '', OriginalBillerName: '', SelectedCountryId: 0 };
            searchBillerModal.OriginalSearchCondition = billerName;
            $('#input-biller-name').autocomplete({
                lookup: []
            });

            if (element) {  // Move this function before setTimeout if invoke by AutoSearchBillers.
                resetBiller();
            }

            var country = $("#select-country-add-biller").val();
            var billerType = 0;

            if (country == "0") {
                type = "All";
            } else if (country == "840") {
                type = "domestic";
            } else {
                type = "international";
            }
            searchBillerModal.SelectedCountryId = parseInt(country);

            cs.addSearchSpinner("#search-billers");
            self.BillerNameValidType(0);
            return cs.BaseAjax({
                url: '/BillPay/SearchBillers',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billerName": billerName, "type": type })
            })
           .done(function (data) {
               //Data Capture
               if (Object.prototype.toString.call(data).slice(8, -1) == "Array" && data.length == 0) {
                   var searchSectionTypeId;

                   if (require('app').page().name == "BillPayConsumer") {
                       searchSectionTypeId = cs.LuSearchSectionType.AddBillerInBillPay;
                   } else {
                       searchSectionTypeId = cs.LuSearchSectionType.AddBillerInManagerBillers;
                   }

                   cs.LogSearchActivity(billerName, searchSectionTypeId);
               }

               cs.removeSearchSpinner("#search-billers");
               data = filterBillerList(data, billerType, billerName);

               $("#input-biller-name").autocomplete({
                   lookup: data,
                   triggerSelectOnValidInput: false,
                   minChars: 1,
                   onSelect: function (suggestion) {
                       if (searchBillerModal.OriginalKey != suggestion.data.Key || searchBillerModal.OriginalType != suggestion.data.BillerType) {
                           searchBillerModal.OriginalKey = suggestion.data.Key;
                           searchBillerModal.OriginalBillerName = suggestion.value;
                           searchBillerModal.OriginalType = suggestion.data.BillerType;
                           getDefaultBillingAccountByBillerKey(searchBillerModal.OriginalKey, searchBillerModal.OriginalType);
                           self.SelectedCountryId(suggestion.data.CountryId);
                       }
                       self.BillerNameValidType(0);
                   }
               });

               $('#input-biller-name').autocomplete().getSuggestionsLocal = function (query) {
                   return cs.GetSuggestionsLocal(this.options.lookup, query);
               }
               if (data == null || data.length == 0) {
                   self.BillerNameValidType(2);
               }

               $('#input-biller-name').off('keyup.autocomplete')
               .on('keyup.autocomplete', function (e) {
                   var value = $(this).val();
                   if (searchBillerModal.OriginalKey != value || !value) {
                       if (value.length >= 1) {
                           if (e.which == 13) return;

                           if (cs.isMatchSuggestion($('#input-biller-name').autocomplete().suggestions, value, false) > -1 ||
                               //Fixed issue: If input second and third characters very fast after inputing an invalid biller name, 
                               //there's a error message for correct biller name (PC only).
                               ($("#input-biller-name").autocomplete().suggestions.length == 0 && value.length == 3)) {
                               self.BillerNameValidType(0);
                           } else {
                               self.BillerNameValidType(2);
                           }
                       }
                       else {
                           self.BillerNameValidType(1);
                       }

                       searchBillerModal.OriginalKey = '';
                       resetBiller();
                   }
               })
               .off('focus.search.biller')
               .on('focus.search.biller', function () {
                   if ($('#input-biller-name').autocomplete().visible) {
                       self.BillerNameValidType(0);
                   }
                   else {
                       if ($('#input-biller-name').val() && $('#input-biller-name').length > 0) {
                           self.BillerNameValidType(2);
                       }
                   }
               });

               // If tab to next input box before search result back, not focus on search box.
               if (document.activeElement && document.activeElement.id == "input-biller-name") {
                   $('#input-biller-name').focus();
               }
           })
            .fail(function (xhr, status) {
                cs.removeSearchSpinner("#search-billers");
            });
        }

        self.CheckBillers = function (element) {
            if ($('.autocomplete-selected').length > 0) return;

            var matchedIndex = -1;
            var value = $(element).val();
            if (searchBillerModal.OriginalKey != value || !value) {
                if (value.length >= 1) {
                    if ($('#input-biller-name').autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($('#input-biller-name').autocomplete().suggestions, value, true)) > -1) {
                        self.BillerNameValidType(0);
                        $('#input-biller-name').autocomplete().select(matchedIndex);
                    } else {
                        self.BillerNameValidType(2);
                    }
                }
                else {
                    self.BillerNameValidType(1);
                }
            }

            if ($('#input-biller-name').autocomplete()) {
                $('#input-biller-name').autocomplete().hide();
            }
        }

        function filterBillerList(result, billerType, billerName) {
            var tempBillers = new Array();
            if (billerType == 0) {
                tempBillers = result;
            }
            else {
                for (var i = 0; i < result.length; i++) {
                    if (result[i].data.Class == billerType) {
                        tempBillers.push(result[i]);
                    }
                }
            }
            var selectedCountry = $("#select-country-add-biller").val();
            var resultBillers = new Array();
            if (selectedCountry == 0) {
                resultBillers = tempBillers;
            }
            else if (selectedCountry == 840) {
                for (var i = 0; i < tempBillers.length; i++) {
                    if (tempBillers[i].data.CountryId == selectedCountry || tempBillers[i].data.CountryId == 0) {
                        resultBillers.push(tempBillers[i]);
                    }
                }
            } else {
                for (var i = 0; i < tempBillers.length; i++) {
                    if (tempBillers[i].data.CountryId == selectedCountry) {
                        resultBillers.push(tempBillers[i]);
                    }
                }
            }

            return resultBillers;
        }

        function getDefaultBillingAccountByBillerKey(key, billerType) {
            cs.BaseAjax({
                url: '/BillPay/GetDefaultBillingAccountByBillerKey',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "key": key, "type": billerType })
            })
           .done(function (result) {
               self.FirstName(result.FirstName);
               self.LastName(result.LastName);
               self.EditablePhoneNumber(result.EditablePhoneNumber);
               self.AccountType = result.AccountType;
               IsSelect = true;
               self.BillerNameValidType(0);

               clearTimeout(timeHandler);
           })
        }
        // end Search Billers

        var saveBillingAccountStatus = new cs.executeStatus();
        self.addBillingAccount = function (element) {
            if (saveBillingAccountStatus.isExecuting()) {
                return;
            }

            var trackSaveTotalClick = trackEvent;
            trackSaveTotalClick("Save");

            if (cs.isDisabled(element)) {
                return;
            }

            if (self.IsAccountNumberInvalid()) {
                return false;
            }

            saveBillingAccountStatus.setExecuting();

            if (!$("#input-biller-name").val()) {
                self.BillerNameValidType(1);
            }
            else if (!searchBillerModal.OriginalBillerName) {
                self.BillerNameValidType(2);
            }

            self.errors = ko.validation.group(self);
            if (self.isValid() && self.BillerNameValidType() == 0) {
                GetAdditionalInfo(element);
            }
            else {
                saveBillingAccountStatus.complete();
                self.errors.showAllMessages();
            }
        }

        function GetAdditionalInfo(element) {
            var tempData = ko.mapping.toJS(self);
            delete tempData.Countries;

            return cs.AjaxBySpinner({
                url: "/BillPay/GetSelfServiceAdditionalInfo",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "billerId": searchBillerModal.OriginalKey, "accountType": tempData.AccountType, "billingAccountId": -1 }),
            }, element)
            .done(function (data) {
                if (data.AdditionalInfoAvaliable) {
                    var tempFields = data.BillingAccountRequiredInfo.Fields;
                    self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                    cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                    self.AdditionalInfoAvaliable(true);
                    cs.isCancelCloseModalCallBack = true;
                    cs.closeModalCallBack('modal-add-additional-info', function () {
                        self.AdditionalInfoAvaliable(false);
                    });
                    $.when(cs.openModal("modal-add-additional-info"))
                    .done(function () {
                        cs.isCancelCloseModalCallBack = false;
                        saveBillingAccountStatus.complete();
                        cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                    });
                } else {
                    AddBillingAccount(element);
                }
            })
            .fail(function () {
                saveBillingAccountStatus.complete();
            });
        }

        function AddBillingAccount(element) {
            var tempCustomer = ko.toJS(ko.utils.unwrapObservable(self));
            delete tempCustomer.Countries;
            tempCustomer.BillerId = searchBillerModal.OriginalKey;
            if (self.AdditionalInfoAvaliable()) {
                delete tempCustomer.BillingAccountRequiredInfo.States;
            }

            cs.AjaxBySpinner({
                url: '/BillPay/SelfServiceAddBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempCustomer),
            }, element)
            .done(function (data) {
                $.when(cs.closeModal())
                .done(function () {
                    trackSaveTimeOnPage();
                    self.AdditionalInfoAvaliable(false);
                    if (typeof params.completedAddBiller === 'function') {
                        params.completedAddBiller(data);
                    }
                    cs.closeFoundationDropdown();
                    saveBillingAccountStatus.complete();
                    self.logActionTimeData({ transactionStepId: 4, label: data.IsRppsBillingAccount === false ? 'Biller ID' : 'RPPS Biller ID', value: data.RppsBillingAccountId });
                })
            })
            .fail(function () {
                saveBillingAccountStatus.complete();
            });
        }

        self.IsAccountNumberInvalid = ko.observable(false);

        self.ValidateAccountNumberKeyup = function () {
            if (!self.AccountNumber.isModified()) return;

            HasBillersMatchAccountNumber();
        }

        self.ValidateAccountNumberBlur = function () {
            HasBillersMatchAccountNumber();
        }

        function HasBillersMatchAccountNumber() {
            var accountNumber = self.AccountNumber();
            if (!accountNumber || !searchBillerModal.OriginalKey || !searchBillerModal.OriginalType) {
                return;
            }
            var mask = null;
            cs.BaseAjax({
                url: '/BillPay/SelfServiceIsBillersMatchAccountNumber',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "accountNumber": accountNumber, "mask": mask, "key": searchBillerModal.OriginalKey, "type": searchBillerModal.OriginalType }),
            })
            .done(function (data) {
                if (data == false) {
                    self.IsAccountNumberInvalid(true);
                }
                else {
                    self.IsAccountNumberInvalid(false);
                }
            })
            .fail(function () {
                self.IsAccountNumberInvalid(false);
            });
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());
            if (validateResult) {
                if (saveBillingAccountStatus.isExecuting()) {
                    return;
                }

                saveBillingAccountStatus.setExecuting();
                AddBillingAccount(element);
            }
        }

        var trackCloseTotalClick = trackEvent;
        self.closeAddBiller = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewBiller,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddNewBiller,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewBiller,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add New Biller",
                eventPage: track.PageEnum.AddNewBiller,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});