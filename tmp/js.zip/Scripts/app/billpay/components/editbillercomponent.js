﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;

        cs.deepClone(ko.mapping.toJS(params.BillingAccount), self);

        self.AccountNumber = ko.observable(self.AccountNumber);
        self.RetypeAccountNumber = ko.observable(self.AccountNumber());
        self.FirstName = ko.observable(self.FirstName);
        self.LastName = ko.observable(self.LastName);
        self.EditablePhoneNumber = ko.observable(self.EditablePhoneNumber);
        self.AccountName = ko.observable(self.AccountName);
        self.IsAccountNumberInvalid = ko.observable(self.IsAccountNumberInvalid);
        self.AdditionalInfoAvaliable = ko.observable(self.AdditionalInfoAvaliable);
        self.BillingAccountRequiredInfo = ko.observable();

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.EditNewBiller, track.PageEnum.EditNewBiller);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        track.generateErrorMessageTrack(track.CategoryEnum.EditNewBiller, track.PageEnum.EditNewBiller);

        // End appsflyer track event

        self.FirstName.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.firstnamerequired
            },
            //Inline message
            minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
            maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
            equal: {
                onlyIf: function () { return self.FirstName() != "" && cs.IsInvalidName(self.FirstName()) != 0 },
                //Inline message
                message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
            }
        }).isModified(false);

        self.AccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnorequired
            },
            equal: {
                onlyIf: function () {
                    return self.IsAccountNumberInvalid();
                },
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.accountnomatch
            }
        }).isModified(false);

        self.RetypeAccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnorequired
            },
            equal: {
                onlyIf: function () { return !cs.equals(self.AccountNumber(), self.RetypeAccountNumber(), true) },
                //Inline message
                message: commonstrings.billpayandbillpaylcr.selectbiller.addnewbiller.accountdetails.validation.confirmnomatch
            },
        });

        self.LastName.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.lastnamerequired
            },
            //Inline message
            minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
            maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
            equal: {
                onlyIf: function () { return self.LastName() != "" && cs.IsInvalidName(self.LastName()) != 0 },
                //Inline message
                message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
            }
        }).isModified(false);

        self.EditablePhoneNumber.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.contactphonerequired
            },
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.EditablePhoneNumber()); },
                //Inline message
                message: commonstrings.commonvalidation.contactphonevalid
            },
            minLength: {
                params: 10,
                //Inline message
                message: commonstrings.commonvalidation.contactphonevalid
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.EditablePhoneNumber()); },
                //Inline message
                message: commonstrings.commonvalidation.contactphonevalid
            }
        }).isModified(false);

        self.AccountName.extend({
            //Inline message
            maxLength: { params: 50, message: commonstrings.commonvalidation.nicknamemaxlength }
        }).isModified(false);

        var updateAccountStatus = new cs.executeStatus();
        self.UpdateBillingAccount = function (element) {
            $.when(self.NormalBillerHasBillersMatchAccountNumber())
           .done(function () {
               if (self.IsAccountNumberInvalid()) return;
               if (updateAccountStatus.isExecuting()) {
                   return;
               }
               if (cs.isDisabled(element)) {
                   return;
               }
               updateAccountStatus.setExecuting();
               self.errors = ko.validation.group(self);
               if (self.isValid()) {
                   GetAdditionalInfo(element);
               }
               else {
                   updateAccountStatus.complete();
                   LogSelectedBillingAccount(self);
                   self.errors.showAllMessages();
               }
           })

            var trackSaveTotalClick = trackEvent;
            trackSaveTotalClick("Save");
        };

        function LogSelectedBillingAccount(billingAccountModel) {
            var message = new Array();

            if (!billingAccountModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + billingAccountModel.AccountNumber.error);
            }
            if (!billingAccountModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + billingAccountModel.RetypeAccountNumber.error);
            }

            cs.logException("BillPayCustomer.SelectedBillingAccount", JSON.stringify(message));
        }

        function GetAdditionalInfo(element) {
            var tempData = ko.mapping.toJS(self);
            delete tempData.Countries;

            return cs.AjaxBySpinner({
                url: "/BillPay/GetSelfServiceAdditionalInfo",
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "billerId": tempData.BillerId, "accountType": tempData.AccountType, "billingAccountId": tempData.RppsBillingAccountId }),
            }, element)
            .done(function (data) {
                if (data.AdditionalInfoAvaliable) {
                    var tempFields = data.BillingAccountRequiredInfo.Fields;
                    self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                    cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                    self.AdditionalInfoAvaliable(true);
                    cs.isCancelCloseModalCallBack = true;
                    cs.closeModalCallBack('modal-update-additional-info', function () {
                        self.AdditionalInfoAvaliable(false);
                    });
                    $.when(cs.openModal("modal-update-additional-info"))
                    .done(function () {
                        cs.initCustomAttributes();
                        cs.isCancelCloseModalCallBack = false;
                        updateAccountStatus.complete();
                        cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                    });
                } else {
                    UpdateBillingAccount(element);
                }
            })
            .fail(function () {
                updateAccountStatus.complete();
            });
        }

        function UpdateBillingAccount(element) {
            var tempData = ko.mapping.toJS(self);
            delete tempData.Countries;
            if (tempData.BillingAccountRequiredInfo) {
                delete tempData.BillingAccountRequiredInfo.States;
            }

            cs.AjaxBySpinner({
                url: '/BillPay/SelfServiceUpdateBillingAccount',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempData)
            }, element)
            .done(function (data) {
                trackSaveTimeOnPage();
                if (params.CompletedEditBiller) {
                    params.CompletedEditBiller(data);
                }

                updateAccountStatus.complete();
                cs.closeModal();
            })
            .fail(function () {
                updateAccountStatus.complete();
            });
        }

        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());
            if (validateResult) {
                if (updateAccountStatus.isExecuting()) {
                    return;
                }
                updateAccountStatus.setExecuting();
                self.BillingAccountRequiredInfo();
                self.AdditionalInfoAvaliable(self.AdditionalInfoAvaliable());
                UpdateBillingAccount(element);
            }
        }

        var timeHandler = 0;
        self.ValidateNormalAccountNumberKeyup = function () {
            $("#input-account-no").trigger("change");

            self.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.NormalBillerHasBillersMatchAccountNumber();
            }, 500);
        }

        self.ValidateNormalAccountNumberBlur = function () {
            self.IsAccountNumberInvalid(false);
            clearTimeout(timeHandler);

            timeHandler = setTimeout(function () {
                self.NormalBillerHasBillersMatchAccountNumber();
            }, 500);
        }
        self.NormalBillerHasBillersMatchAccountNumber = function () {
            var deffered = $.Deferred();
            var accountNumber = self.AccountNumber();
            if (accountNumber == null || accountNumber == "") {
                return deffered.resolve();
            }
            var mask = self.BillerMask;
            cs.BaseAjax({
                url: '/BillPay/SelfServiceIsBillersMatchAccountNumber',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "accountNumber": accountNumber, "mask": mask, "key": self.BillerId, "type": self.AccountType }),
            })
            .done(function (data) {
                if (data == false) {
                    self.IsAccountNumberInvalid(true);
                }
                else {
                    self.IsAccountNumberInvalid(false);
                }
                deffered.resolve();
            })
            .fail(function () {
                self.IsAccountNumberInvalid(true);
                deffered.reject();
            });

            return deffered;
        }

        var trackCloseTotalClick = trackEvent;
        self.closeEditBiller = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.EditNewBiller,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.EditNewBiller,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.EditNewBiller,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Edit New Biller",
                eventPage: track.PageEnum.EditNewBiller,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});