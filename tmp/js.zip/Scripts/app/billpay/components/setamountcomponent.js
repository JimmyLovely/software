﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings']], function (ko, cs, app, dataModel, commonstrings) {
    return function (params) {
        var self = this,
            billingAccount = params.BillingAccount(),
            lastAmountToSend;

        self.TransactionDetail = ko.observable(null);
        self.BillingAccountRequiredInfo = ko.observable(null);
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.CustomerSaveAdditionalInfo = ko.observable(false);

        if (!params.defaultValue()) {
            GetSeletcedToCalculate(billingAccount);
        } else {
            self.TransactionDetail(params.defaultValue());
            lastAmountToSend = self.TransactionDetail().AmountToSend.Value();

            ko.computed(function () {
                if (params.defaultValue()) {
                    if (params.defaultValue().IsInternational) {
                        var amountDestination = params.defaultValue().AmountDestination.Value();
                        lastAmountToSend = params.defaultValue().AmountToSend.Value();
                        self.TransactionDetail().AmountDestination.Value(amountDestination);
                        self.TransactionDetail().AmountToSend.Value(params.defaultValue().AmountToSend.Value());
                    } else {
                        var amountToSend = lastAmountToSend = params.defaultValue().AmountToSend.Value();
                        self.TransactionDetail().AmountToSend.Value(amountToSend);
                    }

                    var amountLimitInValid = params.defaultValue().isAmountLimitInValid();

                    if (amountLimitInValid) {
                        lastAmountToSend = 0;
                    }
                }
            });
        }

        self.CheckAmountIsValid = function (element) {
            if (!self.TransactionDetail()) return;

            var transactionDetail = self.TransactionDetail();
            if ((lastAmountToSend - transactionDetail.AmountToSend.Value() != 0)) {
                app.factoryFunc("AmountChanged");
                transactionDetail.SelectedPaymentMethodId = 0;

                var raRegExp = new RegExp(',', "g");
                var amount = $(element).val().replace(raRegExp, '');

                if (cs.isAmountValid(amount)) {
                    if (transactionDetail.IsInternational) {
                        if (transactionDetail.DisplayRate) {
                            var amountToSend = (amount / transactionDetail.DisplayRate).toFixed(2);
                            transactionDetail.AmountToSend.Value(cs.keepAmountDecimalPlaces(amountToSend));
                        }
                    } else {
                        transactionDetail.AmountToSend.Value(cs.GetFormatAmount(transactionDetail.AmountToSend.Value()));
                    }
                }

                lastAmountToSend = null;
            }
        }

        self.BackToSelectBiller = function () {
            app.factoryFunc("BackToSelectBiller");
        }

        self.GoToServiceType = function (element) {
            var transactionDetail = self.TransactionDetail(),
                amountToSend = transactionDetail.AmountToSend.Value();
            amountDestination = transactionDetail.AmountDestination.Value();

            if ((!transactionDetail.IsInternational && cs.isAmountValid(amountToSend)) ||
                    (transactionDetail.IsInternational && cs.isAmountValid(amountDestination))) {
                if (lastAmountToSend != amountToSend) {
                    lastAmountToSend = amountToSend;
                    app.factoryFunc("GoToServiceType", ko.mapping.toJS(transactionDetail));
                } else {
                    app.factoryFunc("GoToServiceType");
                }
            } else {
                cs.showErrorMessage(commonstrings.billpayandbillpaylcr.messagebox.error, commonstrings.billpayandbillpaylcr.messagebox.inputvalidamount);
            }
        }

        function GetSeletcedToCalculate(billingAccount) {
            cs.BaseAjax({
                url: '/BillPay/GetSeletcedToCalculate',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "selectedBillingAccountId": billingAccount.RppsBillingAccountId, "accountType": billingAccount.AccountType })
            }, true)
            .done(function (result) {
                if (result.AmountToSend.Value) {
                    result.AmountToSend.Value = ko.observable(result.AmountToSend.Value);
                    result.AmountDestination.Value = ko.observable(result.AmountDestination.Value);
                } else {
                    result.AmountToSend.Value = ko.observable("0.00");
                    result.AmountDestination.Value = ko.observable("0.00");
                }

                self.TransactionDetail(result);
                if (cs.IsMobileDevice()) {
                    if (!self.TransactionDetail().AmountToSend.Value()) {
                        self.TransactionDetail().AmountToSend.Value('0.00');
                    }
                    if (!self.TransactionDetail().AmountDestination.Value()) {
                        self.TransactionDetail().AmountDestination.Value('0.00');
                    }
                }
            })
            .fail(function (xhr, status) {
                var data = $.parseJSON(xhr.responseText);
                if (data.returnCode == -318) {
                    cs.showNotification(data, function () { return UpdateAdditionalInfo(data) });
                } else {
                    cs.handleAjaxError(xhr.responseText, false);
                }
            })
        }

        function UpdateAdditionalInfo(data) {
            var AdditionalInfoAvaliable = data.BillingAccountRequiredInfo && data.BillingAccountRequiredInfo.Fields.length > 0;
            if (AdditionalInfoAvaliable) {
                self.CustomerSaveAdditionalInfo(true);
                var tempFields = data.BillingAccountRequiredInfo.Fields;
                self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                self.AdditionalInfoAvaliable(true);
                cs.isCancelCloseModalCallBack = true;

                $.when(cs.openModal("modal-set-amount-additional-info"))
                .done(function () {
                    cs.initCustomAttributes();
                    cs.isCancelCloseModalCallBack = false;
                    cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                });
            }
        }

        self.AmountFormat = function (element, amount) {
            if (!cs.IsMobileDevice() && amount == "") {
                $(element).val("0.00");
                $("#input-amount").addClass("placeholder-color");
            }
        }
        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());

            if (validateResult) {
                var tempBillingAccountRequiredInfo = ko.mapping.toJS(self.BillingAccountRequiredInfo);

                cs.AjaxBySpinner({
                    url: '/BillPay/UpdateAdditionalInfo',
                    datatype: "json",
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ "BillingAccountRequiredInfo": tempBillingAccountRequiredInfo, "billingAccountId": billingAccount.RppsBillingAccountId })
                }, element)
                .done(function (result) {
                    self.AdditionalInfoAvaliable(false);
                    self.CustomerSaveAdditionalInfo(false);

                    cs.showNotification(result, function () { return GetSeletcedToCalculate(billingAccount) });
                })
                .fail(function (xhr, status) {
                    cs.handleAjaxError(xhr.responseText, false);
                })
            }
        }

        self.CancelAdditionalInfo = function () {
            cs.closeModal(false);
            app.factoryFunc("CloseAmountTab");
        }
    }
});