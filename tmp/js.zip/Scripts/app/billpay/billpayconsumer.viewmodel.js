﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'R', 'TrackEvent', 'Plugins'], function (ko, cs, app, dataModel, commonstrings, R, track) {
    function BillPayViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.billpay;
        self.IsQuickToPay = false;

        self.TransactionStart = ko.observable(false);
        self.ShowBillerPicker = ko.observable(false);
        self.ShowTransactionDetails = ko.observable(false);
        self.ShowTransactionDone = ko.observable(false);
        self.ShowQuickPay = ko.observable(false);

        self.SelectBillerCompleted = ko.observable(false);
        self.AmountToSendCompleted = ko.observable(false);
        self.ServiceTypeCompleted = ko.observable(false);
        self.SenderPaymentCompleted = ko.observable(false);
        self.SelectServiceTypeAPI = ko.observable();

        self.isClickToPay = ko.observable(false);
        self.calculateAgain = false;

        self.BillingAccountRequiredInfo = ko.observable(null);
        self.AdditionalInfoAvaliable = ko.observable(false);
        self.CustomerSaveAdditionalInfo = ko.observable(false);

        self.PaymentMethodAPI = ko.observable();

        ko.components.register('billpay-set-amount', {
            viewModel: { require: 'billpay-set-amount-js' },
            template: { require: 'text!billpay-set-amount-html' }
        });

        ko.components.register('billpay-service-type', {
            viewModel: { require: 'billpay-service-type-js' },
            template: { require: 'text!billpay-service-type-html' }
        });

        ko.components.register('billpay-payment-method', {
            viewModel: { require: 'billpay-payment-method-js' },
            template: { require: 'text!billpay-payment-method-html' }
        });

        self.SelectedBillingAccount = ko.observable(null);
        self.BillPayTransaction = ko.observable(null);
        self.SelectedServiceType = ko.observable(null);
        self.SelectedPaymentMethod = ko.observable(null);
        self.ClickPayBillingAccount = ko.observable(null);
        self.IsPromotionCodeValid = ko.observable(true);
        self.IsAddedPromotionCode = ko.observable(false);
        self.ShowPromotionCodeErrorMessage = ko.observable(true);
        self.reLinkPaymentMethod = ko.observable(null);

        self.init = function () {
            //prevent visit without permission
            dataModel.checkStatePermision();
        };

        self.controllers = {
            '/StartPositionCode/:startPositionCode': function (startPositionCode) {
                self.InitSelectBillerView();
                self.TransactionStart(true);

                //Data Capture: Initialize Transaction start from dashboard or left bar.
                cs.CaptureTransactionInfo(startPositionCode, cs.TransactionTypes.BillPay)
            },
            '/StartPositionCode/:startPositionCode/:receiptNumber': function (startPositionCode, receiptNumber) {
                var transactionInitialPositions;
                if (startPositionCode == "FromRecentTransaction") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromRecentTransaction;
                }else if (startPositionCode == "FromTxnHistory") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromTxnHistory;
                }else if (startPositionCode == "FromManageBillers"){
					transactionInitialPositions = cs.TransactionInitialPositions.FromManageBillers;
				}
                cs.AddTransactionStart(
                                        transactionInitialPositions,
                                        cs.QuickWays.QuickPay,
                                        cs.TransactionTypes.BillPay,
                                        cs.GetDateTimeOffset()
                );

                self.InitQuickPayView();
                self.TransactionStart(true);
                var emailAddress = app.senderInfo() == null ? null : app.senderInfo().Customer().CustomerBasic.EmailAddress();
                return cs.BaseAjax({
                    url: '/BillPay/InitializeQuickToPayByReceiptNumber',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "receiptNumber": receiptNumber, "emailAddress": emailAddress })
                }, true)
                  .done(function (data) {
                      var paymentMethod = data.PaymentMethod;

                      // remove credit card function
                      if (!paymentMethod.IsBank) {
                          self.SelectedBillingAccount(data.BillingAccount);
                          self.BillPayTransaction(convertTransactionModel(data.BillPayTransaction));
                          InitTabView('panel-service', true);
                          return;
                      }

                      if (paymentMethod.IsIBVAccount) {
                          $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                           .done(function (result) {
                               $.when(dataModel.checkIBVBalance(paymentMethod, data.BillPayTransaction.AmountDue.Value))
                              .done(function (result) {
                                  if (result.verifyPassed) {
                                      data.BillPayTransaction.IsIBVVerified = true;
                                      GoThroughQuickPay(data);
                                  } else if (!!result && result.isCredentialChanged) {
                                      SwitchPaymentMethodForQuickPayIBVFailed(data);
                                      self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                      return;
                                  } else {
                                      SwitchPaymentMethodForQuickPayIBVFailed(data);
                                      return;
                                  }
                              })
                               .fail(function () {
                                   GoThroughQuickPay(data);
                               });
                           })
                           .fail(function () {
                               GoThroughQuickPay(data);
                           })
                      } else {
                          GoThroughQuickPay(data);
                      }
                  })
                  .fail(function (xhr, status) {
                      var exception = $.parseJSON(xhr.responseText);
                      if (exception.ReturnCode == 17170433) {// Bill account was not found.
                          self.InitSelectBillerView();
                      } else if (exception.ReturnCode == 16842756) { // amount is invalid.
                          self.GoToAmountToSend(exception.Data.BillingAccount);
                          InitTabView('panel-amount', true);
                      } else if (exception.ReturnCode == 17170434) {// Service type was not found.
                          self.SelectedBillingAccount(exception.Data.BillingAccount);
                          self.BillPayTransaction(convertTransactionModel(exception.Data.BillPayTransaction));
                          InitTabView('panel-service', true);
                      } else if (exception.ReturnCode == 17170435) {// Payment method was not found.
                          self.SelectedBillingAccount(exception.Data.BillingAccount);
                          self.BillPayTransaction(convertTransactionModel(exception.Data.BillPayTransaction));
                          self.SelectedServiceType(convertServiceType(exception.Data.ServiceType));
                          InitTabView('panel-payment', true);
                      } else if (xhr.responseText.indexOf("You have no permission to access it") >= 0) {
                          return app.redirectTo("/SelfService/CustomerDashboard");
                      } else if (exception.Message) {

                          try {
                              var message = $.parseJSON(exception.Message).reason;
                              cs.showTransactionNotFoundError(message);
                          } catch (e) {
                              cs.showTransactionNotFoundError(exception.Message);
                          }
                      } else {
                          cs.handleAjaxError(xhr.responseText);
                      }
                  });
            },
            '/:billingAccountId/:accountType': function (billingAccountId, accountType) {
                self.TransactionStart(true);
                var billingAccount = {
                    RppsBillingAccountId: billingAccountId,
                    AccountType: accountType
                };
                self.SelectedBillingAccount(null);
                self.ClickPayBillingAccount(billingAccount);
                InitTabView("panel-amount", true);
                self.isClickToPay(true);

                //Data Capture: Initialize transaction start from click to pay.
                cs.AddTransactionStart(
                                       cs.TransactionInitialPositions.FromClickToPay,
                                       cs.QuickWays.NormalPay,
                                       cs.TransactionTypes.BillPay,
                                       cs.GetDateTimeOffset()
                                      );
            }
        };

        //Start appslfyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        };

        var trackBillPayTotalLoads = function () {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.BPFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Pay Bills",
                eventPage: track.PageEnum.PayBills,
                source: app.page().name,
                eventStructure: track.StructureEnum.InitiatedCheckout,
                eventName: 'af_initiated_checkout_BP'
            });
        }

        var trackTransactionSuccessfully = function (amount, receiptNumber) {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.BPFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Confirm & Send",
                eventPage: track.PageEnum.SendMoney,
                source: app.page().name,
                eventStructure: track.StructureEnum.Purchase,
                eventName: 'af_purchase_BP',
                amount: amount,
                revenue: amount,
                contentType: 'BP',
                currency: 'USD',
                receiptId: receiptNumber
            });
        }

        var trackRecipientPageTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: 'TimeOnPage',
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        }

        var trackViewTransactionDetailsTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: track.LabelEnum.ViewTransactionDetails,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        }

        var trackFinishButtonTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.Finish));

        var trackEmailRecipientTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.EmailReceipt));

        var trackPrintRecipientTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.PrintReceipt));
        //End appsflyer track event

        function GoThroughQuickPay(data) {
            data.PaymentMethod.IsBank = ko.observable([3, 4].indexOf(data.PaymentMethod.PaymentMethodTypeId) != -1);
            self.SelectedBillingAccount(data.BillingAccount);
            self.SelectedServiceType(convertServiceType(data.ServiceType));
            self.SelectedPaymentMethod(data.PaymentMethod);
            self.BillPayTransaction(convertTransactionModel(data.BillPayTransaction));
            //DataCapture
            cs.UpdateTransactionData({
                transactionTypeId: self.BillPayTransaction().TransactionType,
                tax: self.BillPayTransaction().FeeTaxes.Value,
                fee: self.BillPayTransaction().TotalFee.Value,
                total: self.BillPayTransaction().AmountDue.Value,
                amount: self.BillPayTransaction().AmountToSend.Value()
            });

            cs.scrollToElement($('.quick-pay-href #quickpay-input-amount'));
            $("#quickpay-input-amount").blur();
        }

        function SwitchPaymentMethodForQuickPayIBVFailed(data) {
            self.SelectedBillingAccount(data.BillingAccount);
            self.BillPayTransaction(convertTransactionModel(data.BillPayTransaction));
            self.SelectedServiceType(convertServiceType(data.ServiceType));

            var paymentMethods = self.PaymentMethodAPI().PaymentMethods();
            if (paymentMethods) {
                $.each(paymentMethods, function (index, d) {
                    d.Selected(d.PaymentMethodId === data.PaymentMethod.PaymentMethodId);
                })
                self.SelectedPaymentMethod(data.PaymentMethod);
                self.PaymentMethodAPI().PaymentMethods(paymentMethods);
            }

            self.SelectedPaymentMethod(data.PaymentMethod);
            self.reLinkPaymentMethod(data.PaymentMethod);

            InitTabView('panel-payment', true);
        }

        var isSenderInfoInit = true;

        self.afterRender = function () {
            dataModel.checkPersonInfo();

            $("#main").removeClass();
            $("#main").addClass('mod-c-money-transfer mod-c-bill-pay');

            app.cacheComponent([
                'billpay-set-amount', 'billpay-service-type', 'billpay-payment-method'
            ]);

            trackBillPayTotalLoads();
        };

        self.dispose = function () { };

        self.InitializeNewBankAccount = function (element) {
            self.PaymentMethods().AddPaymentMethodFlag(true);
            self.PaymentMethods().InitializeNewBankAccount(element);
        };

        self.InitializeNewCreditAccount = function (element) {
            self.PaymentMethods().AddPaymentMethodFlag(true);
            self.PaymentMethods().InitializeNewCreditAccount(element);
        };

        self.Ready = function () {
            $("#main").addClass("mod-c-money-transfer mod-c-bill-pay");
        }

        self.InitQuickPayView = function () {
            self.ShowBillerPicker(false);
            self.ShowTransactionDetails(true);
            self.ShowTransactionDone(false);
            self.ShowQuickPay(true);

            self.SelectBillerCompleted(true);
            self.AmountToSendCompleted(true);
            self.ServiceTypeCompleted(true);
            self.SenderPaymentCompleted(true);
        }



        self.InitSelectBillerView = function () {
            InitTabView('panel-recipient', true);
        }

        self.BackToSelectBiller = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            BackToTab("panel-recipient");
        }

        self.CloseAmountTab = function () {
            self.BackToSelectBiller();
            self.SelectBillerCompleted(false);
        }

        self.GoToAmountToSend = function (billingAccount) {
            if (billingAccount || !self.SelectBillerCompleted()) {
                self.SelectedBillingAccount(billingAccount || self.SelectedBillingAccount());
                self.BillPayTransaction(null);
                self.SelectedServiceType(null);
                self.SelectedPaymentMethod(null);
                if (self.isClickToPay()) {
                    cs.triggerTab("panel-amount");
                    cs.scrollToTab('panel-amount');
                    self.isClickToPay(false);
                    return;
                }
                return InitTabView('panel-amount', true);
            }
            cs.triggerTab("panel-amount");
            cs.scrollToTab('panel-amount');
        };

        self.BackToAmountToSend = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            BackToTab("panel-amount");
        };

        self.AmountChanged = function () {
            self.BillPayTransaction(null);
            self.SelectedServiceType(null);
            self.SelectedPaymentMethod(null);
            self.PaymentMethodAPI().IBVStatus(cs.IBVStatus.Normal);
            InitTabView("panel-service", true, false);
            self.AmountToSendCompleted(false);
        }

        self.GoToServiceType = function (billPayTransaction) {
            if (billPayTransaction) {
                self.BillPayTransaction(convertTransactionModel(billPayTransaction));
                self.SelectedServiceType(null);
                self.SelectedPaymentMethod(null);
                return InitTabView("panel-service", true);
            }
            cs.triggerTab("panel-service");
            cs.scrollToTab('panel-service');
        }

        self.BackToServiceType = function () {
            BackToTab("panel-service");
        };

        self.GoToSenderPayment = function (serviceType) {
            if (serviceType) {
                self.PaymentMethodAPI().IBVStatus(cs.IBVStatus.Normal);
                self.SelectedServiceType(convertServiceType(serviceType));
                self.SelectedPaymentMethod(null);
                self.SelectBillerCompleted(true);
                self.AmountToSendCompleted(true);
                self.ServiceTypeCompleted(true);
                self.SenderPaymentCompleted(false);

                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(false);
            }
            cs.triggerTab("panel-payment");
            cs.scrollToTab("panel-payment");
        }

        self.BackToSenderPayment = function () {
            BackToTab("panel-payment");
        };

        self.GoToTransactionDetails = function (selectedPaymentMethod, ignoreConvert) {
            //IBV Data capture.
            cs.IBVDataCaptureMmodel.UpdateIbvActivity(selectedPaymentMethod.PaymentMethodId);

            if (self.calculateAgain || selectedPaymentMethod) {
                self.BillPayTransaction().IsIBVVerified = false;
                if (selectedPaymentMethod) {
                    selectedPaymentMethod.IsBank = ko.observable([3, 4].indexOf(selectedPaymentMethod.PaymentMethodTypeId) != -1)
                    self.SelectedPaymentMethod(selectedPaymentMethod);
                }
                self.BillPayTransaction().PromotionCode('');
                self.IsAddedPromotionCode(false);
                $.when(Calculate())
                .done(function () {
                    if (selectedPaymentMethod.IsBank && selectedPaymentMethod.IsIBVAccount && !ignoreConvert) {
                        $.when(dataModel.checkIBVBalance(selectedPaymentMethod, self.BillPayTransaction().AmountDue.Value))
                        .done(function (result) {
                            if (result.verifyPassed) {
                                self.BillPayTransaction().IsIBVVerified = true;
                                SuccessfullyGoToTransactionDetail();
                            } else if (!!result && result.isCredentialChanged) {
                                self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                return;
                            } else {
                                self.PaymentMethodAPI().lastPaymentMethodId = null;
                                return;
                            }
                        })
                        .fail(function () {
                            SuccessfullyGoToTransactionDetail();
                        });
                    } else {
                        SuccessfullyGoToTransactionDetail();
                    }
                })
            } else {
                self.ShowBillerPicker(false);
                self.ShowTransactionDetails(true);
                cs.SlideToBottom();
            }
        }

        function SuccessfullyGoToTransactionDetail() {
            self.ShowTransactionDone(false);
            self.ShowQuickPay(false);
            self.SenderPaymentCompleted(true);
            self.ShowBillerPicker(false);
            self.ShowTransactionDetails(true);

            return cs.SlideToBottom();
        }

        function InitTabView(tabName, isChanged, isTriggerTab) {
            if (isChanged) {
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(false);
                self.ShowQuickPay(false);
                switch (tabName) {
                    case 'panel-recipient':
                    case 'panel-amount':
                        self.SelectBillerCompleted(false);
                    case 'panel-service':
                        self.AmountToSendCompleted(false);
                    default:
                        self.ServiceTypeCompleted(false);
                        self.SenderPaymentCompleted(false);
                }
            }

            switch (tabName) {
                case 'panel-payment':
                    self.ServiceTypeCompleted(true);
                case 'panel-service':
                    if (isTriggerTab !== false) {
                        self.AmountToSendCompleted(true);
                    }
                case 'panel-amount':
                    self.SelectBillerCompleted(true);
                default:
                    self.ShowBillerPicker(true);
            }

            if (isTriggerTab !== false) {
                cs.triggerTab(tabName);
                cs.scrollToTab(tabName);
            }
        }

        function BackToTab(tabName) {
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowBillerPicker(true);
            self.ShowQuickPay(false);

            cs.triggerTab(tabName);
            cs.scrollToTab(tabName);
        }

        self.AgreeChange = ko.computed(function () {
            if (self.BillPayTransaction() && self.BillPayTransaction().IsAgree && self.BillPayTransaction().IsAgree()) {
                $("#NotAgreeError").fadeOut();
            }
        });

        self.EditServiceType = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.CheckAmountIsValid()) {
                self.BackToServiceType();
            }
        };

        self.EditSenderPayment = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.CheckAmountIsValid()) {
                self.BackToSenderPayment();
            }
        };

        self.QuickPayConfirm = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (self.CheckAmountIsValid()) {
                var paymentMethod = self.SelectedPaymentMethod();
                if (paymentMethod.IsIBVAccount) {
                    $.when(dataModel.checkIBVNetwork())
                    .done(function (result) {
                        $.when(dataModel.checkIBVBalance(paymentMethod, self.BillPayTransaction().AmountDue.Value))
                        .done(function (result) {
                            if (result.verifyPassed) {
                                self.BillPayTransaction().IsIBVVerified = true;
                                self.Confirm(element);
                            } else {
                                self.PaymentMethodAPI().lastPaymentMethodId = null;
                                return;
                            }
                        })
                        .fail(function () {
                            self.Confirm(element);
                        });
                    })
                    .fail(function () {
                        self.Confirm(element);
                    })
                } else {
                    self.Confirm(element);
                }
            };
        };

        self.transStatus = new cs.executeStatus();

        self.Confirm = function (element) {
            if (!self.BillPayTransaction().IsAgree()) {
                $("#NotAgreeError").fadeIn();
                return;
            }

            if (self.transStatus.isExecuting()) {
                return;
            }

            Confirm(element);
        };

        self.AddAccount = function (element) {
            $.when(self.PaymentMethods().AddAccount(element))
            .done(function (paymentMethod) {
                if (paymentMethod != null) {
                    self.GoToTransactionDetails(element, self.PaymentMethods().TobeUpdatedPaymentMethod);
                }
            });
        }

        // begin: quick pay
        self.InitializeTransactionQuickPayWithErrorMessage = function (billPay, errorMessage) {
            self.InitializeTransactionQuickPay(billPay);
            quickPayCalculateSuccessfully = false;
            cs.addDisable("quickpay-input-amount");
            cs.showErrorMessage("Error", errorMessage, function () {
                $.when(cs.closeModal())
                .done(function () {
                    cs.removeDisable("quickpay-input-amount");
                });
            });
        };

        self.QuickPayGoToServiceType = function (billPayConsumerModel) {
            var tempBllPayConsumerModel = ko.mapping.toJS(billPayConsumerModel);
            ko.mapping.fromJS(tempBllPayConsumerModel, {}, self);

            self.BackToServiceType();
        };

        self.QuickPayGoToPaymentMethod = function (billPayConsumerModel) {
            var tempBllPayConsumerModel = ko.mapping.toJS(billPayConsumerModel);
            ko.mapping.fromJS(tempBllPayConsumerModel, {}, self);
            self.BillPayTransaction().ServiceTypeSelected(self.BillPayTransaction().SelectedServiceType);
            self.BillPayTransaction().GetServiceTypes(self.BillPayCustomer().SelectedBillingAccount.AccountType());

            self.BackToSenderPayment();
        };

        self.GoBack = function (isBackToAmountToSent) {
            if (isBackToAmountToSent) {
                $("#input-amount").val(cs.keepAmountDecimalPlaces($("#input-amount").val()));
            }
            setTimeout(function () {
                cs.fitTextAmountField($("#input-amount"), cs.keepAmountDecimalPlaces($("#input-amount").val()));
                cs.fitTextAmountField($("#input-send-amount"), cs.keepAmountDecimalPlaces($("#input-send-amount").val()));
            });
        }

        self.QuickPayCalculate = function (isQuickPay, element) {
            if (cs.isOpeningModal()) {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-confirm-done', 'back-to-amount-send', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
                return;
            }

            self.PaymentMethodAPI().lastPaymentMethodId = null;
            var billPayTransaction = self.BillPayTransaction();
            var delegate = function () {
                if (billPayTransaction.PromotionCode && cs.CustomTrim(billPayTransaction.PromotionCode()) != "") {
                    return ApplyPromoCode(isQuickPay, element);
                } else {
                    return Calculate(isQuickPay, element);
                }
            }
            $.when(delegate()).always(function () {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-confirm-done', 'back-to-amount-send', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
            });
        };

        var quickPayCheckAmountTimer;
        var originalAmount;
        self.InputAmountQuickPaySection = function (amount, hideLoading) {
            if (amount == "" || $('#quickpay-input-amount').hasClass("placeholder-color")) {
                $('#quickpay-input-amount').trigger("change.attribute.amounttosend");
            }
            self.ShowPromotionCodeErrorMessage(false);
            if (!CheckAmountIsValidQuickPaySection(amount)) {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-confirm-done', 'back-to-amount-send', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);
                return false;
            }

            amount = setFormattedAmount(amount);
            if (originalAmount != undefined && Number(cs.GetOriginalNumber(originalAmount) == Number(cs.GetOriginalNumber(amount)))) {
                return true;
            }

            if (quickPayCheckAmountTimer) {
                clearTimeout(quickPayCheckAmountTimer);
            }

            self.BillPayTransaction().isAmountLimitInValid(false);

            var element = hideLoading ? '#virtualElement' : null;

            cs.disableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'bill-pay-confirm-done', 'back-to-amount-send', 'back-to-biller', 'back-to-service-type', 'back-to-payment']);

            quickPayCheckAmountTimer = setTimeout(function () {
                self.QuickPayCalculate(true, element);
            }, 500);
        }


        function setFormattedAmount(amount) {
            if (self.BillPayTransaction().IsInternational) {
                originalAmount = self.BillPayTransaction().AmountDestination.Value();
            } else {
                originalAmount = self.BillPayTransaction().AmountToSend.Value();
            }

            if (cs.IsMobileDevice()) {
                cs.formatAmountForInput('#quickpay-input-amount', originalAmount);
                if (self.BillPayTransaction().IsInternational) {
                    self.BillPayTransaction().AmountDestination.Value($('#quickpay-input-amount').val());
                } else {
                    self.BillPayTransaction().AmountToSend.Value($('#quickpay-input-amount').val());
                }

                return $('#quickpay-input-amount').val();
            } else {
                if (self.BillPayTransaction().IsInternational) {
                    self.BillPayTransaction().AmountDestination.Value(amount);
                } else {
                    self.BillPayTransaction().AmountToSend.Value(amount);
                }

                return amount;
            }
        }

        function CheckAmountIsValidQuickPaySection(amount) {
            if (!cs.isAmountValid(amount)) {
                return false;
            }

            return true;
        };

        // end: quick pay

        //start: Bill Pay Transaction
        self.CheckAmountAndPromoCodeIsValid = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            //Check Promo Code
            var promoCode = cs.CustomTrim($("#input-promo-code").val());

            if (!promoCode) {
                return cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.messagebox.validpromocode, function () {
                    self.IsPromotionCodeValid(false);
                    self.IsAddedPromotionCode(false);
                    cs.closeModal();
                });
            }

            //Check Amount
            if (self.CheckAmountIsValid()) {
                ApplyPromoCode();
            }
        }

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.BillPayTransaction().ReceiptNumber, element);

            trackEmailRecipientTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.EmailReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        };

        self.PrintBillPayReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/Customers/SelfServicePrintStandardReceipt',
                dataType: "html",
                cache: false,
                data: { 'receiptNumber': self.BillPayTransaction().ReceiptNumber, 'senderEmailAddress': app.senderInfo().Customer().CustomerBasic.EmailAddress() }
            }, element)
            .done(function (result) {
                cs.PrintTransaction(result, element);
            });

            trackPrintRecipientTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.PrintReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        }

        self.RemovePromoCode = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            $.when(CleanPromo())
           .done(function () {
               self.IsPromotionCodeValid(true);
               self.IsAddedPromotionCode(false);
           });
        }

        //DataCapture
        self.UpdateDataCaptureTransactionFee = function () {
            cs.UpdateTransactionData({
                transactionTypeId: self.BillPayTransaction().TransactionType,
                tax: self.BillPayTransaction().FeeTaxes.Value,
                fee: self.BillPayTransaction().TotalFee.Value,
                total: self.BillPayTransaction().AmountDue.Value
            });
        }

        function Calculate(isQuickPay, element) {
            var transactionModel = GetTransactionModel();
            if (!transactionModel.AmountToSend.Value || transactionModel.AmountToSend.Value == '0.00') {
                return $.Deferred().reject();
            }

            var deferred = $.Deferred();
            cs.AjaxBySpinnerOrLoading({
                url: '/BillPay/SelfServiceCaculate',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(transactionModel)
            }, element, true)
            .done(function (result) {
                if (checkAmountChange(transactionModel)) {
                    return;
                }

                self.SelectedServiceType().Fee.Value(result.FeeCharged.Value);
                var result = convertTransactionModel(result);
                result.IsAgree(self.BillPayTransaction().IsAgree());
                self.BillPayTransaction(result);
                self.calculateAgain = false;

                //DataCapture.
                self.UpdateDataCaptureTransactionFee();

                if (isQuickPay == true) {
                    GetBillPayServiceType(element);
                }

                deferred.resolve();
            })
            .fail(function (xhr, status) {
                if (checkAmountChange(transactionModel)) {
                    return;
                }

                self.calculateAgain = true;
                var data = $.parseJSON(xhr.responseText);
                if (data.ReturnCode == -318) {
                    cs.showNotification(data, function () { return UpdateAdditionalInfo(data) });
                } else if (data.ReturnCode == -146) {
                    self.BillPayTransaction().PromotionCode('');
                    self.IsPromotionCodeValid(false);
                    self.IsAddedPromotionCode(true);
                    self.ShowPromotionCodeErrorMessage(element != '#virtualElement');

                    // Reomve promotion code and calculate again.
                    Calculate(isQuickPay, element);
                } else {
                    cs.handleAjaxError(xhr.responseText, false);
                }

                deferred.reject();
            });

            return deferred;
        }

        function checkAmountChange(transactionModel) {
            if ((self.BillPayTransaction().IsInternational && Number(cs.GetOriginalNumber(self.BillPayTransaction().AmountDestination.Value())) != Number(cs.GetOriginalNumber(transactionModel.AmountDestination.Value)))
                || (!self.BillPayTransaction().IsInternational && Number(cs.GetOriginalNumber(self.BillPayTransaction().AmountToSend.Value())) != Number(cs.GetOriginalNumber(transactionModel.AmountToSend.Value)))) {
                return true;
            }

            return false;
        }

        function GetTransactionModel() {
            self.BillPayTransaction().IsQuickPay = self.ShowQuickPay();
            var transaction = ko.mapping.toJS(self.BillPayTransaction());
            transaction.SelectedPaymentMethodId = self.SelectedPaymentMethod().PaymentMethodId;
            transaction.SelectedServiceType = self.SelectedServiceType();
            transaction.BillingAccountId = self.SelectedBillingAccount().RppsBillingAccountId;
            transaction.Regular = self.SelectedBillingAccount().IsRppsBillingAccount;
            return transaction;
        }

        self.CheckAmountIsValid = function () {
            if (!cs.isAmountValid(GetSendAmount())) {
                cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.messagebox.validamount);
                return false;
            }

            return true;
        }

        function GetSendAmount() {
            if (self.BillPayTransaction().IsInternational) {
                return self.BillPayTransaction().AmountDestination.Value();
            } else {
                return self.BillPayTransaction().AmountToSend.Value();
            }
        };

        function CleanPromo() {
            self.BillPayTransaction().PromotionCode("");
            return Calculate();
        }

        function ApplyPromoCode(isQuickPay, element) {
            var transaction = self.BillPayTransaction(),
                promoCode = transaction.PromotionCode();
            paymentMethodId = self.SelectedPaymentMethod().PaymentMethodId;
            return $.when(Calculate(isQuickPay, element))
                    .done(function () {
                        $("#input-promo-code").val('');
                        self.IsPromotionCodeValid(true);
                        self.IsAddedPromotionCode(true);
                        $("#input-promo-message").removeClass("hide");
                    });
        }

        function convertServiceType(data) {
            data.Fee.Value = ko.observable(data.Fee.Value);
            return data;
        }

        function Confirm(element) {
            self.transStatus.setExecuting();
            if (!(self.IsAddedPromotionCode() && self.IsPromotionCodeValid())) {
                self.BillPayTransaction().PromotionCode("");
            }
            return cs.AjaxByLoading({
                url: '/BillPay/SelfServiceTransaction',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(GetTransactionModel())
            }, true)
            .done(function (result) {
                cs.AddActivityInfo(28, null, true);
                //Init components view
                self.TransactionStart(false);
                self.SelectBillerCompleted(false);
                self.AmountToSendCompleted(false);

                self.BillPayTransaction(convertTransactionModel(result));

                //DataCapture
                if (self.BillPayTransaction().ConfirmationNumber.length === 20) {
                    cs.UpdateTransactionData({
                        receiptNumber: self.BillPayTransaction().ConfirmationNumber,
                        transactionTypeId: self.BillPayTransaction().TransactionType,
                        tax: self.BillPayTransaction().FeeTaxes.Value,
                        fee: self.BillPayTransaction().TotalFee.Value,
                        total: self.BillPayTransaction().AmountDue.Value
                    });
                }

                app.needRefreshVailableBalanceFlag = true;// Refresh available balance.
                self.ShowBillerPicker(false);
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(true);
                cs.RegisterExpandCollapse();
                cs.SlideToTop();

                if (app.senderInfo() != null) {
                    app.senderInfo().GetSenderLevel(element);
                }

                self.transStatus.complete();

                trackTransactionSuccessfully(cs.getValue(result.AmountToSend.Value), self.BillPayTransaction().ConfirmationNumber.trim());

                trackRecipientPageTimeOnPage();
                track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionReceiptPage, track.PageEnum.TransactionReceiptPage);
            })
            .fail(function (data) {
                self.transStatus.complete();

                if (data.statusText == 'timeout') {
                    cs.showErrorMessage(commonstrings.messagebox.billpayfailed, commonstrings.messagebox.timeout);
                    return;
                }

                var tempError = "";
                try {
                    tempError = JSON.parse(data.responseText);
                } catch (e) {
                    cs.handleAjaxError(e);
                    return;
                }
                try {
                    var message = JSON.parse(tempError.Message);
                    if (message != null && message.exceptionCode == -462) {
                        cs.AddActivityInfo(29, null, true);
                        ShowPaymentsMethodFailDialog();
                    } else if (message != null && message.exceptionCode == -481) {
                        cs.BaseAjax({
                            url: '/PaymentMethod/GetCurrentPaymentProvider',
                            type: 'get',
                            dataType: 'json'
                        })
                        .done(function (result) {
                            app.senderInfo().PosPaymentConfig(result);
                        });
                        GetBillPayPaymentMethods();

                        cs.AddActivityInfo(29, null, true);
                        ShowPaymentsMethodFailDialog();
                    } else {
                        cs.showErrorMessage(commonstrings.messagebox.billpayfailed, tempError.Message);
                    }
                } catch (e) {
                    cs.showErrorMessage(commonstrings.messagebox.billpayfailed, tempError.Message);
                }
            });
        }

        function ShowPaymentsMethodFailDialog() {
            $.when(cs.showErrorMessage(commonstrings.messagebox.paymenterror, commonstrings.messagebox.paymentnotsuccess + "&nbsp;<a id='payment-method-link'>" + commonstrings.messagebox.paymentmethod + "</a>&nbsp;" + commonstrings.messagebox.tryagain))
            .done(function () {
                $("#payment-method-link").click(function () {
                    cs.closeModal();
                    if (self.ShowQuickPay()) {
                        self.EditSenderPayment();
                    } else {
                        self.BackToSenderPayment();
                    }
                });
            });
        }

        // end: Bill Pay Transaction
        function convertTransactionModel(data) {
            if (self.BillPayTransaction() && self.ShowQuickPay()) {
                if (self.BillPayTransaction().IsInternational) {
                    data.AmountDestination.Value = $('#quickpay-input-amount').val();
                } else {
                    data.AmountToSend.Value = $('#quickpay-input-amount').val();
                }
            }

            data.AmountToSend.Value = ko.observable(data.AmountToSend.Value);
            data.AmountDestination.Value = ko.observable(data.AmountDestination.Value);
            data.PromotionCode = ko.observable(data.PromotionCode);
            data.IsAgree = ko.observable(false);
            data.isAmountLimitInValid = ko.observable(false);
            return data;
        }

        function GetBillPayServiceType(element) {
            var accountType = self.SelectedBillingAccount().AccountType;
            var amount = cs.GetOriginalNumber(self.BillPayTransaction().AmountToSend.Value());
            if (!amount) {
                return;
            }

            cs.AjaxBySpinnerOrLoading({
                url: '/BillPay/GetServiceTypes',
                dataype: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountId": self.SelectedBillingAccount().RppsBillingAccountId, "accountType": accountType, 'amountToSend': amount })
            }, element)
            .done(function (result) {
                $.each(result, function (index, r) {
                    r.Selected = ko.observable(self.SelectServiceTypeAPI().isEqual(r));
                });
                self.SelectServiceTypeAPI().ServiceTypes(result);
            });
        }

        function UpdateAdditionalInfo(data) {
            var AdditionalInfoAvaliable = data.BillingAccountRequiredInfo && data.BillingAccountRequiredInfo.Fields.length > 0;
            if (AdditionalInfoAvaliable) {
                self.AdditionalInfoAvaliable(false);
                self.BillingAccountRequiredInfo(ko.mapping.fromJS(data.BillingAccountRequiredInfo));
                cs.applyBillerAdditionalValidation(self.BillingAccountRequiredInfo().Fields());
                self.AdditionalInfoAvaliable(true);
                self.CustomerSaveAdditionalInfo(true);
                cs.isCancelCloseModalCallBack = true;

                $.when(cs.openModal("modal-update-additional-info"))
                .done(function () {
                    cs.initCustomAttributes();
                    cs.isCancelCloseModalCallBack = false;
                    cs.bindChange(self.BillingAccountRequiredInfo().Fields());
                });
            }
        }
        self.SaveAdditionalInfo = function (element) {
            var tempFields = ko.mapping.toJS(self.BillingAccountRequiredInfo().Fields);
            var validateResult = cs.validateAdditionalFields(self.BillingAccountRequiredInfo().Fields());

            if (validateResult) {
                var tempBillingAccountRequiredInfo = ko.mapping.toJS(self.BillingAccountRequiredInfo);
                ko.mapping.fromJS(tempBillingAccountRequiredInfo, {}, self.BillPayTransaction().BillingAccountRequiredInfo);

                cs.AjaxBySpinner({
                    url: '/BillPay/UpdateAdditionalInfo',
                    datatype: "json",
                    type: "POST",
                    contentType: "application/json",
                    data: JSON.stringify({ "BillingAccountRequiredInfo": tempBillingAccountRequiredInfo })
                }, element)
                .done(function (result) {
                    self.AdditionalInfoAvaliable(false);
                    self.CustomerSaveAdditionalInfo(false);

                    cs.showNotification(result, function () { return self.GoToTransactionDetails(ko.mapping.toJS(self.SelectedPaymentMethod)) });
                })
                .fail(function (xhr, status) {
                    cs.handleAjaxError(xhr.responseText, false);
                })
            }
        }

        self.CancelAdditionalInfo = function () {
            cs.closeModal(false);
        }

        function GetBillPayPaymentMethods() {
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
           .done(function (result) {
               $.each(result, function (index, d) {
                   d.Selected = ko.observable(false);
               })
               self.PaymentMethodAPI().PaymentMethods(result);
           })
        }


        self.viewTransactionDetails = function () {
            var transaction = self.BillPayTransaction();
            dataModel.viewTransactionHistoryByReceiptNumber(transaction.ReceiptNumber.trim());

            trackViewTransactionDetailsTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.ViewTransactionDetails);
        }

        self.cancelTransaction = function () {
            app.senderInfo().GoToDashboard();

            if (self.ShowTransactionDone()) {
                trackFinishButtonTotalClicks();
                track.trackTimeOnPageForPageLink(track.LabelEnum.Finish);
            }
        };
    }

    return new BillPayViewModel();
});