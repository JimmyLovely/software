﻿define(['knockout', 'app', 'ClientScript', paths['common-strings'], 'R', 'TrackEvent', 'knockout.validation.extended'], function (ko, app, cs, commonstrings, R, track) {
    function ReferralViaEmailViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.referralemail;
        self.emails = ko.observableArray();
        self.hasInvalidEmail = ko.observable(false);
        self.hasNotEnteredEmail = ko.observable(false);
        self.hasDuplicatedEmail = ko.observable(false);
        self.isSendEmailsSuccessfully = ko.observable(false);
        self.UniqueURL_Email = ko.observable();
        self.ReferralLinkId_Email = ko.observable();

        self.init = function () {
            self.hasNotEnteredEmail(false);
        }
        self.dispose = function () { };

        // Start appsflyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.ReferralViaEmail,
                source: app.page().name
            });
        }

        var trackReferralViaEmailTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Refer via Email",
                eventPage: track.PageEnum.ReferralViaEmail
            });
        }

        var trackTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.ReferralViaEmail
            });
        }
        // End appsflyer track event
        self.afterRender = function () {
            initUniqueURL();
            addEvent();

            trackReferralViaEmailTotalLoads();
            trackTimeOnPage();
        };

        //use it to add go to next element
        function addEvent() {
            $("#email-list input[class='email']").off("keydown.enteremail").on("keydown.enteremail", function (event) {
                if (event.keyCode == 13) {
                    array = $("#email-list input").filter(".email");
                    var index = array.index(this);
                    if (index == array.length - 1) {
                        $(this).blur();
                        self.sendEmail();
                        return;
                    } else {
                        array[index + 1].focus();
                    }
                }
            });
        }

        function initUniqueURL() {
            self.emails([]);
            for (var i = 0; i < 3; i++) {
                addEmail();
            }
        }

        ko.validation.init({
            grouping: { deep: false, observable: false },
            decorateElement: true,
            insertMessages: false,
            decorateElementOnModified: true,
            decorateInputElement: true,
            errorClass: 'error-msg',
            errorMessageClass: 'error-msg',
            errorElementClass: 'error'
        });

        self.inputEmailBlur = function (element, index) {
            checkEmailsValidation();
            var emailList = self.emails();
            var emailSet = new Set();
            var indexSet = new Set();
            var hasDuplicated = false;
            $.each(emailList, function (i, e) {
                if (!!e.email() && e.email().length > 0) {
                    if (index() != i && e.email() == element.value) {
                        $(element).addClass("duplicatedError");
                        $(element).prev().addClass('duplicatedError');
                        hasDuplicated = true;
                    }
                }
            });
            if (!hasDuplicated) {
                $(element).removeClass("duplicatedError");
                $(element).prev().removeClass('duplicatedError');
            }
            if ($(".duplicatedError").length > 0) {
                self.hasDuplicatedEmail(true);
            } else {
                self.hasDuplicatedEmail(false);
            }
        }

        self.inputEmailFocus = function () {
            if (self.isSendEmailsSuccessfully()) {
                self.isSendEmailsSuccessfully(false);
            }
        }

        function addEmail() {
            var email = ko.observable(null);
            email.extend({
                email: {
                    params: true,
                    message: function () { self.hasInvalidEmail(true); return '' },
                    equal: {
                        onlyIf: true,
                        message: ''
                    }
                }
            }).isModified(false);
            var hasError = ko.observable(false);
            var emails = self.emails();
            emails.push({ email: email, hasError: hasError });
            self.emails(emails);
            addEvent();
        }

        self.addEmail = function () {
            addEmail();

            var trackAddAnotherEmailTotalClicks = trackEvent;
            trackAddAnotherEmailTotalClicks("Refer via Email: Add Another Email");
        }

        self.sendEmail = function () {
            var trackSendEmailTotalClicks = trackEvent;
            trackSendEmailTotalClicks("Refer via Email: Send");
            self.isSendEmailsSuccessfully(false);
            if (checkEmailsValidation() && !self.hasDuplicatedEmail()) {
                var emailList = self.emails();
                var emailStringList = [];
                $.each(emailList, function (index, e) {
                    if (!!e.email() && e.email().length > 0) {
                        emailStringList.push(e.email());
                    }
                });
                cs.AjaxByLoading({
                    url: '/Referral/SelfServiceShareReferralLinkForWeb',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "referralChannelId": 3, "contactList": emailStringList })
                })
                .done(function (data) {
                    if (!!data) {
                        $.each(emailList, function (index, e) {
                            e.email('');
                        });
                        self.isSendEmailsSuccessfully(true);
                    }

                    //Data Capture Referral activity.
                    cs.LogReferralActivty(data.Url);
                })
                .always(function () {
                    track.trackTimeOnPageForPageLink("Send");
                    track.generatePartialTimeOnPageTrack();// clear time on page track
                });
            }
        }

        self.cancelUpdateEmail = function () {
            app.redirectTo("/SelfService/ReferralLandingConsumer");

            var trackCancelEmailTotalClicks = trackEvent;
            trackCancelEmailTotalClicks("Refer via Email: Cancel");
            track.trackTimeOnPageForPageLink("Cancel");
        }

        function checkEmailsValidation(isSend) {
            var emailList = self.emails();
            var hasError = false;
            var hasNotEnteredEmail = true;
            $.each(emailList, function (index, e) {
                if (!!e.email() && e.email().length > 0) {
                    hasNotEnteredEmail = false;
                    if (!e.email.isValid()) {
                        e.hasError(true);
                        return;
                    } else {
                        e.hasError(false);
                    }
                } else {
                    e.hasError(false);
                }
            });

            $.each(emailList, function (index, e) {
                if (e.hasError()) {
                    setTimeout(function () {
                        self.hasInvalidEmail(true);
                    }, 300);

                    hasError = true;
                }
            });

            setTimeout(function () {
                self.hasNotEnteredEmail(hasNotEnteredEmail);
            }, 300);

            if (hasNotEnteredEmail) {
                setTimeout(function () {
                    self.hasInvalidEmail(false);
                }, 300);

                return false;
            }

            if (!hasError) {
                setTimeout(function () {
                    self.hasInvalidEmail(false);
                }, 300);

                return true;
            } else {
                setTimeout(function () {
                    self.hasInvalidEmail(true);
                }, 300);

                return false;
            }
        }
    }
    return new ReferralViaEmailViewModel();
});