﻿define(['knockout', 'ClientScript', 'app', paths['common-strings']], function (ko, cs, app, commonstrings) {
    function ReferralHowWorksConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.referralhowworks;
        self.init = function () {
        }
        self.dispose = function () { };
    }
    return new ReferralHowWorksConsumerViewModel();
});