﻿define(['knockout', 'app', 'ClientScript', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, commonstrings, R, track) {
    function ReferralHistoryViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.referralhistory;
        self.emailHistoryList = ko.observableArray();
        self.smsHistoryList = ko.observableArray();
        self.facebookHistory = ko.observable(null);
        self.twitterHistory = ko.observable(null);
        self.copyHistory = ko.observable(null);
        self.invitesAccepted = ko.observable(0);
        self.totalRewardEarned = ko.observable(0);
        self.referHistoryListflag = ko.observable(true);

        function initData() {
            cs.BaseAjax({
                url: '/Referral/SelfServiceGetReferralSummaryForWeb',
                type: "GET",
                dataType: "json"
            })
            .done(function (data) {
                self.referHistoryListflag(false);
                self.invitesAccepted(data.InvitesAccepted);
                self.totalRewardEarned(data.RewardsEarned);

                self.emailHistoryList([]);
                self.smsHistoryList([]);

                $.each(data.RefereeDetailsList, function (i, e) {
                    if (e.ReferralChannelId == 1) {
                        var tempModel = { "SentCounts": e.ReferralsPending, "CompletedCounts": e.ReferralsCompleted };
                        self.facebookHistory(tempModel);
                    }
                    if (e.ReferralChannelId == 2) {
                        var tempModel = { "SentCounts": e.ReferralsPending, "CompletedCounts": e.ReferralsCompleted };
                        self.twitterHistory(tempModel);
                    }
                    if (e.ReferralChannelId == 3) {
                        var ReferralName = ko.observable(e.RecipientInfo);

                        var ReferralStatus = ko.observable((e.ReferralsCompleted == 1));
                        var tempList = self.emailHistoryList();
                        tempList.push({ ReferralName: ReferralName, ReferralStatus: ReferralStatus });
                        self.emailHistoryList(tempList);
                    }
                    if (e.ReferralChannelId == 4) {
                        var ReferralName = ko.observable(GetFormatPhoneNumber(e.ReceiverInfo));
                        var ReferralStatus = ko.observable((e.ReferralsCompleted == 1));
                        var tempList = self.smsHistoryList();
                        tempList.push({ ReferralName: ReferralName, ReferralStatus: ReferralStatus });
                        self.smsHistoryList(tempList);
                    }
                    if (e.ReferralChannelId == 5) {
                        var tempModel = { "SentCounts": e.ReferralsPending, "CompletedCounts": e.ReferralsCompleted };
                        self.copyHistory(tempModel);
                    }
                });
            })
            .fail(function () {
                self.referHistoryListflag(false);
            });
        }
        self.init = function () {
        }

        // Start appsflyer track event
        var trackReferMoreFriendTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Referral History: Refer More Friends",
                eventPage: track.PageEnum.ReferralHistory,
                source: app.page().name
            });
            track.trackTimeOnPageForPageLink("ReferralMoreFriends");
        }

        var trackTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Referral History",
                eventPage: track.PageEnum.ReferralHistory
            });
        }

        var trackTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.ReferralHistory
            });
        }
        // End appsflyer track event

        self.afterRender = function () {
            initData();

            trackTotalLoads();

            trackTimeOnPage();
        };

        self.dispose = function () { };

        self.referMoreFriend = function () {
            app.redirectTo("/SelfService/ReferralLandingConsumer");

            trackReferMoreFriendTotalClicks();
        }

        function GetPhoneNumber(phoneNumber) {
            if (!phoneNumber) {
                return phoneNumber;
            }

            var regAreaCode = new RegExp(/^\+[\d|/|\s]*-/);
            phoneNumber = phoneNumber.replace(regAreaCode, '');

            phoneNumber = phoneNumber.replace(/\(/g, '').replace(/\)/g, '').replace(/ /g, '').replace(/-/g, '');

            return phoneNumber;
        }

        function GetFormatPhoneNumber(phoneNumber) {
            if (!!phoneNumber && phoneNumber.length != 10)
                return phoneNumber;

            phoneNumber = GetPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10) {
                var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                phoneNumber = phoneNumber.replace(reg, "$1-$2-$3");
            }

            return phoneNumber;
        }
    }
    return new ReferralHistoryViewModel();
});