﻿define(['knockout', 'ClientScript', 'Clipboard', 'app', paths['common-strings'], 'R', 'TrackEvent'], function (ko, cs, Clipboard, app, commonstrings, R, track) {
    function ReferralLandingConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.referral;
        self.UniqueURL_Facebook = ko.observable();
        self.UniqueURL_Twitter = ko.observable();
        self.UniqueURL_Email = ko.observable();
        self.UniqueURL_Copy = ko.observable();
        self.UniqueURL_SMS = ko.observable();
        self.referralHelpFlag = ko.observable(false);

        self.ReferralLinkId_Facebook = ko.observable();
        self.ReferralLinkId_Twitter = ko.observable();
        self.ReferralLinkId_Email = ko.observable();
        self.ReferralLinkId_SMS = ko.observable();
        self.ReferralLinkId_Copy = ko.observable();
        self.IsShowReferralUrlLoading = ko.observable(true);

        var constPlatformId_Facebook = 1;
        var constPlatformId_Twitter = 2;
        var constPlatformId_Email = 3;
        var constPlatformId_SMS = 4;
        var constPlatformId_Copy = 5;

        self.init = function () {
        }
        self.dispose = function () { };

        // Start appsflyer track event

        var trackViewReferralHistoryTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Landing: View Referral History",
                eventPage: track.PageEnum.ReferralLandingPage
            });
        }


        function trackEvent(eventLabel, eventName, description) {
            track.trackEvent({
                sendType: track.GA + track.MP + track.AF,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.ReferralLandingPage,
                source: app.page().name,
                eventStructure: track.StructureEnum.AfShare,
                eventName: eventName,
                description: description
            });
        }

        var trackRefrralLandingTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Referral Landing Page",
                eventPage: track.PageEnum.ReferralLandingPage
            });
        }

        var trackTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.ReferralLandingPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.ReferralLandingPage
            });
        }

        // End appsflyer track event

        self.afterRender = function () {
            initUniqueURL();
            cs.RemoveOpen();

            trackRefrralLandingTotalLoads();

            trackTimeOnPage();
        };

        function initUniqueURL() {

            cs.BaseAjax({
                url: '/Referral/SelfServiceGetCopyLinkChannelReferralLinkForWeb',
                type: "GET",
                dataType: "json"
            })
            .done(function (data) {
                if (!data) {
                    return;
                }
                self.UniqueURL_Copy(data.Url);
                self.ReferralLinkId_Copy(data.ReferralLinkId);
                self.IsShowReferralUrlLoading(false);
            });
        }

        self.facebookClick = function (element) {
            $(element).addClass("now-loading");

            $.when(shareReferralLink(constPlatformId_Facebook))
            .done(function (data) {
                var content = data.ShareContent;
                self.UniqueURL_Facebook(formatURL(data.Url, content, "facebook"));
                popupwindow(self.UniqueURL_Facebook(), 'Facebook', 600, 400);
                $(element).removeClass("now-loading");

                //Data Capture Referral activity.
                cs.LogReferralActivty(data.Url);
            });

            // Tempory for mobile pop up
            if (cs.IsMobileDevice()) {
                popupwindow("", 'Facebook', 600, 400);
            }

            var trackReferViaFacebookTotalClicks = trackEvent;
            trackReferViaFacebookTotalClicks("Landing: Refer via Facebook", "af_share_initiate_web_FB", "Web-Facebook");
            track.trackTimeOnPageForPageLink("ReferViaFacebook");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        self.twitterClick = function (element) {
            $(element).addClass("now-loading");

            $.when(shareReferralLink(constPlatformId_Twitter))
            .done(function (data) {
                var content = data.ShareContent;
                self.UniqueURL_Twitter(formatURL(data.Url, content, "twitter"));
                popupwindow(self.UniqueURL_Twitter(), 'Twitter', 600, 400);
                $(element).removeClass("now-loading");

                //Data Capture Referral activity.
                cs.LogReferralActivty(data.Url);
            });

            // Tempory for mobile pop up
            if (cs.IsMobileDevice()) {
                popupwindow("", 'Twitter', 600, 400);
            }

            var trackReferViaTwitterTotalClicks = trackEvent;
            trackReferViaTwitterTotalClicks("Landing: Refer via Twitter", "af_share_initiate_web_Twitter", "Web-Twitter");
            track.trackTimeOnPageForPageLink("ReferViaTwitter");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        self.emailClick = function (element) {
            app.redirectTo("/SelfService/ReferralViaEmailConsumer");

            var trackReferViaEmailTotalClicks = trackEvent;
            trackReferViaEmailTotalClicks("Landing: Refer via Email", "af_share_initiate_web_Email", "Web-Email");
            track.trackTimeOnPageForPageLink("ReferViaEmail");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        function shareReferralLink(referralPlatformId) {
            var deferred = $.Deferred();
            cs.BaseAjax({
                url: '/Referral/SelfServiceShareReferralLinkForWeb',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "referralChannelId": referralPlatformId, "contactList": null })
            })
            .done(function (data) {
                deferred.resolve(data);
            });

            return deferred;
        }

        function popupwindow(url, title, w, h) {
            wLeft = window.screenLeft ? window.screenLeft : window.screenX;
            wTop = window.screenTop ? window.screenTop : window.screenY;

            var left = wLeft + (window.innerWidth / 2) - (w / 2);
            var top = wTop + (window.innerHeight / 2) - (h / 2);
            return window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=no, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
        }

        self.goToDashboard = function () {
            app.redirectTo("/SelfService/CustomerDashboard");
        }

        self.copyLink = function () {
            var clipboard = new Clipboard('#copyLink', {
                text: function () {
                    return self.UniqueURL_Copy();
                }
            });

            clipboard.on('success', function (e) {
                $("#copyLink").hide().next(".link-copied").css("display", "inline-block");
                $("#copyLink").prev($('i')).addClass('copied');
                shareReferralLink(constPlatformId_Copy);
            });

            clipboard.on('error', function (e) {
                //document.execCommand("Copy");
                $("#copyLink").hide().next(".link-copied").css("display", "inline-block");
                $("#copyLink").prev($('i')).addClass('copied');
                shareReferralLink(constPlatformId_Copy);
            });

            //Data Capture Referral activity.
            cs.LogReferralActivty(self.UniqueURL_Copy());

            var trackCopyLinkTotalClicks = trackEvent;
            trackCopyLinkTotalClicks("Landing: Copy Link", "af_share_initiate_web_Copy", "Web-CopyLink");
            track.trackTimeOnPageForPageLink("CopyLink");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        self.goToReferralHistory = function () {
            app.redirectTo("/SelfService/ReferralHistoryConsumer");

            trackViewReferralHistoryTotalClicks();
            track.trackTimeOnPageForPageLink("ViewReferralHistory");
        }

        function formatURL(url, content, platform) {
            var newUrl = '';
            if (platform == "twitter") {
                newUrl = url.replace(":", "%3A");
                newUrl = newUrl.replace("/", "%2F");
                newUrl = newUrl.replace("=", "%3D");
                newUrl = newUrl.replace("?", "%3F");
                newUrl = newUrl.replace("&", "%26");

                newUrl = "https://twitter.com/intent/tweet?ref_src=twsrc%5Etfw&url=" + newUrl + "&text=" + content;
            }
            else if (platform == "facebook") {
                newUrl = "http://www.facebook.com/sharer/sharer.php?u=" + url + "&description=" + content + "&picture=" + document.location.origin + "/assets/img/unpackage/sengo-referral-fb-share-graphic.png";
            }

            return newUrl;
        }
    }
    return new ReferralLandingConsumerViewModel();
});