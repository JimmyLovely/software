﻿define(['knockout', 'ClientScript', 'jquery', 'Router', 'app', paths['common-strings'], paths['SettingsConsumer-strings'], 'R', 'TrackEvent'], function (ko, cs, $, Router, app, commonstrings, settingconsumerstrings, R, track) {

    function AppDataModel() {
        var self = this

        self.cities = null;
        self.GetLookUpCities = function (countryId, stateId) {
            return self.GetCitiesByStateId(countryId, stateId);
        };

        self.InitializeDestinationsCountries = function (transactionType, element) {
            if (window.localStorage && window.localStorage.transactionDestinations && window.localStorage.transactionDestinations != "undefined") {
                var transactionDestinations = JSON.parse(window.localStorage.transactionDestinations);
                var result = new Array();
                for (var i = 0; i < transactionDestinations.length; i++) {
                    if (transactionType == transactionDestinations[i].TransactionTypeId) {
                        result.push(transactionDestinations[i]);
                    }
                }

                return $.Deferred().resolve(result);
            } else {
                return cs.AjaxBySpinnerOrLoading(
                       {
                           url: "/MoneyTransfer/SelfServiceInitializeDestinationsCountries",
                           type: "Post",
                           dataType: "json",
                           contentType: "application/json",
                           data: JSON.stringify({ "transactionTypeId": transactionType })
                       }, element);
            }
        }

        self.GetStatesByCountryId = function (countryId) {
            if (window.localStorage && window.localStorage.states && window.localStorage.states != "undefined") {
                var states = JSON.parse(window.localStorage.states);
                var result = new Array();
                for (var i = 0; i < states.length; i++) {
                    if (countryId == states[i].CountryId) {
                        result.push(states[i]);
                    }
                }

                result.sort(function (a, b) {
                    return a.Text == b.Text ? 0 : (a.Text > b.Text ? 1 : -1);
                });

                return $.Deferred().resolve(result);
            } else {
                return cs.BaseAjax({
                    url: "/Customers/GetStatesByCountryId",
                    type: "POST",
                    contentType: "application/json",
                    dataType: "json",
                    data: JSON.stringify({ "countryId": countryId })
                });
            }
        };

        self.GetCountriesByTransactionType = function (transactionType, isLCR) {
            var urlPath, reqData;
            if (window.localStorage) {
                switch (transactionType) {
                    case 11:
                        if (isLCR && window.localStorage.LCRCountries) {
                            return $.Deferred().resolve(JSON.parse(window.localStorage.LCRCountries));
                        } else if (!isLCR && window.localStorage.BPCountries) {
                            return $.Deferred().resolve(JSON.parse(window.localStorage.BPCountries));
                        }

                        reqData = isLCR ? { isLCR: true } : { isLCR: false };
                        urlPath = '/BillPay/InitializeCountries';
                        break;
                    case 12:
                        if (window.localStorage.TUCountries) {
                            return $.Deferred().resolve(JSON.parse(window.localStorage.TUCountries));
                        }

                        urlPath = '/TopUp/SelfServiceGetCarrierInternationalCountry';
                        reqData = {};
                        break;
                }
            }

            return cs.AjaxByDelayLoading({
                url: urlPath,
                type: "Get",
                cache: false,
                dataType: "json",
                data: reqData
            });
        }

        self.GetCitiesByStateId = function (countryId, stateId) {
            if (window.localStorage && window.localStorage.cities && (countryId == 484 || countryId == 840)) {
                var cities = JSON.parse(window.localStorage.cities);
                var result = new Array();
                //C: CountryId, S: StateId, T: Text, V: Value
                for (var i = 0; i < cities.length; i++) {
                    if (countryId == cities[i].C && cities[i].S == stateId) {
                        result.push(cities[i]);
                    }
                }

                result.sort(function (a, b) {
                    return a.T == b.T ? 0 : (a.T > b.T ? 1 : -1);
                });

                var tempCities = $.map(ko.mapping.toJS(result),
                    function (item, index) {
                        return {
                            value: item.T,
                            data: { Text: item.T, StateId: item.S, CountryId: item.C, Value: item.V }
                        };
                    });
                return $.Deferred().resolve(tempCities);
            } else {
                cs.showLoading();
                var deffered = $.Deferred();
                setTimeout(function () {
                    return cs.BaseAjax({
                        url: "/Home/GetCitiesByStateId",
                        type: "POST",
                        contentType: "application/json",
                        dataType: "json",
                        data: JSON.stringify({ "stateId": stateId, "countryId": countryId })
                    })
                        .done(function (result) {
                            var tempCities = $.map(ko.mapping.toJS(result), function (item, index) {
                                return { value: item.value, data: { Value: item.data.Key } };
                            });
                            deffered.resolve(tempCities);
                        })
                        .fail(function () {
                            deffered.reject();
                        })
                        .always(function () {
                            cs.hideLoading();
                        });
                }, 500);

                return deffered;
            }
        };

        self.GetPaymentTypes = function (countryId, currencyId, paymentTypeIds) {
            return cs.BaseAjax({
                url: '/MoneyTransfer/SelfServiceGetPayments',
                type: "POST",
                cache: false,
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                    "countryId": countryId,
                    "currencyId": currencyId,
                    "paymentTypeIds": paymentTypeIds
                })
            });
        };

        self.GetLookUpCitiesByCountryId = function (countryId, element) {
            if (!countryId) {
                return;
            }

            if (false && window.localStorage && window.localStorage.cities) {
                var cities = JSON.parse(window.localStorage.cities);
                var result = new Array();
                if (countryId == 484) {
                    for (var i = 0; i < cities.length; i++) {
                        if (countryId == cities[i].CountryId) {
                            result.push(cities[i]);
                        }
                    }
                }

                result.sort(function (a, b) {
                    return a.Text == b.Text ? 0 : (a.Text > b.Text ? 1 : -1);
                });

                var tempCities = $.map(ko.mapping.toJS(result), function (item, index) { return { value: item.Text, data: item.StateId }; });
                return $.Deferred().resolve(tempCities);
            } else {
                return cs.AjaxBySpinner({
                    url: "/Customers/GetCitiesByCountryId",
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "countryId": countryId })
                }, element)
            }
        };

        self.GetRelationShips = function () {
            return cs.BaseAjax({
                url: "/MoneyTransfer/GetRelationShips",
                type: "POST",
                contentType: "application/json",
                dataType: "json"
            });
        };

        self.TopUpsePinQuickToPayByReceiptNumber = function (receiptNumber, startPositionCode) {
            track.trackNextPage(track.PageEnum.EPin, app);

            app.redirectTo("/SelfService/TopUpsPurchaseConsumer/StartPositionCode/" + startPositionCode + '/' + receiptNumber);
        }

        self.TopUpQuickToPayByReceiptNumber = function (receiptNumber, billerName, startPositionCode) {
            if (billerName.indexOf("PINLESS") == -1) {
                track.trackNextPage(track.PageEnum.Reload, app);

                app.redirectTo("/SelfService/TopUpsReloadConsumer/StartPositionCode/" + startPositionCode + '/' + receiptNumber + '/0');
            } else {
                track.trackNextPage(track.PageEnum.Pinless, app);

                app.redirectTo("/SelfService/TopUpsPinlessConsumer/StartPositionCode/" + startPositionCode + '/' + receiptNumber + '/0');
            }
        };

        self.TopUpQuickToPayWithNoTransaction = function (billingAccountId, billerName, startPositionCode) {
            if (billerName.indexOf("PINLESS") == -1) {
                track.trackNextPage(track.PageEnum.Reload, app);

                app.redirectTo("/SelfService/TopUpsReloadConsumer/StartPositionCode/" + startPositionCode + "/0/" + billingAccountId);
            } else {
                track.trackNextPage(track.PageEnum.Pinless, app);

                app.redirectTo("/SelfService/TopUpsPinlessConsumer/StartPositionCode/" + startPositionCode + "/0/" + billingAccountId);
            }
        };

        self.viewTransactionHistoryByReceiptNumber = function (receiptNumber) {
            track.trackNextPage(track.PageEnum.TransactionHistory, app);

            app.redirectTo('/SelfService/AccountConsumer/' + receiptNumber + '#panel-transaction_refresh');
        }

        self.viewTransactionHistoryWithLimitHoldByReceiptNumber = function (receiptNumber) {
            track.trackNextPage(track.PageEnum.TransactionHistory, app);

            app.redirectTo('/SelfService/AccountConsumer/LimitHold/' + receiptNumber + '#panel-transaction_refresh');
        };

        self.CompareCustomerName = function (isAscending) {
            return function (x, y) {
                if (isAscending) {
                    if (cs.getValue(x.FirstName).toLowerCase() > cs.getValue(y.FirstName).toLowerCase()) {
                        return 1;
                    }
                    else {
                        if (cs.getValue(x.FirstName).toLowerCase() == cs.getValue(y.FirstName).toLowerCase()) {
                            if (cs.getValue(x.LastName).toLowerCase() > cs.getValue(y.LastName).toLowerCase()) {
                                return 1;
                            }
                            else if (cs.getValue(x.LastName).toLowerCase() == cs.getValue(y.LastName).toLowerCase()) {
                                return cs.getValue(x.RppsBillingAccountId) > cs.getValue(y.RppsBillingAccountId) ? 1 : 0;
                            }
                            return -1;
                        }
                        return -1;
                    }
                }
                else {
                    if (cs.getValue(y.FirstName).toLowerCase() > cs.getValue(x.FirstName).toLowerCase()) {
                        return 1;
                    }
                    else {
                        if (cs.getValue(x.FirstName).toLowerCase() == cs.getValue(y.FirstName).toLowerCase()) {
                            if (cs.getValue(y.LastName).toLowerCase() > cs.getValue(x.LastName).toLowerCase()) {
                                return 1;
                            }
                            else if (cs.getValue(x.LastName).toLowerCase() == cs.getValue(y.LastName).toLowerCase()) {
                                return cs.getValue(y.RppsBillingAccountId) > cs.getValue(x.RppsBillingAccountId) ? 1 : 0;
                            }
                            return -1;
                        }
                        return -1;
                    }
                }
            }
        };

        self.QuickToPayByBillingAccount = function (isBillPayLCR, billingAccount, startPositionCode) {
            var billPayPage;
            if (isBillPayLCR == true) {
                var tempBillingAccount = ko.mapping.toJS(billingAccount);
                if (tempBillingAccount.LastReceiptNumber != null && tempBillingAccount.LastReceiptNumber.trim() != "") {
                    billPayPage = "/SelfService/BillPayLCRConsumer/StartPositionCode/" + startPositionCode + '/' + tempBillingAccount.LastReceiptNumber.trim();
                } else {
                    billPayPage = "/SelfService/BillPayLCRConsumer/Number/" + tempBillingAccount.RppsBillingAccountId;
                }
            } else {
                var tempBillingAccount = ko.mapping.toJS(billingAccount);
                if (tempBillingAccount.LastReceiptNumber != null && tempBillingAccount.LastReceiptNumber.trim() != "") {
                    billPayPage = "/SelfService/BillPayConsumer/StartPositionCode/" + startPositionCode + '/' + tempBillingAccount.LastReceiptNumber.trim();
                } else {
                    billPayPage = "/SelfService/BillPayConsumer/" + tempBillingAccount.RppsBillingAccountId + "/" + tempBillingAccount.AccountType;
                }
            }
            if (app.senderInfo() && app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                app.goToPersonalInfo(billPayPage, cs.getShortUrlPath());
            } else {
                track.trackNextPage(track.PageEnum.PayBills, app);
                app.redirectTo(billPayPage);
            }
        };

        self.QuickToPayByReceiver = function (receiver, startPositionCode) {
            var moneyTransferPage;

            var tempReceiver = ko.mapping.toJS(receiver);
            if (tempReceiver.LastReceiptNumber != null && tempReceiver.LastReceiptNumber.trim() != "") {
                moneyTransferPage = "/SelfService/MoneyTransferConsumer/StartPositionCode/" + startPositionCode + '/' + tempReceiver.LastReceiptNumber.trim();
            } else {
                moneyTransferPage = "/SelfService/MoneyTransferConsumer/Number/" + receiver.CardHolderId;
            }

            if (app.senderInfo() && app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                self.goToPersonalInfo(moneyTransferPage, cs.getShortUrlPath());
            } else {
                track.trackNextPage(track.PageEnum.SendMoney, app);
                app.redirectTo(moneyTransferPage);
            }
        };

        self.QuickToPayByCarrier = function (carrier, startPositionCode) {
            var tempCarrier = ko.mapping.toJS(carrier);
            if (tempCarrier.LastReceiptNumber != null && tempCarrier.LastReceiptNumber.trim() != "") {
                self.TopUpQuickToPayByReceiptNumber(tempCarrier.LastReceiptNumber.trim(), tempCarrier.BillerName, startPositionCode);
            } else {
                self.TopUpQuickToPayWithNoTransaction(tempCarrier.RppsBillingAccountId, tempCarrier.BillerName, startPositionCode);
            }
        };

        self.goToMoneyTransferByReceiptNumber = function (receiptNumber, startPositionCode) {
            track.trackNextPage(track.PageEnum.SendMoney, app);

            app.redirectTo("/SelfService/MoneyTransferConsumer/StartPositionCode/" + startPositionCode + '/' + receiptNumber);
        }

        self.goToBillPayByReceiptNumber = function (receiptNumber, startPositionCode) {
            if (app.senderInfo().Customer().HasLCRBillPay()) {
                track.trackNextPage(track.PageEnum.PayBills, app);

                app.redirectTo("/SelfService/BillPayLCRConsumer/StartPositionCode/" + startPositionCode + '/' + receiptNumber);
            } else if (app.senderInfo().Customer().HasBillPay()) {
                track.trackNextPage(track.PageEnum.PayBills, app);

                app.redirectTo("/SelfService/BillPayConsumer/StartPositionCode/" + startPositionCode + '/' + receiptNumber);
            }
        }

        self.GetSelectedTransaction = function (transactionTypeId, receiptNumber, accountName, startPositionCode) {
            if (transactionTypeId == 2 || transactionTypeId == 5 || transactionTypeId == 11) {
                self.goToBillPayByReceiptNumber(receiptNumber, startPositionCode);
            } else if (transactionTypeId == 1 || transactionTypeId == 14) {
                self.goToMoneyTransferByReceiptNumber(receiptNumber, startPositionCode);
                return;
            } else if (transactionTypeId == 13) { // Top ePin
                self.TopUpsePinQuickToPayByReceiptNumber(receiptNumber, startPositionCode);
            } else if (transactionTypeId == 12) { // Top Up
                self.TopUpQuickToPayByReceiptNumber(receiptNumber, accountName, startPositionCode);
            }
        }

        self.SelfServiceSendTransactionReceiptEmail = function (receiptNumber, element) {
            cs.AjaxBySpinner({
                url: '/Customers/SelfServiceSendTransactionReceiptEmail',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "receiptNumber": receiptNumber })
            }, element)
            .done(function () {
                cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.appdatamodeljsmessagebox.transactionemailsuccess);
            })
            .fail(function (xhr, status) {
                cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.appdatamodeljsmessagebox.emailtransactionemailfailed);
            })
        }

        // For cash pickups
        function GetPaymentTypeFromCache(countryId, currencyId) {
            try {
                if (sessionStorage && sessionStorage.CachePaymentTypes) {
                    var paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypes);
                    if (paymentTypesCache) {
                        for (var i = 0; i < paymentTypesCache.length; i++) {
                            if (paymentTypesCache[i].CountryId == countryId && paymentTypesCache[i].CurrencyId == currencyId) {
                                if (paymentTypesCache[i].PaymentTypes.length == 0) {
                                    return null;
                                }
                                return paymentTypesCache[i].PaymentTypes;
                            }
                        }
                    }
                }
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypes');
            }

            return null;
        };

        function GetPaymentTypesByCityFromCache(countryId, currencyId, stateId, city) {
            try {
                if (sessionStorage && sessionStorage.CachePaymentTypesByCity) {
                    var paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypesByCity);
                    if (paymentTypesCache) {
                        for (var i = 0; i < paymentTypesCache.length; i++) {
                            if (paymentTypesCache[i].CountryId == countryId && paymentTypesCache[i].CurrencyId == currencyId && paymentTypesCache[i].StateId == stateId && paymentTypesCache[i].City == city) {
                                if (paymentTypesCache[i].PaymentTypes.length == 0) {
                                    return null;
                                }
                                return paymentTypesCache[i].PaymentTypes;
                            }
                        }
                    }
                }
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypesByCity');
            }

            return null;
        };

        function addPaymentTypesToCache(countryId, currencyId, paymentTypes) {
            try {
                var paymentTypesCache;
                if (!sessionStorage) {
                    return;
                }

                if (sessionStorage && sessionStorage.CachePaymentTypes) {
                    paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypes);
                } else {
                    paymentTypesCache = new Array();
                }

                paymentTypesCache.push({
                    CountryId: countryId,
                    CurrencyId: currencyId,
                    PaymentTypes: paymentTypes
                });

                cs.SetSessionStorage('CachePaymentTypes', JSON.stringify(paymentTypesCache));
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypes');
            }
        }

        function addPaymentTypesByCityToCache(countryId, currencyId, stateId, city, paymentTypes) {
            try {
                var paymentTypesCache;
                if (!sessionStorage) {
                    return;
                }

                if (sessionStorage && sessionStorage.CachePaymentTypesByCity) {
                    paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypesByCity);
                } else {
                    paymentTypesCache = new Array();
                }

                paymentTypesCache.push({
                    CountryId: countryId,
                    CurrencyId: currencyId,
                    StateId: stateId,
                    City: city,
                    PaymentTypes: paymentTypes
                });

                cs.SetSessionStorage('CachePaymentTypesByCity', JSON.stringify(paymentTypesCache));
            } catch (e) {
                sessionStorage.removeItem('CachePaymentTypesByCity');
            }
        }

        self.LoadPayments = function (countryId, currencyId) {
            var cachePaymentType = GetPaymentTypeFromCache(countryId, currencyId);
            if (cachePaymentType) {
                if (!(cachePaymentType && cachePaymentType.length > 0)) {
                    $('#correspondents-note').show();
                }
                return $.Deferred().resolve(cachePaymentType);
            }

            var deferred = $.Deferred();
            var paymentTypeIds = [cs.PaymentType.Cash, cs.PaymentType.CashToAgent, cs.PaymentType.CashToBranch];
            cs.AjaxBySpinner({
                url: '/MoneyTransfer/SelfServiceGetPayments',
                type: "POST",
                cache: false,
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                    "countryId": countryId,
                    "currencyId": currencyId,
                    "paymentTypeIds": paymentTypeIds
                })
            })
            .done(function (result) {
                var tempPaymentTypes = new Array();

                tempPaymentTypes = result.sort(function (a, b) {
                    return cs.sortByString(a.Correspondent, b.Correspondent, true)
                });
                var paymentTypes = ko.mapping.toJS(tempPaymentTypes);
                addPaymentTypesToCache(countryId, currencyId, paymentTypes);
                if (!(paymentTypes && paymentTypes.length > 0)) {
                    $('#correspondents-note').show();
                }
                deferred.resolve(paymentTypes);
            })
            .fail(function () {
                $('#correspondents-note').show();
            });

            return deferred;
        }

        self.GetPaymentsByCity = function (countryId, stateId, cityId, cityName, currencyId) {
            var cachePaymentType = GetPaymentTypesByCityFromCache(countryId, currencyId, stateId, cityName);
            if (cachePaymentType) {
                if (!(cachePaymentType && cachePaymentType.length > 0)) {
                    $('#correspondents-note').show();
                }
                return $.Deferred().resolve(cachePaymentType);
            }
            var deferred = $.Deferred();
            var paymentTypeIdArray = [cs.PaymentType.Cash, cs.PaymentType.CashToAgent, cs.PaymentType.CashToBranch];
            cs.AjaxBySpinner({
                url: "/MoneyTransfer/GetSelfServicePaymentDestinationsByCity",
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({
                    "countryId": countryId,
                    "paymentTypeId": -1,
                    "currency": -1,
                    "state": stateId,
                    "city": cityId,
                    "cityName": cityName,
                    "currencyId": currencyId,
                    "paymentTypeIds": paymentTypeIdArray
                })
            })
            .done(function (result) {
                var tempPaymentTypes = new Array();

                tempPaymentTypes = result.sort(function (a, b) {
                    return cs.sortByString(a.Correspondent, b.Correspondent, true)
                });
                var paymentTypes = ko.mapping.toJS(tempPaymentTypes);
                addPaymentTypesByCityToCache(countryId, currencyId, stateId, cityName, paymentTypes);
                if (!(paymentTypes && paymentTypes.length > 0)) {
                    $('#correspondents-note').show();
                }
                deferred.resolve(paymentTypes);
            })
                .fail(function () {
                    $('#correspondents-note').show();
                });

            return deferred;
        }

        self.deleteAddedCashPickUps = function (cashPickUps, addedCashPickUps) {
            if (!addedCashPickUps || addedCashPickUps.length == 0) {
                return cashPickUps;
            }

            var tempCashPickUps = new Array();
            $.each(cashPickUps, function (index, p) {
                if (p.PaymentTypeId == 6 || addedCashPickUps.indexOf(p.Payouts[0]) == -1) {
                    tempCashPickUps.push(p);
                }
            });

            return tempCashPickUps;
        };


        function getPickUpLocationCitiesFromCache(countryId) {
            try {
                if (sessionStorage && sessionStorage.CachePickUpLocationCities) {
                    var Cities = JSON.parse(sessionStorage.CachePickUpLocationCities);
                    if (Cities) {
                        for (var i = 0; i < Cities.length; i++) {
                            if (Cities[i].CountryId == countryId) {
                                return Cities[i].Cities;
                            }
                        }
                    }
                }
            } catch (e) {
                sessionStorage.removeItem('CachePickUpLocationCities');
            }

            return null;
        };

        function addPickUpLocationCitiesToCache(countryId, cities) {
            try {
                if (!sessionStorage) {
                    return;
                }

                var citiesCache;
                if (sessionStorage && sessionStorage.CachePickUpLocationCities) {
                    citiesCache = JSON.parse(sessionStorage.CachePickUpLocationCities);
                } else {
                    citiesCache = new Array();
                }

                citiesCache.push({
                    CountryId: countryId,
                    Cities: cities
                });

                cs.SetSessionStorage('CachePickUpLocationCities', JSON.stringify(citiesCache));
            } catch (e) {
                sessionStorage.removeItem('CachePickUpLocationCities');
            }
        }

        self.GetPickUpLocationCities = function (countryId, element) {
            var cities = getPickUpLocationCitiesFromCache(countryId, element);
            if (cities) {
                return $.Deferred().resolve(cities);
            }

            return $.when(self.GetLookUpCitiesByCountryId(countryId, element))
            .done(function (cities) {
                addPickUpLocationCitiesToCache(countryId, cities);
            });
        }

        self.GetPaymentTypeLocationsByCityId = function (countryId, stateId, cityName, correspondentId) {
            return cs.BaseAjax(
            {
                url: '/MoneyTransfer/GetLocationsByCity',
                type: "Post",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": countryId, "stateId": stateId, "cityName": cityName, "correspondentId": correspondentId, "transactionTypeId": 14 })
            })
        };

        self.AddDeliveryOption = function (cardHolderId, tempDestination, element) {
            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/AddRecipientDeliveryOption',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "receiverCardHolderId": cardHolderId, "recipientDestinationModel": tempDestination, "amountToLoad": 10 })
            }, element)
        }

        self.GetAddressAutocompleteDetails = function (suggestionAddress) {
            var deferred = $.Deferred();
            var street = suggestionAddress.data.StreetName;
            var city = suggestionAddress.data.City;
            var state = suggestionAddress.data.State;

            cs.AjaxByDelayLoading({
                url: "/Home/SelfServiceGetAddressDetails",
                type: "Get",
                cache: false,
                contentType: "application/json",
                data: {
                    "street": street,
                    "street2": "",
                    "city": city,
                    "state": state,
                    "zipcode": ""
                },
            })
            .done(function (streetAddressResult) {
                deferred.resolve(streetAddressResult);
            })

            return deferred;
        }

        self.GetAddressDetails = function (smartStreetIds, element, address, isOpenPrevious) {
            var deferred = $.Deferred();
            var selectCityId = smartStreetIds.SelectCityId;
            var selectStateId = smartStreetIds.SelectStateId;
            var street = smartStreetIds.Address01Id;
            var secondStreet = smartStreetIds.Address02Id;
            var zipcodeId = smartStreetIds.ZipcodeId;
            var selectState;
            if ($(selectStateId)[0].tagName == "INPUT") {
                selectState = $(selectStateId).val();
            } else {
                selectState = $(selectStateId).find("option:selected").text();
            }
            var selectCity = $(selectCityId).val();
            cs.AjaxBySpinner({
                url: "/Home/SelfServiceGetAddressDetails",
                type: "Get",
                cache: false,
                contentType: "application/json",
                data: {
                    "street": $(street).val(),
                    "street2": $(secondStreet).val(),
                    "city": selectCity,
                    "state": selectState,
                    "zipcode": $(zipcodeId).val()
                },
            }, element)
            .done(function (result) {
                if (result && result.ResultAddress && result.ResultAddress.Analysis.DpvMatchCode != null && result.ResultAddress.Analysis.DpvMatchCode != 'N') {
                    var address = result.ResultAddress;
                    var dpvMatchCode = address.Analysis.DpvMatchCode;
                    var zipType = address.Metadata.ZipType;

                    if (dpvMatchCode == 'D') {
                        cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.address.validations.apartmentmessage, function () {
                            $.when(cs.closeModal(isOpenPrevious))
                            .done(function () {
                                deferred.reject();
                                setTimeout(function () {
                                    $(secondStreet).focus();
                                }, 300);
                            });
                        });
                    } else if (zipType != 'Standard') {
                        cs.showErrorMessage(commonstrings.appdatamodeljsmessagebox.mailmessage, commonstrings.address.validations.zipcodeerror, function () {
                            $.when(cs.closeModal(isOpenPrevious))
                            .done(function () {
                                deferred.reject();
                                setTimeout(function () {
                                    $(zipcodeId).focus();
                                }, 300);
                            });
                        });
                    }
                    else {
                        deferred.resolve();
                    }

                } else {
                    var lastLine = String.format('{0} {1} {2}', selectCity, cs.getStateOrAbbreviation(selectState, true), $(zipcodeId).val());
                    var message = cs.getAutoCompleteAddressInvalidMessage($(street).val(), $(secondStreet).val(), lastLine);
                    cs.ShowCustomMessage(function () {
                        deferred.resolve();
                    }, function () {
                        deferred.reject();
                        setTimeout(function () {
                            $(street).focus();
                        }, 300);
                    }, message);
                }

                cs.AddActivityInfo(22, null, false);
            });

            return deferred;
        }



        self.MoneyTransferCalculate = function (transaction, isSend, value) {
            var amount = "-1";
            transaction().DominantControl = isSend ? 'AmountToBeSent' : 'AmountToBeReceived';
            amount = value;
            if (amount == null) {
                amount = "-1";
            }

            if (amount && parseFloat(cs.GetOriginalNumber(amount.toString())) > 0) {
                amount = parseFloat(cs.GetOriginalNumber(amount.toString()));
                if (transaction().DominantControl == "AmountToBeSent") {
                    //transaction().AmountToSend.Value(amount);
                    var result = 1.0 * amount * transaction().Rate;
                    if (!isNaN(result)) {
                        var amountToBeDispensed = cs.keepAmountDecimalPlaces(result);
                        transaction().AmountToBeDispensed.Value(amountToBeDispensed);

                        if ($("#input-amount-to-be-dispensed") && $("#input-amount-to-be-dispensed").length > 0) {
                            cs.fitTextAmountField($("#input-amount-to-be-dispensed"), amountToBeDispensed);
                        }
                        if ($("#receiver-amount-input") && $("#receiver-amount-input").length > 0) {
                            cs.fitTextAmountField($("#receiver-amount-input"), amountToBeDispensed);
                        }
                    }
                } else {
                    //transaction().AmountToBeDispensed.Value(amount);
                    var result = 1.0 * amount / transaction().Rate;
                    if (!isNaN(result)) {
                        var sendToAmount = cs.keepAmountDecimalPlaces(result);
                        transaction().AmountToSend.Value(sendToAmount);
                        if ($("#input-amount-to-send") && $("#input-amount-to-send").length > 0) {
                            cs.fitTextAmountField($("#input-amount-to-send"), sendToAmount);
                        }
                        if ($("#send-amount-input") && $("#send-amount-input").length > 0) {
                            cs.fitTextAmountField($("#send-amount-input"), sendToAmount);
                        }
                    }
                }
            } else {
                if (value == "" || value == null || value == '0.00') {
                    //transaction().AmountToBeDispensed.Value(null);
                    //transaction().AmountToSend.Value();
                    if (cs.IsMobileDevice()) {
                        $("#input-amount-to-be-dispensed").val("0.00");
                        $("#receiver-amount-input").val("0.00");

                        $("#input-amount-to-send").val("0.00");
                        $("#send-amount-input").val("0.00");
                    } else {
                        $("#input-amount-to-be-dispensed").val("");
                        $("#receiver-amount-input").val("");

                        $("#input-amount-to-send").val("");
                        $("#send-amount-input").val("");
                    }
                }
            }
        };

        self.CashPickUp = function () {
            function getPaymentTypeFromCache(countryId, currencyId) {
                try {
                    if (sessionStorage && sessionStorage.CachePaymentTypes) {
                        var paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypes);
                        if (paymentTypesCache) {
                            for (var i = 0; i < paymentTypesCache.length; i++) {
                                if (paymentTypesCache[i].CountryId == countryId && paymentTypesCache[i].CurrencyId == currencyId) {
                                    if (paymentTypesCache[i].PaymentTypes.length == 0) {
                                        return null;
                                    }
                                    return paymentTypesCache[i].PaymentTypes;
                                }
                            }
                        }
                    }
                } catch (e) {
                    sessionStorage.removeItem('CachePaymentTypes');
                }

                return null;
            };

            function getPaymentTypesByCityFromCache(countryId, currencyId, city) {
                try {
                    if (sessionStorage && sessionStorage.CachePaymentTypesByCity) {
                        var paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypesByCity);
                        if (paymentTypesCache) {
                            for (var i = 0; i < paymentTypesCache.length; i++) {
                                if (paymentTypesCache[i].CountryId == countryId && paymentTypesCache[i].CurrencyId == currencyId && paymentTypesCache[i].City == city) {
                                    if (paymentTypesCache[i].PaymentTypes.length == 0) {
                                        return null;
                                    }
                                    return paymentTypesCache[i].PaymentTypes;
                                }
                            }
                        }
                    }
                } catch (e) {
                    sessionStorage.removeItem('CachePaymentTypesByCity');
                }

                return null;
            };

            function addPaymentTypesToCache(countryId, currencyId, paymentTypes) {
                try {
                    var paymentTypesCache;
                    if (!sessionStorage) {
                        return;
                    }

                    if (sessionStorage && sessionStorage.CachePaymentTypes) {
                        paymentTypesCache = JSON.parse(sessionStorage.CachePaymentTypes);
                    } else {
                        paymentTypesCache = new Array();
                    }

                    paymentTypesCache.push({
                        CountryId: countryId,
                        CurrencyId: currencyId,
                        PaymentTypes: paymentTypes
                    });

                    cs.SetSessionStorage('CachePaymentTypes', JSON.stringify(paymentTypesCache));
                } catch (e) {
                    sessionStorage.removeItem('CachePaymentTypes');
                }
            }

            function loadPayments(countryId, currencyId, addedCashPickUps) {
                var cachePaymentType = getPaymentTypeFromCache(countryId, currencyId);
                if (cachePaymentType) {
                    cachePaymentType = self.deleteAddedCashPickUps(cachePaymentType, addedCashPickUps);
                    return $.Deferred().resolve(cachePaymentType);

                }
                var deferred = $.Deferred();
                var paymentTypeIds = [cs.PaymentType.Cash, cs.PaymentType.CashToAgent, cs.PaymentType.CashToBranch];
                cs.BaseAjax({
                    url: '/MoneyTransfer/SelfServiceGetPayments',
                    type: "POST",
                    cache: false,
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                        "countryId": countryId,
                        "currencyId": currencyId,
                        "paymentTypeIds": paymentTypeIds
                    })
                })
                .done(function (result) {
                    var tempPaymentTypes = new Array();

                    tempPaymentTypes = result.sort(function (a, b) {
                        return cs.sortByString(a.Correspondent, b.Correspondent, true)
                    });
                    addPaymentTypesToCache(countryId, currencyId, tempPaymentTypes);
                    tempPaymentTypes = self.deleteAddedCashPickUps(tempPaymentTypes, addedCashPickUps);
                    deferred.resolve(tempPaymentTypes);
                })
                .fail(deferred.reject);

                return deferred;
            }

            function getPaymentsByCity(countryId, currencyId, stateId, cityId, cityName, addedCashPickUps) {
                if (cityName == null) {
                    cityName = "";
                }
                var cachePaymentType = getPaymentTypesByCityFromCache(countryId, currencyId, cityName);
                if (cachePaymentType) {
                    cachePaymentType = self.deleteAddedCashPickUps(cachePaymentType, addedCashPickUps);
                    return $.Deferred().resolve(cachePaymentType);

                }

                if (!countryId || !stateId || !cityId) {
                    return $.Deferred().resolve([]);
                }
                var deferred = $.Deferred();
                var paymentTypeIds = [cs.PaymentType.Cash, cs.PaymentType.CashToAgent, cs.PaymentType.CashToBranch];
                cs.BaseAjax({
                    url: "/MoneyTransfer/GetSelfServicePaymentDestinationsByCity",
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({
                        "countryId": countryId,
                        "paymentTypeId": -1,
                        "currency": -1,
                        "state": stateId,
                        "city": cityId,
                        "cityName": cityName,
                        "currencyId": currencyId,
                        "paymentTypeIds": paymentTypeIds
                    })
                }, true)
                .done(function (result) {
                    var tempPaymentTypes = new Array();

                    tempPaymentTypes = result.sort(function (a, b) {
                        return cs.sortByString(a.Correspondent, b.Correspondent, true)
                    });
                    addPaymentTypesByCityToCache(countryId, currencyId, stateId, cityName, tempPaymentTypes);
                    tempPaymentTypes = self.deleteAddedCashPickUps(tempPaymentTypes, addedCashPickUps);
                    deferred.resolve(tempPaymentTypes);
                })
                .fail(deferred.reject);

                return deferred;
            }

            this.getPayments = function (isSearchOutsideLocationCities, countryId, currencyId, stateId, cityId, cityName, addedCashPickUps) {
                return isSearchOutsideLocationCities ? loadPayments(countryId, currencyId, addedCashPickUps) :
                    getPaymentsByCity(countryId, currencyId, stateId, cityId, cityName, addedCashPickUps);
            }


            //get payment type by city
            function getPickUpLocationCitiesFromCache(countryId) {
                try {
                    if (sessionStorage && sessionStorage.CachePickUpLocationCities) {
                        var Cities = JSON.parse(sessionStorage.CachePickUpLocationCities);
                        if (Cities) {
                            for (var i = 0; i < Cities.length; i++) {
                                if (Cities[i].CountryId == countryId) {
                                    return Cities[i].Cities;
                                }
                            }
                        }
                    }
                } catch (e) {
                    sessionStorage.removeItem('CachePickUpLocationCities');
                }

                return null;
            };

            function addPickUpLocationCitiesToCache(countryId, cities) {
                try {
                    if (!sessionStorage) {
                        return;
                    }

                    var citiesCache;
                    if (sessionStorage && sessionStorage.CachePickUpLocationCities) {
                        citiesCache = JSON.parse(sessionStorage.CachePickUpLocationCities);
                    } else {
                        citiesCache = new Array();
                    }

                    citiesCache.push({
                        CountryId: countryId,
                        Cities: cities
                    });

                    cs.SetSessionStorage('CachePickUpLocationCities', JSON.stringify(citiesCache));
                } catch (e) {
                    sessionStorage.removeItem('CachePickUpLocationCities');
                }
            }

            this.getCities = function (countryId, element) {
                var cities = getPickUpLocationCitiesFromCache(countryId, element);
                if (cities) {
                    return $.Deferred().resolve(cities);
                }

                return $.when(self.GetLookUpCitiesByCountryId(countryId, element))
                .done(function (cities) {
                    addPickUpLocationCitiesToCache(countryId, cities);
                });
            }

            this.getLocations = function (countryId, stateId, cityName, paymentType) {
                if (!cityName) {
                    return $.Deferred().reject([]);
                }
                return cs.BaseAjax(
                {
                    url: '/MoneyTransfer/GetLocationsByCity',
                    type: "Post",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "countryId": countryId, "stateId": stateId, "cityName": cityName, "correspondentId": paymentType.Payouts()[0], "transactionTypeId": 14 })
                })
            };
        }

        self.GetStateId = function (abbreviationState, states) {
            var stateId = '';
            if (states && states.length > 0) {
                for (var i = 0; i < states.length; i++) {
                    if (cs.getValue(states[i].Code) == abbreviationState) {
                        stateId = cs.getValue(states[i].Value);
                        break;
                    }
                }
            }

            return stateId;
        }

        self.GetStateWithAbbreviation = function (abbreviationState, states) {
            var state = '';
            if (states && states.length > 0) {
                for (var i = 0; i < states.length; i++) {
                    if (cs.getValue(states[i].Code) == abbreviationState) {
                        state = cs.getValue(states[i].Text);
                        break;
                    }
                }
            }

            return state;
        }

        self.GetCity = function (cityName, cities) {
            var city = null;
            if (cities && cities.length > 0) {
                for (var i = 0; i < cities.length; i++) {
                    if (cs.getValue(cities[i].value) == cityName) {
                        city = cities[i];
                    }
                }
            }

            return city;
        }

        self.GetAutoCompleteSuggestionAddresses = function (streetName) {
            var deferred = $.Deferred();
            cs.AjaxBySpinner({
                url: "/Home/GetSuggestionAddressParameters",
                type: "Get",
                cache: false,
                contentType: "application/json",
                data: {
                    "streetName": streetName
                }
            }, null, false)
            .done(function (parameters) {
                if (parameters) {
                    cs.AjaxBySpinner({
                        url: parameters.HostUrl,
                        type: "Get",
                        cache: false,
                        contentType: "jsonp",
                        data: {
                            "auth-id": parameters.AuthId,
                            "auth-token": parameters.AuthToken,
                            "prefix": streetName,
                            "suggestions": parameters.SuggestionCount,
                            "geolocate": "true",
                            "geolocate_precision": parameters.GeolocatePrecision
                        }
                    }, null, true)
                   .done(function (result) {
                       var suggestions = new Array();
                       if (result.suggestions) {
                           for (var i = 0; i < result.suggestions.length; i++) {
                               suggestions.push({
                                   value: result.suggestions[i].text,
                                   data: {
                                       StreetName: result.suggestions[i].street_line,
                                       City: result.suggestions[i].city,
                                       State: result.suggestions[i].state
                                   }
                               });
                           }
                       }

                       deferred.resolve(suggestions);
                   })
                  .fail(function (xhr, status) {
                      /*For DataCapture*/
                      cs.LogInformationOfAddressSearch(streetName, true /*true stand for other issue*/, xhr.statusText);
                  });
                }
            })
            .fail(function (xhr, status) {
                /*For DataCapture*/
                cs.LogInformationOfAddressSearch(streetName, true /*true stand for other issue*/, xhr.statusText);
            });;

            return deferred;
        }

        self.cancelPersonalInfo = function () {
            try {
                var previousPage = sessionStorage.getItem("personalInfoPerviousPage");
            } catch (e) { }

            if (previousPage) {
                app.redirectTo(previousPage);
            }
        }

        self.refreshPersonalInfo = function (personalInfo, errorState, isWeb) {
            try {
                var nextPage = sessionStorage.getItem("personalInfoNextPage");
            } catch (e) { }

            refreshPersonalInfoWithPermission(personalInfo, nextPage, errorState, isWeb);
        }

        self.goToPersonalInfo = function (nextPage, previousPage) {
            try {
                sessionStorage.setItem("personalInfoPerviousPage", previousPage);
                sessionStorage.setItem("personalInfoNextPage", nextPage);
            } catch (e) {
                console.log("The device can't support sessionStorage!");
            }

            self.cancelPersonalInfo = function () {
                app.redirectTo(previousPage);
            }
            self.refreshPersonalInfo = function (personalInfo, errorState, isWeb) {
                refreshPersonalInfoWithPermission(personalInfo, nextPage, errorState, isWeb);
            };

            openPersonalInfo();
        }

        function refreshPersonalInfoWithPermission(personalInfo, nextPage, errorState, isWeb) {
            if (isWeb) {
                checkPermission(personalInfo, nextPage, errorState, isWeb);
            } else {
                refreshPersonalInfo(personalInfo, nextPage);
            }
        }

        function checkPermission(personalInfo, nextPage, errorState, isWeb) {
            var errorMessage = '';
            var emptySpace = " ";

            if (isCheckPermisionPage(nextPage) && !personalInfo.hasPermission) {
                errorMessage = settingconsumerstrings.message.obtaininglicensetosendmoney + emptySpace + errorState + emptySpace + settingconsumerstrings.message.profileaddressnotifyonceacquired;
            }
            else {
                return refreshPersonalInfo(personalInfo, nextPage);
            }

            cs.showErrorMessage(settingconsumerstrings.message.messagetitle, errorMessage, function () {
                $.when(cs.closeModal(false))
                .done(function () {
                    refreshPersonalInfo(personalInfo, nextPage);
                });
            });
        }

        function isCheckPermisionPage(nextPage) {
            return nextPage.match(/MoneyTransfer|BillPay|TopUps|UpgradeLevel/i);
        }

        function getPersonalInfoModel() {
            var deferred = $.Deferred();
            var customerBasic = ko.toJS(app.senderInfo().Customer().CustomerBasic);
            var nPage = "";

            var nextTransactionPage = "";
            try {
                nextTransactionPage = sessionStorage.getItem("personalInfoNextPage");
                nPage = nextTransactionPage.indexOf("MoneyTransfer") != -1 ? "MoneyTransfer" : (nextTransactionPage.indexOf("BillPay") != -1 ? "BillPay" : "TopUp");
            } catch (e) { }

            var personalInfo = {
                FirstName: customerBasic.FirstName || "",
                MiddleName: customerBasic.MiddleName || "",
                LastName: customerBasic.LastName || "",
                DateOfBirth: customerBasic.DateOfBirth || "",
                SenderMaxAge: app.configurations().senderMaxAge,
                CurrentDate: app.configurations().currentDate || "",
                Address: customerBasic.Address || "",
                Address2: customerBasic.Address2 || "",
                States: [],
                StateId: customerBasic.StateId,
                CityId: customerBasic.CityId,
                CityName: customerBasic.City,
                Zipcode: customerBasic.Zipcode || "",
                IsShowDateOfBirth: customerBasic.IsShowDateOfBirth,
                IsShowAddressInformation: customerBasic.IsShowAddressInformation,
                IsShowNameInformation: customerBasic.IsShowNameInformation,
                MemberInfoId: app.senderInfo().SenderLevel().SenderLevelId,
                MemberStatus: customerBasic.CardHolderStatusCode,
                NextPage: nPage
            }

            $.when(self.GetStatesByCountryId(840))
            .done(function (data) {
                personalInfo.States = data.map(function (item) {
                    return {
                        StateName: item.Text,
                        StateId: item.Value,
                        Abbr: item.Code
                    };
                });

                deferred.resolve(personalInfo);
            })
            .fail(function () {
                deferred.resolve(personalInfo);
            });
            return deferred;
        }

        function openPersonalInfo() {
            $.when(getPersonalInfoModel())
            .done(function (data) {
                track.trackNextPage(track.PageEnum.PersonalInformation, app);

                try {
                    Android.openPersonalInfo(JSON.stringify(data));
                    return;
                } catch (e) {
                    // error
                }

                try {
                    webkit.messageHandlers.openPersonalInfo.postMessage(data);
                    return;
                } catch (e) {
                    // error
                }

                app.redirectTo("/SelfService/PersonalInfoConsumer");
            });
        }

        function refreshPersonalInfo(personalInfo, nextPage) {
            if (app.senderInfo().Customer().CustomerBasic.IsShowAddressInformation()) {
                app.senderInfo().GetSenderLevel(null);
            }

            var customerBasic = ko.toJS(app.senderInfo().Customer().CustomerBasic);

            customerBasic.FirstName = personalInfo.FirstName;
            customerBasic.MiddleName = personalInfo.MiddleName;
            customerBasic.LastName = personalInfo.LastName;
            if (personalInfo.MiddleName != "") {
                customerBasic.DisplayName = personalInfo.FirstName + " " + personalInfo.MiddleName + " " + personalInfo.LastName;
            } else {
                customerBasic.DisplayName = personalInfo.FirstName + " " + personalInfo.LastName;
            }
            customerBasic.DisplayName = customerBasic.DisplayName.toLowerCase().replace(/\b([\w|']+)\b/g, function (word) {
                return word.replace(word.charAt(0), word.charAt(0).toUpperCase());
            });
            customerBasic.Address = personalInfo.Address;
            customerBasic.Address2 = personalInfo.Address2;
            customerBasic.StateId = personalInfo.StateId;
            customerBasic.CityId = personalInfo.CityId;
            customerBasic.City = personalInfo.CityName;
            customerBasic.Zipcode = personalInfo.Zipcode;
            customerBasic.DateOfBirth = personalInfo.DateOfBirth == '01/01/1753' ? '' : personalInfo.DateOfBirth;

            ko.mapping.fromJS(customerBasic, {}, app.senderInfo().Customer().CustomerBasic);
            self.updateSenderInfoPermission(personalInfo);

            cs.CacheMoneyTransferPermission(app.senderInfo().HasMoneyTransferPermission());

            app.senderInfo().Customer().CustomerBasic.IsShowDateOfBirth(false);
            app.senderInfo().Customer().CustomerBasic.IsShowAddressInformation(false);
            app.senderInfo().Customer().CustomerBasic.IsShowNameInformation(false);

            if (nextPage) {
                if (nextPage.indexOf("MoneyTransferConsumer") != -1) {
                    if (personalInfo.hasPermission) {
                        app.redirectTo(nextPage);
                    }
                    else {
                        app.redirectTo("/SelfService/CustomerDashboard");
                    }
                }
                else if (nextPage.indexOf("BillPayLCRConsumer") != -1 || nextPage.indexOf("BillPayConsumer") != -1) {
                    if (app.senderInfo().Customer().HasLCRBillPay()) {
                        app.redirectTo("/SelfService/BillPayLCRConsumer/StartPositionCode/FromDashBoard");
                    }
                    else if (app.senderInfo().Customer().HasBillPay()) {
                        app.redirectTo("/SelfService/BillPayConsumer/StartPositionCode/FromDashBoard");
                    }
                    else {
                        app.redirectTo("/SelfService/CustomerDashboard");
                    }
                }
                else if (nextPage.indexOf("UpgradeLevelConsumer") != -1) {
                    if (personalInfo.hasPermission) {
                        app.redirectTo(nextPage);
                    } else {
                        app.redirectTo("/SelfService/CustomerDashboard");
                    }
                }
                else {
                    app.redirectTo(nextPage);
                }
            }
        }

        self.checkStatePermision = function () {
            //prevent visit without permission
            if (!(sessionStorage.getItem("HasMoneyTransferPermission") == "true") && app.page().name != "Error" && app.page().name != "CustomerDashboard") {
                app.redirectTo("/SelfService/CustomerDashboard");
                return;
            }
        }

        self.checkPersonInfo = function (module) {
            if (app.senderInfo() && app.senderInfo().Customer() && app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                var nextPage;
                switch (app.page().name) {
                    case "MoneyTransferConsumer":
                        nextPage = "/SelfService/MoneyTransferConsumer/StartPositionCode/FromDashBoard";
                        break;
                    case "BillPayLCRConsumer":
                        nextPage = "/SelfService/BillPayLCRConsumer/StartPositionCode/FromDashBoard";
                        break;
                    case "BillPayConsumer":
                        nextPage = "/SelfService/BillPayConsumer/StartPositionCode/FromDashBoard";
                        break;
                    case "TopUpsReloadConsumer":
                        nextPage = "/SelfService/TopUpsReloadConsumer/StartPositionCode/FromDashBoard";
                        break
                    case "TopUpsPurchaseConsumer":
                        nextPage = "/SelfService/TopUpsPurchaseConsumer/StartPositionCode/FromDashBoard";
                        break;

                    default:

                }
                if (nextPage) {
                    app.goToPersonalInfo(nextPage, "/SelfService/CustomerDashboard");
                }
            } else {
                app.page().data.LoadedSenderInfo = function () {
                    self.checkPersonInfo();
                };
            }
        }

        window.cancelPersonalInfo = function () {
            self.cancelPersonalInfo();
        }

        window.refreshPersonalInfo = function (personalInfo, errorState, isWeb) {
            personalInfo.hasPermission = personalInfo.HasMoneyTransfer && (personalInfo.HasBillPay || personalInfo.HasLCRBillPay);
            self.refreshPersonalInfo(personalInfo, errorState, isWeb);
        }

        self.goToReferral = function (cardHolderId) {
            try {
                Android.openReferral(cardHolderId);
                app.senderInfo().GoToDashboard();
                return;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.openReferral.postMessage(cardHolderId);
                app.senderInfo().GoToDashboard();
                return;
            } catch (e) {
                // error
            }

            app.redirectTo("/SelfService/ReferralLandingConsumer");
        }

        self.openUpgrade = function (currentLevelId, targetLevelId, isPreTransaction) {
            var memberLevelDocumentExtensions = getDocumentExtensions();
            var upgradeInfo = {
                "transactionUniqueCode": localStorage && localStorage.getItem('TransactionUniqueCode'),
                "cardHolderId": require('app').senderInfo().Customer().CustomerBasic.CardHolderId(),
                "currentLevelId": currentLevelId || '',
                "targetLevelId": targetLevelId || '',
                'isPreTransaction': isPreTransaction || false,
                "isFromIndependentUpgrade": app.page().name != 'MoneyTransferConsumer',
                "configuration": {
                    "memberLevelProductName": app.configurations().memberLevelProductName,
                    "memberLevelEmailAddress": app.configurations().memberLevelEmailAddress,
                    "memberLevelDocumentMaxSize": app.configurations().memberLevelDocumentMaxSize,
                    "memberLevelDocumentExtensions": memberLevelDocumentExtensions
                }
            }

            try {
                Android.openUpgrade(JSON.stringify(upgradeInfo));
                return true;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.openUpgrade.postMessage(upgradeInfo);
                return true;
            } catch (e) {
                // error
            }

            return false;
        }

        self.openIncreaseSendingLimit = function (currentLevelId) {
            $.when(getPersonalInfoModel())
            .done(function (result) {

                track.trackNextPage(track.PageEnum.IncreaseSendingLimit, app);

                var personalInfoModel = null;
                if (app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                    personalInfoModel = result;
                }

                var memberLevelDocumentExtensions = getDocumentExtensions();
                var data = {
                    "cardHolderId": require('app').senderInfo().Customer().CustomerBasic.CardHolderId(),
                    "currentLevelId": currentLevelId || '',
                    "configuration": {
                        "memberLevelProductName": app.configurations().memberLevelProductName,
                        "memberLevelEmailAddress": app.configurations().memberLevelEmailAddress,
                        "memberLevelDocumentMaxSize": app.configurations().memberLevelDocumentMaxSize,
                        "memberLevelDocumentExtensions": memberLevelDocumentExtensions
                    },
                    "personalInfoModel": personalInfoModel
                }

                try {
                    Android.openIncreaseSendingLimit(JSON.stringify(data));
                    return;
                } catch (e) {
                    // error
                }

                try {
                    webkit.messageHandlers.openIncreaseSendingLimit.postMessage(data);
                    return;
                } catch (e) {
                    // error
                }

                //DataCapture.
                if (cs.IsTransactionPage()) {
                    cs.AddTransactionStep(15, 'Left Button', 'Increase Sending Limit');
                }

                app.redirectTo("/SelfService/IncreaseLimitConsumer");
            });
        }

        self.openFeeCalculator = function () {
            var data = {
                "cardHolderId": require('app').senderInfo().Customer().CustomerBasic.CardHolderId()
            }

            var trackReferralUrl = function () {
                track.trackEvent({
                    sendType: track.GA,
                    eventCategory: track.CategoryEnum.CalculatorScreenPost,
                    eventAction: track.ActionEnum.SourcePage,
                    eventLabel: track.getEventPage(app),
                    eventPage: track.PageEnum.CalculatorScreenPost
                });
            }

            trackReferralUrl();

            try {
                Android.openFeeCalculator(JSON.stringify(data));
                return;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.openFeeCalculator.postMessage(data);
                return;
            } catch (e) {
                // error
            }

            app.redirectTo("/SelfService/FeeCalculatorConsumer");
        }

        window.finishFeeCalculator = function () {
            app.redirectTo("/SelfService/MoneyTransferConsumer/StartPositionCode/FromLeftBar");
        }

        window.closeFeeCalculator = function () {
            app.redirectTo("/SelfService/CustomerDashboard");
        }

        window.closeIncreaseSendingLimit = function () {
            //DataCapture.
            if (cs.IsTransactionPage()) {
                cs.AddTransactionStep(15, 'Left Button', 'Increase Sending Limit');
            }

            app.redirectTo("/SelfService/CustomerDashboard");
        }

        self.openSubmitPrompt = function (currentLevelId, targetLevelId) {
            // Close left menu.
            cs.RemoveOpen();

            var memberLevelDocumentExtensions = getDocumentExtensions();
            var data = {
                "currentLevelId": currentLevelId || '',
                "targetLevelId": targetLevelId | '',
                "configuration": {
                    "memberLevelProductName": app.configurations().memberLevelProductName,
                    "memberLevelEmailAddress": app.configurations().memberLevelEmailAddress,
                    "memberLevelDocumentMaxSize": app.configurations().memberLevelDocumentMaxSize,
                    "memberLevelDocumentExtensions": memberLevelDocumentExtensions
                }
            }

            try {
                Android.openSubmitPrompt(JSON.stringify(data));
                return;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.openSubmitPrompt.postMessage(data);
                return;
            } catch (e) {
                // error
            }

            $('#ConfirmCaption').text(commonstrings.appdatamodeljsmessagebox.mailmessage);
            //Inline message
            $('#ConfirmMessage').html("<p>" + commonstrings.appdatamodeljsmessagebox.pleasesubmitupgradedocument + "</p>");
            $('#ConfirmOk').text(commonstrings.appdatamodeljsmessagebox.submitdocs);
            $('#ConfirmCancel').text(commonstrings.buttons.cancel).removeAttr("style");
            $('#ConfirmOk').off('click');
            $('#ConfirmOk').one('click', function () {
                $.when(cs.closeModal())
                .done(function () {
                    //DataCapture.
                    if (cs.IsTransactionPage()) {
                        cs.AddTransactionStep(15, 'Left Button', 'Increase Sending Limit');
                    }

                    self.GoToUpgradeLevel(currentLevelId, targetLevelId);
                });
            });
            $('#ConfirmCancel').off('click');
            $('#ConfirmCancel').one('click', function () {
                cs.closeModal()
            });
            cs.openModal('modal-confirm');
        }

        self.openPendingPrompt = function () {
            // Close left menu.
            cs.RemoveOpen();

            try {
                Android.openPendingPrompt();
                return;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.openPendingPrompt.postMessage("Dummy message");
                return;
            } catch (e) {
                // error
            }

            var data = { Caption: commonstrings.appdatamodeljsmessagebox.upgradepending, Message: commonstrings.appdatamodeljsmessagebox.limitupgradeispending };
            cs.showNotification(data, null);
        }

        self.openEmailLaterPrompt = function () {
            try {
                Android.openEmailLaterPrompt();
                return true;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.openEmailLaterPrompt.postMessage("Dummy message");
                return true;
            } catch (e) {
                // error
            }

            return false;
        }

        self.uploadDocumentNotSubmit = function () {
            try {
                Android.uploadDocumentNotSubmit();
                return true;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.uploadDocumentNotSubmit.postMessage("Dummy message");
                return true;
            } catch (e) {
                // error
            }

            return false;
        }

        // isNormalBP & isRppsBillingAccount only for Normal BP limitation check.
        self.CheckTransactionAmount = function (receiverCardHolderId, amountToSend, element) {
            if (!cs.isAmountValid(amountToSend) || amountToSend < 10) {
                return $.Deferred().reject();
            }

            return cs.AjaxBySpinnerOrLoading({
                url: '/Customers/CheckTransactionAmount',
                datType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    "amountToSend": cs.GetOriginalNumber(amountToSend),
                    "receiverCardHolderId": receiverCardHolderId
                })
            }, element).
            done(function (data) {
                data.isInitialize = false;
                return data;
            });
        }

        self.getPaymentMethods = function () {
            var deferred = $.Deferred();
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
           .done(function (result) {
               $.each(result, function (index, d) {
                   d.Selected = ko.observable(false);
                   d.SelectedToCalculate = false;
                   d.IsVerifying = ko.observable(false);
               })

               deferred.resolve(result);
           })
            .fail(deferred.reject);

            return deferred;
        }

        self.checkIBVBalance = function (paymentMethod, amountCollected, element) {
            var deferred = $.Deferred();
            var result = { verifyPassed: false, isCredentialChanged: false };

            cs.AjaxBySpinnerOrLoading({
                url: '/PaymentMethod/GetAvailableBalance',
                datatype: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({
                    "paymentMethodId": paymentMethod.PaymentMethodId,
                })
            }, element, true)
            .done(function (posAmount) {
                //IBV data capture.
                if (posAmount.userSessionCostId != -1) {
                    cs.IBVDataCaptureMmodel.AddTransactionIbvCost(posAmount.userSessionCostId);
                }

                if (!!amountCollected && typeof (amountCollected) == "string") {
                    amountCollected = amountCollected.replace(',', '');
                }
                if (!!posAmount && !posAmount.isCredentialChanged && (posAmount.amount - amountCollected) <= 0) {
                    cs.showErrorMessage("Error", commonstrings.appdatamodeljsmessagebox.unablecomplatetransaction);
                    deferred.resolve(result);
                }
                if (!!posAmount && !posAmount.isCredentialChanged && (posAmount.amount - amountCollected) > 0) {
                    result.verifyPassed = true;
                    deferred.resolve(result);
                }
                if ((!!posAmount && posAmount.isCredentialChanged)) {
                    result.verifyPassed = false;
                    result.isCredentialChanged = true;
                    deferred.resolve(result);
                } else {
                    deferred.reject();
                }
            })
            .fail(function () {
                deferred.reject();
            });

            return deferred;
        }

        self.checkIBVNetwork = function (/*Optional*/IbvStartFlag,  /*Optional*/element) {
            var deferred = $.Deferred();

            cs.AjaxBySpinnerOrLoading({
                url: '/PaymentMethod/InitialYodleeService',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "paymentMethodId": -1 }),
            }, element, true)
            .done(function (result) {
                if (!result) {
                    deferred.reject();
                    return;
                }

                //IBV data capture.
                if (IbvStartFlag != undefined && IbvStartFlag == "StartIbvBankAccount") {
                    cs.IBVDataCaptureMmodel.InitializeIbvActivity();
                }

                if (result.userSessionCostId != -1) {
                    cs.IBVDataCaptureMmodel.AddTransactionIbvCost(result.userSessionCostId);
                }

                if (result.accessTokenCostId != -1) {
                    cs.IBVDataCaptureMmodel.AddTransactionIbvCost(result.accessTokenCostId);
                }

                deferred.resolve(result.yodleeForm);
            })
            .fail(function () {
                deferred.reject();
            });

            return deferred;
        }

        self.reVerify = function (paymentMethodId, element) {
            var deferred = $.Deferred();
            cs.AjaxBySpinnerOrLoading({
                url: '/PaymentMethod/InitialYodleeService',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "paymentMethodId": paymentMethodId }),
            }, element, true)
            .done(function (result) {
                if (!result) {
                    deferred.reject();
                    return;
                }
                //IBV data capture.
                if (result.userSessionCostId != -1) {
                    cs.IBVDataCaptureMmodel.AddTransactionIbvCost(result.userSessionCostId);
                }

                deferred.resolve(result.yodleeForm);
            })
            .fail(function () {
                deferred.reject();
            });

            return deferred;
        }

        self.setFastLinkEvent = function (callback) {
            self.handleFastLink = callback;
        }

        self.addIBVPostMessageListener = function () {
            window.addEventListener("message", self.ibvPostMessage);
        }

        self.ibvPostMessage = function (e) {
            if (!!e && !!e.data) {
                var callBackModal = parseCallBackModal(e.data);
                if (callBackModal.reason === "LOGIN_FAILURE") {
                    cs.showErrorMessage("Error", "Invalid Credentials.", function () {
                        cs.closeModal();
                    });
                }
                if (callBackModal.reason === "REFRESH_COMPLETED") {
                    cs.closeModal();
                    cs.AjaxByLoading({ // if delay loading, when IBV done user can select other payment method before loading icon show.
                        url: '/PaymentMethod/GetIBVAccountInfo',
                        datatype: "json",
                        type: "POST",
                        contentType: "application/json",
                        data: JSON.stringify({
                            "accountId": callBackModal.itemAccountId
                        })
                    })
                    .done(function (result) {
                        //IBV data capture.
                        if (result.userSessionCostId != -1) {
                            cs.IBVDataCaptureMmodel.AddTransactionIbvCardInfo(result.ibvAccountInfo);
                            cs.IBVDataCaptureMmodel.AddTransactionIbvCost(result.userSessionCostId);
                        }

                        self.handleFastLink(result.ibvAccountInfo);
                    });
                } else {
                    cs.closeModal();
                }
            } else {
                cs.closeModal();
            }
        }

        function parseCallBackModal(source) {
            var datas = source.split(':');
            var callBackModal = {};
            callBackModal.itemId = datas[0];
            callBackModal.itemAccountId = datas[1];
            callBackModal.errorCode = datas[2];
            callBackModal.reason = datas[3];
            callBackModal.status = datas[4];
            callBackModal.bankName = datas[5];
            callBackModal.intermediateFlowTransition = datas[6];
            callBackModal.isCBLFlow = datas[7];
            callBackModal.providerAccountId = datas[8];
            callBackModal.transferAccountId = datas[9];
            return callBackModal;
        }

        self.GoToUpgradeLevel = function (currentLevel, needToUpgradeLevel, isIndependenceUpgrade) {
            var upgradepage;
            if (isIndependenceUpgrade) {
                if (currentLevel == 1) {
                    if (needToUpgradeLevel == 2) {
                        upgradepage = "/SelfService/UpgradeLevelConsumer/independenceupgrade/" + 1;
                    } else if (needToUpgradeLevel == 3) {
                        upgradepage = "/SelfService/UpgradeLevelConsumer/independenceupgrade/" + 3;
                    }
                } else if (currentLevel == 2) {
                    if (needToUpgradeLevel == 3) {
                        upgradepage = "/SelfService/UpgradeLevelConsumer/independenceupgrade/" + 2;
                    }
                }
            } else {
                if (currentLevel == 1) {
                    if (needToUpgradeLevel == 2) {
                        upgradepage = "/SelfService/UpgradeLevelConsumer/" + 1;
                    } else if (needToUpgradeLevel == 3) {
                        upgradepage = "/SelfService/UpgradeLevelConsumer/" + 3;
                    }
                } else if (currentLevel == 2) {
                    if (needToUpgradeLevel == 3) {
                        upgradepage = "/SelfService/UpgradeLevelConsumer/" + 2;
                    }
                }
            }

            if (!upgradepage) {
                return;
            }

            if (app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                app.goToPersonalInfo(upgradepage, cs.getShortUrlPath());

            } else {
                track.trackNextPage(track.PageEnum.IndependentUpgrade, app);
                var openUpgradeResult = self.openUpgrade(currentLevel, needToUpgradeLevel);
                if (!openUpgradeResult) {
                    app.redirectTo(upgradepage);
                }
            }
        }

        self.GetSenderLevelInfos = function () {
            return cs.BaseAjax({
                url: '/Customers/GetSenderLevelInfos',
                type: "Get",
                cache: false,
                contentType: "application/json",
                dataType: "json"
            })
        }

        function getUploadingFiles(documentType, uploadDocuments) {
            if (documentType.Content && documentType.Content instanceof File) {
                uploadDocuments["document_" + documentType.SenderLevelInfoId + "_" + documentType.DocumentTypeId] = documentType.Content;
            }

            if (documentType.SubDocumentTypes && documentType.SubDocumentTypes.length > 0) {
                for (var i = 0, l = documentType.SubDocumentTypes.length; i < l; i++) {
                    getUploadingFiles(documentType.SubDocumentTypes[i], uploadDocuments);
                }
            }
        }

        self.uploadDocuments = function (documentTypes, isSubmit, element) {
            var uploadDocuments = {};

            for (var i = 0, l = documentTypes.length; i < l; i++) {
                getUploadingFiles(documentTypes[i], uploadDocuments);
            }

            var hasFiles = false;

            if (cs.isEmptyObject(uploadDocuments)) {
                if (!isSubmit) {
                    return;
                }
            } else {
                hasFiles = true;
            }

            uploadDocuments["isSubmit"] = !!isSubmit;
            uploadDocuments["hasFiles"] = hasFiles;

            return cs.AjaxUpload({
                url: '/Customers/UploadSenderLevelDocument',
                dataType: 'json',
                data: uploadDocuments
            }, element)
            .fail(function (xhr, status) {
                if (status == 'error' && (xhr.status == 0 || xhr.status == 404) && xhr.statusText != 'Not Found') {
                    cs.showInfoWhenInternetUnavailable();
                    return deferred.reject(xhr, status);
                }

                if (xhr.responseText.indexOf("\"ExceptionCode\":-488") == -1) {//Document has been submited.
                    cs.handleAjaxError(xhr.responseText, false);
                    return;
                }
            });
        };

        self.getDocumentTypes = function (currentLevelId, targetLevelId) {
            var deferred = $.Deferred();
            cs.BaseAjax({
                url: '/Customers/GetDocumentTypes',
                type: "GET",
                dataType: "json",
                data: { 'currentLevelId': currentLevelId, 'targetLevelId': targetLevelId }
            }).done(function (data) {
                deferred.resolve(data.map(function (item) {
                    item.Selected = false;
                    item.Content = '';

                    if (item.SubDocumentTypes && item.SubDocumentTypes.length > 0) {
                        for (var i = 0, l = item.SubDocumentTypes.length; i < l; i++) {
                            var subDocumentType = item.SubDocumentTypes[i];
                            subDocumentType.Selected = false;
                            subDocumentType.Content = '';
                        }
                    }
                    return item;
                }));
            }).fail(deferred.reject);

            return deferred;
        }

        self.updateSenderInfoPermission = function (result) {
            app.senderInfo().Customer().HasMoneyTransfer((result.HasMoneyTransfer == null || result.HasMoneyTransfer == undefined) ? app.senderInfo().Customer().HasMoneyTransfer() : result.HasMoneyTransfer);
            app.senderInfo().Customer().HasBillPay((result.HasBillPay == null || result.HasBillPay == undefined) ? app.senderInfo().Customer().HasBillPay() : result.HasBillPay);
            app.senderInfo().Customer().HasLCRBillPay((result.HasLCRBillPay == null || result.HasLCRBillPay == undefined) ? app.senderInfo().Customer().HasLCRBillPay() : result.HasLCRBillPay);
            app.senderInfo().Customer().HasTopUp((result.HasTopUp == null || result.HasTopUp == undefined) ? app.senderInfo().Customer().HasTopUp() : result.HasTopUp);
            app.senderInfo().Customer().HasTopUpPurchase((result.HasTopUpPurchase == null || result.HasTopUpPurchase == undefined) ? app.senderInfo().Customer().HasTopUpPurchase() : result.HasTopUpPurchase);
            app.senderInfo().Customer().HasTopUpReload((result.HasTopUpReload == null || result.HasTopUpReload == undefined) ? app.senderInfo().Customer().HasTopUpReload() : result.HasTopUpReload);
            app.senderInfo().Customer().HasTopUpPinless((result.HasTopUpPinless == null || result.HasTopUpPinless == undefined) ? app.senderInfo().Customer().HasTopUpPinless() : result.HasTopUpPinless);
        }

        self.getLastSendMoneyFeeCalculator = function (element) {
            var senderInfo = app.senderInfo();
            var deferred = $.Deferred();

            var ajaxParameter = {
                url: '/MoneyTransfer/GetLastSendMoneyPreviewTransaction',
                type: 'get',
                dataType: "json",
                contentType: "application/json"
            };
            $.when(function (element) {
                if (element) {
                    return cs.AjaxBySpinner(ajaxParameter, element);
                }
                else {
                    return cs.AjaxByDelayLoading(ajaxParameter);
                }
            }(element))
            .done(function (data) {
                deferred.resolve(data.PreviewTransactionModel);
            });

            return deferred;
        }

        self.closeExpiredDocumentNotification = function () {
            cs.BaseAjax({
                url: "/Customers/CloseExpiredDocumentNotification",
                type: "Post"
            })

            var senderLevel = app.senderInfo().SenderLevel();
            senderLevel.Status = 0;
            app.senderInfo().SenderLevel(senderLevel);
        }

        self.saveAppsflyer = function (appsflyer) {
            cs.BaseAjax({
                url: '/Customers/SaveAppsflyer',
                type: "GET",
                dataType: "json",
                contentType: "application/json",
                data: appsflyer
            }, true);
        }

        function logoutForWrapper() {
            try {
                Android.logout();
                return true;
            } catch (e) {
                // error
            }

            try {
                webkit.messageHandlers.logout.postMessage("Dummy message");
                return true;
            } catch (e) {
                // error
            }

            return false;
        }

        function getDocumentExtensions() {
            var configurations = app.configurations();
            var documentExtensions;
            if (configurations) {
                var configPart1 = configurations.memberLevelDocumentExtensions.replace(/^(.*)(,\..*)$/, '$1');
                var configPart2 = configurations.memberLevelDocumentExtensions.replace(/^(.*)(\..*)$/, '$2');
                documentExtensions = configPart1 + " or " + configPart2;
            }
            return documentExtensions;
        }

        self.logout = function () {
            logoutForWrapper();
        }
    }

    return new AppDataModel();
});