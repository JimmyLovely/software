﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'CarrierModel', 'knockout.validation'], function (ko, cs, app, dataModel) {
    return function TopUpReloadTransactionModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        self.IsAgree = ko.observable(false);
        self.tempPromoCode = ko.observable("");
        self.IsPromotionCodeValid = ko.observable(false);

        self.AgreeChange = ko.computed(function () {
            if (self.IsAgree()) {
                $("#NotAgreeError").fadeOut();
            }
        });

        self.GetSelectedCarrierToCalculate = function (carrierBasic, element) {
            return cs.AjaxBySpinner({
                url: '/TopUp/GetSeletcedToCalculate',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "selectedBillingAccountId": carrierBasic.RppsBillingAccountId(), "topUpType": carrierBasic.TopUpType() }),
            }, element)
            .done(function (result) {
                ko.mapping.fromJS(result, {}, self);
            })
        }

        self.TopUpReload$Caculate = function (element) {
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceCaculateReload',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountId": app.page().data.TopUpReloadCustomer().SelectedCarrierModel.RppsBillingAccountId(), "transactionModel": ko.mapping.toJS(self) })
            })
            .done(function (result) {
                var tempBankAccountFee = self.BankAccountFee();
                var tempCreditOrDebitFee = self.CreditOrDebitFee();
                var tempTransaction = ko.mapping.toJS(result);
                ko.mapping.fromJS(tempTransaction, {}, self);
                self.BankAccountFee(tempBankAccountFee);
                self.CreditOrDebitFee(tempCreditOrDebitFee);

                //DataCapture.
                if (result.BillerName.indexOf("PINLESS") > 0) {
                    require("TopUpsPinlessConsumer-js").UpdateDataCaptureTransactionFee();
                } else {
                    require("TopUpsReloadConsumer-js").UpdateDataCaptureTransactionFee();
                }
            })
        }

        self.CheckAmountAndPromoCodeIsValid = function (element) {
            var promoCode = cs.CustomTrim($("#input-promo-code").val());

            if (!self.CheckAmount()) {
                return;
            }

            if (promoCode == "" || promoCode == null) {
                self.PromotionCode("");
                cs.showErrorMessage("Error", "Please input a valid Promo Code", function () {
                    self.IsPromotionCodeValid(false);
                    self.tempPromoCode("");
                    cs.closeModal();
                });
            } else {
                self.ApplyPromoCode(element);
            }
        }

        self.ApplyPromoCode = function (element) {
            var promoCode = cs.CustomTrim(self.PromotionCode());

            var paymentMethodId = self.SelectedPaymentMethodId();
            self.PromotionCode(cs.CustomTrim(self.PromotionCode()));
            cs.AjaxByLoading({
                url: '/TopUp/SelfServiceCaculateReload',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountId": app.page().data.TopUpReloadCustomer().SelectedCarrierModel.RppsBillingAccountId(), "transactionModel": ko.mapping.toJS(self) })
            }, true)
            .done(function (result) {
                var tempBankAccountFee = self.BankAccountFee();
                var tempCreditOrDebitFee = self.CreditOrDebitFee();
                var tempTransaction = ko.mapping.toJS(result);
                ko.mapping.fromJS(tempTransaction, {}, self);
                self.BankAccountFee(tempBankAccountFee);
                self.CreditOrDebitFee(tempCreditOrDebitFee);
                self.IsPromotionCodeValid(true);
                $("#input-promo-message").removeClass("hide");
                $("#promo-code-added").removeClass("hide");
                $("#promo-code").addClass("hide");
                self.tempPromoCode(promoCode);
                //DataCapture.
                if (result.BillerName.indexOf("PINLESS") > 0) {
                    require("TopUpsPinlessConsumer-js").UpdateDataCaptureTransactionFee();
                } else {
                    require("TopUpsReloadConsumer-js").UpdateDataCaptureTransactionFee();
                }
            })
            .fail(function (xhr, status) {
                self.PromotionCode("");
                self.TopUpReload$Caculate();
                self.tempPromoCode(promoCode);
                self.IsPromotionCodeValid(false);
            })
            .always(function () {
                ko.mapping.fromJS(paymentMethodId, {}, self.SelectedPaymentMethodId);
            });
        }

        self.RemovePromoCode = function () {
            $.when(CleanPromo())
           .done(function () {
               $("#promo-code-added").addClass("hide");
               $("#input-promo-message").addClass("hide");
               $("#promo-code").removeClass("hide");
               $("#input-promo-code").val("");
               self.IsPromotionCodeValid(false);          
           })
        }

        function CleanPromo() {
            self.PromotionCode("");
            self.tempPromoCode("");
            self.TopUpReload$Caculate();
        }

        self.TopUpReload$Confirm = function (element) {
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceTransactionReload',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
                .done(function (result) {
                    var tempTransaction = ko.mapping.toJS(result);
                    ko.mapping.fromJS(tempTransaction, {}, self);
                });
        }

        self.GetTopUpReloadServiceTypes = function (carrierId, element) {
            return cs.AjaxBySpinner({
                url: '/TopUp/GetTopUpReloadServiceTypes',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'carrierId': carrierId, 'amountToSend': parseFloat(cs.GetOriginalNumber(self.AmountToLoad.Value())) })
            }, element)
            .done(function (result) {
                for (var i = 0; i < result.length; i++) {
                    if (result[i].PaymentMethodTypeId == 3 || result[i].PaymentMethodTypeId == 4) {
                        self.BankAccountFee(result[i].Fee.Symbol + result[i].Fee.Value);
                    } else {
                        self.CreditOrDebitFee(result[i].Fee.Symbol + result[i].Fee.Value);
                    }
                }
            })
        }

        self.ValidateAmountToLoad = function () {
            var amountToLoad = parseFloat(cs.GetOriginalNumber(self.AmountToLoad.Value()));
            var minValue = parseFloat(cs.GetOriginalNumber(self.DisplayMinValue.Value()));
            var maxValue = parseFloat(cs.GetOriginalNumber(self.DisplayMaxValue.Value()));

            if (minValue == maxValue) {
                return true;
            }

            if (amountToLoad < minValue || amountToLoad > maxValue) {
                cs.showErrorMessage("Error", "Allowed amount should be from " +
                    self.DisplayMinValue.Symbol() + self.DisplayMinValue.Value() + " to " + self.DisplayMaxValue.Symbol() + self.DisplayMaxValue.Value());

                return false;
            } else {
                return true;
            }
        }

        self.CheckAmount = function () {
            if (cs.isAmountValid(self.AmountToLoad.Value())) {
                return self.ValidateAmountToLoad();
            } else {
                cs.showErrorMessage("Error", "Please input a valid amount");
                return false;
            }
        };

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.ReceiptNumber(), element);
        };

        self.PrintTopUpReloadReceipt = function (element) {

            var isPinless = app.page().data.TopUpReloadCustomer().SelectedCarrierModel.BillerName().toLowerCase().indexOf('pinless') > -1;

            cs.AjaxBySpinner({
                url: '/TopUp/SelfServicePrintTopUpStandardReceipt',
                dataType: "html",
                cache: false,
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'topUpType': 3, 'isPinless': isPinless })
            }, element)
            .done(function (result) {
                cs.PrintTransaction(result, element);
            });
        }
    }
});