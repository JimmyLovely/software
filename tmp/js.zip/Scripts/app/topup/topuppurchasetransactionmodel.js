﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation'], function (ko, cs, app, dataModel) {
    return function TopUpPurchaseTransaction(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);
        self.IsAgree = ko.observable(false);

        self.ConditionChecked = ko.computed(function () {
            if (self.IsAgree()) {
                $("#confirmError").fadeOut();
            }
        });

        self.TopUp$SelectProductToCalculateWithSpinner = function (key, element) {
            self.CarrierKey(key);
            //return self.CalculateTransactionWithSpinner(element);
        }

        self.CalculateTransactionWithSpinner = function (element) {
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceCaculatePurchase',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            })
           .done(function (result) {
               var r = ko.mapping.toJS(result);
               ko.mapping.fromJS(r, {}, self);

               //DataCapture.
               require("TopUpsPurchaseConsumer-js").UpdateDatacaptureTransactionFee();
           });
        }

        self.LatestPromoCode = ko.observable("");
        self.IsInvalidPromoCode = ko.observable(true);
        self.ApplyPromo = function (element) {
            var tempPromoCode = self.PromotionCode();
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceCaculatePurchase',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
            .done(function (result) {
                var r = ko.mapping.toJS(result);
                ko.mapping.fromJS(r, {}, self);
                self.LatestPromoCode(tempPromoCode);
                self.IsInvalidPromoCode(false);
                $("#promo-code-added").removeClass("hide");
                $("#promo-code").addClass("hide");

                //DataCapture.
                require("TopUpsPurchaseConsumer-js").UpdateDatacaptureTransactionFee();
            })
            .fail(function () {
                self.PromotionCode("");
                self.LatestPromoCode(tempPromoCode);
            });
        }

        self.RemovePromoCode = function (element) {
            self.PromotionCode("");
            self.LatestPromoCode("");
            $("#promo-code-added").addClass("hide");
            $("#promo-code").removeClass("hide");
            $("#input-promo-code").val("");
            self.CalculateTransactionWithSpinner(element);
            self.IsInvalidPromoCode(true);
        }

        self.ConfirmAndSendTransaction = function (element) {
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceTransactionPurchase',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self))
            }, true)
             .done(function (result) {
                 var tempTransaction = ko.mapping.toJS(result);
                 ko.mapping.fromJS(tempTransaction, {}, self);
             });
        }

        self.GetServiceTypes = function (carrierKey,element) {
            return cs.AjaxByLoading({
                url: '/TopUp/GetEpinServiceTypes',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ 'carrierKey': carrierKey, 'amountToSend': self.EPinAmount.Value() })
            })
             .done(function (result) {
                 for (var i = 0; i < result.length; i++) {
                     if (result[i].PaymentMethodTypeId == 3 || result[i].PaymentMethodTypeId == 4) {
                         self.BankAccountFee(result[i].Fee.Symbol + result[i].Fee.Value);
                         continue;
                     } else {
                         self.CreditOrDebitFee(result[i].Fee.Symbol + result[i].Fee.Value);
                     }
                 }
             });
        }

        self.HasBankAccountFee = ko.computed(function () {
            if (self.ServiceTypes() == undefined || self.ServiceTypes() == null || self.ServiceTypes().length <= 0) {
                return 0;
            }
            for (var i = self.ServiceTypes().length - 1; i > -1; i--) {
                if (self.ServiceTypes()[i].PaymentMethodTypeId() == 3 || self.ServiceTypes()[i].PaymentMethodTypeId() == 4) {
                    return 1;
                }
            }
        });

        self.HasCreditCardFee = ko.computed(function () {
            if (self.ServiceTypes() == undefined || self.ServiceTypes() == null || self.ServiceTypes().length <= 0) {
                return 0;
            }
            for (var i = self.ServiceTypes().length - 1; i > -1 ; i--) {
                if (self.ServiceTypes()[i].PaymentMethodTypeId() == 1 || self.ServiceTypes()[i].PaymentMethodTypeId() == 2) {
                    return 1;
                }
            }
        });

        self.ClearTransactionExternalCondation = function () {
            self.PromotionCode("");
            self.LatestPromoCode("");
            self.IsInvalidPromoCode(true);
            self.IsAgree(false);
        };

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.ReceiptNumber(), element);
        };

        self.PrintTopUpEpinReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/TopUp/SelfServicePrintTopUpStandardReceipt',
                dataType: "html",
                cache: false,
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'topUpType': 2, 'isPinless': false })
            }, element)
             .done(function (result) {
                 cs.PrintTransaction(result, element);
             });
        }
    }
});