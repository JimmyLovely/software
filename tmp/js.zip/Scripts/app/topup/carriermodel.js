﻿define(['knockout', 'ClientScript', 'app', 'knockout.validation', 'knockout.validation.extended'], function (ko, cs, app) {
    return function CarrierModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);

        self.TempAreaCode = ko.observable("");
        self.IsEditAreaCode = ko.observable(false);
        self.DefaultCarrier = ko.mapping.toJSON(self);

        self.SearchCarrierModal = { OriginalSearchCondition: '' , CarrierList:[], OriginalCarrierName:'', OriginalKey:0};

        // 0 means valid.
        // 1 means empty.
        // 2 means no result.
        self.CarrierNameValidType = ko.observable(0);
        self.timeHandler = 0;
        self.GetCarriersByName = function (carrierName, country, isReload) {
            if (self.SearchCarrierModal.OriginalCarrierName == carrierName) {
                return;
            }

            self.timeHandler = setTimeout(function () {
                if (self.SearchCarrierModal.OriginalSearchCondition == ''
                    || carrierName.toLowerCase().indexOf(self.SearchCarrierModal.OriginalSearchCondition.toLowerCase()) == -1 ) {
                    self.SearchCarrierModal.OriginalSearchCondition = carrierName;
                    self.SearchCarrier(carrierName, country, isReload);
                }
                else {
                    if (self.SearchCarrierModal.CarrierList.length > 0) {
                        var clearFlag = true;
                        for (var i = 0; i < self.SearchCarrierModal.CarrierList.length; i++) {
                            if (self.SearchCarrierModal.CarrierList[i].value == carrierName) {
                                $("#input-new-carrier-name").autocomplete().selection = self.SearchCarrierModal.CarrierList[i];
                                $("#input-new-carrier-name").autocomplete().currentValue = self.SearchCarrierModal.CarrierList[i].value;
                                clearFlag = false;
                                break;
                            }
                        }

                        if (clearFlag) {
                            self.ClearCarrierInfo();
                            resetCarrier();
                        }
                    }
                }
                
            }, 500);

        }

        self.ClearCarrierInfo = function () {
            self.SearchCarrierModal.OriginalCarrierName = "";
            self.SearchCarrierModal.OriginalKey = 0;
            ko.mapping.fromJSON(self.DefaultCarrier, {}, self);
            self.DisabledBillingAccountValidattion();
        }

        self.SearchCarrier = function (carrierName, country, isReload) {
            self.CarrierNameValidType(0);
            $('#input-new-carrier-name').autocomplete({
                lookup: []
            });
            self.SearchCarrierModal.CarrierList = [];
            resetCarrier();
            
            cs.addSearchSpinner("#search-carriers");
            var typeName = country == "0" ? "isReload" : country == "840" ? "isDomestic" : "isInternational";
            self.ClearCarrierInfo();
            if (!isReload) {
                self.EditablePhoneNumber.isModified(false);
            }

            cs.BaseAjax({
                url: '/TopUp/TopUpGetCarriers',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "type": typeName, "carrierName": carrierName })
            })
            .done(function (data) {
                self.UpdateCarrierList(isReload, data, carrierName, country);
                self.FillInAutoCompleteForCarrier();

                $('#input-new-carrier-name').focus();
            })
            .always(function () {
                cs.removeSearchSpinner("#search-carriers");
            });
        }

        self.UpdateCarrierList = function (isReload, data, carrierName, country) {
            result = [];
            if (isReload) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].value.toLowerCase().indexOf("pinless") < 0) {
                        result.push(data[i]);
                    }
                }
            } else {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].value.toLowerCase().indexOf("pinless") > 0) {
                        result.push(data[i]);
                    }
                }
            }

            var tempBillers = [];
            if (country == 0) {
                tempBillers = result;
            }
            else {
                for (var i = 0; i < result.length; i++) {
                    if (result[i].data.CountryId == country) {
                        tempBillers.push(result[i]);
                    }
                }
            }

            self.SearchCarrierModal.CarrierList = tempBillers;
        }

        self.FillInAutoCompleteForCarrier = function () {
            $('#input-new-carrier-name').autocomplete({
                lookup: self.SearchCarrierModal.CarrierList,
                triggerSelectOnValidInput: false,
                minChars: 3,
                onSelect: function (suggestion) {
                    if (suggestion.data.Key != self.SearchCarrierModal.OriginalKey) {
                        self.SearchCarrierModal.OriginalKey = suggestion.data.Key;
                        self.SearchCarrierModal.OriginalCarrierName = suggestion.value;
                        self.TopUp$GetReloadDefaultCarrierByKey(self.SearchCarrierModal.OriginalKey);
                        self.IsEditAreaCode(true);
                    }

                    self.CarrierNameValidType(0);
                }
            });

            if (!self.SearchCarrierModal.CarrierList || self.SearchCarrierModal.CarrierList.length == 0) {
                self.CarrierNameValidType(2);
            }

            $('#input-new-carrier-name').autocomplete().getSuggestionsLocal = function (query) {
                return cs.GetSuggestionsLocal(this.options.lookup, query);
            };

            $('#input-new-carrier-name').off('keyup.autocomplete')
            .on('keyup.autocomplete', function (e) {
                var value = $(this).val();

                if (value.length >= 3) {
                    if (e.which == 13) return;

                    if (cs.isMatchSuggestion($('#input-new-carrier-name').autocomplete().suggestions, value, false) > -1) {
                        self.CarrierNameValidType(0);
                    } else {
                        self.CarrierNameValidType(2);
                    }
                }
                else if (value.length < 3 && value.length > 0) {
                    self.CarrierNameValidType(3);
                }
                else {
                    self.CarrierNameValidType(1);
                }
            })
            .off('focus.search.carrier')
            .on('focus.search.carrier', function () {
                if ($('#input-new-carrier-name').autocomplete().visible) {
                    self.CarrierNameValidType(0);
                }
            })
            .off('blur.search.carrier')
            .on('blur.search.carrier', function () {
                if ($('.autocomplete-selected').length > 0) return;

                var matchedIndex = -1;
                var value = $(this).val();
                if (value) {
                    if (value.length >= 3) {
                        if ($('#input-new-carrier-name').autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($('#input-new-carrier-name').autocomplete().suggestions, value, true)) > -1) {
                            self.CarrierNameValidType(0);
                            $('#input-new-carrier-name').autocomplete().select(matchedIndex);
                        } else {
                            self.CarrierNameValidType(2);
                        }

                    }
                }

                if ($('#input-new-carrier-name').autocomplete()) {
                    $('#input-new-carrier-name').autocomplete().hide();
                }
            });
        }

        self.ResetAddCarrierModal = function () {
            $('#input-new-carrier-name').autocomplete({
                lookup: []
            });
            self.SearchCarrierModal.OriginalSearchCondition = '';
            $('#input-new-carrier-name').val('');
            self.ClearCarrierInfo();
            self.SearchCarrierModal.CarrierList = [];
            self.CarrierNameValidType(0);
        }

        self.DisabledBillingAccountValidattion = function () {
            self.AccountNumber.isModified(false);
            self.RetypeAccountNumber.isModified(false);
            self.FirstName.isModified(false);
            self.LastName.isModified(false);
            //self.MobilePhoneNumber.isModified(false);
        }

        self.TopUp$GetReloadDefaultCarrierByKey = function (key) {
            
            return cs.BaseAjax({
                url: '/TopUp/GetReloadDefaultCarrierByKey',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "key": key })
            })
           .done(function (result) {
               result.AccountNickName = null;
               result.AccountNumber = "";
               result.RetypeAccountNumber = "";

               var r = ko.mapping.toJS(result);
               ko.mapping.fromJS(r, {}, self);
               self.TempAreaCode(r.AreaCode);

               self.CarrierNameValidType(0);
               self.AccountNumber.isModified(false);
               self.RetypeAccountNumber.isModified(false);
           });
        }

        self.FormateAccountNickName = function (element) {
            var accountNumber = $(element).val();
            var length = accountNumber.length;

            var billerName = $("#input-new-carrier-name").val();
            if (self.BillerName() == null) {
                return;
            }

            if (length < 4) {
                self.AccountNickName(billerName + " [****" + accountNumber + "]");
            } else {
                var temp = accountNumber.substr(0, length - 4).length;
                var prefix = " [****";

                self.AccountNickName(billerName + prefix + accountNumber.substr(length - 4, 4) + "]");
            }
        }

        self.FirstName.extend({
            minTrimLength: { params: 2, message: 'Minimum length of first name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of first name is 50 characters' },
            equal: {
                onlyIf: function () { return self.FirstName() != "" && cs.IsInvalidName(self.FirstName()) != 0 },
                message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? 'First name should start with a letter' : 'Invalid first name' }
            }
        }).isModified(false);

        self.LastName.extend({
            minTrimLength: { params: 2, message: 'Minimum length of last name is 2 characters' },
            maxLength: { params: 50, message: 'Maximum length of last name is 50 characters' },
            equal: {
                onlyIf: function () { return self.LastName() != "" && cs.IsInvalidName(self.LastName()) != 0 },
                message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? 'Last name should start with a letter' : 'Invalid last name' }
            }
        }).isModified(false);

        self.AccountNumber.extend({
            required: {
                params: true,
                message: 'Cell no. is required'
            },
            number: {
                params: true,
                message: 'Enter a valid cell no.'
            },
            equal: {
                onlyIf: function () { return IsInvalidCarrierAccountNumber(self.AccountNumber()); },
                message: 'Enter a valid cell no.'
            }
        }).isModified(false);

        self.RetypeAccountNumber.extend({
            required:{
                params: true,
                message: 'Confirm cell no. is required'
            },
            equal: {
                onlyIf: function () { return !cs.equals(self.AccountNumber(), self.RetypeAccountNumber(), true) },
                message: "Values of cell no. and confirm cell no. don't match"
            },
            number: {
                params: true,
                message: 'Enter a valid confirm cell no.'
            }
        }).isModified(false);

        self.AfterRenderNewCarrierPage = function () {
        }

        function IsInvalidCarrierAccountNumber(phoneNumber) {
            if (phoneNumber != null && self.DestinationCountry() == 'United States') {
                return !(ko.validation.rules.maxLength.validator(phoneNumber.replace(/-/g, ''), 10)
                && ko.validation.rules.minLength.validator(phoneNumber.replace(/-/g, ''), 10));
            }
            return false;
        }

        /*
        self.MobilePhoneNumber.extend({
            required: {
                onlyIf: function () { return (self.TopUpType() == 2) },
                message: 'Required field'
            },
            number: {
                params: true,
                message: 'Enter a valid mobile phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid mobile phone number'
            },
            maxLength: {
                params: 10,
                message: 'Enter a valid mobile phone number'
            }
        }).isModified(false);
        */

        function isVaildAccountNumber(accountNumber) {
            if (accountNumber) {
                return !ko.validation.rules.number.validator(accountNumber.replace(/-/g, ''), true);
            }

            return false;
        }

        self.ApplyValidation = function () {
            self.CustomDisplayAccountNumber.extend({
                required: {
                    params: true,
                    message: 'Cell no. is required'
                },
                equal: {
                    onlyIf: function () { return IsInvalidCarrierAccountNumber(self.CustomDisplayAccountNumber()) },
                    message: 'Enter a valid cell no.'
                }
            }).isModified(false);

            self.CustomRetypeAccountNumber.extend({
                equal: {
                    onlyIf: function () {
                        if (!self.CustomDisplayAccountNumber() || !self.CustomRetypeAccountNumber()) {
                            return true;
                        }

                        return !(self.CustomDisplayAccountNumber().replace(/-/g, '') == self.CustomRetypeAccountNumber().replace(/-/g, ''));
                    },
                    message: "Values of cell no. and confirm cell no. don't match"
                }
            }).isModified(false);
        }

        self.resetErrorMessage = function () {
            self.CustomRetypeAccountNumber.isModified(false);
            self.CustomDisplayAccountNumber.isModified(false);
            self.RetypeAccountNumber.isModified(false);
            self.AccountNumber.isModified(false);
            self.LastName.isModified(false);
            self.FirstName.isModified(false);
            self.LastName.isModified(false);
            self.LastName.isModified(false);
            self.LastName.isModified(false);
            self.LastName.isModified(false);
            self.LastName.isModified(false);
        }

        function resetCarrier() {
            self.AccountNumber('');
            self.RetypeAccountNumber('');
            self.FirstName('');
            self.LastName('');
            self.AccountNickName('');

            self.AccountNumber.isModified(false);
            self.RetypeAccountNumber.isModified(false);
            self.FirstName.isModified(false);
            self.LastName.isModified(false);
        }
    }
});