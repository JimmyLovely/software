﻿define(['knockout', 'ClientScript', 'app'], function (ko, cs, app) {
    return function (params) {
        var self = this, lastAmountToLoad;
        self.TransactionDetail = ko.observable(null);

        if (params.defaultValue()) {
            self.TransactionDetail = params.defaultValue;
            lastAmountToLoad = self.TransactionDetail().AmountToLoad.Value();
        } else {
            convertToTransactionDetail(params.Carrier());
        }

        if (cs.IsMobileDevice()) {
            if (!self.TransactionDetail().AmountToLoad.Value()) {
                self.TransactionDetail().AmountToLoad.Value('0.00');
            }
        }

        self.AmountChanged = function () {
            var amountToLoad = self.TransactionDetail().AmountToLoad.Value();

            if (amountToLoad != lastAmountToLoad) {
                self.TransactionDetail().IsChanged(true);
                app.factoryFunc("AmountChanged");
            }
        }

        self.BackToSelectCarrier = function () {
            app.factoryFunc("BackToSelectCarrier");
        }

        self.GoToSenderPayment = function (elment, transactionDetail) {
            var transactionDetail = self.TransactionDetail();
            var amountToLoad = transactionDetail.AmountToLoad.Value();
            var isAmountToLoadValid = app.factoryFunc("checkAmountToLoad", ko.mapping.toJS(transactionDetail));

            if (!isAmountToLoadValid) return;

            if (transactionDetail.IsChanged() || !lastAmountToLoad) {
                lastAmountToLoad = amountToLoad;
                self.TransactionDetail().IsChanged(false);
                app.factoryFunc("GoToSenderPayment", self.TransactionDetail());
            } else {
                app.factoryFunc("GoToSenderPayment");
            }
        }

        self.AmountFormat = function (element, amount) {
            if (!cs.IsMobileDevice() && amount == "" ) {
                $(element).val("0.00");
                $("#input-amount").addClass("placeholder-color");
            }
        }

        function convertToTransactionDetail(data) {
            var transactionDetail = {};
            transactionDetail.AmountToLoad = {
                Value: ko.observable(cs.GetOriginalNumber(data.AmountToLoad.Value == "" ? "0.00" : data.AmountToLoad.Value)),
                Symbol: data.AmountToLoad.Symbol
            };
            transactionDetail.PaymentAmountReadOnly = data.PaymentAmountReadOnly;
            transactionDetail.DisplayMaxValue = data.DisplayMaxValue;
            transactionDetail.DisplayMinValue = data.DisplayMinValue;
            transactionDetail.IsChanged = ko.observable(false);
            self.TransactionDetail(transactionDetail);
        }
    }
});