﻿define(['knockout', 'ClientScript', 'app', 'tinyscrollbar'], function (ko, cs, app) {
    return function (params) {
        var self = this;
        self.Carriers = ko.observable();
        self.history = ko.observable();
        self.lastSearchValue = ko.observable("");
        self.SelectedCarrier;
        self.RecentCarrierCount = ko.observable(0);
        var timeHandler = 0;

        self.searchProducts = function (searchValue) {
            if (!searchValue) {
                return;
            }
            clearTimeout(timeHandler);
            var element = $("#selec-carrier-button");
            timeHandler = setTimeout(function () {
                searchProduct(element, searchValue);
            }, 500);
        }

        getHistory();

        function getHistory() {
            cs.BaseAjax({
                url: '/TopUp/GetEpinHistory',
                type: "POST",
                dataType: "json",
                contentType: "application/json"
            })
            .done(function (data) {
                $.each(data, function (index, d) {
                    d.Selected = ko.observable(d.data.Key == params.defaultValue());

                    if (d.Selected()) {
                        self.SelectedCarrier = d;
                    }
                });

                self.RecentCarrierCount(data.length);
                self.history(data);
            })
            .fail(function () {
                self.history([]);
            });
        }

        function searchProduct(element, searchValue) {
            if (searchValue.indexOf(self.lastSearchValue()) === 0 && self.lastSearchValue().length > 2 == searchValue.length > 2 && self.lastSearchValue() != "") {
                self.lastSearchValue(searchValue);
                return false;
            }
            $('#autocomplete-carrier-products').autocomplete({
                lookup: [],
            });
            cs.AjaxBySpinner({
                url: '/TopUp/SearchEpinProducts',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "key": searchValue })
            },element)
            .done(function (data) {
                $.each(data, function (index, d) {
                    d.Selected = ko.observable(d.data.Key == params.defaultValue());
                });
                self.Carriers(data);
                self.lastSearchValue(searchValue);
                initializeSearchPurchaseProduces();
            })
            .fail(function () {
                self.Carriers([]);
            });
        }

        function initializeSearchPurchaseProduces() {
            var result = $.map(self.Carriers(), function (item, index) { return { value: item.value, data: item }; });
            require(['foundation.extended', 'Plugins'], function () {
                var timeHandler = 0;

                $("#autocomplete-carrier-products").autocomplete({
                    lookup: result,
                    triggerSelectOnValidInput: true,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        self.SelectedCarrier = suggestion.data;
                        cs.removeDisable("#selec-carrier-button");
                    },
                    onInvalidateSelection: function () {
                        self.SelectedCarrier = null;
                        cs.addDisable("#selec-carrier-button");
                    },
                    onSearchComplete: function (query, suggestions) {
                        //Data Capture
                        if (Object.prototype.toString.call(suggestions).slice(8, -1) == "Array" && suggestions.length == 0) {
                            clearTimeout(timeHandler);

                            timeHandler = setTimeout(function () {
                                cs.LogSearchActivity(query, cs.LuSearchSectionType.AddEpinCarrierInTopUp);
                            }, 500);

                        }

                    },
                    maxHeight: 195
                });

                $('#autocomplete-carrier-products').autocomplete().getSuggestionsLocal = function (query) {
                    return cs.GetSuggestionsLocal(this.options.lookup, query);
                };

                $("#autocomplete-carrier-products").focus();
                $("#input-phone-number-epin").blur();
            });
        }

        self.SelectCarrier = function (element, carrier) {
            self.GoToSenderPayment(element, self.SelectedCarrier);
        }

        self.recordSelectEpinActionTime = (function () {
            var firstClickDateTime = null;
            return {
                ClickInSearchCarrier: function () {
                    if (firstClickDateTime == null) {
                        firstClickDateTime = cs.GetDateTimeOffset();
                    }
                },
                SelectCarrierLogStep: function (isAddingNewEpin, carrier) {
                    cs.AddTransactionStep(9, 'Biller ID', carrier.data.key, firstClickDateTime, isAddingNewEpin);
                    firstClickDateTime = null;
                }
            };
        })();

        self.GoToSenderPayment = function (element, carrier) {
            if (!carrier) {
                return;
            }
            var isAddingNew = true;
            if (carrier.Selected()) {
                app.factoryFunc("GoToSenderPayment");
                isAddingNew = false;
            } else {
                if (self.history()) {
                    $.each(self.history(), function (index, c) {
                        c.Selected(carrier.data.Key == c.data.Key);
                        if (carrier.data.Key == c.data.Key) {
                            isAddingNew = false;
                        }
                     });
                } else {
                    carrier.Selected(true);
                }
                app.factoryFunc("GoToSenderPayment", carrier);
            }
          self.recordSelectEpinActionTime.SelectCarrierLogStep(isAddingNew, carrier);
        }
    };
});