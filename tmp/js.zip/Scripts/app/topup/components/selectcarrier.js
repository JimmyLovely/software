﻿define(['knockout', 'ClientScript', 'app', 'tinyscrollbar', 'Plugins'], function (ko, cs, app) {
    return function (params) {
        var self = this, selectedCarrier;
        self.Carriers = ko.observable();
        self.TopUpAddCarrierFlag = ko.observable(false);
        self.TopUpAddPinlessFlag = ko.observable(false);
        self.TopUpsType = ko.observable(params.TopUpsType);
        if (params.autoNext()) {
            app.factoryFunc("GoToAmountToSend");
        }


        cs.BaseAjax({
            url: '/TopUp/GetTopUpsBillingAccounts',
            datatype: "json",
            type: "Post",
            contentType: "application/json",
            data: JSON.stringify({ isPinless: params.TopUpsType == 2 })
        })
       .done(function (result) {
           result = result || [];
           if (result.length == 0) return self.Carriers(result);

           var selectedIndex;
           $.each(result, function (index, r) {
               r.Selected = ko.observable(r.RppsBillingAccountId == params.defaultValue());
               if (r.Selected()) {
                   selectedIndex = index;
               }
           });
           
           self.Carriers(result);
           self.initializeSearchCarriers();
           
           if (params.autoNext()) {
               if (selectedIndex >= 0) {
                   var carriers = self.Carriers();

                   carriers[selectedIndex].Selected(false);
                   self.GoToAmountToSend(null, carriers[selectedIndex]);
               } else {
                   app.factoryFunc("GoToSelectCarrier");
               }
           }
       })

        self.AddNewCarrier = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            AddNewCarrier();
        }

        self.GoToAmountToSend = function (element, carrier) {
            if (carrier && carrier.Selected()) {
                app.factoryFunc("GoToAmountToSend");
            } else {
                var billingAccountId = carrier.RppsBillingAccountId;
                $.each(self.Carriers(), function (index, c) {
                    c.Selected(c.RppsBillingAccountId == billingAccountId);
                });
                app.factoryFunc("GoToAmountToSend", ko.mapping.toJS(carrier));
            }
        }

        self.SelectAccount = function (element) {
            if (!cs.isDisabled(element) && selectedCarrier != null) {
                self.GoToAmountToSend(element, selectedCarrier);
            }
        }

        self.initializeSearchCarriers = function () {
            if (!self.Carriers() || self.Carriers().length < 6) {
                return;
            }

            var carriers = $.map((self.Carriers()), function (item, index) {
                return { value: (!item.AccountName) ? item.BillerName : item.AccountName, data: item };
            });

            carriers.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            if (selectedCarrier) {
                $('#autocomplete-search-for-carriers').val(!selectedCarrier.AccountName ? selectedCarrier.BillerName : selectedCarrier.AccountName);
                cs.removeDisable('#button-select-carrier');
            }
            $('#autocomplete-search-for-carriers').autocomplete({
                lookup: carriers,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    selectedCarrier = suggestion.data;
                    cs.removeDisable('#button-select-carrier');
                },
                onInvalidateSelection: function () {
                    selectedCarrier = null;
                    cs.addDisable('#button-select-carrier');
                }
            });
        }

        self.completedAddReloadCarrier = function (carrier) {
            var carriers = self.Carriers() || [];
            carrier.Selected = ko.observable(false);
            carriers.push(carrier);
            
            self.Carriers(carriers);
            self.initializeSearchCarriers();
            self.GoToAmountToSend(null, carrier);

        };

        function AddNewCarrier() {
            var isPinless = app.page().name.toLowerCase().indexOf('pinless') != -1,
                modalId = isPinless ? 'modal-carrier-pinless-new' : 'modal-carrier-new',
                flag = isPinless ? 'TopUpAddPinlessFlag' : 'TopUpAddCarrierFlag';

            cs.closeModalCallBack(modalId, function () {
                self[flag](false);
            });
            self[flag](true);
            cs.openModal(modalId);
        }
    };
});