﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], paths['TopUpsReloadConsumer-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, reloadstrings, R, track) {
    return function (params) {
        var self = this;
        //1: Reload 2: pinless
        self.TopUpType = params.TopUpType;
        self.Countries = ko.observable([]);
        self.AccountNumber = ko.observable();
        self.BillerKey = ko.observable(-1);
        self.RetypeAccountNumber = ko.observable();
        self.AreaCode = ko.observable();
        self.FirstName = ko.observable();
        self.LastName = ko.observable();
        self.AccountNickName = ko.observable();
        self.EditablePhoneNumber = ko.observable();
        self.logActionTimeData = ko.observable({ transactionStepId: 7, label: 'Biller ID', value: 0 });
        self.MobilePhoneNumber = ko.observable(); // required feild
        self.DestinationCountry = null;
        self.CountryId = ko.observable();
        self.IsEditAreaCode = ko.observable(false);
        var searchCarrierModal = { OriginalSearchCondition: '', OriginalCarrierName: '', OriginalKey: 0 };
        // 0: means valid. 1: means empty. 2: means no result.
        self.CarrierNameValidType = ko.observable(0);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(self.TopUpType == 1 ? track.CategoryEnum.AddNewCarrierReload : track.CategoryEnum.AddNewCarrierPinless, self.TopUpType == 1 ? track.CategoryEnum.AddNewCarrierReload : track.CategoryEnum.AddNewCarrierPinless);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = track.generateErrorMessageTrack(self.TopUpType == 1 ? track.CategoryEnum.AddNewCarrierReload : track.CategoryEnum.AddNewCarrierPinless, self.TopUpType == 1 ? track.CategoryEnum.AddNewCarrierReload : track.CategoryEnum.AddNewCarrierPinless);

        ko.computed(function () {
            var carrierNameValidType = self.CarrierNameValidType();

            if (carrierNameValidType === 1) {
                self.trackErrorMessage(commonstrings.topups.addcarrier.accountdetails.validation.carrierrequired);
            } else if (carrierNameValidType === 2) {
                self.trackErrorMessage(commonstrings.topups.addcarrier.accountdetails.validation.carriermatched);
            } else if (carrierNameValidType === 3) {
                self.trackErrorMessage(commonstrings.topups.addcarrier.accountdetails.validation.selectcarrierkeylength);
            }

        });
        // End appsflyer track event

        //Begin: Init component view and data
        applyCarrierValidation();

        if (self.TopUpType == 1) {
            InitializeDestinationCountries();
        }
        //End: Init component view and data

        self.CountryChange = function () {
            self.CountryId($("#select-new-country").val());
            if (self.DestinationCountry == $("#select-new-country option:selected").text() || ($("#select-new-country").val() == '0' && !!self.DestinationCountry)) {
                return;
            }
            resetCarrier();
            resetAutoComplete();

            var selectedCountry = $("#select-new-country").val();
            self.GetAreaCode(selectedCountry);
            if (selectedCountry == 0) {
                self.AreaCode("");
                self.AreaCode.isModified(false);
                self.IsEditAreaCode(false);
            } else {
                self.IsEditAreaCode(true);
            }
        }

        self.GetAreaCode = function (code) {
            if (!code || code == '0') {
                return;
            }
            cs.BaseAjax({
                url: '/TopUp/SelfServiceGetAreaCodeByCountry',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": code })
            })
            .done(function (data) {
                self.AreaCode(data);
            });
        }

        //Search Carriers
        var timeHandler = 0;
        self.AutoSearchCarriers = function (data, e) {
            if (cs.isKeyPressControlOrSelect(e.which)) {
                return;
            }

            var carrierName = $("#input-new-carrier-name").val().trim();
            clearTimeout(timeHandler);

            //Reset input box's status when clear carrier name.
            if (carrierName != undefined && carrierName.length == 0) {
                self.CarrierNameValidType(0);
                searchCarrierModal.OriginalSearchCondition = "";
                $('#input-new-carrier-name').autocomplete({
                    lookup: []
                });

                e.stopImmediatePropagation();
                $('#input-new-carrier-name').off('keyup.autocomplete');
                $('#input-new-carrier-name').off('focus.search.carrier');
                resetCarrier();
                return;
            }

            if (carrierName.length > 0) {
                if (carrierName != searchCarrierModal.OriginalSearchCondition ||
                    //Fixed issue: if input an invalid carrrier name with 3 characters, then delete the latest character, then input the deleted character,
                    //There is no validation for inputed carrrier name.
                    ($('#input-new-carrier-name').autocomplete() && $('#input-new-carrier-name').autocomplete().suggestions.length < 1)) {
                    resetCarrier();
                }

                timeHandler = setTimeout(function () {
                    if (carrierName != searchCarrierModal.OriginalSearchCondition ||
                        //Fixed issue: if input an invalid carrrier name with 3 characters, then delete the latest character, then input the deleted character,
                        //There is no validation for inputed carrrier name.
                        ($('#input-new-carrier-name').autocomplete() && $('#input-new-carrier-name').autocomplete().suggestions.length < 1)) {
                        self.SearchCarriers();
                    }
                }, 500);
            }
        }

        self.SearchCarriers = function (element) {
            var carrierName = $("#input-new-carrier-name").val().trim();
            if (carrierName.length < 1) {
                self.CarrierNameValidType(3);
                $('#input-new-carrier-name').focus();
                return;
            }

            searchCarrierModal = { OriginalCarrierName: '', OriginalKey: 0 };
            searchCarrierModal.OriginalSearchCondition = carrierName;
            $('#input-new-carrier-name').autocomplete({
                lookup: []
            });

            if (element) {  // Move this function before setTimeout if invoke by AutoSearchCarriers.
                resetCarrier();
            }

            var isReload = self.TopUpType == 1 ? true : false;
            var country = !isReload ? '0' : $("#select-new-country").val();

            cs.addSearchSpinner("#search-carriers");
            self.CarrierNameValidType(0);
            var typeName = country == "0" ? "isReload" : country == "840" ? "isDomestic" : "isInternational";
            if (!isReload) {
                self.EditablePhoneNumber.isModified(false);
            }

            cs.BaseAjax({
                url: '/TopUp/TopUpGetCarriers',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "type": typeName, "carrierName": carrierName })
            })
            .done(function (data) {
                //Data Capture
                if (Object.prototype.toString.call(data).slice(8, -1) == "Array" && data.length == 0) {
                    var searchSectionTypeId;

                    if (isReload) {
                        if (require('app').page().name == "TopUpsReloadConsumer") {
                            searchSectionTypeId = cs.LuSearchSectionType.AddReloadCarrierInTopUp;
                        } else {
                            searchSectionTypeId = cs.LuSearchSectionType.AddReloadCarrierInManagerCarriers;
                        }

                    } else {
                        if (require('app').page().name == "TopUpsPinlessConsumer") {
                            searchSectionTypeId = cs.LuSearchSectionType.AddPinlessCarrierInTopUp;
                        } else {
                            searchSectionTypeId = cs.LuSearchSectionType.AddPinlessCarrierInManagerCarriers;
                        }
                    }

                    cs.LogSearchActivity(carrierName, searchSectionTypeId);
                }

                data = filterCarrierList(isReload, data, carrierName, country);
                $('#input-new-carrier-name').autocomplete({
                    lookup: data,
                    triggerSelectOnValidInput: false,
                    minChars: 1,
                    onSelect: function (suggestion) {
                        if (suggestion.data.Key != searchCarrierModal.OriginalKey) {
                            searchCarrierModal.OriginalKey = suggestion.data.Key;
                            searchCarrierModal.OriginalCarrierName = suggestion.value;
                            getReloadDefaultCarrierByKey(searchCarrierModal.OriginalKey);
                            self.IsEditAreaCode(true);
                        }

                        self.CarrierNameValidType(0);
                    }
                });

                $('#input-new-carrier-name').autocomplete().getSuggestionsLocal = function (query) {
                    return cs.GetSuggestionsLocal(this.options.lookup, query);
                };

                if (data == null || data.length == 0) {
                    self.CarrierNameValidType(2);
                }

                $('#input-new-carrier-name').off('keyup.autocomplete')
                .on('keyup.autocomplete', function (e) {
                    var value = $(this).val();

                    if (searchCarrierModal.OriginalKey != value || !value) {
                        if (value.length >= 1) {
                            if (e.which == 13) return;

                            if (cs.isMatchSuggestion($('#input-new-carrier-name').autocomplete().suggestions, value, false) > -1 ||
                                //Fixed issue: If input second and third characters very fast after inputing an invalid carrier name, 
                                //there's a error message for correct carrier name (PC only).
                                 ($('#input-new-carrier-name').autocomplete().suggestions.length == 0 && value.length == 3)) {
                                self.CarrierNameValidType(0);
                            } else {
                                self.CarrierNameValidType(2);
                            }
                        }
                        else {
                            self.CarrierNameValidType(1);
                        }

                        resetCarrier();
                        searchCarrierModal.OriginalKey = "";
                    }
                })
                .off('focus.search.carrier')
                .on('focus.search.carrier', function () {
                    if ($('#input-new-carrier-name').autocomplete().visible) {
                        self.CarrierNameValidType(0);
                    }
                    else {
                        if ($('#input-new-carrier-name').val() && $('#input-new-carrier-name').length > 0) {
                            self.CarrierNameValidType(2);
                        }
                    }
                })

                // If tab to next input box before search result back, not focus on search box.
                if (document.activeElement && document.activeElement.id == "input-new-carrier-name") {
                    $('#input-new-carrier-name').focus();
                }
            })
            .always(function () {
                cs.removeSearchSpinner("#search-carriers");
            });
        }

        self.CheckReloadCarrier = function (element) {
            if ($('.autocomplete-selected').length > 0) return;

            var matchedIndex = -1;
            var value = $(element).val();
            if (searchCarrierModal.OriginalKey != value || !value) {
                if (value.length >= 1) {
                    if ($('#input-new-carrier-name').autocomplete().suggestions.length > 0 && (matchedIndex = cs.isMatchSuggestion($('#input-new-carrier-name').autocomplete().suggestions, value, true)) > -1) {
                        self.CarrierNameValidType(0);
                        $('#input-new-carrier-name').autocomplete().select(matchedIndex);
                    } else {
                        self.CarrierNameValidType(2);
                    }
                }
                else {
                    self.CarrierNameValidType(1);
                }
            }

            if ($('#input-new-carrier-name').autocomplete()) {
                $('#input-new-carrier-name').autocomplete().hide();
            }
        }

        function filterCarrierList(isReload, data, carrierName, country) {
            var result = [];
            for (var i = 0, j = data.length - 1; i <= j; i++) {
                var isReloadCarrier = data[i].value.toLowerCase().indexOf("pinless") == -1;

                if (isReload && isReloadCarrier) {
                    //For selected a country or all country
                    if (country != 0 && data[i].data.CountryId == country || country == 0) {
                        result.push(data[i]);
                    }
                } else if (!isReload && !isReloadCarrier) {//For pinless
                    result.push(data[i]);
                }
            }

            return result;
        }

        function getReloadDefaultCarrierByKey(key) {
            return cs.BaseAjax({
                url: '/TopUp/GetReloadDefaultCarrierByKey',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "key": key })
            })
           .done(function (result) {
               self.AreaCode(result.AreaCode);
               self.FirstName(result.FirstName);
               self.LastName(result.LastName);
               self.MobilePhoneNumber(result.MobilePhoneNumber);
               self.AccountNickName('');
               self.DestinationCountry = result.DestinationCountry;
               self.CountryId(result.Country);
               self.CarrierNameValidType(0);
               if (self.TopUpType == 2) {
                   self.EditablePhoneNumber(result.EditablePhoneNumber);
               }
               
               clearTimeout(timeHandler);
           });
        }
        //End Search Carriers

        var addCarrierStatus = new cs.executeStatus();
        self.AddCarrier = function (element) {
            if (addCarrierStatus.isExecuting()) {
                return;
            }

            var trackSaveTotalClick = trackEvent;
            trackSaveTotalClick("Save");

            if (cs.isDisabled(element)) {
                return;
            }
            addCarrierStatus.setExecuting();
            var toBeAddedCarrierName = $('#input-new-carrier-name').val();
            if (toBeAddedCarrierName == '' || toBeAddedCarrierName == null) {
                self.CarrierNameValidType(1);
            }
            else if (!searchCarrierModal.OriginalCarrierName) {
                self.CarrierNameValidType(2);
            }

            if (self.TopUpType == 2) {
                self.MobilePhoneNumber(self.AccountNumber()); //For pinless
            }

            self.error = ko.validation.group(self);
            if ($('#input-new-carrier-name').isValid() && self.isValid()) {
                self.BillerKey(searchCarrierModal.OriginalKey);
                var tempTobeAddedCarrier = ko.toJS(ko.utils.unwrapObservable(self));
                tempTobeAddedCarrier.Domestic = self.DestinationCountry == "United States" ? true : false;
                delete tempTobeAddedCarrier.Countries;
                delete tempTobeAddedCarrier.CarrierNameValidType;
                cs.AjaxBySpinner({
                    url: '/TopUp/SelfServiceAddCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "carrierModel": tempTobeAddedCarrier }),
                }, element)
                .done(function (data) {
                    trackSaveTimeOnPage();

                    $.when(cs.closeModal())
                    .done(function () {
                        if (typeof params.completedAddReloadCarrier === 'function') {
                            params.completedAddReloadCarrier(data);
                        }
                        addCarrierStatus.complete();
                        cs.closeFoundationDropdown();
                    })
                    self.logActionTimeData({ transactionStepId: 7, label: 'Biller ID', value: data.RppsBillingAccountId });
                })
                .fail(function () {
                    addCarrierStatus.complete();
                });
            }
            else {
                addCarrierStatus.complete();
                self.errors.showAllMessages();
                cs.reRenderedOverflowy();
            }
        }

        function applyCarrierValidation() {
            self.FirstName.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.firstnamerequired
                },
                //Inline message
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
                equal: {
                    onlyIf: function () { return self.FirstName() != "" && cs.IsInvalidName(self.FirstName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
                }
            }).isModified(false);

            self.LastName.extend({
                required: {
                    params: true,
                    message: commonstrings.commonvalidation.lastnamerequired
                },
                //Inline message
                minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
                maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
                equal: {
                    onlyIf: function () { return self.LastName() != "" && cs.IsInvalidName(self.LastName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
                }
            }).isModified(false);

            self.AccountNickName.extend({
                //Inline message
                maxLength: { params: 50, message: commonstrings.commonvalidation.nicknamemaxlength }
            }).isModified(false);

            self.AccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.topups.addcarrier.accountdetails.validation.cellnorequired
                },
                number: {
                    params: true,
                    //Inline message
                    message: commonstrings.topups.addcarrier.accountdetails.validation.cellnovalid
                },
                equal: {
                    onlyIf: function () { return IsInvalidCarrierAccountNumber(self.AccountNumber()); },
                    //Inline message
                    message: commonstrings.topups.addcarrier.accountdetails.validation.cellnovalid
                }
            }).isModified(false);

            self.RetypeAccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.topups.addcarrier.accountdetails.validation.confirmcellnorequired
                },
                equal: {
                    onlyIf: function () { return !cs.equals(self.AccountNumber(), self.RetypeAccountNumber(), true) },
                    //Inline message
                    message: commonstrings.topups.addcarrier.accountdetails.validation.confirmcellnomatch
                },
                number: {
                    params: true,
                    //Inline message
                    message: commonstrings.topups.addcarrier.accountdetails.validation.confirmcellnovalid
                }
            }).isModified(false);

            if (self.TopUpType == 1) {
                self.AreaCode.extend({
                    required: {
                        params: true,
                        //Inline message
                        message: commonstrings.topups.addcarrier.accountdetails.validation.countrycoderequired
                    }
                }).isModified(false);
            } else {
                self.EditablePhoneNumber.extend({
                    required: {
                        params: true,
                        message: commonstrings.commonvalidation.contactphonerequired
                    },
                    number: {
                        onlyIf: function () { return cs.IsInvalidPhoneNumber(self.EditablePhoneNumber()); },
                        //Inline message
                        message: commonstrings.commonvalidation.contactphonevalid
                    },
                    minLength: {
                        params: 10,
                        //Inline message
                        message: commonstrings.commonvalidation.contactphonevalid
                    },
                    maxLength: {
                        onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.EditablePhoneNumber()); },
                        //Inline message
                        message: commonstrings.commonvalidation.contactphonevalid
                    }
                }).isModified(false);
            }
        }

        function IsInvalidCarrierAccountNumber(phoneNumber) {
            if (phoneNumber != null && self.DestinationCountry == 'United States') {
                return !(ko.validation.rules.maxLength.validator(phoneNumber.replace(/-/g, ''), 10)
                && ko.validation.rules.minLength.validator(phoneNumber.replace(/-/g, ''), 10));
            }
            return false;
        }

        function InitializeDestinationCountries() {
            $.when(dataModel.GetCountriesByTransactionType(12))
           .done(function (data) {
               var index = data.indexOf(data.filter(function (x) {
                   return x.Value == "840";
               })[0]);

               data.splice(0, 0,
                   new Object({ Code: "", Text: reloadstrings.selectreloadcarrier.addcarrier.country, Value: "0" }),
                   data.splice(index, 1)[0]);
               self.Countries(data);
               $("#select-new-country").val(self.Countries()[0].Value);
           });
        }

        function resetCarrier() {
            self.AccountNumber(null);
            self.RetypeAccountNumber(null);
            self.FirstName(null);
            self.LastName(null);
            self.AccountNickName('');
            self.DestinationCountry = null;

            self.AccountNumber.isModified(false);
            self.RetypeAccountNumber.isModified(false);
            self.FirstName.isModified(false);
            self.LastName.isModified(false);

            if (self.TopUpType == 1 && $("#select-new-country").val() == 0) {
                self.AreaCode('');
                self.IsEditAreaCode(false);
                self.AreaCode.isModified(false);
            }

            if (self.TopUpType == 2) {
                self.EditablePhoneNumber("");
                self.EditablePhoneNumber.isModified(false);
            }
        }

        function resetAutoComplete() {
            $('#input-new-carrier-name').autocomplete({
                lookup: []
            }).val("");

            self.CarrierNameValidType(0);
            searchCarrierModal = { OriginalCarrierName: '', OriginalKey: 0 };
        }

        var trackCloseTotalClick = trackEvent;
        self.closeAddCarrier = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: self.TopUpType == 1 ? track.CategoryEnum.AddNewCarrierReload : track.CategoryEnum.AddNewCarrierPinless,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: self.TopUpType == 1 ? track.PageEnum.AddNewCarrierReload : track.PageEnum.AddNewCarrierPinless,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: self.TopUpType == 1 ? track.CategoryEnum.AddNewCarrierReload : track.CategoryEnum.AddNewCarrierPinless,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: self.TopUpType == 1 ? "Add New Carrier-reload" : "Add New Carrier-pinless",
                eventPage: self.TopUpType == 1 ? track.PageEnum.AddNewCarrierReload : track.PageEnum.AddNewCarrierPinless,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});