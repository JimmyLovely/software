﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'instant-bank-verification-component'], function (ko, cs, app, dataModel) {
    return function (params) {
        var self = this;
        self.PaymentMethods = ko.observable();
        self.BankAccountFee = ko.observable();
        self.CreditDebitFee = ko.observable();
        self.HasBankAccount = ko.observable(false);
        self.HasCarditOrDebitCard = ko.observable(false);
        self.addBankAccountFlag = ko.observable(false);
        self.addCreditDebitFlag = ko.observable(false);
        self.lastPaymentMethodId = null;
        self.linkIBVAccountFlag = ko.observable(false);
        self.reLinkIBVAccountFlag = ko.observable(false);
        self.IBVStatus = ko.observable(cs.IBVStatus.Normal);
        self.existedPaymentMethod = ko.observable(null);

        var isAddIBV = false;

        if (params.api) {
            params.api(this);
        }

        self.GetPaymentMethods = function () {
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
            .done(function (result) {
                $.each(result, function (index, paymentMethod) {
                    paymentMethod.Selected = ko.observable(false);
                    paymentMethod.IsVerifying = ko.observable(false);
                });
                initializePaymentMethods(result, params.defaultValue());

                if (params.reLinkPaymentMethod() && params.reLinkPaymentMethod().PaymentMethodId > 0) {
                    var paymentMethods = self.PaymentMethods();
                    $.each(paymentMethods, function (index, d) {
                        d.Selected(d.PaymentMethodId === params.reLinkPaymentMethod().PaymentMethodId);
                    });
                    self.PaymentMethods(paymentMethods);
                }
            });
        }

        self.GetPaymentMethods();

        self.OpenNewModal = function () {
            self['addCreditDebitFlag'](false);
            InitializePaymentMethodModel('modal-credit-debit-account', 'addCreditDebitFlag');
        }

        function InitializePaymentMethodModel(modalId, flagName) {
            cs.closeModalCallBack(modalId, function () {
                self[flagName](false);
                if (modalId == 'modal-link-ibv-account') {
                    window.removeEventListener("message", dataModel.ibvPostMessage);
                }
            });

            self[flagName](true);
            cs.openModal(modalId);
        }

        self.GoToTransactionDetails = function (paymentMethod, ignoreConvert) {
            if (paymentMethod.IsBank && paymentMethod.IsIBVAccount) {
                $.each(self.PaymentMethods(), function (index, p) {
                    p.IsVerifying(false);
                });
                self.IBVStatus(cs.IBVStatus.Normal);
            }

            if (!self.lastPaymentMethodId || self.lastPaymentMethodId != paymentMethod.PaymentMethodId) {
                initializePaymentMethods(self.PaymentMethods(), paymentMethod);

                if (paymentMethod.IsBank) {
                    $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                       .done(function (result) {
                           if (!paymentMethod.IsIBVAccount && !ignoreConvert) {
                               $.each(self.PaymentMethods(), function (index, p) {
                                   p.IsVerifying(p.PaymentMethodId === paymentMethod.PaymentMethodId);
                               });
                               self.lastPaymentMethodId = null;
                               self.IBVStatus(cs.IBVStatus.Verifying);
                               return;
                           }

                           self.lastPaymentMethodId = paymentMethod.PaymentMethodId;
                           app.factoryFunc("GoToTransactionDetails", paymentMethod);
                       })
                       .fail(function () {
                           self.lastPaymentMethodId = paymentMethod.PaymentMethodId;
                           app.factoryFunc("GoToTransactionDetails", paymentMethod, true);
                       })
                } else {
                    self.lastPaymentMethodId = paymentMethod.PaymentMethodId;
                    self.IBVStatus(cs.IBVStatus.Normal);
                    app.factoryFunc("GoToTransactionDetails", paymentMethod, true);
                }
            } else {
                self.IBVStatus(cs.IBVStatus.Normal);
                app.factoryFunc("GoToTransactionDetails", paymentMethod);
            }
        }

        self.CancelVerification = function () {
            var canceledPaymenthod = removeVerifyingStatus();
            
            app.factoryFunc("GoToTransactionDetails", canceledPaymenthod, true);
        }

        function removeVerifyingStatus() {
            var canceledPaymenthod = null;

            $.each(self.PaymentMethods(), function (index, p) {
                if (p.IsVerifying()) {
                    self.existedPaymentMethod(p);
                    p.IsVerifying(false);
                    canceledPaymenthod = p;
                    return false;
                }
            });
            self.IBVStatus(cs.IBVStatus.Normal);

            return canceledPaymenthod;
        }

        self.DoVerificationNow = function () {
            $.when(dataModel.checkIBVNetwork())
            .done(function (result) {
                InitializePaymentMethodModel('modal-link-ibv-account', 'linkIBVAccountFlag');
                setTimeout(function () {
                    dataModel.addIBVPostMessageListener();
                    $("#ibv-submit-form").empty();
                    $("#ibv-submit-form").append(result);
                    document.getElementById('rsessionPost').submit();

                    removeVerifyingStatus();

                }, 500);

                dataModel.setFastLinkEvent(function (data) {
                    AddIBVPaymentMethod(data);
                })
            })
            .fail(function () {
                removeVerifyingStatus();
            })
        }

        function AddIBVPaymentMethod(data) {
            var newAddedPaymentMethod = null;
            if (!isAddIBV) {
                var tempPaymentMethods = self.PaymentMethods();
                $.each(tempPaymentMethods, function (index, p) {
                    if (p.Selected()) {
                        newAddedPaymentMethod = p;
                    }
                });
            }

            if (!newAddedPaymentMethod) {
                newAddedPaymentMethod = {};
            }
            newAddedPaymentMethod.CardName = data.AccountName;
            if (data.AccountType == "CHECKING") {
                newAddedPaymentMethod.AccountTypeId = 3
            } else if (data.AccountType == "SAVINGS") {
                newAddedPaymentMethod.AccountTypeId = 4
            }
            newAddedPaymentMethod.AccountRoutingNumber = data.BankTransferCode;
            newAddedPaymentMethod.CardNumber = data.AccountNumber;
            newAddedPaymentMethod.IsBank = true;
            newAddedPaymentMethod.IBVAccount = data;
            newAddedPaymentMethod.IsIBVAccount = true;
            newAddedPaymentMethod.IsDefault = false;
            newAddedPaymentMethod.PaymentProviderId = !!app.senderInfo() ? !!app.senderInfo().PosPaymentConfig() ? app.senderInfo().PosPaymentConfig().BankAccountProviderId : 2 : 2;

            cs.AjaxByLoading({
                url: '/PaymentMethod/AddPaymentMethod',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(newAddedPaymentMethod))
            })
            .done(function (data) {
                data.Selected = ko.observable(true);
                self.CompletedAddBankAccount(data);
            })
        }

        self.credentialChangedReLink = function (paymentMethodId) {
            $.when(dataModel.reVerify(paymentMethodId))
            .done(function (result) {
                InitializePaymentMethodModel('modal-link-ibv-account', 'linkIBVAccountFlag');
                setTimeout(function () {
                    dataModel.addIBVPostMessageListener();
                    $("#ibv-submit-form").empty();
                    $("#ibv-submit-form").append(result);
                    document.getElementById('rsessionPost').submit();

                    self.lastPaymentMethodId = null;
                }, 500);

                dataModel.setFastLinkEvent(function (data) {
                    AddIBVPaymentMethod(data);
                })
            })
            .fail(function () {
                self.removeVerifyingStatus();
            })
        }

        self.BackToAmountToSend = function () {
            app.factoryFunc("BackToAmountToSend");
        }

        self.InitializeNewCreditAccount = function () {
            cs.closeModalCallBack('modal-credit-debit-account', function () {
                self.addCreditDebitFlag(false);
            });
            self.addCreditDebitFlag(true);
            cs.openModal('modal-credit-debit-account');
        }

        self.InitializeNewBankAccount = function () {
            $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
            .done(function (result) {
                self.IBVStatus(cs.IBVStatus.AddingPrompt);
            })
            .fail(function () {
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            })
        }

        self.promptIBVResult = function (isIBV) {
            if (isIBV) {
                self.IBVStatus(cs.IBVStatus.Normal);
                self.DoVerificationNow();
                isAddIBV = true;
            } else {
                self.IBVStatus(cs.IBVStatus.Normal);
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
        }

        self.continueAddBankAccount = function (isContinue) {
            if (isContinue) {
                InitializePaymentMethodModel('modal-bank-account', 'addBankAccountFlag');
            }
            self.IBVStatus(cs.IBVStatus.Normal);
        }

        self.CompletedAddBankAccount = function (paymentMethod) {
            var paymentMethods = self.PaymentMethods();

            var isConvert = false;

            for (var i = 0; i < paymentMethods.length; i++) {
                if (paymentMethods[i].PaymentMethodId == paymentMethod.PaymentMethodId) {
                    paymentMethods[i] = paymentMethod;
                    paymentMethods[i].IsVerifying = ko.observable(false);
                    isConvert = true;
                }
            }

            if (isConvert) {
                self.PaymentMethods(paymentMethods);
                self.GoToTransactionDetails(paymentMethod);
                return;
            }

            var tempPaymentMethod = {
                PaymentMethodId: paymentMethod.PaymentMethodId,
                CardName: paymentMethod.CardName,
                CardNickname: paymentMethod.CardNickname,
                DisplayCardNumber: paymentMethod.DisplayCardNumber,
                IsBank: paymentMethod.IsBank,
                Fee: 0,
                AccountTypeId: paymentMethod.AccountTypeId,
                AccountType: paymentMethod.AccountType,
                Selected: ko.observable(true),
                IsVerifying: ko.observable(false),
                IsIBVAccount: paymentMethod.IsIBVAccount
            };

            var paymentMethods = self.PaymentMethods() || [];

            $.each(paymentMethods, function (index, p) {
                p.Selected(false)
            });
            paymentMethods.push(tempPaymentMethod);
            self.PaymentMethods(paymentMethods);
            self.lastPaymentMethodId = tempPaymentMethod.PaymentMethodId;
            self.GoToTransactionDetails(tempPaymentMethod, true);
        }

        function initializePaymentMethods(paymentMethods, selectedPaymentMethod) {
            if (!paymentMethods || paymentMethods.length <= 0) {
                return self.PaymentMethods([]);
            }

            var paymentMethodId = selectedPaymentMethod && selectedPaymentMethod.PaymentMethodId;
            $.each(paymentMethods, function (index, p) {
                p.Selected(p.PaymentMethodId == paymentMethodId);

                if (p.IsBank) {
                    self.HasBankAccount(true);
                } else {
                    self.HasCarditOrDebitCard(true);
                }
            });
            self.PaymentMethods(paymentMethods);
        }

        self.setPaymentMethod = function (paymentMethodId) {
            if (self.PaymentMethods()) {
                $.each(self.PaymentMethods(), function (index, p) {
                    p.Selected(p.PaymentMethodId == paymentMethodId);
                    self.lastPaymentMethodId = p.PaymentMethodId == paymentMethodId ? paymentMethodId : null;
                });
            }
        }

        self.initializePaymentMethod = function () {
            $.each(self.PaymentMethods() || [], function (index, p) {
                p.Selected(false);
                p.IsVerifying(false);
            });
            self.lastPaymentMethodId = null;
            self.BankAccountFee(null);
            self.CreditDebitFee(null);
        };
    };
});