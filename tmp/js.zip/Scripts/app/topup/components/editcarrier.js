﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;
        cs.deepClone(ko.mapping.toJS(params.carrier), self);

        self.CarrierBasic.AreaCode = ko.observable(self.CarrierBasic.AreaCode);
        self.CarrierBasic.CustomDisplayAccountNumber = ko.observable(self.CarrierBasic.CustomDisplayAccountNumber);
        self.CarrierBasic.CustomRetypeAccountNumber = ko.observable(self.CarrierBasic.CustomRetypeAccountNumber);
        self.CarrierBasic.FirstName = ko.observable(self.CarrierBasic.FirstName);
        self.CarrierBasic.LastName = ko.observable(self.CarrierBasic.LastName);
        self.CarrierBasic.AccountNickName = ko.observable(self.CarrierBasic.AccountNickName);
        self.CarrierBasic.CountryCode = ko.observable(self.CarrierBasic.CountryCode);

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.EditNewCarrierReload, track.PageEnum.EditNewCarrierReload);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        track.generateErrorMessageTrack(track.CategoryEnum.EditNewCarrierReload, track.PageEnum.EditNewCarrierReload);
        // End appsflyer track event

        self.CarrierBasic.FirstName.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.firstnamerequired
            },
            //Inline message
            minTrimLength: { params: 2, message: commonstrings.commonvalidation.firstnameminlength },
            maxLength: { params: 50, message: commonstrings.commonvalidation.firstnamemaxlength },
            equal: {
                onlyIf: function () { return self.CarrierBasic.FirstName() != "" && cs.IsInvalidName(self.CarrierBasic.FirstName()) != 0 },
                //Inline message
                message: function () { return cs.IsInvalidName(self.CarrierBasic.FirstName()) == 1 ? commonstrings.commonvalidation.firstnamestart : commonstrings.commonvalidation.firstnameinvalid }
            }
        }).isModified(false);

        self.CarrierBasic.LastName.extend({
            required: {
                params: true,
                message: commonstrings.commonvalidation.lastnamerequired
            },
            //Inline message
            minTrimLength: { params: 2, message: commonstrings.commonvalidation.lastnameminlength },
            maxLength: { params: 50, message: commonstrings.commonvalidation.lastnamemaxlength },
            equal: {
                onlyIf: function () { return self.CarrierBasic.LastName() != "" && cs.IsInvalidName(self.CarrierBasic.LastName()) != 0 },
                //Inline message
                message: function () { return cs.IsInvalidName(self.CarrierBasic.LastName()) == 1 ? commonstrings.commonvalidation.lastnamestart : commonstrings.commonvalidation.lastnameinvalid }
            }
        }).isModified(false);


        self.CarrierBasic.AreaCode.extend({
            required: {
                params: true,
                message: commonstrings.topups.addcarrier.accountdetails.validation.countrycoderequired
            }
        }).isModified(false);

        function IsInvalidCarrierAccountNumber(phoneNumber) {
            if (phoneNumber != null && self.CarrierBasic.DestinationCountry == 'United States') {
                return !(ko.validation.rules.maxLength.validator(phoneNumber.replace(/-/g, ''), 10)
                && ko.validation.rules.minLength.validator(phoneNumber.replace(/-/g, ''), 10));
            }
            return false;
        }

        function isVaildAccountNumber(accountNumber) {
            if (accountNumber) {
                return !ko.validation.rules.number.validator(accountNumber.replace(/-/g, ''), true);
            }

            return false;
        }

        self.CarrierBasic.CustomDisplayAccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.topups.addcarrier.accountdetails.validation.cellnorequired
            },
            equal: {
                onlyIf: function () { return IsInvalidCarrierAccountNumber(self.CarrierBasic.CustomDisplayAccountNumber()) },
                //Inline message
                message: commonstrings.topups.addcarrier.accountdetails.validation.cellnovalid
            }
        }).isModified(false);

        self.CarrierBasic.CustomRetypeAccountNumber.extend({
            required: {
                params: true,
                //Inline message
                message: commonstrings.topups.addcarrier.accountdetails.validation.confirmcellnorequired
            },
            equal: {
                onlyIf: function () {
                    if (!self.CarrierBasic.CustomDisplayAccountNumber() || !self.CarrierBasic.CustomRetypeAccountNumber()) {
                        return true;
                    }

                    return !(self.CarrierBasic.CustomDisplayAccountNumber().replace(/-/g, '') == self.CarrierBasic.CustomRetypeAccountNumber().replace(/-/g, ''));
                },
                //Inline message
                message: commonstrings.topups.addcarrier.accountdetails.validation.confirmcellnomatch
            }
        }).isModified(true);

        self.CarrierBasic.AccountNickName.extend({
            //Inline message
            maxLength: { params: 50, message: commonstrings.commonvalidation.nicknamemaxlength },
        }).isModified(false);

        var updateCarrierStatus = new cs.executeStatus();
        self.updateCarrier = function (element) {
            if (updateCarrierStatus.isExecuting()) {
                return;
            }

            var trackSaveTotalClick = trackEvent;
            trackSaveTotalClick("Save");

            if (cs.isDisabled(element)) {
                return;
            }
            updateCarrierStatus.setExecuting();

            self.CarrierBasic.error = ko.validation.group(self.CarrierBasic);
            if (self.CarrierBasic.isValid()) {
                var carrierModel = ko.toJS(ko.utils.unwrapObservable(self.CarrierBasic));
                carrierModel.AccountNumber = carrierModel.CustomDisplayAccountNumber.replace(/-/g, '');
                cs.AjaxBySpinner({
                    url: '/TopUp/SelfServiceUpdateReloadCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(carrierModel)
                }, element)
                .done(function (data) {
                    trackSaveTimeOnPage();

                    if (typeof params.completedEditCarrier == 'function') {
                        params.completedEditCarrier(data);
                    }

                    $.when(cs.closeModal())
                    .done(function () {
                        updateCarrierStatus.complete();
                    });
                })
                .fail(function () {
                    updateCarrierStatus.complete();
                    cs.deepClone(ko.mapping.toJS(params.carrier), self);
                });
            }
            else {
                updateCarrierStatus.complete();
                self.CarrierBasic.errors.showAllMessages();
            }
        }

        var trackCloseTotalClick = trackEvent;
        self.closeEditReload = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.EditNewCarrierReload,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.EditNewCarrierReload,
                    source: app.page().name
                });
            });
        };

        function trackTotalLoads() {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.EditNewCarrierReload,
                    eventAction: T.ActionEnum.ScreenView,
                    eventLabel: "Edit New Carrier-reload",
                    eventPage: T.PageEnum.EditNewCarrierReload,
                    source: app.page().name
                });
            });
        }

        trackTotalLoads();
    }
});