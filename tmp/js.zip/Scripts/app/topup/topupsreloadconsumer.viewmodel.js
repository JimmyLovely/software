﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'R', 'TrackEvent', 'Plugins'], function (ko, cs, app, dataModel, commonstrings, R, track) {
    function TopUpsReloadViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.topupsreload;

        self.ShowCarrierPicker = ko.observable(false);
        self.ShowTransactionDetails = ko.observable(false);
        self.ShowTransactionDone = ko.observable(false);
        self.ShowQuickPay = ko.observable(false);

        self.SelectCarrierCompleted = ko.observable(false);
        self.AmountToSendCompleted = ko.observable(false);
        self.SenderPaymentCompleted = ko.observable(false);

        ko.components.register('topups-set-amount', {
            viewModel: { require: 'topups-set-amount-js' },
            template: { require: 'text!topups-set-amount-html' }
        });

        self.TransactionStart = ko.observable(false);
        self.IsAddedPromotionCode = ko.observable(false);
        self.IsPromotionCodeValid = ko.observable(false);
        self.ShowPromotionCodeErrorMessage = ko.observable(true);
        self.IsClickToPay = ko.observable(false);
        self.CalculateAgain = false;
        self.reLinkPaymentMethod = ko.observable(null);

        self.SelectedCarrier = ko.observable();
        self.TransactionDetail = ko.observable();
        self.SelectedPaymentMethod = ko.observable();
        self.PaymentMethodAPI = ko.observable();
        //For click to pay
        self.SelectedBillingAccountId = ko.observable();

        self.init = function () {
        };

        self.controllers = {
            '/StartPositionCode/:startPositionCode': function (startPositionCode) {
                if (startPositionCode == 'FromQuickTransaction') {
                    cs.RemoveQuickTransactionPage();
                    cs.ToggleQuickReload();
                }
                else {
                    cs.ShowQuickButton();
                }
                self.GoToSelectCarrier();

                //Data Capture: capture transaction info which start from dashboard or left bar.
                cs.CaptureTransactionInfo(startPositionCode, cs.TransactionTypes.TopUpReloadOrPinless);
            },
            '/StartPositionCode/:startPositionCode/:receiptNumber/:billingAccountId': function (startPositionCode, receiptNumber, billingAccountId) {
                if (receiptNumber === '0') {
                    initTabView("panel-amount", true);
                    self.IsClickToPay(true);
                    self.SelectedCarrier(null);
                    self.SelectedBillingAccountId(billingAccountId);

                    //Data Capture: Initialize Transaction start from quick pay.
                    cs.AddTransactionStart(
                                              cs.TransactionInitialPositions.FromClickToPay,
                                              cs.QuickWays.NormalPay,
                                              cs.TransactionTypes.TopUpReloadOrPinless,
                                              cs.GetDateTimeOffset()
                                          );
                } else {
                    initQuickPayPage();

                    var transactionInitialPositions;
                    if (startPositionCode == "FromRecentTransaction") {
                        transactionInitialPositions = cs.TransactionInitialPositions.FromRecentTransaction;
                    }else if (startPositionCode == "FromTxnHistory") {
                        transactionInitialPositions = cs.TransactionInitialPositions.FromTxnHistory;
                    } else if (startPositionCode == "FromManageCarriers") {
                        transactionInitialPositions = cs.TransactionInitialPositions.FromManageCarriers;
                    }
                    cs.AddTransactionStart(
                                              transactionInitialPositions,
                                              cs.QuickWays.QuickPay,
                                              cs.TransactionTypes.TopUpReloadOrPinless,
                                              cs.GetDateTimeOffset()
                                          );

                    return cs.BaseAjax({
                        url: '/TopUp/InitializeQuickToPayByReceiptNumber',
                        type: "POST",
                        dataType: "json",
                        contentType: "application/json",
                        data: JSON.stringify({ "receiptNumber": receiptNumber, 'isPinless': false })
                    }, true)
                    .done(function (data) {
                        var paymentMethod = data.PaymentMethod;

                        // remove credit card function
                        if (!paymentMethod.IsBank) {
                            initQuickPayPaymentMethod(data);
                            return;
                        }

                        if (paymentMethod.IsIBVAccount) {
                            $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                             .done(function (result) {
                                 $.when(dataModel.checkIBVBalance(paymentMethod, data.TopUpReloadTransaction.AmountToLoad.Value))
                                .done(function (result) {
                                    if (result.verifyPassed) {
                                        data.TopUpReloadTransaction.IsIBVVerified = true;
                                        InitializeTransactionQuickPay(data);
                                    } else if (!!result && result.isCredentialChanged) {
                                        SwitchPaymentMethodForQuickPayIBVFailed(data);
                                        self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                        return;
                                    } else {
                                        SwitchPaymentMethodForQuickPayIBVFailed(data);
                                        return;
                                    }
                                })
                                 .fail(function () {
                                     InitializeTransactionQuickPay(data);
                                 });
                             })
                             .fail(function () {
                                 InitializeTransactionQuickPay(data);
                             })
                        } else {
                            InitializeTransactionQuickPay(data);
                        }
                    })
                    .fail(function (xhr, status) {
                        var exception = $.parseJSON(xhr.responseText);
                        if (exception.ReturnCode == 17170433) {// Bill account was not found.
                            initTabView("panel-recipient", true);
                        } else if (exception.ReturnCode == 16842756) { // amount is invalid.
                            initQuickPayAmountToLoad(exception.Data);
                        } else if (exception.ReturnCode == 17170435) {// Payment method was not found.
                            initQuickPayPaymentMethod(exception.Data);
                        } else if (exception.Message) {
                            try {
                                var message = $.parseJSON(exception.Message).reason;
                                cs.showTransactionNotFoundError(message);
                            } catch (e) {
                                cs.showTransactionNotFoundError(exception.Message);
                            }
                        } else {
                            cs.handleAjaxError(xhr.responseText);
                        }
                    });
                }
            }
        };

        function SwitchPaymentMethodForQuickPayIBVFailed(data) {
            initQuickPayPaymentMethod(data);
            var paymentMethods = self.PaymentMethodAPI().PaymentMethods();
            if (paymentMethods) {
                $.each(paymentMethods, function (index, d) {
                    d.Selected(d.PaymentMethodId === data.PaymentMethod.PaymentMethodId);
                })
                self.SelectedPaymentMethod(data.PaymentMethod);
                self.PaymentMethodAPI().PaymentMethods(paymentMethods);
            };

            self.SelectedPaymentMethod(data.PaymentMethod);
            self.reLinkPaymentMethod(data.PaymentMethod);
        }

        // Start appsflyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionReceiptPage
            });
        };

        var trackPageLoad = function () {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.TUReloadFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Reload",
                eventPage: track.PageEnum.Reload,
                source: app.page().name,
                eventStructure: track.StructureEnum.InitiatedCheckout,
                eventName: 'af_initiated_checkout_TU_Reload',
                contentType: app.page().name.indexOf('TopUpsReloadConsumer') != -1 ? "TU-reload" : "TU-pinless",
            });
        }

        var trackTransactionSuccessfully = function (amount, receiptNumber) {
            var isReload = app.page().name.indexOf('TopUpsReloadConsumer') != -1;
            require(['TrackEvent'], function (T) {
                track.trackEvent({
                    sendType: track.AF,
                    eventCategory: isReload ? track.CategoryEnum.TUReloadFlow : track.CategoryEnum.TUPinlessFlow,
                    eventAction: track.ActionEnum.ButtonClick,
                    eventLabel: "Confirm & Send",
                    eventPage: isReload ? track.PageEnum.Reload : track.PageEnum.Pinless,
                    source: app.page().name,
                    eventStructure: track.StructureEnum.Purchase,
                    eventName: isReload ? 'af_purchase_TU_Reload' : 'af_purchase_TU_Pinless',
                    amount: amount,
                    revenue: amount,
                    contentType: isReload ? "TU-reload" : "TU-pinless",
                    currency: 'USD',
                    receiptId: receiptNumber
                });
            });
        }

        var trackRecipientPageTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: 'TimeOnPage',
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        }

        var trackViewTransactionDetailsTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: track.LabelEnum.ViewTransactionDetails,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        }

        var trackFinishTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.Finish));

        var trackEmailTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.EmailReceipt));

        var trackPrintTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.PrintReceipt));
        // End appsflyer track event

        self.afterRender = function () {
            dataModel.checkPersonInfo();

            $("#main").removeClass()
            $("#main").addClass("mod-c-money-transfer mod-c-top-ups reload");

            app.cacheComponent(['topups-set-amount', 'topups-payment-method']);

            trackPageLoad();
        }

        self.dispose = function () { };

        //Begin: Initialize Tab View
        self.GoToSelectCarrier = function () {
            self.SelectedCarrier(null);
            self.TransactionDetail(null);
            self.SelectedPaymentMethod(null);
            self.SelectedBillingAccountId(null);

            initTabView("panel-recipient", true);
        }

        self.BackToSelectCarrier = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            backToTabView("panel-recipient");
        }

        self.GoToAmountToSend = function (carrier) {
            if (carrier) {
                self.SelectedCarrier(carrier);
                self.TransactionDetail(null);
                self.SelectedPaymentMethod(null);

                return initTabView("panel-amount", true);
            }
            triggerToTabView("panel-amount");
        };

        self.BackToAmountToSend = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            backToTabView("panel-amount");
        }

        self.AmountChanged = function () {
            self.SelectedPaymentMethod(null);
            self.PaymentMethodAPI().IBVStatus = ko.observable(cs.IBVStatus.Normal);
            initTabView("panel-payment", true, false);
        }

        self.GoToSenderPayment = function (transactionDetail) {
            if (transactionDetail) {
                transactionDetail = convertToTransactionDetail(transactionDetail);
                self.TransactionDetail(transactionDetail);
                self.SelectedPaymentMethod(null);
                if (self.PaymentMethodAPI()) {
                    self.PaymentMethodAPI().initializePaymentMethod();
                }
                initTabView("panel-payment", true);
                return $.when(GetTopUpReloadServiceTypes(self.SelectedCarrier().RppsBillingAccountId, self.TransactionDetail().AmountToLoad.Value(), true))
                       .done(function () {
                           triggerToTabView("panel-payment");
                       });
            }
            triggerToTabView("panel-payment");
        };

        self.BackToSenderPayment = function () {
            backToTabView("panel-payment");
        };

        self.GoToTransactionDetails = function (paymentMethod, ignoreConvert) {
            if (!self.checkAmountToLoad(ko.mapping.toJS(self.TransactionDetail()))) {
                return;
            }

            //IBV Data capture.
            cs.IBVDataCaptureMmodel.UpdateIbvActivity(paymentMethod.PaymentMethodId);

            if (paymentMethod || self.CalculateAgain) {
                if (paymentMethod) {
                    self.SelectedPaymentMethod(paymentMethod);
                    self.TransactionDetail().SelectedPaymentMethodId = paymentMethod.PaymentMethodId;
                    self.TransactionDetail().PromotionCode('');
                }

                $.when(Calculate())
                .done(function () {
                    if (paymentMethod.IsBank && paymentMethod.IsIBVAccount && !ignoreConvert) {
                        $.when(dataModel.checkIBVBalance(paymentMethod, self.TransactionDetail().AmountToLoad.Value()))
                        .done(function (result) {
                            if (result.verifyPassed) {
                                self.TransactionDetail().IsIBVVerified = true;
                                initTransactionDetailView();
                                self.CalculateAgain = false;
                                // Restore new payment method value
                            } else if (!!result && result.isCredentialChanged) {
                                self.PaymentMethodAPI().existedPaymentMethod(paymentMethod);
                                self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                return;
                            } else {
                                self.PaymentMethodAPI().lastPaymentMethodId = null;
                                return;
                            }
                        })
                        .fail(function () {
                            switchToTransactionDetail();
                        });
                    } else {
                        switchToTransactionDetail();
                    }
                })
                .fail(function () {
                    self.CalculateAgain = true;
                });
            } else {
                initTransactionDetailView();
            }
        }

        function switchToTransactionDetail() {
            initTransactionDetailView();
            self.CalculateAgain = false;
        }

        function initTabView(tabName, isChanged, isTriggerTab) {
            if (isChanged) {
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(false);
                self.ShowQuickPay(false);
                self.IsClickToPay(false);
                switch (tabName) {
                    case 'panel-recipient':
                    case 'panel-amount':
                        self.SelectCarrierCompleted(false);
                    case 'panel-payment':
                        self.AmountToSendCompleted(false);
                    default:
                        self.SenderPaymentCompleted(false);
                }
            }

            switch (tabName) {
                case 'panel-payment':
                    if (isTriggerTab !== false) {
                        self.AmountToSendCompleted(true);
                    }
                case 'panel-amount':
                    self.SelectCarrierCompleted(true);
                default:
                    self.ShowCarrierPicker(true);
                    self.TransactionStart(true);
            }

            if (isTriggerTab !== false) {
                triggerToTabView(tabName);
            }
        }

        function backToTabView(tabName) {
            self.ShowTransactionDetails(false);
            self.ShowTransactionDone(false);
            self.ShowCarrierPicker(true);
            self.ShowQuickPay(false);

            triggerToTabView(tabName);
        }

        function triggerToTabView(tabName) {
            cs.triggerTab(tabName);
            cs.scrollToTab(tabName);
        }

        function initTransactionDetailView() {
            self.ShowCarrierPicker(false);
            self.ShowTransactionDetails(true);

            self.ShowTransactionDone(false);
            self.ShowQuickPay(false);
            cs.SlideToBottom();
            self.SenderPaymentCompleted(true);
        }

        function initQuickPayAmountToLoad(data) {
            self.SelectedCarrier(data.SelfServiceCarrierModel);
            self.SelectedBillingAccountId(data.SelfServiceCarrierModel.RppsBillingAccountId);

            initTabView("panel-amount", true);
        }

        function initQuickPayPaymentMethod(data) {
            self.SelectedCarrier(data.SelfServiceCarrierModel);
            self.SelectedBillingAccountId(data.SelfServiceCarrierModel.RppsBillingAccountId);
            self.TransactionDetail(convertToTransactionDetail(data.TopUpReloadTransaction));
            GetTopUpReloadServiceTypes(self.SelectedCarrier().RppsBillingAccountId, self.TransactionDetail().AmountToLoad.Value());

            initTabView("panel-payment", true);
        }

        //End: Initialize Tab View

        //Start: Transaction
        //The set amount component also need this method, so the param needed.
        self.isAmountToLoadValid = function (transactionDetail) {
            var amountToLoad = parseFloat(cs.GetOriginalNumber(transactionDetail.AmountToLoad.Value));
            var minValue = parseFloat(cs.GetOriginalNumber(transactionDetail.DisplayMinValue.Value));
            var maxValue = parseFloat(cs.GetOriginalNumber(transactionDetail.DisplayMaxValue.Value));

            if (!cs.isAmountValid(amountToLoad)) {
                return commonstrings.commonmessagebox.error, commonstrings.messagebox.validamount;
            }

            if (minValue == maxValue) {
                return '';
            }

            if (amountToLoad < minValue || amountToLoad > maxValue) {
                return commonstrings.commonmessagebox.error, commonstrings.messagebox.allowedamount + "&nbsp;" +
                    transactionDetail.DisplayMinValue.Symbol + transactionDetail.DisplayMinValue.Value + "&nbsp;" + commonstrings.messagebox.to + "&nbsp;" +
                        transactionDetail.DisplayMaxValue.Symbol + transactionDetail.DisplayMaxValue.Value;
            }
            return '';
        };

        self.checkAmountToLoad = function (transactionDetail) {
            var errorMessage = self.isAmountToLoadValid(transactionDetail);
            if (errorMessage) {
                cs.showErrorMessage(commonstrings.commonmessagebox.error, errorMessage);
                return false;
            }

            return true;
        }


        self.ApplyPromoCode = function (element, isQuickPay) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!CheckAmountAndPromoCodeIsValid(element, isQuickPay)) {
                return $.Deferred().reject();
            }
            self.TransactionDetail().PromotionCode(cs.CustomTrim(self.TransactionDetail().PromotionCode()));
            return $.when(Calculate(null, isQuickPay))
            .done(function (result) {
                $("#input-promo-code").val('');
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(true);
            });
        }

        self.RemovePromoCode = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            $.when(ClearPromo())
            .done(function () {
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(false);
            });
        }

        function ClearPromo() {
            self.TransactionDetail().PromotionCode("");
            Calculate();
        }

        self.transStatus = new cs.executeStatus();

        self.GoToTransactionDone = function (element) {
            if (!self.TransactionDetail().IsAgree()) {
                $("#NotAgreeError").fadeIn();
                return;
            }

            if (self.transStatus.isExecuting()) {
                return;
            }
            self.transStatus.setExecuting();
            if (!(self.IsAddedPromotionCode() && self.IsPromotionCodeValid())) {
                self.TransactionDetail().PromotionCode('');
            }

            $.when(Confirm())
            .done(function () {
                self.ShowCarrierPicker(false);
                self.ShowTransactionDetails(false);
                self.ShowTransactionDone(true);
                cs.RegisterExpandCollapse();
                cs.SlideToTop();
                self.transStatus.complete();

                //DataCapture
                UpdateDataCaptureTransactionFee();
            })
            .fail(function (data) {
                self.transStatus.complete();

                if (data.statusText == 'timeout') {
                    cs.showErrorMessage(commonstrings.messagebox.topupfailed, commonstrings.messagebox.timeout);
                    return;
                }

                var tempError = "";
                try {
                    self.transStatus.complete();
                    tempError = JSON.parse(data.responseText);

                } catch (e) {
                    cs.handleAjaxError(e);
                }
                try {
                    var message = JSON.parse(tempError.Message);
                    if (message != null && message.exceptionCode == -462) {
                        ShowPaymentsMethodFailDialog();
                    } else if (message != null && message.exceptionCode == -481) {
                        cs.BaseAjax({
                            url: '/PaymentMethod/GetCurrentPaymentProvider',
                            type: 'get',
                            dataType: 'json'
                        })
                        .done(function (result) {
                            app.senderInfo().PosPaymentConfig(result);
                        });
                        GetTopUpPaymentMethods();

                        ShowPaymentsMethodFailDialog();
                    } else {
                        cs.showErrorMessage(commonstrings.messagebox.topupfailed, tempError.Message);
                    }
                } catch (e) {
                    cs.showErrorMessage(commonstrings.messagebox.topupfailed, tempError.Message);
                }
            });
        };

        function ShowPaymentsMethodFailDialog() {
            $.when(cs.showErrorMessage(commonstrings.messagebox.paymenterror, commonstrings.messagebox.paymentnotsuccess + "&nbsp;<a id='payment-method-link'>" + commonstrings.messagebox.paymentmethod + "</a>&nbsp;" + commonstrings.messagebox.tryagain))
            .done(function () {
                $("#payment-method-link").click(function () {
                    cs.closeModal();
                    if (self.ShowQuickPay()) {
                        self.EditSenderPayment();
                    } else {
                        self.BackToSenderPayment();
                    }
                });
            });
        }

        self.AgreeChange = ko.computed(function () {
            if (self.ShowTransactionDetails() && self.TransactionDetail() && self.TransactionDetail().IsAgree()) {
                $("#NotAgreeError").fadeOut();
            }
        });

        function CheckAmountAndPromoCodeIsValid(element, isQuickPay) {
            var promoCode = cs.CustomTrim(self.TransactionDetail().PromotionCode());

            if (isQuickPay) {
                if (self.isAmountToLoadValid(ko.mapping.toJS(self.TransactionDetail())) != '') {
                    return false;
                }
            } else {
                if (!self.checkAmountToLoad(ko.mapping.toJS(self.TransactionDetail()))) {
                    return false;
                }
            }

            if (!promoCode) {
                self.TransactionDetail().PromotionCode("");
                cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.messagebox.validpromocode);
                cs.closeModalCallBack('modal-error', function () {
                    self.IsPromotionCodeValid(true);
                    self.IsAddedPromotionCode(false);
                });
                return false;
            }
            return true;
        }

        function GetTopUpReloadServiceTypes(carrierId, amountToLoad, isNeedLoading) {
            return cs.AjaxBySpinnerOrLoading({
                url: '/TopUp/GetTopUpReloadServiceTypes',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'carrierId': carrierId, 'amountToSend': cs.GetOriginalNumber(amountToLoad) })
            }, isNeedLoading)
            .done(function (result) {
                var bankAccountFee, creditDebitFee;
                for (var i = result.length; i--;) {
                    var r = result[i];
                    if (r.PaymentMethodTypeId == 3 || r.PaymentMethodTypeId == 4) {
                        bankAccountFee = r.Fee.Symbol + r.Fee.Value;
                    } else {
                        creditDebitFee = r.Fee.Symbol + r.Fee.Value;
                    }
                }
                self.PaymentMethodAPI().BankAccountFee(bankAccountFee);
                self.PaymentMethodAPI().CreditDebitFee(creditDebitFee);
            });
        }

        function Calculate(isShowPromotionCodeError, isquickPay) {
            var element = isquickPay ? '#virtualElement' : null;
            if (!self.TransactionDetail().PromotionCode() && isShowPromotionCodeError != true) {
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(false);
            }

            if (!checkAmountRange()) {
                return $.Deferred().reject();
            }

            var tempTransaction = ko.mapping.toJS(self.TransactionDetail());

            var deferred = $.Deferred();
            cs.AjaxBySpinnerOrLoading({
                url: '/TopUp/SelfServiceCaculateReload',
                dataType: "json",
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ "billingAccountId": self.SelectedCarrier().RppsBillingAccountId, "transactionModel": tempTransaction })
            }, element, true)
            .done(function (result) {
                if (checkAmountChange(tempTransaction)) {
                    return;
                }

                var isAgree = self.TransactionDetail().IsAgree();

                result = convertToTransactionDetail(result);
                result.IsAgree(isAgree);
                self.TransactionDetail(result);
                //DataCapture.
                UpdateDataCaptureTransactionFee();

                if (isquickPay == true) {
                    GetTopUpReloadServiceTypes(self.SelectedCarrier().RppsBillingAccountId, self.TransactionDetail().AmountToLoad.Value(), element);
                }

                deferred.resolve();
            })
            .fail(function (xhr, status) {
                if (checkAmountChange(tempTransaction)) {
                    return;
                }

                var data = $.parseJSON(xhr.responseText);
                if (data.Message.indexOf(-146) != -1) {
                    self.TransactionDetail().PromotionCode('');
                    self.IsPromotionCodeValid(false);
                    self.IsAddedPromotionCode(true);
                    self.ShowPromotionCodeErrorMessage(element != '#virtualElement');

                    // Reomve promotion code and calculate again.
                    Calculate(true, isquickPay);
                } else {
                    cs.handleAjaxError(xhr.responseText, false);
                }

                deferred.reject();
            })

            return deferred;
        }

        function checkAmountChange(tempTransaction) {
            if (Number(cs.GetOriginalNumber(self.TransactionDetail().AmountToLoad.Value())) != Number(cs.GetOriginalNumber(tempTransaction.AmountToLoad.Value))) {
                return true;
            }

            return false;
        }

        function Confirm() {
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceTransactionReload',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "transactionModel": ko.mapping.toJS(self.TransactionDetail()) })
            }, true)
            .done(function (result) {
                result = convertToTransactionDetail(result);
                self.TransactionDetail(result);

                trackTransactionSuccessfully(cs.getValue(result.AmountToSend.Value), self.TransactionDetail().ReceiptNumber.trim());

                trackRecipientPageTimeOnPage();
                track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionReceiptPage, track.PageEnum.TransactionReceiptPage);
            });
        }

        function convertToTransactionDetail(data) {
            data = ko.mapping.toJS(data);

            if (self.TransactionDetail() && self.ShowQuickPay()) {
                data.AmountToLoad.Value = $('#send-amount-input').val();
            }

            data.AmountToLoad.Value = ko.observable(data.AmountToLoad.Value);
            data.PromotionCode = ko.observable(data.PromotionCode || '');
            data.IsAgree = ko.observable(false);
            data.IsChanged = ko.observable(false);
            return data;
        }
        //End: Transaction

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.TransactionDetail().ReceiptNumber, element);

            trackEmailTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.EmailReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        };

        self.PrintTopUpReloadReceipt = function (element) {
            var isPinless = self.SelectedCarrier().BillerName.toLowerCase().indexOf('pinless') > -1;

            cs.AjaxBySpinner({
                url: '/Customers/SelfServicePrintStandardReceipt',
                dataType: "html",
                cache: false,
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'receiptNumber': self.TransactionDetail().ReceiptNumber, 'senderEmailAddress': app.senderInfo().Customer().CustomerBasic.EmailAddress(), 'isPinless': isPinless })
            }, element)
            .done(function (result) {
                cs.PrintTransaction(result, element);
            });

            trackPrintTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.PrintReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        }

        self.GoBack = function () {
            setTimeout(function () {
                cs.fitTextAmountField($("#input-amount"), cs.keepAmountDecimalPlaces($("#input-amount").val()));
            });
        }

        // Start 
        function initQuickPayPage() {
            self.SelectedCarrier(null);
            self.SelectedPaymentMethod(null);
            self.TransactionDetail(null);
            self.SelectedBillingAccountId(null);

            self.ShowCarrierPicker(false);
            self.ShowTransactionDetails(true);
            self.ShowTransactionDone(false);
            self.ShowQuickPay(true);

            self.SelectCarrierCompleted(true);
            self.AmountToSendCompleted(true);
            self.SenderPaymentCompleted(true);
        }

        var quickPayCalculateSuccessfully = false;
        self.QuickPayCalculate = function (isQuickPayCalculate) {
            if (cs.isOpeningModal()) {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'top-ups-confirm-done', 'back-to-amount-send', 'back-to-carrier', 'back-to-payment']);
                return;
            }

            quickPayCalculateSuccessfully = false;
            var delegate = function () {
                //If promotion code has value, then should use apply promo code to calculate the value, or the display would incorrect.
                if (cs.CustomTrim(self.TransactionDetail().PromotionCode()) != "") {
                    return self.ApplyPromoCode(null, isQuickPayCalculate);
                } else {
                    return Calculate(null, isQuickPayCalculate);
                }
            };

            $.when(delegate())
            .done(function () {
                quickPayCalculateSuccessfully = true;
            })
            .fail(function () {
                quickPayCalculateSuccessfully = false;
            })
            .always(function () {
                if (self.TransactionDetail().PaymentAmountReadOnly) {
                    cs.addDisable("send-amount-input");
                }
                else {
                    cs.removeDisable("send-amount-input");
                }
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'top-ups-confirm-done', 'back-to-amount-send', 'back-to-carrier', 'back-to-payment']);
            });
        };


        var quickPayCheckAmountTimer;
        var originalAmount;
        self.InputAmountQuickPaySection = function (amount) {
            if (amount == "" || $('#send-amount-input').hasClass("placeholder-color")) {
                $("#send-amount-input").trigger("change.attribute.amounttosend");
                amount = "0.00";
            }

            self.ShowPromotionCodeErrorMessage(false);
            // format amount
            if (cs.IsMobileDevice()) {
                cs.formatAmountForInput('#send-amount-input', originalAmount);
                amount = $('#send-amount-input').val();
            }
            originalAmount = amount;

            // check amount
            if (originalAmount != undefined && Number(cs.GetOriginalNumber(originalAmount) == Number(cs.GetOriginalNumber(self.TransactionDetail().AmountToLoad.Value())))) {
                return;
            }

            self.TransactionDetail().AmountToLoad.Value(amount);
            if (self.isAmountToLoadValid(ko.mapping.toJS(self.TransactionDetail())) != '') {
                cs.enableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'top-ups-confirm-done', 'back-to-amount-send', 'back-to-carrier', 'back-to-payment']);
                return;
            }
            self.PaymentMethodAPI().lastPaymentMethodId = null;

            if (quickPayCheckAmountTimer) {
                clearTimeout(quickPayCheckAmountTimer);
            }

            cs.disableElements(['input-promo-code', 'promo-code-apply', 'promo-code-remove', 'top-ups-confirm-done', 'back-to-amount-send', 'back-to-carrier', 'back-to-payment']);
            quickPayCheckAmountTimer = setTimeout(function () {
                self.QuickPayCalculate(true);
            }, 500);
        }

        self.CheckAmountBlur = function () {
            self.checkAmountToLoad(ko.mapping.toJS(self.TransactionDetail()));
        }

        function checkAmountRange() {
            var amountToLoad = parseFloat(cs.GetOriginalNumber(self.TransactionDetail().AmountToLoad.Value()));
            var minValue = parseFloat(cs.GetOriginalNumber(self.TransactionDetail().DisplayMinValue.Value));
            var maxValue = parseFloat(cs.GetOriginalNumber(self.TransactionDetail().DisplayMaxValue.Value));

            if (!cs.isAmountValid(amountToLoad)) {
                return false;
            }

            if (minValue == maxValue) {
                return true;
            }

            if (amountToLoad < minValue || amountToLoad > maxValue) {
                return false;
            }
            return true;
        }

        self.EditSenderPayment = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!self.checkAmountToLoad(ko.mapping.toJS(self.TransactionDetail()))) {
                return;
            }

            self.BackToSenderPayment();
        };

        self.QuickPayGoToTransactionDone = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            if (!self.CheckQuickPayCalculate()) {
                return;
            }

            if (self.CheckQuickPayCalculate()) {
                var paymentMethod = self.SelectedPaymentMethod();
                if (paymentMethod.IsIBVAccount) {
                    $.when(dataModel.checkIBVNetwork())
                    .done(function (result) {
                        $.when(dataModel.checkIBVBalance(paymentMethod, self.TransactionDetail().AmountDue.Value))
                        .done(function (result) {
                            if (result.verifyPassed) {
                                self.TransactionDetail().IsIBVVerified = true;
                                self.GoToTransactionDone(element);
                            } else {
                                self.PaymentMethodAPI().lastPaymentMethodId = null;
                                return;
                            }
                        })
                        .fail(function () {
                            self.GoToTransactionDone(element);
                        });
                    })
                    .fail(function () {
                        self.GoToTransactionDone(element);
                    })
                } else {
                    self.GoToTransactionDone(element);
                }
            };
        };
        // End

        // begin: quick pay
        function InitializeTransactionQuickPay(data) {
            self.SelectedCarrier(data.SelfServiceCarrierModel);
            self.SelectedBillingAccountId(data.SelfServiceCarrierModel.RppsBillingAccountId);
            self.SelectedPaymentMethod(data.PaymentMethod);
            if (self.PaymentMethodAPI()) {
                self.PaymentMethodAPI().setPaymentMethod(data.PaymentMethod.PaymentMethodId);
            }
            self.TransactionDetail(convertToTransactionDetail(data.TopUpReloadTransaction));
            GetTopUpReloadServiceTypes(self.SelectedCarrier().RppsBillingAccountId, self.TransactionDetail().AmountToLoad.Value());
            if (self.TransactionDetail().PromotionCode()) {
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(true);
            } else {
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(false);
            }
            quickPayCalculateSuccessfully = true;

            originalAmount = self.TransactionDetail().AmountToLoad.Value();

            //DataCapture
            cs.UpdateTransactionData({
                transactionTypeId: self.TransactionDetail().TransactionType,
                tax: self.TransactionDetail().FeeTaxes.Value,
                fee: self.TransactionDetail().TotalFee.Value,
                total: self.TransactionDetail().AmountDue.Value,
                amount: self.TransactionDetail().AmountToLoad.Value()
            });

            cs.scrollToElement($('.quick-pay-href #send-amount-input'));
        };

        self.QuickPayGoToPaymentMethod = function (topUpReloadConsumerModel) {
            var tempTopUpReloadConsumerModel = ko.mapping.toJS(topUpReloadConsumerModel);
            ko.mapping.fromJS(tempTopUpReloadConsumerModel, {}, self);

            self.BackToSenderPayment();
        };

        self.CheckQuickPayCalculate = function () {
            if (!self.checkAmountToLoad(ko.mapping.toJS(self.TransactionDetail()))) {
                return false;
            }

            if (quickPayCalculateSuccessfully == false) {
                self.QuickPayCalculate(false);
                return false;
            }

            return true;
        };
        // end: quick pay

        //DataCapture
        function UpdateDataCaptureTransactionFee() {
            var data = {
                transactionTypeId: self.TransactionDetail().TransactionType,
                tax: self.TransactionDetail().FeeTaxes.Value,
                fee: self.TransactionDetail().TotalFee.Value,
                total: self.TransactionDetail().AmountDue.Value
            };
            if (self.TransactionDetail().ConfirmationNumber)
                data['receiptNumber'] = self.TransactionDetail().ConfirmationNumber;
            cs.UpdateTransactionData(data);
        }

        function GetTopUpPaymentMethods() {
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
            .done(function (result) {
                $.each(result, function (index, paymentMethod) {
                    paymentMethod.Selected = ko.observable(false);
                });
                self.PaymentMethodAPI().PaymentMethods(result);
            });
        }

        self.viewTransactionDetails = function () {
            var transaction = self.TransactionDetail();
            dataModel.viewTransactionHistoryByReceiptNumber(transaction.ReceiptNumber.trim());

            trackViewTransactionDetailsTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.ViewTransactionDetails);
        }

        self.cancelTransaction = function () {
            app.senderInfo().GoToDashboard();

            if (self.ShowTransactionDone()) {
                trackFinishTotalClicks();
                track.trackTimeOnPageForPageLink(track.LabelEnum.Finish);
            }
        };
    }

    return new TopUpsReloadViewModel();
});