﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, cs, app, dataModel, commonstrings, R, track) {
    function TopUpsPurchaseViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.topupsepin;

        self.TransactionProcess = ko.observable(false);
        self.ConfirmAndReviewProcess = ko.observable(false);
        self.CompleteTransactionProcess = ko.observable(false);
        self.IsQuickPay = ko.observable(false);

        self.SelectCarriersCompleted = ko.observable(false);
        self.SelectPaymentMethodCompleted = ko.observable(false);

        self.TransactionStart = ko.observable(false);
        self.IsAddedPromotionCode = ko.observable(false);
        self.IsPromotionCodeValid = ko.observable(false);

        self.TransactionDetail = ko.observable();
        self.SelectedCarrier = ko.observable();
        self.SelectedPaymentMethod = ko.observable();
        self.PaymentMethodAPI = ko.observable();
        self.reLinkPaymentMethod = ko.observable(null);

        self.CalculateAgain = false;

        self.init = function () {
        };

        self.controllers = {
            '/StartPositionCode/:startPositionCode': function (startPositionCode) {
                if (startPositionCode == 'FromQuickTransaction') {
                    cs.RemoveQuickTransactionPage();
                    cs.ToggleQuickReload();
                }
                else {
                    cs.ShowQuickButton();
                }

                self.initSelectCarrierView();

                //Data Capture: capture transaction info which start from dashboard or left bar.
                cs.CaptureTransactionInfo(startPositionCode, cs.TransactionTypes.TopUpEpin);
            },
            '/StartPositionCode/:startPositionCode/:receiptNumber': function (startPositionCode, receiptNumber) {
                //Data Capture
                var transactionInitialPositions;
                if (startPositionCode == "FromRecentTransaction") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromRecentTransaction;
                }else if (startPositionCode == "FromTxnHistory") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromTxnHistory;
                } else if (startPositionCode == "FromManageCarriers") {
                    transactionInitialPositions = cs.TransactionInitialPositions.FromManageCarriers;
                }
                cs.AddTransactionStart(
                                        transactionInitialPositions,
                                        cs.QuickWays.QuickPay,
                                        cs.TransactionTypes.TopUpEpin,
                                        cs.GetDateTimeOffset()
                                      );

                initQuickPayPage();
                return cs.BaseAjax({
                    url: '/TopUp/TopUpsePinInitializeQuickToPayByReceiptNumber',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify({ "receiptNumber": receiptNumber })
                }, true)
                .done(function (data) {
                    var paymentMethod = data.PaymentMethod;

                    // remove credit card function
                    if (!paymentMethod.IsBank) {
                        self.GoToSenderPayment(data.Carrier);
                        return;
                    }

                    if (paymentMethod.IsIBVAccount) {
                        $.when(dataModel.checkIBVNetwork("StartIbvBankAccount"))
                         .done(function (result) {
                             $.when(dataModel.checkIBVBalance(paymentMethod, data.TopUpPurchaseTransaction.AmountCollected))
                            .done(function (result) {
                                if (result.verifyPassed) {
                                    data.TopUpPurchaseTransaction.IsIBVVerified = true;
                                    self.InitializeTransactionQuickPay(data);
                                } else if (!!result && result.isCredentialChanged) {
                                    SwitchPaymentMethodForQuickPayIBVFailed(data);
                                    self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                    return;
                                } else {
                                    SwitchPaymentMethodForQuickPayIBVFailed(data);
                                    return;
                                }
                            })
                             .fail(function () {
                                 self.InitializeTransactionQuickPay(data);
                             });
                         })
                         .fail(function () {
                             self.InitializeTransactionQuickPay(data);
                         })
                    } else {
                        self.InitializeTransactionQuickPay(data);
                    }
                })
                .fail(function (xhr, status) {
                    var exception = $.parseJSON(xhr.responseText);
                    if (exception.ReturnCode == 17170433) {// Bill account was not found.
                        self.initSelectCarrierView();
                    } else if (exception.ReturnCode == 17170435) {// Payment method was not found.
                        var carrier = exception.Data.Carrier;
                        self.GoToSenderPayment(carrier);
                    } else if (exception.Message) {
                        try {
                            var message = $.parseJSON(exception.Message).reason;
                            cs.showTransactionNotFoundError(message);
                        } catch (e) {
                            cs.showTransactionNotFoundError(exception.Message);
                        }
                    } else {
                        cs.handleAjaxError(xhr.responseText);
                    }
                });
            }
        };

        // Start appsflyer track event
        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionReceiptPage,
                source: app.page().name
            });
        };

        var trackViewTransactionDetailsTotalClicks = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: track.LabelEnum.ViewTransactionDetails,
                eventPage: track.PageEnum.TransactionReceiptPage
            });
        }

        var trackTransactionSuccessfully = function (amount, receiptNumber) {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.TUEPinFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "Confirm & Send",
                eventPage: track.PageEnum.EPin,
                source: app.page().name,
                eventStructure: track.StructureEnum.Purchase,
                eventName: 'af_purchase_TU_ePIn',
                amount: amount,
                revenue: amount,
                contentType: "TU-epin",
                currency: 'USD',
                receiptId: receiptNumber
            });
        }

        var trackRecipientPageTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.TransactionReceiptPage,
                eventAction: track.ActionEnum.Metric,
                eventLabel: 'TimeOnPage',
                eventPage: track.PageEnum.TransactionReceiptPage
            });
        }

        var trackPurchasePageTotalLoads = function () {
            track.trackEvent({
                sendType: track.AF,
                eventCategory: track.CategoryEnum.TUEPinFlow,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: "ePin",
                eventPage: track.PageEnum.EPin,
                source: app.page().name,
                eventStructure: track.StructureEnum.InitiatedCheckout,
                eventName: 'af_initiated_checkout_TU_ePin',
                contentType: 'TU-epin'
            });
        }

        var trackFinishTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.Finish));

        var trackEmailTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.EmailReceipt));

        var trackPrintTotalClicks = R.compose(trackEvent, R.always(track.LabelEnum.PrintReceipt));
        // End appsflyer track event

        function SwitchPaymentMethodForQuickPayIBVFailed(data) {
            var paymentMethods = self.PaymentMethodAPI().PaymentMethods();
            if (paymentMethods) {
                $.each(paymentMethods, function (index, d) {
                    d.Selected(d.PaymentMethodId === data.PaymentMethod.PaymentMethodId);
                })
                self.SelectedPaymentMethod(data.PaymentMethod);
                self.PaymentMethodAPI().PaymentMethods(paymentMethods);
            }
            self.SelectedPaymentMethod(data.PaymentMethod);
            self.reLinkPaymentMethod(data.PaymentMethod);

            var carrier = data.Carrier;
            self.GoToSenderPayment(carrier);
        }

        self.dispose = function () { };

        self.initSelectCarrierView = function () {
            self.SelectCarriersCompleted(false);
            self.SelectPaymentMethodCompleted(false);
            self.IsQuickPay(false);

            self.TransactionStart(true);
            self.TransactionProcess(true);
            self.ConfirmAndReviewProcess(false);
            self.CompleteTransactionProcess(false);
        }

        self.BackToSelectCarrier = function () {
            self.IsQuickPay(false);
            self.TransactionProcess(true);
            self.ConfirmAndReviewProcess(false);
            self.CompleteTransactionProcess(false);

            cs.triggerTab("panel-carriers");
            cs.scrollToTab('panel-carriers');
        }

        self.GoToSenderPayment = function (carrier) {
            if (carrier) {
                self.SelectedCarrier(convertToCarrierModel(carrier));

                if (self.PaymentMethodAPI()) {
                    self.PaymentMethodAPI().initializePaymentMethod();
                }
                self.SelectCarriersCompleted(true);
                self.SelectPaymentMethodCompleted(false);
                self.IsQuickPay(false);

                self.TransactionStart(true);
                self.TransactionProcess(true);
                self.ConfirmAndReviewProcess(false);
                self.CompleteTransactionProcess(false);
                GetServiceTypes(carrier.data.Key, carrier.data.Value);
            }
            cs.triggerTab("panel-carriers-payment");
            cs.scrollToTab('panel-carriers-payment');
        }

        self.BackToAmountToSend = function (transactionDetail) {
            cs.triggerTab("panel-carriers");
            cs.scrollToTab("panel-carriers");
        }

        self.GoToTransactionDetails = function (paymentMethod, ignoreConvert) {
            //IBV Data capture.
            cs.IBVDataCaptureMmodel.UpdateIbvActivity(paymentMethod.PaymentMethodId);

            if (paymentMethod || self.CalculateAgain) {
                if (paymentMethod) {
                    self.SelectedPaymentMethod(paymentMethod);
                }
                self.TransactionDetail({
                    "CarrierKey": self.SelectedCarrier().Key,
                    "PaymentMethodId": self.SelectedPaymentMethod().PaymentMethodId,
                    "IsAgree": ko.observable(false),
                    'PromotionCode': ko.observable('')
                });
                $.when(Calculate())
                .done(function () {
                    if (paymentMethod.IsBank && paymentMethod.IsIBVAccount && !ignoreConvert) {
                        $.when(dataModel.checkIBVBalance(paymentMethod, self.TransactionDetail().AmountCollected))
                        .done(function (result) {
                            if (result.verifyPassed) {
                                self.TransactionDetail().IsIBVVerified = true;
                                initTransactionDetailView();
                                self.CalculateAgain = false;
                                // Restore new payment method value
                            } else if (!!result && result.isCredentialChanged) {
                                self.PaymentMethodAPI().existedPaymentMethod(paymentMethod);
                                self.PaymentMethodAPI().credentialChangedReLink(paymentMethod.PaymentMethodId);
                                return;
                            } else {
                                self.PaymentMethodAPI().lastPaymentMethodId = null;
                                return;
                            }
                        })
                        .fail(function () {
                            // use non-ibv
                            switchToTransactionDetail();
                        });
                    } else {
                        switchToTransactionDetail();
                    }
                })
                .fail(function () {
                    self.CalculateAgain = true;
                });
            } else {
                initTransactionDetailView();
            }
        }

        function switchToTransactionDetail() {
            initTransactionDetailView();
            self.CalculateAgain = false;
            // Restore new payment method value
        }

        self.ApplyPromoCode = function (element) {
            var promoCode = cs.CustomTrim(self.TransactionDetail().PromotionCode());
            if (promoCode != "") {
                $.when(Calculate())
                .done(function (result) {
                    $("#input-promo-code").val('');
                    self.IsPromotionCodeValid(true);
                    self.IsAddedPromotionCode(true);
                });
            }
            else {
                cs.showErrorMessage(commonstrings.commonmessagebox.error, commonstrings.messagebox.validpromocode);
                cs.closeModalCallBack('modal-error', function () {
                    self.IsPromotionCodeValid(true);
                    self.IsAddedPromotionCode(false);
                });
            }
        }

        self.RemovePromoCode = function () {
            $.when(ClearPromo())
            .done(function () {
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(false);
            });
        }

        function ClearPromo() {
            self.TransactionDetail().PromotionCode("");
            Calculate()
        }

        self.AgreeChange = ko.computed(function () {
            if (self.TransactionDetail() && self.TransactionDetail().IsAgree()) {
                $("#confirmError").fadeOut();
            }
        });

        self.transStatus = new cs.executeStatus();
        self.Confirm = function (element) {
            if (self.TransactionDetail().IsAgree()) {

                if (self.transStatus.isExecuting()) {
                    return;
                }

                self.transStatus.setExecuting();
                if (!(self.IsAddedPromotionCode() && self.IsPromotionCodeValid())) {
                    self.TransactionDetail().PromotionCode('');
                }
                $.when(Confirm(element))
                .done(function () {
                    initTransactionDoneView();
                    self.transStatus.complete();
                    //DataCapture
                    if (self.TransactionDetail().ReceiptNumber.length === 20) {
                        cs.UpdateTransactionData({
                            receiptNumber: self.TransactionDetail().ReceiptNumber,
                            transactionTypeId: self.TransactionDetail().TransactionType,
                            tax: self.TransactionDetail().FeeTaxes.Value,
                            fee: self.TransactionDetail().TotalFee.Value,
                            total: self.TransactionDetail().AmountDue.Value
                        });
                    }
                })
                .fail(function (data) {
                    self.transStatus.complete();

                    if (data.statusText == 'timeout') {
                        cs.showErrorMessage(commonstrings.messagebox.topupfailed, commonstrings.messagebox.timeout);
                        return;
                    }
                    var tempError = "";
                    try {
                        self.transStatus.complete();
                        tempError = JSON.parse(data.responseText);

                    } catch (e) {
                        cs.handleAjaxError(e);
                    }
                    try {
                        var message = JSON.parse(tempError.Message);
                        if (message != null && message.exceptionCode == -462) {
                            ShowPaymentsMethodFailDialog();
                        } else if (message != null && message.exceptionCode == -481) {
                            cs.BaseAjax({
                                url: '/PaymentMethod/GetCurrentPaymentProvider',
                                type: 'get',
                                dataType: 'json'
                            })
                            .done(function (result) {
                                app.senderInfo().PosPaymentConfig(result);
                            });
                            GetTopUpPaymentMethods();

                            ShowPaymentsMethodFailDialog();
                        } else {
                            cs.showErrorMessage(commonstrings.messagebox.topupfailed, tempError.Message);
                        }
                    } catch (e) {
                        cs.showErrorMessage(commonstrings.messagebox.topupfailed, tempError.Message);
                    }
                });
            }
            else {
                self.transStatus.complete();
                $("#confirmError").fadeIn();
                return;
            }
        }

        function ShowPaymentsMethodFailDialog() {
            $.when(cs.showErrorMessage(commonstrings.messagebox.paymenterror, commonstrings.messagebox.paymentnotsuccess + "&nbsp;<a id='payment-method-link'>" + commonstrings.messagebox.paymentmethod + "</a>&nbsp;" + commonstrings.messagebox.tryagain))
            .done(function () {
                $("#payment-method-link").click(function () {
                    cs.closeModal();
                    self.BackToSelectPaymentMethodPage();
                });
            });
        }

        self.SelfServiceSendTransactionReceiptEmail = function (element) {
            dataModel.SelfServiceSendTransactionReceiptEmail(self.TransactionDetail().ReceiptNumber.trim(), element);

            trackEmailTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.EmailReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        }

        self.PrintTopUpEpinReceipt = function (element) {
            cs.AjaxBySpinner({
                url: '/Customers/SelfServicePrintStandardReceipt',
                dataType: "html",
                cache: false,
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'receiptNumber': self.TransactionDetail().ReceiptNumber.trim(), 'senderEmailAddress': app.senderInfo().Customer().CustomerBasic.EmailAddress(), 'isPinless': false })
            }, element)
            .done(function (result) {
                cs.PrintTransaction(result, element);
            });

            trackPrintTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.PrintReceipt);
            track.generatePartialTimeOnPageTrack(); // clear time on page track
        }

        function initTransactionDetailView() {
            self.TransactionStart(true);
            self.SelectCarriersCompleted(true);
            self.SelectPaymentMethodCompleted(true);
            self.IsQuickPay(false);

            self.TransactionProcess(false);
            self.ConfirmAndReviewProcess(true);
            self.CompleteTransactionProcess(false);

            cs.SlideToBottom();
        }

        function initQuickPayPage() {
            self.SelectedCarrier(null);
            self.TransactionDetail(null);
            self.SelectedPaymentMethod(null);

            self.SelectCarriersCompleted(true);
            self.SelectPaymentMethodCompleted(true);
            self.IsQuickPay(true);

            self.TransactionProcess(false);
            self.ConfirmAndReviewProcess(true);
            self.CompleteTransactionProcess(false);

            cs.SlideToTop();
        }

        function initTransactionDoneView() {
            self.SelectCarriersCompleted(true);
            self.SelectPaymentMethodCompleted(true);
            self.IsQuickPay(false);

            self.TransactionProcess(false);
            self.ConfirmAndReviewProcess(false);
            self.CompleteTransactionProcess(true);
            cs.RegisterExpandCollapse();
            cs.SlideToTop();
        }

        function GetServiceTypes(carrierKey, amountToSend) {
            return cs.BaseAjax({
                url: '/TopUp/GetEpinServiceTypes',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ 'carrierKey': carrierKey, 'amountToSend': amountToSend })
            })
             .done(function (result) {
                 for (var i = 0; i < result.length; i++) {
                     if (result[i].PaymentMethodTypeId == 3 || result[i].PaymentMethodTypeId == 4) {
                         self.PaymentMethodAPI().BankAccountFee(result[i].Fee.Symbol + result[i].Fee.Value);
                     } else {
                         self.PaymentMethodAPI().CreditDebitFee(result[i].Fee.Symbol + result[i].Fee.Value);
                     }
                 }
             });
        }

        function Calculate(isShowPromotionCodeError) {
            if ((!self.TransactionDetail() || !self.TransactionDetail().PromotionCode()) && isShowPromotionCodeError != true) {
                self.IsPromotionCodeValid(true);
                self.IsAddedPromotionCode(false);
            }

            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceCaculatePurchase',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "purchaseModel": ko.mapping.toJS(self.TransactionDetail()) })
            }, true)
           .done(function (result) {
               self.TransactionDetail(convertToTransactionDetail(result));
               //DataCapture.
               UpdateDatacaptureTransactionFee();
           })
           .fail(function (xhr, status) {
               var data = $.parseJSON(xhr.responseText);
               if (data.Message.indexOf(-146) == -1) { //promotion code is not valid
                   cs.handleAjaxError(xhr.responseText, false);
               } else {
                   self.TransactionDetail().PromotionCode('');
                   self.IsPromotionCodeValid(false);
                   self.IsAddedPromotionCode(true);

                   // Reomve promotion code and calculate again.
                   Calculate(true);
               }
           });
        }

        function Confirm() {
            return cs.AjaxByLoading({
                url: '/TopUp/SelfServiceTransactionPurchase',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(self.TransactionDetail()))
            }, true)
            .done(function (result) {
                result = convertToTransactionDetail(result);
                self.TransactionDetail(result);

                trackTransactionSuccessfully(cs.getValue(result.AmountToSend), self.TransactionDetail().ReceiptNumber.trim());

                trackRecipientPageTimeOnPage();
                track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionReceiptPage, track.PageEnum.TransactionReceiptPage);
            })
        }

        function convertToCarrierModel(carrier) {
            return {
                CarrierName: carrier.value,
                Type: carrier.data.type,
                Key: carrier.data.Key,
                AmountToLoad: '$' + cs.keepAmountDecimalPlaces(carrier.data.Value)
            };
        }

        function convertToTransactionDetail(data) {
            data.IsAgree = ko.observable(self.TransactionDetail() && self.TransactionDetail().IsAgree());
            data.PromotionCode = ko.observable(data.PromotionCode);
            return data;
        }

        self.BackToSelectPaymentMethodPage = function () {
            self.IsQuickPay(false);
            self.TransactionProcess(true);
            self.ConfirmAndReviewProcess(false);
            self.CompleteTransactionProcess(false);

            cs.triggerTab("panel-carriers-payment");
            cs.scrollToTab('panel-carriers-payment');
        }

        self.afterRender = function () {
            dataModel.checkPersonInfo();

            $("#main").removeClass()
            $("#main").addClass("mod-c-money-transfer mod-c-top-ups epin");

            app.cacheComponent(['topups-payment-method']);

            trackPurchasePageTotalLoads();
        };

        //begin: quick pay
        self.InitializeTransactionQuickPay = function (topupspurchase) {
            var carrier = topupspurchase.Carrier;
            self.SelectedCarrier(convertToCarrierModel(topupspurchase.Carrier));
            self.SelectedPaymentMethod(topupspurchase.PaymentMethod);
            self.TransactionDetail(convertToTransactionDetail(topupspurchase.TopUpPurchaseTransaction));
            GetServiceTypes(carrier.data.Key, carrier.data.Value);

            self.TransactionStart(true);
            self.SelectCarriersCompleted(true);
            self.SelectPaymentMethodCompleted(true);

            self.TransactionProcess(false);
            self.ConfirmAndReviewProcess(true);
            self.CompleteTransactionProcess(false);
            self.TransactionStart(true);

            self.IsQuickPay(true);
            self.IsPromotionCodeValid(true);
            //DataCapture
            UpdateDatacaptureTransactionFee();
        };
        //end: quick pay

        //DataCapture
        function UpdateDatacaptureTransactionFee() {
            cs.UpdateTransactionData({
                transactionTypeId: self.TransactionDetail().TransactionType,
                tax: self.TransactionDetail().FeeTaxes.Value,
                fee: self.TransactionDetail().TotalFee.Value,
                total: self.TransactionDetail().AmountDue.Value,
                amount: self.TransactionDetail().EPinAmount.Value
            });
        }

        function GetTopUpPaymentMethods() {
            cs.BaseAjax({
                url: '/PaymentMethod/GetPaymentMethods',
                datatype: "json",
                type: "POST",
                contentType: "application/json"
            })
            .done(function (result) {
                $.each(result, function (index, paymentMethod) {
                    paymentMethod.Selected = ko.observable(false);
                    paymentMethod.IsVerifying = ko.observable(false);
                });
                self.PaymentMethodAPI().PaymentMethods(result);
            });
        }

        self.viewTransactionDetails = function () {
            var transaction = self.TransactionDetail();
            dataModel.viewTransactionHistoryByReceiptNumber(transaction.ReceiptNumber.trim());

            trackViewTransactionDetailsTotalClicks();
            track.trackTimeOnPageForPageLink(track.LabelEnum.ViewTransactionDetails);
        }

        self.cancelTransaction = function () {
            app.senderInfo().GoToDashboard();

            if (self.CompleteTransactionProcess()) {
                trackFinishTotalClicks();
                track.trackTimeOnPageForPageLink(track.LabelEnum.Finish);
            }
        };
    }

    return new TopUpsPurchaseViewModel();
});