﻿define(['knockout', 'ClientScript', 'app', 'CarrierModel', 'knockout.validation'], function (ko, cs, app, CarrierModel) {
    return function TopUpsPinlessCustomerModel(data) {
        var self = this;
        var originalCarrierModel;
        var mapping = {
            'TobeAddedCarrier': {
                create: function (options) {
                    return new CarrierModel(options.data);
                }
            },
            'SelectedCarrierModel': {
                create: function (options) {
                    return new CarrierModel(options.data);
                }
            }
        };

        self.TopUpAddPinlessCarrierFlag = ko.observable(false);

        ko.mapping.fromJS(data, mapping, self);

        self.SelectedCarrierModel.ApplyValidation();

        self.TobeAddedCarrier.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.TobeAddedCarrier.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.TobeAddedCarrier.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number.'
            }
        }).isModified(false);

        self.SelectedCarrierModel.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.SelectedCarrierModel.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.SelectedCarrierModel.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number.'
            }
        }).isModified(false);

        self.CloseAddPinlessModal = function () {
            $.when(cs.closeModal())
        .done(function () {
            self.TopUpAddPinlessCarrierFlag(false);
        });
        }

        self.resetAddPinless = function () {
            self.TopUpAddPinlessCarrierFlag(false);
            self.TobeAddedCarrier.ResetAddCarrierModal();
            self.TobeAddedCarrier.EditablePhoneNumber.isModified(false);
            cs.closeModalCallBack('modal-carrier-pinless-new', function () {
                self.TopUpAddPinlessCarrierFlag(false);
            });
        };
        self.AddNewPinlessCarrier = function (element) {
            ko.mapping.fromJSON(self.TobeAddedCarrier.DefaultCarrier, {}, self.TobeAddedCarrier);

            //If open adding pinless modal in Manage Carriers, should set the TopUpType, or the MobilePhoneNumber don't have validation.
            self.TobeAddedCarrier.TopUpType(2);
        };

        self.GetSelectedCarrier = function (billingAccount, element) {

            var selected = ko.mapping.toJS(billingAccount.CarrierBasic);
            ko.mapping.fromJS(selected, {}, self.SelectedCarrierModel);

            //return app.page().data.TopUpReloadTransaction.GetSelectedCarrierToCalculate(self.SelectedCarrierModel, element);
        };

        self.Ready = function () {

        }

        self.initializeSearchCarriers = function () {
            var tempAccounts = $.map(ko.mapping.toJS(self.BillingAccounts), function (item, index) { return { value: (!item.CarrierBasic.AccountName) ? item.CarrierBasic.BillerName : item.CarrierBasic.AccountName, data: item }; });
            tempAccounts.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            if (self.tempSelectReceiver) {
                $('#autocomplete-carrier-products').val(!self.tempSelectReceiver.CarrierBasic.AccountName ? self.tempSelectReceiver.CarrierBasic.BillerName : self.tempSelectReceiver.CarrierBasic.AccountName);
                cs.removeDisable('#button-select-pinless-carrier');
            }
            $('#autocomplete-carrier-products').autocomplete({
                lookup: tempAccounts,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.tempSelectReceiver = suggestion.data;
                    cs.removeDisable('#button-select-pinless-carrier');
                },
                onInvalidateSelection: function () {
                    self.tempSelectReceiver = null;
                    cs.addDisable('#button-select-pinless-carrier');
                }
            });
        };

        self.GetCarriersByName = function () {
            var carrierName = $("#input-new-carrier-name").val();
            if (self.TobeAddedCarrier.timeHandler != 0) {
                clearTimeout(self.TobeAddedCarrier.timeHandler);
                self.TobeAddedCarrier.timeHandler = 0;
            }
            if (carrierName != undefined && carrierName != "" && carrierName.length > 2) {
                self.TobeAddedCarrier.GetCarriersByName(carrierName, 840, false);
            }

            if (carrierName != undefined && carrierName.length == 0) {
                self.TobeAddedCarrier.ResetAddCarrierModal();
                self.TobeAddedCarrier.EditablePhoneNumber.isModified(false);
            }
        }

        self.SearchCarriersByName = function () {
            var carrierName = $("#input-new-carrier-name").val();
            if (carrierName != undefined && carrierName != "" && carrierName.length > 2) {
                self.TobeAddedCarrier.SearchCarrier(carrierName, 840, false);
            }
            else {
                self.TobeAddedCarrier.CarrierNameValidType(3);
                $('#input-new-carrier-name').focus();
            }
        }

        //Save
        self.SaveTopUpCarrier = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            var toBeAddedCarrierName = $('#input-new-carrier-name').val();
            if (toBeAddedCarrierName == '' || toBeAddedCarrierName == null) {
                self.TobeAddedCarrier.CarrierNameValidType(1);
            }
            self.TobeAddedCarrier.MobilePhoneNumber(self.TobeAddedCarrier.AccountNumber());
            var tempTobeAddedCarrier = ko.toJS(ko.utils.unwrapObservable(self.TobeAddedCarrier));
            tempTobeAddedCarrier.Domestic = true;
            self.TobeAddedCarrier.error = ko.validation.group(self.TobeAddedCarrier);
            if ($('#input-new-carrier-name').isValid() && self.TobeAddedCarrier.isValid()) {
                return cs.AjaxBySpinner({
                    url: '/TopUp/SelfServiceAddCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(tempTobeAddedCarrier),
                }, element)
            .done(function (result) {
                var IsLayoutTopUpReloadModalOpen = app.senderInfo().TopUpReloadCarrier() != null && app.senderInfo().TopUpReloadCarrier().LayoutAddCarrierFlag();

                if (app.page().name == 'TopUpsPinlessConsumer' && !IsLayoutTopUpReloadModalOpen) {
                    app.page().data.GoToAmoutToSend(element, ko.mapping.fromJS(result));
                }
                //Add carrier For navigate bar
                if (app.page().name == 'AccountConsumer' && $('#panel-carriers').css('display') == 'none') {
                    $.when(cs.closeModal())
                .done(function () {
                    self.TopUpAddPinlessCarrierFlag(false);
                    app.redirectTo('/SelfService/AccountConsumer#panel-carriers')
                });
                } else {
                    cs.closeModal();
                }
            });
            }
            else {
                LogTobeAddedCarrier(self.TobeAddedCarrier);
                self.TobeAddedCarrier.errors.showAllMessages();
                //Required field validation failed, need return -1 to view model. 
                return -1;
            }
        };

        //Update
        self.TopUpEditPinlessFlag = ko.observable(false);
        var updatePinlessCarrierStatus = new cs.executeStatus();
        self.TopUp$UpdateCarrier = function (element) {
            if (updatePinlessCarrierStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            updatePinlessCarrierStatus.setExecuting();
            carrierModel = ko.mapping.toJS(self.SelectedCarrierModel);
            self.SelectedCarrierModel.error = ko.validation.group(self.SelectedCarrierModel);
            if (self.SelectedCarrierModel.isValid()) {
                self.SelectedCarrierModel.AccountNumber(self.SelectedCarrierModel.CustomDisplayAccountNumber().replace(/-/g, ''));
                cs.AjaxBySpinner({
                    url: '/TopUp/SelfServiceUpdateReloadCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(ko.mapping.toJS(self.SelectedCarrierModel))
                }, element)
            .done(function (result) {

                for (var i = 0; i < app.page().data.TopUpReloadCustomer().BillingAccounts().length; i++) {
                    if (app.page().data.TopUpReloadCustomer().BillingAccounts()[i].CarrierBasic.RppsBillingAccountId() == result.RppsBillingAccountId) {
                        app.page().data.TopUpReloadCustomer().BillingAccounts()[i].Selected(true);
                        self.SelectedBillerAccountId(result.RppsBillingAccountId);
                        ko.mapping.fromJS(result, {}, app.page().data.TopUpReloadCustomer().BillingAccounts()[i].CarrierBasic);
                    }
                }
                ko.mapping.fromJS(result, {}, self.SelectedCarrierModel);
                ko.mapping.fromJS(result, {}, originalCarrierModel);
                $.when(cs.closeModal())
                .done(function () {
                    updatePinlessCarrierStatus.complete();
                });
            })
            .fail(function () {
                updatePinlessCarrierStatus.complete();
                ko.mapping.fromJS(originalCarrierModel, {}, self.SelectedCarrierModel);
            });
            }
            else {
                updatePinlessCarrierStatus.complete();
                LogTobeAddedCarrier(self.SelectedCarrierModel);
                self.SelectedCarrierModel.errors.showAllMessages();
            }
        }

        function LogTobeAddedCarrier(carrierModel) {
            var message = new Array();

            if (!carrierModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + carrierModel.AccountNumber.error);
            }

            cs.logException("TopUpsPinlessCarrierPicker.TobeAddedCarrier", JSON.stringify(message));
        }

        function resetEditReloadCarrier(billingAccount) {
            self.TopUpEditPinlessFlag(false);
            self.SelectedCarrierModel.resetErrorMessage();
            cs.closeModalCallBack('modal-carrier-pinless-edit', function () {
                self.TopUpEditPinlessFlag(false);
            });
        }

        self.EditCarrier = function (billingAccount) {
            if (cs.isDisabled()) {
                return;
            }

            resetEditReloadCarrier(billingAccount);

            billingAccount.ShouldShowCustomerInfo = true;

            self.TopUpEditPinlessFlag(true);
            self.SelectedCarrierModel.EditablePhoneNumber.isModified(false);
            cs.openModal("#modal-carrier-pinless-edit");

            cs.AjaxByLoading({
                url: '/TopUp/SelfServiceGetDefaultCarrier',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(billingAccount))
            })
           .done(function (result) {
               ko.mapping.fromJS(result, {}, self.SelectedCarrierModel);
           });
        }
    }
});