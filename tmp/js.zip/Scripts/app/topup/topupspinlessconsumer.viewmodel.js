﻿define(['knockout', 'ClientScript', 'app', 'TopUpsReloadConsumer-js', paths['common-strings']], function (ko, cs, app, TopUpsReloadConsumer, commonstrings) {
    function TopUpsPinlessViewModel() {
        var self = this;
        self.isReady = ko.observable(false);
        self.title = commonstrings.viewmodeltitle.topupspinless;

        // Begin: Init Data with component
        self.GetCarriersAndPaymentMethods = function () {
            return cs.BaseAjax({
                url: '/TopUp/TopUpsPinlessConsumer',
                type: 'POST',
                contentType: 'application/json',
            });
        }

        //self.dispose = function () { };

        self.afterRender = function () {
            $("#main").removeClass();
            $('#main').addClass('mod-c-money-transfer mod-c-top-ups pinless');

            var trackPageLoad = function () {
                require(['TrackEvent'], function (T) {
                    T.trackEvent({
                        sendType: T.AF,
                        eventCategory: T.CategoryEnum.TUPinlessFlow,
                        eventAction: T.ActionEnum.ButtonClick,
                        eventLabel: "Pinless",
                        eventPage: T.PageEnum.Pinless,
                        source: app.page().name,
                        eventStructure: T.StructureEnum.InitiatedCheckout,
                        eventName: 'af_initiated_checkout_TU_Pinless'
                    });
                });
            }

            trackPageLoad();
        };

    }

    TopUpsPinlessViewModel.prototype = TopUpsReloadConsumer;
    return new TopUpsPinlessViewModel();
});