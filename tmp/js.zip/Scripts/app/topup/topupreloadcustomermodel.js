﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'CarrierModel', 'knockout.validation'], function (ko, cs, app, dataModel, CarrierModel) {
    return function TopUpReloadCustomerModel(data) {
        var self = this;
        var originalKey = 0;
        var searchOldName = "";
        var originalCarrierModel;
        var mapping = {
            'TobeAddedCarrier': {
                create: function (options) {
                    return new CarrierModel(options.data);
                }
            },
            'SelectedCarrierModel': {
                create: function (options) {
                    return new CarrierModel(options.data);
                }
            }
        };

        ko.mapping.fromJS(data, mapping, self);

        self.SelectedCarrierModel.ApplyValidation();

        self.SelectedCarrierModel.EditablePhoneNumber.extend({
            number: {
                onlyIf: function () { return cs.IsInvalidPhoneNumber(self.SelectedCarrierModel.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number'
            },
            minLength: {
                params: 10,
                message: 'Enter a valid contact phone number'
            },
            maxLength: {
                onlyIf: function () { return cs.IsInvalidEditablePhoneNumberMaxLength(self.SelectedCarrierModel.EditablePhoneNumber()); },
                message: 'Enter a valid contact phone number.'
            }
        }).isModified(false);

        self.SelectedCarrierModel.AreaCode.extend({
            required: {
                params: true,
                message: 'Country code is required'
            }
        }).isModified(false);

        self.TobeAddedCarrier.TempAreaCode.extend({
            required: {
                params: true,
                message: 'Country code is required'
            }
        }).isModified(false);

        self.AccountAddCarrierFlag = ko.observable(false);
        self.LayoutAddCarrierFlag = ko.observable(false);
        self.TopUpAddCarrierFlag = ko.observable(false);

        self.TopUpEditReloadFlag = ko.observable(false);

        var defaultCarrier = ko.mapping.toJSON(self.TobeAddedCarrier);
        self.GetSelectedCarrier = function (billingAccount, element) {

            var selected = ko.mapping.toJS(billingAccount.CarrierBasic);
            ko.mapping.fromJS(selected, {}, self.SelectedCarrierModel);

            //return app.page().data.TopUpReloadTransaction.GetSelectedCarrierToCalculate(self.SelectedCarrierModel, element);
        };

        self.Ready = function () {

        }

        self.initializeSearchCarriers = function () {
            var tempAccounts = $.map(ko.mapping.toJS(self.BillingAccounts), function (item, index) { return { value: (!item.CarrierBasic.AccountName) ? item.CarrierBasic.BillerName : item.CarrierBasic.AccountName, data: item }; });
            tempAccounts.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });
            if (self.tempSelectReceiver) {
                $('#autocomplete-search-for-carriers').val(!self.tempSelectReceiver.CarrierBasic.AccountName ? self.tempSelectReceiver.CarrierBasic.BillerName : self.tempSelectReceiver.CarrierBasic.AccountName);
                cs.removeDisable('#button-select-carrier');
            }
            $('#autocomplete-search-for-carriers').autocomplete({
                lookup: tempAccounts,
                triggerSelectOnValidInput: true,
                minChars: 0,
                onSelect: function (suggestion) {
                    self.tempSelectReceiver = suggestion.data;
                    cs.removeDisable('#button-select-carrier');
                },
                onInvalidateSelection: function () {
                    self.tempSelectReceiver = null;
                    cs.addDisable('#button-select-carrier');
                }
            });
        };

        function GetToDelete(billingAccount, element) {
            return cs.AjaxBySpinner({
                url: '/TopUp/SelfServiceDeleteCarrier',
                type: "Get",
                cache: false,
                contentType: "application/json",
                data: { "selectedBillingAccountId": ko.mapping.toJS(billingAccount.RppsBillingAccountId()), "domestic": ko.mapping.toJS(billingAccount.Domestic()) },
            }, element)
            .done(function () {
                var tempBillingAccounts = self.BillingAccounts();
                for (var i = 0; i < tempBillingAccounts.length; i++) {
                    if (tempBillingAccounts[i].CarrierBasic.RppsBillingAccountId() == billingAccount.RppsBillingAccountId()) {
                        tempBillingAccounts.splice(i, 1);
                    }
                }
                ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);
            })
        }

        self.CancelCarrier = function () {
            $('.panel-flow.my-top-ups').trigger('owl.prev');
        }

        self.IsDelete = false;

        self.ChangeStatus = function () {
            self.IsDelete = !self.IsDelete;
        }

        function resetEditReloadCarrier(billingAccount) {
            self.TopUpEditReloadFlag(false);
            self.SelectedCarrierModel.resetErrorMessage();
            cs.closeModalCallBack('modal-carrier-edit', function () {
                self.TopUpEditReloadFlag(false);
            });
        }

        var editCarrierStatus = new cs.executeStatus();
        self.EditCarrier = function (billingAccount) {
            if (editCarrierStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled()) {
                return;
            }

            resetEditReloadCarrier(billingAccount);

            editCarrierStatus.setExecuting();
            billingAccount.ShouldShowCustomerInfo = true;

            self.TopUpEditReloadFlag(true);
            self.SelectedCarrierModel.EditablePhoneNumber.isModified(false);
            self.SelectedCarrierModel.AreaCode.isModified(false);

            cs.openModal("#modal-carrier-edit");
            cs.AjaxByLoading({
                url: '/TopUp/SelfServiceGetDefaultCarrier',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(billingAccount))
            })
           .done(function (result) {
               ko.mapping.fromJS(result, {}, self.SelectedCarrierModel);
           })
           .always(function () {
               editCarrierStatus.complete();
           });
        }

        var removeCarrierStatus = new cs.executeStatus();
        self.ConfirmDeleteForManageCarriers = function (billingAccount) {
            $("#ConfirmToRemove").unbind('click');
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove carrier。
                cs.AddActivityInfo(17);

                if (removeCarrierStatus.isExecuting()) {
                    return;
                }
                if (cs.isDisabled("ConfirmToRemove")) {
                    return;
                }
                removeCarrierStatus.setExecuting();
                $.when(GetToDelete(billingAccount, "#ConfirmToRemove"))
               .done(function () {
                   $.when(cs.closeModal())
                   .done(function () {
                       removeCarrierStatus.complete();
                   });
               })
                .fail(function () {
                    removeCarrierStatus.complete();
               });
            });

            cs.openModal("#modal-remove");
        }

        self.ChangeFavorites = function (billingAccount) {
            var tempCarrierBasic = ko.mapping.toJS(ko.utils.unwrapObservable(billingAccount));
            tempCarrierBasic.IsFavorite = !billingAccount.IsFavorite();

            tempCarrierBasic.errors = ko.validation.group(tempCarrierBasic);
            if (tempCarrierBasic.isValid()) {
                cs.BaseAjax({
                    url: '/TopUp/SelfServiceUpdateReloadCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(ko.mapping.toJS(tempCarrierBasic))
                })
                .done(function (data) {
                    var tempReceiver = ko.mapping.toJS(data);
                    ko.mapping.fromJS(tempReceiver, {}, billingAccount);
                });
            }
        }

        self.resetAddNewCarrier = function (modalId) {
            self.TobeAddedCarrier.ResetAddCarrierModal();
            self.AccountAddCarrierFlag(false);
            self.TobeAddedCarrier.TempAreaCode('');
            self.TobeAddedCarrier.TempAreaCode.isModified(false);
            self.TobeAddedCarrier.IsEditAreaCode(false);
            self.TobeAddedCarrier.TempAreaCode("");
            cs.closeModalCallBack(modalId, function () {
                self.AccountAddCarrierFlag(false);
            });
        }

        self.AddNewCarrier = function (element) {
            $.when(dataModel.GetCountriesByTransactionType(12))
            .done(function (data) {
                var index = data.indexOf(data.filter(function (x) {
                    return x.Value == "840";
                })[0]);

                data.splice(0, 0,
                    new Object({ Code: "", Text: "Country", Value: "0" }),
                    data.splice(index, 1)[0]);
                var countries = ko.mapping.toJS(data);
                ko.mapping.fromJS(countries, {}, self.Countries);
                $("#select-new-country").val(self.Countries()[0].Value());
            });
        }

        self.GetAreaCode = function (code) {
            if (!code || code == '0') {
                return;
            }
            cs.BaseAjax({
                url: '/TopUp/SelfServiceGetAreaCodeByCountry',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "countryId": code })
            })
            .done(function (data) {
                self.TobeAddedCarrier.TempAreaCode(data);
            });
        }

        self.ChangeCountry = function () {
            if (self.TobeAddedCarrier.DestinationCountry() == $("#select-new-country option:selected").text() || ($("#select-new-country").val() == '0' && !!self.TobeAddedCarrier.DestinationCountry())) {
                return;
            }
            $('#input-new-carrier-name').val("");

            $('#input-new-carrier-name').autocomplete({
                lookup: new Array()
            });
            self.TobeAddedCarrier.ResetAddCarrierModal();
            self.TobeAddedCarrier.CarrierNameValidType(0);
            ko.mapping.fromJSON(defaultCarrier, {}, self.TobeAddedCarrier);
            self.TobeAddedCarrier.DisabledBillingAccountValidattion();

            var selectedCountry = $("#select-new-country").val();
            self.GetAreaCode(selectedCountry);
            if (selectedCountry == 0) {
                self.TobeAddedCarrier.TempAreaCode("");
                self.TobeAddedCarrier.TempAreaCode.isModified(false);
                self.TobeAddedCarrier.IsEditAreaCode(false);
            } else {
                self.TobeAddedCarrier.IsEditAreaCode(true);
            }
        }

        self.GetCarriersByName = function () {
            var carrierName = $("#input-new-carrier-name").val();
            var selectedCountry = $("#select-new-country").val();

            if (selectedCountry == "0") {
                self.TobeAddedCarrier.IsEditAreaCode(false);
                self.TobeAddedCarrier.TempAreaCode("");
                self.TobeAddedCarrier.TempAreaCode.isModified(false);
            }
            if (self.TobeAddedCarrier.timeHandler != 0) {
                clearTimeout(self.TobeAddedCarrier.timeHandler);
                self.TobeAddedCarrier.timeHandler = 0;
            }
            if (carrierName != undefined && carrierName != "" && carrierName.length > 2) {
                self.TobeAddedCarrier.GetCarriersByName(carrierName, selectedCountry, true);
            }

            if (carrierName != undefined && carrierName.length == 0) {
                self.TobeAddedCarrier.ResetAddCarrierModal();
            }
        }

        self.SearchCarriersByName = function () {
            var carrierName = $("#input-new-carrier-name").val();
            var selectedCountry = $("#select-new-country").val();

            if (carrierName != undefined && carrierName != "" && carrierName.length > 2) {
                self.TobeAddedCarrier.SearchCarrier(carrierName, selectedCountry, true);
            }
            else {
                self.TobeAddedCarrier.CarrierNameValidType(3);
                $('#input-new-carrier-name').focus();
            }
        }

        var addCarrierStatus = new cs.executeStatus();
        self.AddCarrier = function (element) {
            if (addCarrierStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            addCarrierStatus.setExecuting();
            var toBeAddedCarrierName = $('#input-new-carrier-name').val();
            if (toBeAddedCarrierName == '' || toBeAddedCarrierName == null) {
                self.TobeAddedCarrier.CarrierNameValidType(1);
            }
            var tempTobeAddedCarrier = ko.toJS(ko.utils.unwrapObservable(self.TobeAddedCarrier));
            tempTobeAddedCarrier.Domestic = $("#select-new-country").val() == "USA" ? true : false;
            self.TobeAddedCarrier.error = ko.validation.group(self.TobeAddedCarrier);
            var deferred = $.Deferred();
            tempTobeAddedCarrier.AreaCode = self.TobeAddedCarrier.TempAreaCode();
            if ($('#input-new-carrier-name').isValid() && self.TobeAddedCarrier.isValid()) {
                cs.AjaxBySpinner({
                    url: '/TopUp/SelfServiceAddCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(tempTobeAddedCarrier),
                }, element)
                .done(function (result) {
                    var tempBillingAccounts = ko.mapping.toJS(self.BillingAccounts);
                    var IsLayoutTopUpReloadModalOpen = app.senderInfo().TopUpReloadCarrier() != null && app.senderInfo().TopUpReloadCarrier().LayoutAddCarrierFlag();

                    if (self.BillingAccounts == null || self.BillingAccounts().length < 1) {
                        tempBillingAccounts = new Array();
                    }

                    tempBillingAccounts.push(result);
                    ko.mapping.fromJS(tempBillingAccounts, {}, self.BillingAccounts);

                    self.Ready();

                    if (app.page().name == 'TopUpsReloadConsumer' && !IsLayoutTopUpReloadModalOpen) {
                        app.page().data.GoToAmoutToSend(element, result);
                    }
                    self.TobeAddedCarrier.ResetAddCarrierModal();
                    self.TobeAddedCarrier.AccountNumber.isModified(false);
                    self.TobeAddedCarrier.TempAreaCode.isModified(false);
                    $.when(cs.closeModal())
                        .done(function () {
                            addCarrierStatus.complete();
                            self.AccountAddCarrierFlag(false);
                            self.LayoutAddCarrierFlag(false);
                            self.TopUpAddCarrierFlag(false);

                            // After add carrier success, clear TempAreaCode.
                            self.TobeAddedCarrier.TempAreaCode('');
                            self.TobeAddedCarrier.IsEditAreaCode(false);
                            self.TobeAddedCarrier.TempAreaCode.isModified(false);
                            deferred.resolve();
                        });
                })
                .fail(function () {
                    addCarrierStatus.complete();
                });
            }
            else {
                addCarrierStatus.complete();
                LogTobeAddedCarrier(self.TobeAddedCarrier);
                self.TobeAddedCarrier.errors.showAllMessages();
            }

            return deferred;
        }

        function LogTobeAddedCarrier(carrierModel) {
            var message = new Array();

            if (!carrierModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + carrierModel.AccountNumber.error);
            }

            cs.logException("TopUpsPinlessCarrierPicker.TobeAddedCarrier", JSON.stringify(message));
        }

        var updateCarrierStatus = new cs.executeStatus();
        self.TopUp$UpdateCarrier = function (element) {
            if (updateCarrierStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            updateCarrierStatus.setExecuting();
            carrierModel = ko.toJS(ko.utils.unwrapObservable(self.SelectedCarrierModel));
            self.SelectedCarrierModel.error = ko.validation.group(self.SelectedCarrierModel);
            if (self.SelectedCarrierModel.isValid()) {
                self.SelectedCarrierModel.AccountNumber(self.SelectedCarrierModel.CustomDisplayAccountNumber().replace(/-/g, ''));
                cs.AjaxBySpinner({
                    url: '/TopUp/SelfServiceUpdateReloadCarrier',
                    type: "POST",
                    dataType: "json",
                    contentType: "application/json",
                    data: JSON.stringify(ko.mapping.toJS(self.SelectedCarrierModel))
                }, element)
                .done(function (result) {
                    for (var i = 0; i < self.BillingAccounts().length; i++) {
                        if (self.BillingAccounts()[i].CarrierBasic.RppsBillingAccountId() == result.RppsBillingAccountId) {
                            self.BillingAccounts()[i].Selected(true);
                            self.SelectedBillerAccountId(result.RppsBillingAccountId);
                            ko.mapping.fromJS(result, {}, self.BillingAccounts()[i].CarrierBasic);
                        }
                    }
                    ko.mapping.fromJS(result, {}, self.SelectedCarrierModel);
                    ko.mapping.fromJS(result, {}, originalCarrierModel);
                    $.when(cs.closeModal())
                    .done(function () {
                        updateCarrierStatus.complete();
                    });
                })
                .fail(function () {
                    updateCarrierStatus.complete();
                    ko.mapping.fromJS(originalCarrierModel, {}, self.SelectedCarrierModel);
                });
            }
            else {
                updateCarrierStatus.complete();
                LogSelectedCarrierModel(self.SelectedCarrierModel);
                self.SelectedCarrierModel.errors.showAllMessages();
            }
        }

        function LogSelectedCarrierModel(carrierModel) {
            var message = new Array();

            if (!carrierModel.AccountNumber.isValid()) {
                message.push("AccountNumber: " + carrierModel.AccountNumber.error);
            }
            if (!carrierModel.RetypeAccountNumber.isValid()) {
                message.push("RetypeAccountNumber: " + carrierModel.RetypeAccountNumber.error);
            }

            cs.logException("TopUpsPinlessCarrierPicker.SelectedCarrierModel", JSON.stringify(message));
        }

        self.CarrierSearchText = ko.observable("");
        var timerHandler = 0;
        self.AutoSearchCarriers = function (value) {
            var oldValue = self.CarrierSearchText();
            self.CarrierSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.CarrierSearchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 3) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.SearchCarriers(); }, 500);
            }
        }

        self.SearchCarriers = function () {
            var criteria = $("#input-search-for-carriers").val();

            cs.AjaxBySpinner({
                url: '/TopUp/SearchCarriers',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ 'criteria': criteria })
            }, "#search-for-carriers")
            .done(function (result) {
                var billingAccount = ko.mapping.toJS(result);
                ko.mapping.fromJS(billingAccount, {}, self.BillingAccounts);
                cs.closeFoundationDropdown();
            });
        }

        self.FormatUpdateAccountNickName = function (element) {
            var accountNumber = $(element).val();
            var length = accountNumber.length;

            var billerName = $("#autocomplete-reload-carrier-names").val();

            if (length < 4) {
                self.SelectedCarrierModel.AccountNickName(billerName + " [****" + accountNumber + "]");
            } else {
                var temp = accountNumber.substr(0, length - 4).length;
                var prefix = " [****";

                self.SelectedCarrierModel.AccountNickName(billerName + prefix + accountNumber.substr(length - 4, 4) + "]");
            }
        }


        self.SortType = ko.observable('sortby');
        self.IsAscending = ko.observable(true);

        self.SortBillingAccountBy = function (value, element) {

            var classname = element.childNodes[1].className;
            ResetSort();

            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-up";
                self.SortType(value);
                self.IsAscending(true);
            }
            else {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-down";
                self.SortType(value);
                self.IsAscending(false);
            }
        }

        function ResetSort() {
            $("#carriers-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#carriers-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#carriers-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.SortType("sortby");
            self.IsAscending(true);
        }

        self.SortedCarriers = ko.computed(function () {
            var tempCarriers = new Array();
            if (self.BillingAccounts()) {
                for (var i = 0; i < self.BillingAccounts().length; i++) {
                    tempCarriers.push(self.BillingAccounts()[i].CarrierBasic);
                }

                var sortType = self.SortType();
                var isAscending = self.IsAscending();
                if (sortType == "sortby") {
                    return tempCarriers;
                }
                else {
                    if (sortType == "FirstName") {
                        return tempCarriers.sort(dataModel.CompareCustomerName(isAscending));
                    }
                    else {
                        return tempCarriers.sort(cs.compare(sortType, null, isAscending, 'RppsBillingAccountId'));
                    }
                }
            }
            return tempCarriers;
        });

    }
});
