define(['knockout'], function (ko) {

    var Error = {
        isReady: ko.observable(false),
        init: function (code) {
            Error.statusCode(code);
        },
        dispose: function () { },
        controllers: {
            '/:code': function (code) {
                Error.statusCode(code);
            }
        },
        title: "404",
        statusCode: ko.observable('')
    };

    return Error;

});
