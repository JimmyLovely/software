﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'upgrade-component'], function (ko, cs, app, dataModel, commonstrings) {
    function IncreaseLimitConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.upgrade;
        self.senderLevelInfos = ko.observable([]);

        self.init = function () {
            //prevent visit without permission
            dataModel.checkStatePermision();
        };

        self.afterRender = function () {
            self.checkSenderLevelInfo();
            cs.RemoveOpen();
        }

        self.isReadySenderLevelInfos = ko.observable(false);
        self.checkSenderLevelInfo = function () {
            if (app.senderInfo() && app.senderInfo().SenderLevel()) {
                $.when(dataModel.GetSenderLevelInfos())
                .done(function (result) {
                    self.senderLevelInfos(result);
                    self.isReadySenderLevelInfos(true);
                });
                getDocumentTypes();
            } else {
                app.page().data.LoadedSenderInfo = function () {
                    self.checkSenderLevelInfo();
                };
            }
        }

        self.dispose = function () {
        };

        self.levelUpgrade = function (senderInfo) {
            //Upgrade DataCapture.
            cs.UpgradeDataCaptureModel.SetUpgradeInitiator("Independent");
            cs.UpgradeDataCaptureModel.InitalIndependentUpgrade({ 'SourceLevelId': app.senderInfo().SenderLevel().SourceLevelId, 'TargetLevelId': senderInfo.SenderLevelInfoId }, "Independent");

            dataModel.GoToUpgradeLevel(app.senderInfo().SenderLevel().SourceLevelId, senderInfo.SenderLevelInfoId, true);
        }

        self.uploadDocumentTypes;
        self.isReadyDocumentTypes = ko.observable(false);
        function getDocumentTypes() {
            return dataModel.getDocumentTypes(app.senderInfo().SenderLevel().SenderLevelId, app.senderInfo().SenderLevel().TargetLevelId > 1 ? app.senderInfo().SenderLevel().TargetLevelId : 3)
            .done(function (data) {
                self.uploadDocumentTypes = data;
                self.isReadyDocumentTypes(true);
            });
        }
    }

    return new IncreaseLimitConsumerViewModel();
});