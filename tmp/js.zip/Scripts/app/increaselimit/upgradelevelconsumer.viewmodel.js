﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'upgrade-component'], function (ko, cs, app, dataModel, commonstrings) {
    function UpgradeLevelConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.independentupgrade;
        // 1 means upgrade level 1 to level 2
        // 2 means upgrade level 2 to level 3
        // 3 means upgrade level 1 to level 3
        self.levelUpgradeType = ko.observable(1);

        self.init = function () {
            //prevent visit without permission
            dataModel.checkStatePermision();
        };

        self.dispose = function () {
        };

        self.afterRender = function () {
            self.checkSenderLevelInfo();

            //DataCapture.
            if (cs.UpgradeDataCaptureModel.GetIndependentUpgrade().UpgradeInitiator == null) {
            senderLevelObject = {};

            if (self.levelUpgradeType() == 1) {
                senderLevelObject.SourceLevelId = 1;
                senderLevelObject.TargetLevelId = 2;
            } else if (self.levelUpgradeType() == 2) {
                senderLevelObject.SourceLevelId = 2;
                senderLevelObject.TargetLevelId = 3;
            } else if (self.levelUpgradeType() == 3) {
                senderLevelObject.SourceLevelId = 1;
                senderLevelObject.TargetLevelId = 3;
            }

            cs.UpgradeDataCaptureModel.InitalIndependentUpgrade(senderLevelObject, null);

            delete senderLevelObject;
        }

        }

        self.checkSenderLevelInfo = function () {
            if (app.senderInfo() && app.senderInfo().SenderLevel()) {
                // TODO: Load document type.
                getDocumentTypes();
            } else {
                app.page().data.LoadedSenderInfo = function () {
                    self.checkSenderLevelInfo();
                };
            }
        }

        self.sourceLevelId;
        self.targetLevelId;
        self.isIndependence = false;
        self.controllers = {
            '/:levelUpgradeType': function (levelUpgradeType) {
                self.levelUpgradeType(levelUpgradeType);
                if (levelUpgradeType == 1) {
                    self.sourceLevelId = 1;
                    self.targetLevelId = 2;
                } else if (levelUpgradeType == 2) {
                    self.sourceLevelId = 2;
                    self.targetLevelId = 3;
                } else if (levelUpgradeType == 3) {
                    self.sourceLevelId = 1;
                    self.targetLevelId = 3;
                }
            },
            '/independenceupgrade/:levelUpgradeType': function (levelUpgradeType) {
                self.levelUpgradeType(levelUpgradeType);
                if (levelUpgradeType == 1) {
                    self.sourceLevelId = 1;
                    self.targetLevelId = 2;
                } else if (levelUpgradeType == 2) {
                    self.sourceLevelId = 2;
                    self.targetLevelId = 3;
                } else if (levelUpgradeType == 3) {
                    self.sourceLevelId = 1;
                    self.targetLevelId = 3;
                }
                
                self.isIndependence = true;
            }
        }

        self.uploadDocumentTypes;
        self.isReadyDocumentTypes = ko.observable(false);
        function getDocumentTypes() {
            return dataModel.getDocumentTypes(1, 3)
           .done(function (data) {
               self.uploadDocumentTypes = data;
               self.isReadyDocumentTypes(true);

               for (var i = 0, l = data.length; i < l; i++) {
                   var documentType = data[i];
                   if (documentType.SenderLevelInfoId == (self.levelUpgradeType() >= 2 ? 3 : 2) && !!documentType.Url) {
                       self.isActive(true);
                   }
               }
           });
        }

        self.SubmitDocument = function (element) {
            if ($(element).hasClass('secondary')) {
                return;
            }

            if (!checkChioceDocuments()) {
                return;
            }

            $.when(dataModel.uploadDocuments(self.uploadDocumentTypes, true, element))
               .done(function (data) {
                   //DataCapture.
                    cs.UpgradeDataCaptureModel.UpdateSubmittedInformation(true);

                   //ToDo: Redirect to other page.
                   app.senderInfo().ShowSubmittedPrompt = true;
                   $.when(app.senderInfo().GetSenderLevel(element))
                   .done(function () {
                       app.redirectTo("/SelfService/CustomerDashboard");
                   });
               })
            .fail(function (xhr, status) {
                try {
                    var tempError = $.parseJSON(xhr.responseText);
                    if (tempError.ExceptionCode == -488) {//Document has been submited.
                        cs.showContinue(tempError, function () {
                            $.when(cs.closeModal())
                            .done(function () {
                                app.redirectTo("/SelfService/CustomerDashboard");
                            });
                        });
                    }
                } catch (e) { }
            });
        }

        self.isActive = ko.observable(false);
        self.refreshDocumentTypes = function (documentTypes) {
            self.uploadDocumentTypes = documentTypes;
            if (checkChioceDocuments()) {
                self.isActive(true);
            }
            else {
                self.isActive(false);
            }
        }

        function hasChioceFiles(targetLevelId) {
            // Check sub document types first.
            for (var i = 0, l = self.uploadDocumentTypes.length; i < l; i++) {
                var documentType = self.uploadDocumentTypes[i];
                if (targetLevelId == documentType.SenderLevelInfoId) {
                    if (documentType.SubDocumentTypes && documentType.SubDocumentTypes.length > 0) {
                        var hasChioceCount = 0;
                        for (var j = 0; j < documentType.SubDocumentTypes.length; j++) {
                            if (documentType.SubDocumentTypes[j].Content || !!documentType.SubDocumentTypes[j].Url) {
                                hasChioceCount++;
                            }
                        }

                        if (hasChioceCount == documentType.SubDocumentTypes.length) {
                            return true;
                        }
                        else if (hasChioceCount > 0 && hasChioceCount < documentType.SubDocumentTypes.length) {
                            return false;
                        }
                    }
                }
            }

            // Check normal document type.
            for (var i = 0, l = self.uploadDocumentTypes.length; i < l; i++) {
                var documentType = self.uploadDocumentTypes[i];
                if (targetLevelId == documentType.SenderLevelInfoId) {
                    if (!documentType.SubDocumentTypes || documentType.SubDocumentTypes.length == 0) {
                        if (documentType.Content || !!documentType.Url) {
                            return true;
                        }
                    }
                }
            }

            return false;
        }

        function checkChioceDocuments() {
            var currentLevel = 1;
            var targetLevel = 1;
            if (self.levelUpgradeType() == 1) {
                currentLevel = 1;
                targetLevel = 2;
            } else if (self.levelUpgradeType() == 2) {
                currentLevel = 2;
                targetLevel = 3;
            } else if (self.levelUpgradeType() == 3) {
                currentLevel = 1;
                targetLevel = 3;
            }

            if (targetLevel - currentLevel === 1) {
                if (!hasChioceFiles(targetLevel)) {
                    return false;
                }
            }
            if (targetLevel - currentLevel === 2) {
                if (!hasChioceFiles(2) || !hasChioceFiles(3)) {
                    return false;
                }
            }

            return true;
        }
    }

    return new UpgradeLevelConsumerViewModel();
});