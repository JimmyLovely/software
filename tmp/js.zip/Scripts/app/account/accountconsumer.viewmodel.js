﻿define(['knockout', 'ClientScript', 'app', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, cs, app, dataModel, commonstrings, R, track) {
    function AccountConsumerViewModel() {
        var self = this;
        self.title = commonstrings.viewmodeltitle.account;
        self.init = function () {
        };

        self.dispose = function () {
        };

        self.billingAccountFlag = ko.observable(false);
        self.billingAccountApi = ko.observable();

        self.recipientFlag = ko.observable(false);
        self.recipientApi = ko.observable();

        self.carrierFlag = ko.observable(false);
        self.carrierApi = ko.observable();

        self.transactionDetailsFlag = ko.observable(false);
        self.transactionDefailsApi = ko.observable();
        self.receiptNumber = "";
        self.isLimitHold = "";

        self.controllers = {
            '/': function () {

            },
            '/:receiptNumber': function (receiptNumber) {
                self.receiptNumber = receiptNumber;
            },
            '/LimitHold/:receiptNumber': function (receiptNumber) {
                self.receiptNumber = receiptNumber;
                self.isLimitHold = true;
            }
        };

        //Start appsflyer track event
        var trackRecipeintTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.ManageRecipients,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.ManageRecipients,
                source: app.page().name
            });
        }

        var trackManagmentReceiptTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ManageRecipients,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Manage Recipients",
                eventPage: track.PageEnum.ManageRecipients,
                source: app.page().name
            });
        }

        var trackBillerTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.ManageBillers,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.ManageBillers,
                source: app.page().name
            });
        }

        var trackManagementBillerTotalLoads = function () {
            track.trackEvent({
                sendType: (track.GA + track.MP),
                eventCategory: track.CategoryEnum.ManageBillers,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Manage Billers",
                eventPage: track.PageEnum.ManageBillers,
                source: app.page().name
            });
        }

        var trackCarrierTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.ManageCarriers,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.ManageCarriers,
                source: app.page().name
            });
        }

        var trackManagementCarrierTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.ManageCarriers,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Manage Carriers",
                eventPage: track.PageEnum.ManageCarriers,
                source: app.page().name
            });
        }

        var trackTransactionHistoryTimeOnPage = function () {
            track.trackTimeOnPage({
                sendType: track.GA,
                eventCategory: track.CategoryEnum.TransactionHistory,
                eventAction: track.ActionEnum.Metric,
                eventLabel: "TimeOnPage",
                eventPage: track.PageEnum.TransactionHistory,
                source: app.page().name
            });
        }

        var trackTransactionHistoryTotalLoads = function () {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionHistory,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Transaction History",
                eventPage: track.PageEnum.TransactionHistory,
                source: app.page().name
            });
        }

        //End appsflyer track event

        self.GetAllRecipients = function () {
            if (!$('#panel-recipients').hasClass('active')) {
                track.trackNextPage(track.PageEnum.ManageRecipients, app);
            }

            cs.collapseManageTransaction();
            self.recipientFlag(true);
            closeFoundationDropDown();

            trackRecipeintTimeOnPage();

            trackManagmentReceiptTotalLoads();
            track.trackTimeOnPageForPageLink("ManageRecipientsLink");
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.ManageRecipients, track.PageEnum.ManageRecipients);
        }

        var getBillerFailed = false;
        self.GetAllBillers = function () {
            if (!$('#panel-billers').hasClass('active')) {
                track.trackNextPage(track.PageEnum.ManageBillers, app);
            }
            cs.collapseManageTransaction();
            closeFoundationDropDown();
            if (!app.senderInfo() && !getBillerFailed) {
                self.LoadedSenderInfo = function () {
                    self.billingAccountFlag(true);

                    trackBillerTimeOnPage();

                    trackManagementBillerTotalLoads();
                }
                return;
            }
            self.billingAccountFlag(true);

            trackBillerTimeOnPage();

            trackManagementBillerTotalLoads();
            track.trackTimeOnPageForPageLink("ManageBillersLink");
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.ManageBillers, track.PageEnum.ManageBillers);
        }

        self.GetAllReloadCarriers = function () {
            if (!$('#panel-carriers').hasClass('active')) {
                track.trackNextPage(track.PageEnum.ManageCarriers, app);
            }

            cs.collapseManageTransaction();
            closeFoundationDropDown();
            self.carrierFlag(true);

            trackCarrierTimeOnPage();

            trackManagementCarrierTotalLoads();
            track.trackTimeOnPageForPageLink("ManageCarriesLink");
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.ManageCarriers, track.PageEnum.ManageCarriers);
        }

        self.GetAllTransactions = function () {
            if (!$('#panel-transaction').hasClass('active') && (self.billingAccountFlag() || self.recipientFlag() || self.carrierFlag())) {
                track.trackNextPage(track.PageEnum.TransactionHistory, app);
            }

            cs.collapseManageTransaction();
            closeFoundationDropDown();
            self.transactionDetailsFlag(true);

            trackTransactionHistoryTimeOnPage();

            trackTransactionHistoryTotalLoads();
            if (location.href.indexOf("_refresh") < 0) {
                track.trackTimeOnPageForPageLink("TransactionHistoryLink");
            }
            track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionHistory, track.PageEnum.TransactionHistory);
        }

        function closeFoundationDropDown() {
            $('.f-dropdown.table-options').each(function (idx, dropdown) {
                var $dropdown = $(dropdown);
                require(['foundation.extended'], function () {
                    $dropdown.foundation('dropdown', 'close', $dropdown);
                })
            })
        };

        self.afterRender = function () {
            cs.RemoveOpen();
            var hash = location.hash;
            if (hash.indexOf('#panel-recipients') == -1 && hash != '#panel-billers' && hash != '#panel-carriers'
                && hash.indexOf('#panel-transaction') == -1) {
                cs.triggerTab("panel-recipients");
            }
        };

        self.addBillingAccount = function (element) {
            if (self.billingAccountFlag()) {
                self.billingAccountApi().initAddBillingAccount();
            }
        }

        self.addRecipient = function (element) {
            if (self.recipientFlag()) {
                self.recipientApi().addRecipient(element);
            }
        };

        self.addCarrier = function (element) {
            if (self.carrierFlag()) {
                self.carrierApi().addCarrier(element);
            }
        };
    }

    return new AccountConsumerViewModel();
});