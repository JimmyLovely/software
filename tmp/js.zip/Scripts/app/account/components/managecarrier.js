﻿define(['knockout', 'app', 'ClientScript', 'DataModel', 'TrackEvent'], function (ko, app, cs, dataModel, track) {
    return function (params) {
        var self = this;
        if (params.api) {
            params.api(this);
        }

        self.carriers = ko.observable();
        self.addCarrierFlag = ko.observable(false);
        self.editCarrierFlag = ko.observable(false);
        self.editCarrier = ko.observable();
        self.addPinlessFlag = ko.observable(false);
        self.editPinlessFlag = ko.observable(false);

        ko.components.unregister('edit-carrier');
        ko.components.register('edit-carrier', {
            viewModel: { require: 'edit-carrier-js' },
            template: { require: 'text!edit-carrier-html' }
        });

        ko.components.unregister('edit-pinless-carrier');
        ko.components.register('edit-pinless-carrier', {
            viewModel: { require: 'edit-pinless-carrier-js' },
            template: { require: 'text!edit-pinless-carrier-html' }
        });

        $.when(searrChCarriers(null, null))
        .fail(function () {
            self.carriers([]);
        });

        app.cacheComponent(['edit-carrier', 'edit-pinless-carrier']);

        self.searchText = ko.observable("");
        var timerHandler = 0;
        self.autoSearchCarriers = function (value) {
            var oldValue = self.searchText();
            self.searchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.searchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 1) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.searchCarriers(); }, 500);
            }
        }

        self.searchCarriers = function () {
            var criteria = $("#input-search-for-carriers").val().trim();

            searrChCarriers(criteria, "#search-for-carriers");
        }

        function searrChCarriers(criteria, element) {
            return cs.AjaxBySpinner({
                url: '/TopUp/SearchCarriers',
                type: "GET",
                dataType: "json",
                data: { 'criteria': criteria }
            }, element)
            .done(function (data) {
                data = convertCarrier(data || []);

                //DataCapture.
                if (Object.prototype.toString.call(data).slice(8, -1) == "Array" && data.length == 0) {
                    cs.LogSearchActivity(criteria, cs.LuSearchSectionType.SearchFromTransactedCarriersInManagerCarriers);
                }

                self.carriers(data);
            });
        }

        self.sortType = ko.observable('sortby');
        self.isAscending = ko.observable(true);

        self.sortBillingAccountBy = function (value, element) {
            var classname = element.children[0].className;
            resetSort();

            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-up";
                self.sortType(value);
                self.isAscending(true);
            }
            else {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-down";
                self.sortType(value);
                self.isAscending(false);
            }
        }

        function resetSort() {
            $("#carriers-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#carriers-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#carriers-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.sortType("sortby");
            self.isAscending(true);
        }

        self.sortedCarriers = ko.computed(function () {
            var tempCarriers = [];
            if (self.carriers()) {
                for (var i = 0; i < self.carriers().length; i++) {
                    if (self.carriers()[i].BillerName.toUpperCase().indexOf('PINLESS') == -1) { // remove pinless temporarily.
                        tempCarriers.push(self.carriers()[i]);
                    }
                }

                var sortType = self.sortType();
                var isAscending = self.isAscending();
                if (sortType == "sortby") {
                    return tempCarriers;
                }
                else {
                    return tempCarriers.sort(cs.compare(sortType, null, isAscending, 'RppsBillingAccountId'));
                }
            }
            return tempCarriers;
        });

        self.quickPay = function (carrier, element) {
            if (cs.isDisabled(element) || !app.senderInfo().HasTopUpReloadPermission()) {
                return;
            }

            trackQuickPay(carrier.LastReceiptNumber != null && carrier.LastReceiptNumber.trim() != "");
            track.trackTimeOnPageForPageLink(carrier.LastReceiptNumber ? "Reload" : "ClickToPay");
            track.generatePartialTimeOnPageTrack();// clear time on page track

            dataModel.QuickToPayByCarrier(carrier, "FromManageCarriers");
        };

        function trackQuickPay(isQuickPay) {
            var trackQuickPay = trackEvent;
            if (isQuickPay) {
                trackQuickPay("Quick Pay");
            } else {
                trackQuickPay("Click To Pay");
            }
        }

        self.updateFavoriteStatus = new cs.executeStatus();
        // Not used any more.
        self.updateFavorite = function (billingAccount) {
            if (self.updateFavoriteStatus.isExecuting()) {
                return;
            }
            self.updateFavoriteStatus.setExecuting();
            cs.BaseAjax({
                url: '/TopUp/UpdateFavorite',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'rppsBillingAccountId': billingAccount.RppsBillingAccountId, 'isFavorite': !billingAccount.IsFavorite() })
            })
            .done(function () {
                billingAccount.IsFavorite(!billingAccount.IsFavorite());
            })
            .always(function () {
                self.updateFavoriteStatus.complete();
            });
        }

        var removeCarrierStatus = new cs.executeStatus();
        self.deleteCarrier = function (billingAccount) {
            $("#ConfirmToRemove").unbind('click');
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove carrier。
                cs.AddActivityInfo(17);

                if (removeCarrierStatus.isExecuting()) {
                    return;
                }
                if (cs.isDisabled("ConfirmToRemove")) {
                    return;
                }
                removeCarrierStatus.setExecuting();
                $.when(getToDelete(billingAccount, "#ConfirmToRemove"))
               .done(function () {
                   $.when(cs.closeModal())
                   .done(function () {
                       removeCarrierStatus.complete();
                   });
               })
                .fail(function () {
                    removeCarrierStatus.complete();
                });
            });

            cs.openModal("#modal-remove");
            track.trackTimeOnPageForPageLink("Remove");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        function getToDelete(billingAccount, element) {
            return cs.AjaxBySpinner({
                url: '/TopUp/SelfServiceDeleteCarrier',
                type: "Get",
                cache: false,
                contentType: "application/json",
                data: { "selectedBillingAccountId": billingAccount.RppsBillingAccountId },
            }, element)
            .done(function () {
                var carriers = self.carriers();
                for (var i = 0; i < carriers.length; i++) {
                    if (carriers[i].RppsBillingAccountId == billingAccount.RppsBillingAccountId) {
                        carriers.splice(i, 1);
                    }
                }

                self.carriers(carriers);
            })
        }

        self.addCarrier = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            cs.closeModalCallBack('modal-carrier-new', function () {
                self.addCarrierFlag(false);
            });
            self.addCarrierFlag(true);
            cs.openModal('modal-carrier-new');
            track.trackTimeOnPageForPageLink("AddCarrier");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        };

        self.completedAddReloadCarrier = function (carrier) {
            var carriers = self.carriers();

            if (carriers == null) {
                carriers = new Array();
            }

            carrier.IsFavorite = ko.observable(carrier.IsFavorite);
            carriers.push(carrier);
            self.carriers(carriers);
            if (!$("#panel-carriers").hasClass('active')) {
                app.redirectTo("/SelfService/AccountConsumer#panel-carriers");
            }
        };

        self.addPinless = function (element) {
            cs.closeModalCallBack('modal-carrier-pinless-new', function () {
                self.addPinlessFlag(false);
            });
            self.addPinlessFlag(true);
            cs.openModal('modal-carrier-pinless-new');
            track.trackTimeOnPageForPageLink("AddPinless");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        };

        self.completedEditCarrier = function (carrier) {
            var carriers = self.carriers();
            var tempCarrier = {
                RppsBillingAccountId: carrier.RppsBillingAccountId,
                AccountNumber: carrier.AccountNumber,
                AccountName: carrier.AccountName,
                CustomDisplayAccountNumber: carrier.CustomDisplayAccountNumber,
                CustomerName: carrier.FirstName + ' ' + carrier.LastName,
                IsFavorite: ko.observable(carrier.IsFavorite),
                LastReceiptNumber: carrier.LastReceiptNumber,
                BillerName: carrier.BillerName,
                BillerType: carrier.BillerType,
                CountryCode: carrier.CountryCode
            };
            if (tempCarrier.BillerName.indexOf('PINLESS') == -1) {
                tempCarrier.CustomDisplayAccountNumber = "+" + carrier.AreaCode + "-" + carrier.CustomDisplayAccountNumber;
            }

            $.each(carriers, function (index, c) {
                if (c.RppsBillingAccountId == carrier.RppsBillingAccountId) {
                    c = tempCarrier;
                    return false;
                }
            });

            for (var i = 0; i < carriers.length; i++) {
                if (carriers[i].RppsBillingAccountId == carrier.RppsBillingAccountId) {
                    carriers[i] = tempCarrier;
                    break;
                }
            }
            self.carriers(carriers);
            self.editCarrier(null);
        };

        self.initEditCarrier = function (billingAccountId) {
            cs.AjaxByDelayLoading({
                url: '/TopUp/GetCarrier',
                type: 'GET',
                dataType: 'json',
                contentType: 'application/json',
                data: { 'billingAccountId': billingAccountId }
            })
             .done(function (data) {
                 self.editCarrier(data);

                 if (data.CarrierBasic.BillerName.toLowerCase().indexOf('pinless') == -1) {
                     cs.closeModalCallBack('modal-carrier-edit', function () {
                         self.editCarrierFlag(false);
                         self.editCarrier(null);
                     });
                     self.editCarrierFlag(true);
                     cs.openModal('modal-carrier-edit');
                 } else {
                     cs.closeModalCallBack('modal-carrier-pinless-edit', function () {
                         self.editPinlessFlag(false);
                         self.editCarrier(null);
                     });
                     self.editPinlessFlag(true);
                     cs.openModal('modal-carrier-pinless-edit');
                 }
             })

            track.trackTimeOnPageForPageLink("Edit");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        function convertCarrier(data) {
            $.each(data, function (index, d) {
                d.IsFavorite = ko.observable(d.IsFavorite);
            });
            return data;
        }

        //track event
        self.trackWrenchTotalClick = trackEvent;

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.ManageCarriers,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.ManageCarriers,
                    source: app.page().name
                });
            });
        };
    }
});