﻿define(['knockout', 'app', 'ClientScript', 'DataModel', 'TrackEvent'], function (ko, app, cs, dataModel, track) {
    return function (params) {
        var self = this;
        if (params.api) {
            params.api(this);
        }

        self.editBillingAccountFlag = ko.observable(false);
        self.addBillingAccountFlag = ko.observable(false);
        self.editBillingAccount = ko.observable();
        self.billingAccounts = ko.observable();
        self.sortType = ko.observable('sortby');
        self.isAscending = ko.observable(true);

        ko.components.unregister('edit-biller');
        ko.components.register('edit-biller', {
            viewModel: { require: 'edit-biller-js' },
            template: { require: 'text!edit-biller-html' }
        });

        cs.BaseAjax({
            url: '/BillPay/GetBillingAccounts',
            type: 'GET',
            data: 'json'
        })
       .done(function (data) {
           data = data || [];

           $.each(data, function (index, d) {
               d.IsFavorite = ko.observable(d.IsFavorite);
           });
           self.billingAccounts(data);
       })
       .fail(function () {
           self.billingAccounts([]);
       });

        app.cacheComponent(['edit-biller']);

        self.initEditBillingAccount = function (billingAccount) {
            cs.AjaxByDelayLoading({
                url: '/BillPay/GetBillingAccount',
                type: "GET",
                dataType: "json",
                contentType: "application/json",
                data: { "billingAccountId": billingAccount.RppsBillingAccountId, "accountType": billingAccount.AccountType }
            })
            .done(function (data) {
                self.editBillingAccount(data);
                cs.closeModalCallBack('modal-biller-Edit', function () {
                    self.editBillingAccountFlag(false);
                    self.editBillingAccount(null);
                });
                self.editBillingAccountFlag(true);
                cs.openModal('modal-biller-Edit');
            });

            track.trackTimeOnPageForPageLink("Edit");
        };

        function convertToManageBillingAccount(billingAccount) {
            var tempBillingAccount = {
                RppsBillingAccountId: billingAccount.RppsBillingAccountId,
                AccountNumber: billingAccount.AccountNumber,
                BillerName: billingAccount.BillerName,
                BillerType: billingAccount.BillerType,
                AccountName: billingAccount.AccountName,
                AccountType: billingAccount.AccountType,
                LastReceiptNumber: billingAccount.LastReceiptNumber,
                IsFavorite: billingAccount.IsFavorite,
                FirstName: billingAccount.FirstName,
                LastName: billingAccount.LastName,
                IsRppsBillingAccount: billingAccount.IsRppsBillingAccount,
                DestinationCountry: billingAccount.DestinationCountry,
                CountryCode: billingAccount.CountryCode
            }

            return tempBillingAccount;
        }


        function refreshBillingAccounts(billingAccount) {
            var tempBillingAccount = convertToManageBillingAccount(billingAccount);
            var billingAccounts = ko.mapping.toJS(self.billingAccounts);

            for (var i = 0; i < billingAccounts.length; i++) {
                if (billingAccounts[i].RppsBillingAccountId == billingAccount.RppsBillingAccountId) {
                    billingAccounts[i] = tempBillingAccount;
                }

                billingAccounts[i].IsFavorite = ko.observable(billingAccounts[i].IsFavorite);
            }

            self.billingAccounts(billingAccounts);
        }

        self.completedEditBiller = function (billingAccount) {
            refreshBillingAccounts(billingAccount);

            self.editBillingAccountFlag(false);
            self.editBillingAccount(null);
        };

        self.searchText = ko.observable("");
        var timerHandler = 0;
        self.autoSearchBillingAccount = function (value) {
            var oldValue = self.searchText();
            self.searchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.searchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 1) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.searchBillingAccount(); }, 500);
            }
        }

        self.searchBillingAccount = function () {
            var criteria = $("#input-search-for-recipients-billers").val().trim();
            cs.AjaxBySpinner({
                url: '/BillPay/SearchBillingAccount',
                type: "GET",
                dataType: "json",
                contentType: "application/json",
                data: { "criteria": criteria }
            }, "#search-bill-pay-billers")
            .done(function (data) {
                data = data || [];
                $.each(data, function (index, d) {
                    d.IsFavorite = ko.observable(d.IsFavorite);
                });

                //DataCapture.
                if (Object.prototype.toString.call(data).slice(8, -1) == "Array" && data.length == 0) {
                    cs.LogSearchActivity(criteria, cs.LuSearchSectionType.SearchFromTransactedBillersInManagerBillers);
                }

                self.billingAccounts(data);
                cs.closeFoundationDropdown();
            });
        }

        // Not used any more.
        self.updateFavorite = function (billingAccount) {
            var tempBillingAccount = ko.mapping.toJS(billingAccount);
            tempBillingAccount.IsFavorite = !tempBillingAccount.IsFavorite;
            cs.BaseAjax({
                url: '/BillPay/SelfServiceUpdateFavorite',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify({ 'billingAccountId': tempBillingAccount.RppsBillingAccountId, 'accountType': tempBillingAccount.AccountType, 'isFavorite': tempBillingAccount.IsFavorite })
            })
            .done(function (data) {
                billingAccount.IsFavorite(!billingAccount.IsFavorite());
            });
        };

        self.sortBillingAccountBy = function (value, element) {
            var classname = element.children[0].className;
            resetSort();

            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-up";
                self.sortType(value);
                self.isAscending(true);
            }
            else {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-down";
                self.sortType(value);
                self.isAscending(false);
            }
        }

        function resetSort() {
            $("#bill-pay-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#bill-pay-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#bill-pay-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.sortType("sortby");
            self.isAscending(true);
        }

        self.sortBillingAccounts = ko.computed(function () {
            if (self.billingAccounts() != null) {
                var sortedBillingAccount = self.billingAccounts();
                var sortType = self.sortType();
                var isAscending = self.isAscending();
                if (sortType == "sortby") {
                    return sortedBillingAccount;
                }
                else {
                    if (sortType == "FirstName") {
                        return sortedBillingAccount.sort(dataModel.CompareCustomerName(isAscending));
                    }
                    else {
                        return sortedBillingAccount.sort(cs.compare(sortType, null, isAscending, 'RppsBillingAccountId'));
                    }
                }
            }

            return new Array();
        });

        var deleteStatus = new cs.executeStatus();
        self.deleteBillingAccount = function (billingAccount) {
            $("#ConfirmToRemove").unbind('click');
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove biller
                cs.AddActivityInfo(16);

                if (deleteStatus.isExecuting()) {
                    return;
                }
                if (cs.isDisabled("ConfirmToRemove")) {
                    return;
                }
                deleteStatus.setExecuting();
                return cs.AjaxBySpinner({
                    url: '/BillPay/SelfServiceDeleteBillingAccount',
                    contentType: "application/json",
                    type: "Get",
                    cache: false,
                    data: { "billingAccountId": billingAccount.RppsBillingAccountId, "accountType": billingAccount.AccountType }
                }, "#ConfirmToRemove")
                .done(function () {
                    var tempBillingAccounts = self.billingAccounts();
                    for (var i = 0; i < tempBillingAccounts.length; i++) {
                        if (tempBillingAccounts[i].RppsBillingAccountId == billingAccount.RppsBillingAccountId) {
                            tempBillingAccounts.splice(i, 1);
                        }
                    }
                    self.billingAccounts(tempBillingAccounts);
                    $.when(cs.closeModal())
                    .done(function () {
                        deleteStatus.complete();
                    });
                })
                .fail(function () {
                    deleteStatus.complete();
                });
            })
            cs.openModal("modal-remove", true, true, true);
            track.trackTimeOnPageForPageLink("Remove");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        self.completedAddBiller = function (billingAccount) {
            var tempBillingAccount = convertToManageBillingAccount(billingAccount);
            var billingAccounts = ko.mapping.toJS(self.billingAccounts);

            billingAccounts.push(tempBillingAccount);

            for (var i = 0; i < billingAccounts.length; i++) {
                billingAccounts[i].IsFavorite = ko.observable(billingAccounts[i].IsFavorite);
            }

            self.billingAccounts(billingAccounts);
            if (!$("#panel-billers").hasClass('active'))
            {
                app.redirectTo("/SelfService/AccountConsumer#panel-billers");
            }
            self.addBillingAccountFlag(false);
        }

        self.initAddBillingAccount = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            cs.closeModalCallBack('modal-biller-new', function () {
                self.addBillingAccountFlag(false);
            });

            self.addBillingAccountFlag(true);
            cs.openModal('modal-biller-new');
            track.trackTimeOnPageForPageLink("Add");
        }

        self.quickPay = function (billingAccount, element) {
            if (cs.isDisabled(element)) {
                return;
            }

            trackQuickPay(billingAccount.LastReceiptNumber != null && billingAccount.LastReceiptNumber.trim() != "");
            track.trackTimeOnPageForPageLink(billingAccount.LastReceiptNumber ? "PayAgain" : "ClickToPay");

            if (!app.senderInfo().HasMoneyTransferPermission()) {
                return;
            }

            dataModel.QuickToPayByBillingAccount(false, billingAccount, "FromManageBillers");
        };

        function trackQuickPay(isQuickPay) {
            var trackQuickPay = trackEvent;
            if (isQuickPay) {
                trackQuickPay("Quick Pay");
            } else {
                trackQuickPay("Click To Pay");
            }
        }

        //Track Event
        self.trackWrenchTotalClick = trackEvent;

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.ManageBillers,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.ManageBillers,
                    source: app.page().name
                });
            });
        };
    }
});