﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['AccountConsumer-strings'], paths['common-strings'], 'TrackEvent'], function (ko, app, cs, dataModel, accuntconsumerstrings, commonstrings, track) {
    return function (params) {
        if (params.api) {
            params.api(this);
        }
        var self = this;
        self.transactionRecords = ko.observable();
        var pageSize = 10;
        self.pageIndex = ko.observable("1");
        self.TimeType = ko.observable("1");
        self.sortType = ko.observable('Date');
        self.isAscending = ko.observable(false);
        self.TransactionDetailModel = ko.observable();
        self.maxSize = ko.observable(0);
        self.onHoldCount = ko.observable(0);

        self.filterStatus = ko.observable('all');
        self.filterType = ko.observable("all");
        self.ShowUpgradePrompt = ko.observable(false);

        getTransactions();
        checkSenderLevelInfo();

        function checkSenderLevelInfo() {
            if (app.senderInfo() && app.senderInfo().SenderLevel()) {
                if (app.senderInfo().SenderLevel().TargetLevelId > app.senderInfo().SenderLevel().SourceLevelId) {
                    self.ShowUpgradePrompt(app.senderInfo().SenderLevel().Status == 2 && app.senderInfo().HasMoneyTransferPermission());
                }
            } else {
                app.page().data.LoadedSenderInfo = function () {
                    checkSenderLevelInfo();
                };
            }
        }

        app.cachePage(['BillPayTransactionDetail-html', 'MoneyTransferTransactionDetail-html', 'TopUpsTransactionDetail-html']);

        self.TransactionSearchText = ko.observable("");
        var timerHandler = 0;
        self.autoSearchTransactions = function (value) {
            var oldValue = self.TransactionSearchText();
            self.TransactionSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.TransactionSearchText(value);

                if (value.length < 1) {
                    isSearch = false;
                }
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 1) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () {
                    self.searchTransactions();
                    var trackSearchTotalNumbers = trackInput;
                    trackSearchTotalNumbers("Search");
                }, 500);
            }
        }

        self.searchTransactions = function () {
            self.pageIndex(1);
            getTransactions("#search-transaction");
        }

        function getTransactions(element) {
            var criteria = $("#input-search-for-transaction-history").val().trim();

            cs.AjaxBySpinner({
                url: '/Customers/SearchTransactionHistory',
                type: "GET",
                dataType: "json",
                contentType: "application/json",
                data: { "criteria": criteria, 'transactionType': self.filterType(), 'processType': self.filterStatus(), 'currentPage': self.pageIndex(), 'pageCount': pageSize, 'sortType': self.sortType(), 'isAscending': self.isAscending() }
            }, element)
            .done(function (data) {
                $.each(data.TransactionRecords, function (index, v) {
                    v.CanVoid = ko.observable(v.CanVoid);
                    v.Status = ko.observable(v.Status);
                });
                //Data Capture
                if (Object.prototype.toString.call(data.TransactionRecords).slice(8, -1) == "Array" && data.TransactionRecords.length == 0) {
                    cs.LogSearchActivity(criteria, cs.LuSearchSectionType.SearchFromTransactionhistory);
                }

                self.transactionRecords(data.TransactionRecords);
                self.maxSize(data.MaxSize);
                if (!criteria && self.filterType() == 'all' && self.filterStatus() == 'all' && self.pageIndex() == 1 && self.sortType() == 'Date' && !self.isAscending()) {
                    self.onHoldCount(data.OnHoldCount);
                }
            })
            .fail(function () {
                self.transactionRecords([]);

                //Data Capture.
                cs.LogSearchActivity(criteria, cs.LuSearchSectionType.SearchFromTransactionhistory);

                self.maxSize(0);
            });
        }

        function getOnHoldCount() {
            cs.AjaxBySpinner({
                url: '/Customers/SearchTransactionHistory',
                type: "GET",
                dataType: "json",
                contentType: "application/json",
                data: { "criteria": '', 'transactionType': 'all', 'processType': 'all', 'currentPage': 1, 'pageCount': 10, 'sortType': 'Date', 'isAscending': false }
            })
            .done(function (data) {
                self.onHoldCount(data.OnHoldCount);
                if (self.onHoldCount() <= 0) {
                    self.ShowUpgradePrompt(false);
                }
            })
        }

        self.filterChanged = function () {
            self.pageIndex("1");
            getTransactions();
        }

        //sort
        self.sortTransactionBy = function (value, element) {
            var classname = element.children[0].className;
            resetSort();
            self.pageIndex("1");
            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-up";

                self.isAscending(true);
                self.sortType(value);
            }
            else {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-down";

                self.isAscending(false);
                self.sortType(value);
            }

            getTransactions();
        }

        function resetSort() {
            $("#Transaction-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#Transaction-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#Transaction-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.sortType("sortby");
            self.isAscending(true);
        }


        self.sortedTransactionRecords = ko.computed(function () {
            var tempTransactions = self.transactionRecords();
            var transactionType = self.filterType();
            var transactionStatus = self.filterStatus();
            if (!tempTransactions || transactionType == undefined || transactionStatus == undefined) {
                return tempTransactions;
            }

            return tempTransactions;
        });

        self.filterTransactionRecords = ko.computed(function () {
            var sortedTransactionList = self.sortedTransactionRecords();
            if (!sortedTransactionList) {
                return sortedTransactionList;
            }

            return sortedTransactionList;
        });

        var transactionDetailStatus = new cs.executeStatus();
        self.openTransactionDetails = function (receiptNumber, isOnHold) {
            if (transactionDetailStatus.isExecuting()) {
                return;
            }

            var trackTransactionDetailsTotalClick = trackEvent;
            trackTransactionDetailsTotalClick('Transaction Details');

            transactionDetailStatus.setExecuting();
            cs.AjaxByDelayLoading({
                url: '/Customers/GetTransactionDetailByReceiptNumber',
                type: "GET",
                dataType: "json",
                contentType: "application/json",
                data: { "receiptNumber": receiptNumber }
            })
            .done(function (data) {
                data.IsOnHold = isOnHold;
                self.TransactionDetailModel(ko.mapping.fromJS(data));
                track.generatePartialTimeOnPageTrack(track.CategoryEnum.TransactionDetails, track.PageEnum.TransactionDetails);
                if (self.TransactionDetailModel().TransactionTypeId() == 1 || self.TransactionDetailModel().TransactionTypeId() == 14) {
                    cs.closeModalCallBack("modal-transaction-details-mt", null);
                    $.when(cs.openModal("modal-transaction-details-mt"))
                    .done(function () {
                        transactionDetailStatus.complete();
                    });
                }
                else if (self.TransactionDetailModel().TransactionTypeId() == 5 || self.TransactionDetailModel().TransactionTypeId() == 11) {
                    cs.closeModalCallBack("modal-transaction-details-bp", null);
                    $.when(cs.openModal("modal-transaction-details-bp"))
                    .done(function () {
                        transactionDetailStatus.complete();
                    });
                }
                else if (self.TransactionDetailModel().TransactionTypeId() == 12 || self.TransactionDetailModel().TransactionTypeId() == 13) {
                    cs.closeModalCallBack("modal-transaction-details-tu", null);
                    $.when(cs.openModal("modal-transaction-details-tu"))
                    .done(function () {
                        transactionDetailStatus.complete();
                    });
                }
                $("#TimeType").val("2");
                self.TimeType("2");
            })
            .fail(function () {
                transactionDetailStatus.complete();
            });

            track.trackTimeOnPageForPageLink("TransactionDetails");
            trackTransactionDetailsTotalLoads();
        }

        self.closeTransactionDetails = function (action) {
            if (typeof track.trackTimeOnPageForPageLink === 'function') {
                track.trackTimeOnPageForPageLink(action);
            }
            cs.closeModal();
        }

        self.changePageIndex = function (value) {
            self.pageIndex(value);
            getTransactions();
        }

        self.pageIndexs = ko.computed(function () {
            if (self.maxSize() == 0) {
                return 0;
            }
            var tempPageIndexs = new Array();
            var i = 1;

            if (self.maxSize() <= pageSize) {
                tempPageIndexs.push(i);
            }
            else {
                for (var a = 1; a <= self.maxSize() / pageSize; a++) {
                    tempPageIndexs.push(a);
                    i++;
                }

                if (self.maxSize() % pageSize > 0) {
                    tempPageIndexs.push(i);
                    i++;
                }
            }

            return tempPageIndexs;
        });

        self.moveToFirstPage = function () {
            self.pageIndex(1);
            getTransactions();
        }

        self.moveToLastPage = function () {
            self.pageIndex(self.pageIndexs().length);
            getTransactions();
        }

        var voidTransactionStatus = new cs.executeStatus();
        self.voidTransaction = function (transactionModel) {
            cs.showConfirmMessage(accuntconsumerstrings.message.messagetitle, accuntconsumerstrings.message.voidtransaction, function () {
                if (voidTransactionStatus.isExecuting()) {
                    return;
                }
                //For datacapture, void transaction
                cs.AddActivityInfo(27);

                voidTransactionStatus.setExecuting();
                return $.when(voidTransaction(transactionModel, "#ConfirmOk"))
                .done(function () {
                    voidTransactionStatus.complete();
                })
                .fail(function () {
                    voidTransactionStatus.complete();
                });
            });
        }

        function voidTransaction(transactionModel, element) {
            $("#ConfirmCancel").off("click");
            $("#ConfirmCancel").attr("disabled", true);

            /*For DataCapture: Log Request Info of Cancellation.*/
            var cancellationActivity = {
                ReceiptNumber: transactionModel.ReceiptNumber,
                TransactionTypeId: transactionModel.TransactionTypeId,
                TransactionStatusCode: transactionModel.TransactionStatusCode,
                PaymentStatusCode: transactionModel.PaymentStatusCode,
                BatchStatusId: transactionModel.BatchStatusId,
                CancellationFlag: -1,
                CancelRequestTime: cs.GetDateTimeOffset()
            };

            return cs.AjaxBySpinner({
                url: '/Customers/VoidSelfServiceTransaction',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(transactionModel))
            }, element)
            .done(function (data) {
                $("#ConfirmCancel").removeAttr("disabled");
                $("#ConfirmCancel").click(function () {
                    cs.closeModal();
                });

                if (data) {
                    app.senderInfo().GetSenderLevel(element);
                    for (var i = 0; i < self.transactionRecords().length; i++) {
                        if (transactionModel.ReceiptNumber == self.transactionRecords()[i].ReceiptNumber) {
                            if ([cs.TransactionType.MoneyTransferToCard, cs.TransactionType.MoneyTransferToCash].indexOf(transactionModel.TransactionTypeId) != -1) {
                                if (self.transactionRecords()[i].Status() == accuntconsumerstrings.transaction.onhold) {
                                    getOnHoldCount();
                                }
                                self.transactionRecords()[i].Status(accuntconsumerstrings.transaction.pendingcancellation);
                            }
                            else {
                                self.transactionRecords()[i].Status(accuntconsumerstrings.transaction.canceled);
                            }
                            self.transactionRecords()[i].CanVoid(false);
                            var notifyMessageModel = {
                                Title: accuntconsumerstrings.message.success,
                                Message: ([cs.TransactionType.MoneyTransferToCard, cs.TransactionType.MoneyTransferToCash].indexOf(transactionModel.TransactionTypeId) != -1) ?
                                         accuntconsumerstrings.message.cancelledtransactionsuccess : accuntconsumerstrings.message.voidtransactionsuccess
                            }
                            openNotifyMessageModal(notifyMessageModel);
                        }
                    }

                    /*For DataCapture: Log Request Info of Cancellation.*/
                    cancellationActivity.CancellationFlag = 1;
                }
                else {
                    /*For DataCapture: Log Request Info of Cancellation.*/
                    cancellationActivity.CancellationFlag = 0;

                    var message = ([cs.TransactionType.MoneyTransferToCard, cs.TransactionType.MoneyTransferToCash].indexOf(transactionModel.TransactionTypeId) != -1) ? accuntconsumerstrings.message.cancelledtransactionfailed : accuntconsumerstrings.message.voidtransactionfailed;
                    cs.showErrorMessage(accuntconsumerstrings.message.error, message);
                }
            })
            .fail(function () {
                $("#ConfirmCancel").removeAttr("disabled");
                $("#ConfirmCancel").click(function () {
                    cs.closeModal();
                });

                /*For DataCapture: Log Request Info of Cancellation.*/
                cancellationActivity.CancellationFlag = 0;
            })
            .always(function () {
                /*For DataCapture: Log Request Info of Cancellation.*/
                cancellationActivity.CancelProcessedTime = cs.GetDateTimeOffset();
                cs.LogRequestInformationOfCancellation(cancellationActivity);
            });
        }


        function openNotifyMessageModal(notifyMessageModel) {
            $("#NotificationHead").text(notifyMessageModel.Title);
            $("#NotificationMessage").text(notifyMessageModel.Message);
            $('#NotificationConfirmOK').unbind('click');
            $('#NotificationConfirmOK').click(function () {
                cs.closeModal();
            });
            cs.openModal("modal-notification");
        };

        self.TimeTypeChanged = function () {
            self.TimeType($("#TimeType").val());
        }

        self.getSelectedTransaction = function (transaction, element) {
            var trackQuickPayTotalClick = trackEvent;
            trackQuickPayTotalClick("Quick Pay");

            if (cs.isDisabled(element)) {
                return;
            }

            dataModel.GetSelectedTransaction(transaction.TransactionTypeId, transaction.ReceiptNumber, transaction.ReceiverName, "FromTxnHistory");
        }

        self.SendTransactionDetailEmail = function (element) {
            self.SendEmailForTransactionHistory(self.TransactionDetailModel().ReceiptNumber(), element);

            var trackEmailTotalClicks = trackTransactionDetailsEvent;
            trackEmailTotalClicks("Email");
        };

        var emailStatus = new cs.executeStatus();
        self.SendEmailForTransactionHistory = function (receiptNumber, element) {
            if (emailStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            emailStatus.setExecuting();
            cs.AjaxBySpinner({
                url: '/Customers/SelfServiceSendEmailForTransactionDetail',
                type: 'POST',
                dataType: 'json',
                cache: false,
                contentType: 'application/json',
                data: JSON.stringify({ 'receiptNumber': receiptNumber })
            }, element)
            .done(function (data) {
                if (data) {
                    cs.showErrorMessage(accuntconsumerstrings.message.messagetitle, accuntconsumerstrings.message.sentemailsuccess);
                    emailStatus.complete();
                }
                else {
                    cs.showErrorMessage(accuntconsumerstrings.message.messagetitle, accuntconsumerstrings.message.sentemailfail);
                    emailStatus.complete();
                }
            })
            .fail(function (xhr, status) {
                cs.showErrorMessage(accuntconsumerstrings.message.messagetitle, accuntconsumerstrings.message.sentemailfailed);
                emailStatus.complete();
            })
        };

        self.PrintTransactionHistoryStandardReceipt = function (receiptNumber, element) {
            var timeType = $('#TimeType').val();
            var timeTypeName = $("#TimeType").find("option:selected").text();

            if (!timeType) {
                timeType = 0;
            }
            if (!timeTypeName) {
                timeTypeName = "";
            }
            cs.AjaxBySpinner({
                url: '/Customers/PrintTransactionHistoryStandardReceipt',
                type: 'POST',
                dataType: "html",
                cache: false,
                contentType: 'application/json',
                data: JSON.stringify({ 'receiptNumber': receiptNumber(), 'timeType': timeType, 'timeTypeName': timeTypeName })
            }, element)
          .done(function (result) {
              cs.PrintTransaction(result, element);
          });

            var trackPrintTotalClicks = trackTransactionDetailsEvent;
            trackPrintTotalClicks('Print');
        };

        self.SubmitUpgradeDocuments = function (shouldCloseModal) {
            if (shouldCloseModal) {
                $.when(cs.closeModal())
                .done(function () {
                    dataModel.GoToUpgradeLevel(app.senderInfo().SenderLevel().SourceLevelId, app.senderInfo().SenderLevel().TargetLevelId);
                });
            } else {
                dataModel.GoToUpgradeLevel(app.senderInfo().SenderLevel().SourceLevelId, app.senderInfo().SenderLevel().TargetLevelId);
            }
            track.trackTimeOnPageForPageLink(track.LabelEnum.SubmitNow);
        }

        if (params.receiptNumber) {
            setTimeout(function () {
                self.openTransactionDetails(params.receiptNumber, params.isLimitHold);
            }, 300);

        }

        self.receiptNumber = params.receiptNumber;

        //track event
        self.trackWrenchTotalClick = trackEvent;

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionHistory,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionHistory,
                source: app.page().name
            });
        };

        function trackInput(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionHistory,
                eventAction: track.ActionEnum.InputField,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionHistory,
                source: app.page().name
            });
        }

        function trackTransactionDetailsEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionDetails,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.TransactionDetails,
                source: app.page().name
            });
        };

        function trackTransactionDetailsTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.TransactionDetails,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Transaction Details",
                eventPage: track.PageEnum.TransactionDetails,
                source: app.page().name
            });
        }
    }
});