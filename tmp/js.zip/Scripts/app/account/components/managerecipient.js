﻿define(['knockout', 'app', 'ClientScript', 'DataModel', 'TrackEvent'], function (ko, app, cs, dataModel, track) {
    return function (params) {
        var self = this;
        if (params.api) {
            params.api(this);
        }

        self.addRecipientFlag = ko.observable(false);
        self.editRecipientFlag = ko.observable(false);
        self.editRecipient = ko.observable();
        self.recipients = ko.observable();

        ko.components.unregister('edit-recipient');
        ko.components.register('edit-recipient', {
            viewModel: { require: 'edit-recipient-js' },
            template: { require: 'text!edit-recipient-html' }
        });

        cs.BaseAjax({
            url: '/MoneyTransfer/GetReceivers',
            type: 'GET',
            data: 'json',
        })
        .done(function (data) {
            data = data || [];
            self.recipients(convertRecipients(data));
        })
        .fail(function () {
            self.recipients([]);
        });

        app.cacheComponent(['edit-recipient']);

        function convertRecipients(data) {
            if (!data) {
                data = [];
            }
            $.each(data, function (index, recipient) {
                recipient.IsFavorite = ko.observable(recipient.IsFavorite);
            });

            return data;
        }

        self.searchText = ko.observable();
        var timerHandler = 0;
        self.autoSearchRecipients = function (value) {
            var oldValue = self.searchText();
            self.searchText(value);

            var isSearch = true;
            clearTimeout(timerHandler);

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.searchText(value);
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 1) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.searchReceivers("#search-money-transfer-recipient"); }, 500);
            }
        }

        self.searchReceivers = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }

            var searchCriteria = $("#input-search-for-manager-recipients").val().trim();
            return cs.AjaxBySpinner(
            {
                url: '/MoneyTransfer/SearchReceivers',
                dataType: "json",
                type: "Get",
                cache: false,
                data: { "searchCriteria": searchCriteria }
            }, element)
            .done(function (data) {
                data = data || [];

                //DataCapture.
                if (Object.prototype.toString.call(data).slice(8, -1) == "Array" && data.length == 0) {
                    cs.LogSearchActivity(searchCriteria, cs.LuSearchSectionType.SearchFromAddedRecipientsInManagerRecipients);
                }

                self.recipients(convertRecipients(data));
            });
        }

        self.addRecipient = function (element) {
            if (cs.isDisabled(element)) {
                return;
            }
            cs.closeModalCallBack('modal-recipient-new', function () {
                self.addRecipientFlag(false);
            });
            self.addRecipientFlag(true);
            cs.openModal('modal-recipient-new');

            track.trackTimeOnPageForPageLink("Add");
        };

        self.completedAddRecipient = function (recipientModel) {
            var receiver = convertToRecipient(recipientModel);

            var tempReceivers = self.recipients();
            if (tempReceivers == null) {
                tempReceivers == new Array();
            }
            tempReceivers.push(receiver);
            self.recipients(tempReceivers);
            if (!$("#panel-recipients").hasClass('active')) {
                app.redirectTo("/SelfService/AccountConsumer#panel-recipients");
            }
        }

        self.sortType = ko.observable('sortby');
        self.isAscending = ko.observable(true);
        self.sortedReceivers = ko.computed(function () {
            var tempReceivers = self.recipients();
            if (tempReceivers == null || tempReceivers == undefined) {
                return tempReceivers;
            }

            var sortType = self.sortType();
            var isAscending = self.isAscending();
            if (sortType == 'sortby') {
                return tempReceivers;
            }
            else {
                return tempReceivers.sort(cs.compare(sortType, null, isAscending, 'CardHolderId'));
            }
        });

        // Sort
        self.recipientSort = function (value, element) {
            var classname = element.children[0].className;
            resetSort();
            if (classname == 'sortFieldIcon entypo-icon-arrow-down') {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-up";
                self.sortType(value);
                self.isAscending(true);
            } else {
                element.children[0].className = "sortFieldIcon entypo-icon-arrow-down";
                self.sortType(value);
                self.isAscending(false);
            }
        }

        function resetSort() {
            $("#recipient-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#recipient-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#recipient-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.sortType("sortby");
            self.isAscending(true);
        }

        var showDefaultCity = false;
        var editReceiverStatus = new cs.executeStatus();
        self.initEditRecipient = function (receiver) {
            cs.AjaxByDelayLoading({
                url: '/MoneyTransfer/GetRecipientForEdit',
                type: 'GET',
                data: 'json',
                contentType: 'application/json',
                data: { 'receiverCardHolderId': receiver.CardHolderId }
            })
            .done(function (data) {
                self.editRecipient(data);
                cs.closeModalCallBack('modal-recipient-edit', function () {
                    self.editRecipientFlag(false);
                    self.editRecipient(null);
                });
                self.editRecipientFlag(true);
                cs.openModal('modal-recipient-edit');
            })

            track.trackTimeOnPageForPageLink("Edit");
        };

        function convertToRecipient(recipientModel) {
            var receiver = {
                CardHolderId: recipientModel.CardHolderId,
                CountryImage: recipientModel.CountryImage,
                RecipientName: cs.removeRepeatSpace(recipientModel.FirstName + ' ' + (!!recipientModel.MiddleName ? recipientModel.MiddleName.substring(0, 1) + '.' : recipientModel.MiddleName) + ' ' + recipientModel.LastName),
                LastTransactionDate: null,
                LastTransactionAmount: null,
                Selected: ko.observable(false),
                Address: recipientModel.Address,
                City: recipientModel.City,
                StateName: recipientModel.StateName,
                Zipcode: recipientModel.Zipcode,
                PhoneNumber: '+' + recipientModel.AreaCode + '-' + recipientModel.PhoneNumber,
                FromCurrencyCode: "USD",
                ToCurrencyCode: recipientModel.ToCurrencyCode,
                DisplayRate: recipientModel.DisplayRate,
                Rate: recipientModel.Rate,
                FromCountryImage: recipientModel.FromCountryImage,
                ToCountryImage: recipientModel.ToCountryImage,
                ToCurrencyId: recipientModel.ToCurrencyId,
                CountryId: recipientModel.CountryId,
                StateId: recipientModel.StateId,
                CityId: recipientModel.CityId,
                RelationShip: recipientModel.RelationShip,
                LastReceiptNumber: recipientModel.LastReceiptNumber,
                TotalFunds: recipientModel.TotalFunds,
                IsFavorite: ko.observable(recipientModel.IsFavorite),
                LastPickupType: recipientModel.LastPickupType
            }

            return receiver;
        }

        self.completedEditRecipient = function (recipientModel) {
            var receiver = convertToRecipient(recipientModel);

            var tempReceivers = self.recipients();
            if (tempReceivers == null) {
                tempReceivers == new Array();
            }
            for (var i = 0; i < tempReceivers.length; i++) {
                if (tempReceivers[i].CardHolderId == receiver.CardHolderId) {
                    tempReceivers[i] = receiver;
                    break;
                }
            }
            self.recipients(tempReceivers);
        };

        self.quickPay = function (receiver, element) {
            if (cs.isDisabled(element) || !app.senderInfo().HasMoneyTransferPermission()) {
                return;
            }

            dataModel.QuickToPayByReceiver(receiver, "FromManageRecipients");

            trackQuickPay(receiver.LastReceiptNumber);
            track.trackTimeOnPageForPageLink(receiver.LastReceiptNumber ? "SendAgain" : "ClickToPay");
        };

        function trackQuickPay(isQuickPay) {
            var trackQuickPay = trackEvent;
            if (isQuickPay) {
                trackQuickPay("Quick Pay");
            } else {
                trackQuickPay("Click To Pay");
            }
        }

        // Not used any more.
        self.updateFavorite = function (receiver) {
            return cs.BaseAjax(
                    {
                        url: '/MoneyTransfer/SetFavoriteRecipient',
                        type: "POST",
                        contentType: "application/json",
                        data: JSON.stringify({ "receiverCardHolderId": receiver.CardHolderId, "isFavorite": !receiver.IsFavorite() })
                    })
                   .done(function () {
                       receiver.IsFavorite(!receiver.IsFavorite());
                   })
        }

        var removeReceiverStatus = new cs.executeStatus();
        self.deleteRecipient = function (receiver) {
            $("#ConfirmToRemove").unbind('click');
            $("#ConfirmToRemove").click(function () {
                //For DataCapture, remove receiver
                cs.AddActivityInfo(19);

                if (removeReceiverStatus.isExecuting()) {
                    return;
                }

                if (cs.isDisabled("#ConfirmToRemove")) {
                    return;
                }

                removeReceiverStatus.setExecuting();
                return cs.AjaxBySpinner({
                    url: '/MoneyTransfer/DeleteReceiver',
                    contentType: "application/json",
                    type: "Get",
                    cache: false,
                    data: { "cardHolderId": receiver.CardHolderId }
                }, "#ConfirmToRemove")
                .done(function () {
                    var recipients = self.recipients();
                    for (var i = 0; i < recipients.length; i++) {
                        if (recipients[i].CardHolderId == receiver.CardHolderId) {
                            recipients.splice(i, 1);
                        }
                    }

                    self.recipients(recipients);
                    $.when(cs.closeModal())
                    .done(function () {
                        removeReceiverStatus.complete();
                    })
                })
                .fail(function () {
                    removeReceiverStatus.complete();
                });
            });
            cs.openModal('modal-remove', true, true, true);
            track.trackTimeOnPageForPageLink("Remove");
            track.generatePartialTimeOnPageTrack();// clear time on page track
        }

        self.trackWrenchTotalClick = trackEvent;

        function trackEvent(eventLabel) {
            require(['TrackEvent'], function (T) {
                T.trackEvent({
                    sendType: T.GA + T.MP,
                    eventCategory: T.CategoryEnum.ManageRecipients,
                    eventAction: T.ActionEnum.ButtonClick,
                    eventLabel: eventLabel,
                    eventPage: T.PageEnum.ManageRecipients,
                    source: app.page().name
                });
            });
        };
    }
});