﻿define(['knockout', 'app', 'ClientScript', 'DataModel', paths['common-strings'], 'R', 'TrackEvent'], function (ko, app, cs, dataModel, commonstrings, R, track) {
    return function (params) {
        var self = this;

        function PaymentType() {
            var self = this;
            self.TypeName = ko.observable();
            self.Correspondent = ko.observable();
            self.CurrencyName = ko.observable();
            self.Rate = ko.observable();
            self.AccountNumber = ko.observable();
            self.DisplayAccountNumber = ko.observable();
            self.AccountType = ko.observable();
            self.AccountTypeName = ko.observable();
            self.CurrencyId = ko.observable();
            self.TransactionTypeId = ko.observable();
            self.Payouts = ko.observable();
            self.CountryId = ko.observable();
            self.PaymentTypeId = ko.observable();
            self.Selected = ko.observable(false);
            self.IsPaymentTypeAccount = ko.observable(false);
            self.AccountTypes = ko.observable();
            self.ConfirmAccountNumber = ko.observable();
            self.LastFourCharCardNumber = ko.observable();
            self.SearchCityOutSideCities = ko.observable(false);

            self.AccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accountnumberrequired
                }
            }).isModified(false);

            self.ConfirmAccountNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumberrequired
                },
                equal: {
                    params: self.AccountNumber,
                    //Inline message
                    message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.confirmnumbernotmatch
                }
            }).isModified(false);

            self.ShowAccountTypeForNewBankAccount = ko.computed(function () {
                var accountTypes = self.AccountTypes();
                var correspondent = self.Correspondent();

                if (accountTypes == null) {
                    return false;
                }

                if (correspondent != null && accountTypes != null && accountTypes.length == 0) {
                    return false;
                }

                if (accountTypes != null && accountTypes.length == 1 && accountTypes[0].Value() == cs.BankAccountTypeEnum.NotUsed) {
                    self.AccountType(accountTypes[0].Value());
                    return false;
                } else {
                    return true;
                }
            });

            self.AccountType.extend({
                required: {
                    onlyIf: function () { return (self.ShowAccountTypeForNewBankAccount() && (self.AccountType() == null || self.AccountType() == "" || self.AccountType() == -1)) },
                    //Inline message
                    message: commonstrings.paymentmethod.bankaccount.addbankaccountobject.bankinformation.validation.accounttyperequired
                }
            }).isModified(false);

            self.RemoveValidationMessage = function () {
                self.AccountType.isModified(false);
                self.AccountNumber.isModified(false);
                self.ConfirmAccountNumber.isModified(false);
            };
        };

        self.FirstName = ko.observable(null);
        self.MiddleName = ko.observable(null);
        self.LastName = ko.observable(null);
        self.SecondLastName = ko.observable(null);
        self.RelationShipId = ko.observable(null);
        self.Relationships = ko.observable([commonstrings.addnewrecipient.relationship]);
        self.CountryId = ko.observable();
        self.Countries = ko.observable([]);
        self.Address = ko.observable(null);
        self.Address2 = ko.observable(null);
        self.StateId = ko.observable(null);
        self.States = ko.observable(null);
        self.CityId = ko.observable(null);
        self.CityValidateType = ko.observable(0);
        self.City = null;
        self.cities = null;
        self.Zipcode = ko.observable(null);
        self.PhoneNumber = ko.observable(null);
        self.PhoneType = ko.observable(null);
        self.EmailAddress = ko.observable(null);
        self.AreaCode = ko.observable(null);
        self.CellPhoneNumber = null;
        self.HomePhoneNumber = null;
        self.NewBankAccount = ko.observable();
        self.ToCurrencyId;
        self.SearchCityOutSideCities = ko.observable();
        self.PickUpLocationPaymentTypes = ko.observable();
        self.LocationStores = ko.observable();
        self.ValidType = ko.observable(0);
        self.PaymentType = new PaymentType();
        self.pickupLocationFlag = ko.observable(false);
        self.LocationPickupType = null;
        self.BankAccountPickupType = null;
        self.ShouldShowLocation = ko.observable(false);
        self.Branch;
        self.IsMaternalLastName = ko.observable(true);

        // the whole number including the country must be minimum 10 digits and maximun 17 digits. 
        self.PhoneNumberInValidReason = ko.observable('');

        self.PhoneNumberIsInValid = ko.computed(function () {
            self.PhoneNumberInValidReason('');
            var phoneNumber = self.PhoneNumber();
            if (!phoneNumber) {
                return;
            }

            var areaCodeLength = self.AreaCode() ? self.AreaCode().length : 0;
            if (self.PhoneNumber().length + areaCodeLength < 10) {
                self.PhoneNumberInValidReason('limitMinLength');
                return true;
            }

            var tempPhoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (cs.IsInvalidPhoneNumber(tempPhoneNumber)) {
                return true;
            }

            if (tempPhoneNumber.length + areaCodeLength <= 17) {
                return false;
            } else {
                self.PhoneNumberInValidReason('limitMaxLength');
                return true;
            }
        });

        self.FormatAreaCode = ko.observable("");
        ko.computed(function () {
            if (self.AreaCode()) {
                self.FormatAreaCode('+' + self.AreaCode());
            } else {
                self.AreaCode("");
            }
        });

        // Start appsflyer track event
        track.generatePartialTimeOnPageTrack(track.CategoryEnum.AddNewRecipient, track.PageEnum.AddNewRecipient);

        var trackCancelTimeOnPage = function (timeStop) {
            track.trackTimeOnPageForPageLink(timeStop);
        };

        var trackSaveTimeOnPage = function () {
            track.trackTimeOnPageForPageLink("Save");
        };

        self.trackErrorMessage = self.trackError = track.generateErrorMessageTrack(track.CategoryEnum.AddNewRecipient, track.PageEnum.AddNewRecipient);

        ko.computed(function () {
            var cityValidationType = self.CityValidateType();
            if (cityValidationType === 1) {
                self.trackErrorMessage(commonstrings.validation.addressvalidation.cityrequired);
            } else if (cityValidationType === 2) {
                self.trackErrorMessage(commonstrings.validation.addressvalidation.cityinvalid);
            }
        });

        ko.computed(function () {
            var validType = self.ValidType();

            if (validType === 1) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.bankrequired);
            } else if (validType === 2) {
                self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addaccountdeposit.validation.invalidcorrespondent);
            }
        });
        // End appsflyer track event


        function applyReceiverValidation() {
            self.FirstName.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.namevalidation.firstnamerequired },
                minTrimLength: { params: 2, message: commonstrings.validation.namevalidation.firstnameminlength },
                maxLength: { params: 50, message: commonstrings.validation.namevalidation.firstnamemaxlength },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.FirstName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.FirstName()) == 1 ? commonstrings.validation.namevalidation.firstnamestartwithletter : commonstrings.validation.namevalidation.firstnameinvalid }
                }
            }).isModified(false);
            self.MiddleName.extend({
                //Inline message
                maxLength: { params: 50, message: commonstrings.validation.namevalidation.middlenamemaxlength },
                equal: {
                    onlyIf: function () { return self.MiddleName() != "" && cs.IsInvalidName(self.MiddleName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.MiddleName()) == 1 ? commonstrings.validation.namevalidation.middlenamestartwithletter : commonstrings.validation.namevalidation.middlenameinvalid }
                }
            }).isModified(false);
            self.LastName.extend({
                //Inline message
                required: { params: true, message: commonstrings.validation.namevalidation.lastnamerequired },
                minTrimLength: { params: 2, message: commonstrings.validation.namevalidation.lastnameminlength },
                maxLength: { params: 50, message: commonstrings.validation.namevalidation.lastnamemaxlength },
                equal: {
                    onlyIf: function () { return cs.IsInvalidName(self.LastName()) != 0 },
                    //Inline message
                    message: function () { return cs.IsInvalidName(self.LastName()) == 1 ? commonstrings.validation.namevalidation.lastnamestartwithletter : commonstrings.validation.namevalidation.lastnameinvalid }
                }
            }).isModified(false);
            self.SecondLastName.extend({
                minTrimLength: {
                    params: 2, message: function () {
                        if (self.IsMaternalLastName()) {
                            return commonstrings.validation.namevalidation.maternallastnameminlength;
                        } else {
                            return commonstrings.validation.namevalidation.secondlastnameminlength;
                        }
                    }
                },
                maxLength: {
                    params: 50, message: function () {
                        if (self.IsMaternalLastName()) {
                            return commonstrings.validation.namevalidation.maternallastnamemaxlength;
                        }
                        else {
                            return commonstrings.validation.namevalidation.secondlastnamemaxlength;
                        }
                    }
                },
                equal: {
                    onlyIf: function () { return self.SecondLastName() != "" && cs.IsInvalidName(self.SecondLastName()) != 0 },
                    message: function () {
                        if (self.IsMaternalLastName()) {
                            return cs.IsInvalidName(self.SecondLastName()) == 1 ? commonstrings.validation.namevalidation.maternallastnamestartwithletter : commonstrings.validation.namevalidation.maternallastnameinvalid
                        }
                        else {
                            return cs.IsInvalidName(self.SecondLastName()) == 1 ? commonstrings.validation.namevalidation.secondlastnamestartwithletter : commonstrings.validation.namevalidation.secondlastnamesinvalid
                        }
                    }
                }
            }).isModified(false);
            //Inline message
            self.Address.extend({ required: { params: true, message: commonstrings.validation.addressvalidation.addressrequired } }).isModified(false);
            self.StateId.extend({ required: { params: true, message: commonstrings.validation.addressvalidation.staterequired } }).isModified(false);
            self.Zipcode.extend({
                number: {
                    params: true,
                    //Inline message
                    message: commonstrings.validation.addressvalidation.zipcodeinvalid
                },
                maxLength: {
                    params: 12,
                    //Inline message
                    message: commonstrings.validation.addressvalidation.zipcodeinvalid
                }
            }).isModified(false);

            self.PhoneNumber.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.phonerequired
                },
                equal: {
                    onlyIf: self.PhoneNumberIsInValid,
                    //Inline message
                    message: function () {
                        if (self.PhoneNumberInValidReason() == 'limitMinLength') {
                            return commonstrings.addnewrecipient.validation.phoneminimumlength;
                        } else if (self.PhoneNumberInValidReason() == 'limitMaxLength') {
                            return commonstrings.addnewrecipient.validation.phonemaximumlength;
                        }
                        else {
                            return commonstrings.addnewrecipient.validation.phoneinvalid;
                        }
                    }
                }
            }).isModified(false);

            self.RelationShipId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.relationshiprequired
                }
            }).isModified(false);

            self.EmailAddress.extend({
                email: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.emailinvalid
                }
            }).isModified(false);

            self.CountryId.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.validation.addressvalidation.countryrequired
                }
            }).isModified(false);

            self.PhoneType.extend({
                required: {
                    params: true,
                    //Inline message
                    message: commonstrings.addnewrecipient.validation.phonetyperequired
                }
            }).isModified(false);
        }

        function InitializeDestinationCountries(element) {
            $.when(dataModel.InitializeDestinationsCountries(14, element))
            .done(function (data) {
                self.Countries(data);
                self.States([]);
            })
        }

        function InitializeDestinationCountry() {
            $.when(dataModel.getLastSendMoneyFeeCalculator())
            .done(function (data) {
                if (!data) return;

                var countryId = data.ToCountryId;

                //init Areacode for countryid
                ResetAreaCodeForCountryId(countryId);

                self.CountryId(countryId);
                GetCurrencyId(countryId);
                InitializeDestinationStates(countryId);
                SetSecondLastName(countryId);
            });

        }

        function InitializeRelationShips() {
            $.when(dataModel.GetRelationShips())
            .done(function (data) {
                self.Relationships(data);
            });
        }

        applyReceiverValidation();

        InitializeRelationShips();

        InitializeDestinationCountries();
        InitializeDestinationCountry();

        self.CountryChanged = function (countryId) {
            InitializeDestinationStates(countryId);
            ResetState();
            resetCity();
            RestAreaCodeForAddReceiver(countryId);
            GetCurrencyId(countryId);
            self.SearchCityOutSideCities(false);

            // Reset bank account diposit.
            if ($('#panel_bank1').hasClass('active')) {
                $('a[href=#panel_bank1]').trigger('click');
            }

            // Reset pick up location.
            if ($('#panel_cash1').hasClass('active')) {
                $('a[href=#panel_cash1]').trigger('click');
            }

            SetSecondLastName(countryId);
        };

        function SetSecondLastName(countryId) {
            // Mexico 484, Peru 604
            if (countryId == 484 || countryId == 604) {
                self.IsMaternalLastName(false);
            }
            else {
                self.IsMaternalLastName(true);
            }
        }

        function GetCurrencyId(countryId) {
            for (var i = 0; i < self.Countries().length ; i++) {
                if (countryId == self.Countries()[i].Value) {
                    self.ToCurrencyId = self.Countries()[i].CurrencyId;
                    return self.ToCurrencyId;
                }
            }
        }

        function RestAreaCodeForAddReceiver(countryId) {
            if (!countryId || !self.Countries()) {
                self.AreaCode("");
                return;
            }

            ResetAreaCodeForCountryId(countryId);

            self.AddPhoneNumberBlur($("#input-home-phone"));
        }

        function ResetAreaCodeForCountryId(countryId) {
            var countries = ko.mapping.toJS(self.Countries());

            if (!countries || countries.length == 0) {
                return;
            }

            for (var i = 0; i < countries.length; i++) {
                var country = countries[i];
                if (country.Value == countryId.toString()) {
                    self.AreaCode(country.Code);
                    break;
                }
            }
        }

        function ResetState() {
            self.StateId(null);
        }

        function ResetCity() {
            AutoCompleteCitys('#autocomplete-moneytransfer-city-names-addrecipient', null);
            self.CityId(null)
        }

        function InitializeDestinationStates(countryId) {
            $.when(dataModel.GetStatesByCountryId(countryId))
            .done(function (data) {
                self.States(data);
            })
            .fail(function () {
                self.states([]);
            });
        }

        self.StateChanged = function () {
            var countryId = self.CountryId();
            var stateId = self.StateId();

            clearCityLocationContent();
            resetCity();
            $.when(dataModel.GetCitiesByStateId(countryId, stateId))
            .done(function (result) {
                AutoCompleteCitys('#autocomplete-city-names-addrecipient', result);
            });
        };

        function resetCity() {
            $("#autocomplete-city-names-addrecipient").val('');
            $("#autocomplete-city-names-addrecipient").autocomplete({
                lookup: [],
            });
            self.CityId(null);
            self.CityValidateType(0);
        }

        function AutoCompleteCitys(element, lookup) {// using now
            $(element).val("");
            self.CityId(null);
            self.City = null;
            self.cities = lookup;
            $(element).autocomplete({
                lookup: lookup,
                triggerSelectOnValidInput: false,
                minChars: 1,
                onSelect: function (suggestion) {
                    self.CityId(suggestion.data.Value);
                    self.City = suggestion.value;
                    self.CityValidateType(0);

                    if (self.pickupLocationFlag() && !self.SearchCityOutSideCities()) {
                        initializePaymentTypeList();
                        InitializePickUpLocationCities();
                    }
                },
                lookupFilter: function (k, j, l) {
                    var inputValue = (cs.removeDiacritics(l).toLowerCase());
                    return cs.removeDiacritics(k.value).toLowerCase().indexOf(inputValue) !== -1
                }
            });
            $(element).autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
            $(element).off('keyup.validation.city');
            $(element).on('keyup.validation.city', function () {
                var value = $(this).val();
                if (value != self.City) {
                    if (value == "") {
                        self.CityValidateType(1);
                    }
                    else if (cs.isMatchSuggestion($(element).autocomplete().suggestions, value, false) > -1) {
                        self.CityValidateType(0);
                        return;
                    }
                    else {
                        self.CityValidateType(2);
                    }
                    self.CityId(null);
                    self.City = null;
                    clearCityLocationContent();
                }
            });

            $(element).off('blur.validation.city');
            $(element).on('blur.validation.city', function () {
                if ($('.autocomplete-selected').length > 0) return;

                var matchedIndex = -1;
                var value = $(this).val();

                if (value == "") {
                    self.CityValidateType(1);
                }
                else if ($(element).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(element).autocomplete().suggestions, value, true)) > -1) {
                    self.CityValidateType(0);
                    $(element).autocomplete().select(matchedIndex);
                    return;
                } else {
                    self.CityValidateType(2);
                }
            });
        }

        self.PhoneNumberFocus = function (element) {
            if (!($(element).val())) {
                return;
            }

            $(element).val(cs.GetRemoveFormatPhoneNumber($(element).val()));
        }

        self.AddPhoneNumberBlur = function (element) {
            var phoneNumber = $(element).val();
            if (!phoneNumber) {
                return;
            }

            phoneNumber = cs.GetRemoveFormatPhoneNumber(phoneNumber);
            if (phoneNumber.length == 10 && !cs.IsInvalidPhoneNumber(phoneNumber)) {
                var reg = new RegExp("(\\d{3})(\\d{3})(\\d{4})")
                if (self.PhoneType() == 2) {
                    if (self.AreaCode()) {
                        phoneNumber = '-' + phoneNumber.replace(reg, "($1) $2-$3");
                    }
                    else {
                        phoneNumber = phoneNumber.replace(reg, "($1) $2-$3");
                    }
                } else {
                    if (self.AreaCode()) {
                        phoneNumber = '-' + phoneNumber.replace(reg, "$1-$2-$3");
                    } else {
                        phoneNumber = phoneNumber.replace(reg, "$1-$2-$3");
                    }
                }
            }
            else {
                if (self.AreaCode()) {
                    phoneNumber = '-' + phoneNumber;
                }
            }

            $(element).val(phoneNumber);
        }

        var addReceiverStatus = new cs.executeStatus();
        function AddSelfServiceReceiver(element) {
            if (addReceiverStatus.isExecuting()) {
                return;
            }
            if (cs.isDisabled(element)) {
                return;
            }
            addReceiverStatus.setExecuting();

            var tempRecipeintModel = ko.mapping.toJS(self);
            delete tempRecipeintModel.Countries;
            delete tempRecipeintModel.States;
            delete tempRecipeintModel.Relationships;
            delete tempRecipeintModel.cities;
            delete tempRecipeintModel.PickUpLocationPaymentTypes;
            delete tempRecipeintModel.LocationStores;

            return cs.AjaxBySpinner({
                url: '/MoneyTransfer/AddSelfServiceReceiver',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify(tempRecipeintModel)
            }, element)
            .done(function (data) {
                trackSaveTimeOnPage();

                $.when(cs.closeModal())
                .done(function () {
                    if (params.done) {
                        params.done(data);
                    }
                });

                addReceiverStatus.complete();
            })
            .fail(function () {
                addReceiverStatus.complete();
            });
        }


        function validationReceiver() {
            var isValidDestination = true;
            if (self.BankAccountPickupType == 1) {
                var bankName = $('#autocomplete-bank-names').val();
                if ($('#autocomplete-bank-names').length > 0 && (bankName == '' || bankName == null)) {
                    self.ValidType(1);
                    isValidDestination = false;
                } else if ($('#autocomplete-bank-names').length > 0 && self.ValidType() != 0) {
                    isValidDestination = false;
                }
                if (!(self.NewBankAccount() && self.NewBankAccount().PaymentType().AccountTypes() && (self.NewBankAccount().PaymentType().AccountTypes().length == 0 || self.NewBankAccount().PaymentType().AccountType() != 0))) {
                    isValidDestination = false;
                }
            }

            if (self.LocationPickupType == 1) {
                if (self.PaymentType.PaymentTypeId() && self.PaymentType.PaymentTypeId() == 6 && !(self.Branch && self.Branch.BranchName)) {
                    $('#location-store-error-message').show();
                    self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addcashpickup.selectlocation);
                    isValidDestination = false;
                } else if (!self.PaymentType.PaymentTypeId() || self.PaymentType.PaymentTypeId() < 1) {
                    $('#correspondent-error-message').show();
                    self.trackErrorMessage(commonstrings.addnewrecipient.adddeliveryoptions.addcashpickup.selectcorrespondent);
                    isValidDestination = false;
                }
            }

            self.errors = ko.validation.group(self);

            var phoneType = $("#input-phone-type").val();
            var isValidBankAccount = true
            var PaymentTypeGroup;
            if (self.NewBankAccount()) {
                PaymentTypeGroup = {
                    Correspondent: self.NewBankAccount().PaymentType().Correspondent,
                    AccountType: self.NewBankAccount().PaymentType().AccountType,
                    AccountNumber: self.NewBankAccount().PaymentType().AccountNumber,
                    ConfirmAccountNumber: self.NewBankAccount().PaymentType().ConfirmAccountNumber
                };

                PaymentTypeGroup.errors = ko.validation.group(PaymentTypeGroup);
                isValidBankAccount = PaymentTypeGroup.isValid();
            }

            var cities = self.cities ? ko.mapping.toJS(self.cities) : self.cities;
            var validAutocompleteCity = cs.setCityValidateType(self.CityValidateType, $('#autocomplete-city-names-addrecipient'), cities)
            var isValid = validAutocompleteCity[0];
            if (self.isValid() && isValidBankAccount && isValid && isValidDestination) {
                return true;
            }
            else {
                //LogToAddReceiver(self.TobeAddedReceiver);
                self.errors.showAllMessages();
                if (!isValidBankAccount && PaymentTypeGroup) {
                    PaymentTypeGroup.errors.showAllMessages();
                }

                return false;
            }
        };

        self.AddReceiver = function (element) {
            var trackTotalSaveClick = trackEvent;
            trackTotalSaveClick("Save");

            if (!validationReceiver()) {
                return;
            }

            var phoneType = $("#input-phone-type").val();
            if (phoneType == 1) {
                self.CellPhoneNumber = cs.GetRemoveFormatPhoneNumber(self.PhoneNumber());
            } else if (phoneType == 2) {
                self.HomePhoneNumber = cs.GetRemoveFormatPhoneNumber(self.PhoneNumber());
            }

            AddSelfServiceReceiver(element);
        };

        self.OpenBankAccountDetail = function (element) {
            var isActive = $(element).parent().hasClass("active");
            if (!(self.CountryId())) {
                return false;
            }

            if (isActive) {
                self.NewBankAccount(null);
                self.BankAccountPickupType = 0;
                self.ValidType(0);
            }
            else {

                self.NewBankAccount({
                    PaymentType: ko.observable(new PaymentType())
                });
                self.BankAccountPickupType = 1;
                self.SearchBankAccountCorrespondents("button-bank-account-deposit", "autocomplete-bank-names");
            }

            return true;
        }

        self.SearchBankAccountCorrespondents = function (element, autocompleteElement, focus) {
            var tempAutocompleteElement = '';
            if (typeof autocompleteElement == "string") {
                if (autocompleteElement.indexOf("#") != 0) {
                    tempAutocompleteElement = "#" + autocompleteElement;
                }
            }

            cs.addSearchSpinner(element);
            self.ValidType(0);
            $.when(GetCorrespondentsByPaymentTypeIds(self.CountryId(), [1], self.ToCurrencyId))
            .done(function (correspondents) {
                BindBankAccountCorrespondents(autocompleteElement, correspondents);
            })
            .always(function () {
                cs.removeSearchSpinner(element);
                if (focus) {
                    $(tempAutocompleteElement).focus();
                };
            });
        };

        function GetCorrespondentsByPaymentTypeIds(countryId, paymentTypeIdArray, currencyId) {
            var deferred = $.Deferred();
            $.when(dataModel.GetPaymentTypes(countryId, currencyId, paymentTypeIdArray))
            .done(function (result) {
                deferred.resolve(result);
            });

            return deferred;
        };

        function BindBankAccountCorrespondents(autoCompleteElement, correspondents) {
            if (typeof autoCompleteElement == "string") {
                if (autoCompleteElement.indexOf("#") != 0) {
                    autoCompleteElement = "#" + autoCompleteElement;
                }
            }

            var tempCorrespondents = $.map(ko.mapping.toJS(correspondents), function (item, index) { return { value: item.Correspondent, data: item }; });;
            tempCorrespondents.sort(function (x, y) {
                return cs.sortByString(x.value, y.value, true);
            });

            $(autoCompleteElement).autocomplete({
                lookup: tempCorrespondents,
                triggerSelectOnValidInput: false,
                minChars: 0,
                onSelect: function (suggestion) {
                    if (suggestion.value != self.NewBankAccount().PaymentType().Correspondent()) {
                        ko.mapping.fromJS(suggestion.data, {}, self.NewBankAccount().PaymentType);
                        self.NewBankAccount().PaymentType().ConfirmAccountNumber(null);
                        self.NewBankAccount().PaymentType().RemoveValidationMessage();
                        if (self.NewBankAccount().PaymentType().IsPaymentTypeAccount) {
                            var accountTypes = self.NewBankAccount().PaymentType().AccountTypes();
                            if (accountTypes.length > 0) {
                                if (accountTypes.length == 1 && accountTypes[0].Value() == cs.BankAccountTypeEnum.NotUsed) {
                                    var accountType = accountTypes[0].Value();
                                    self.NewBankAccount().PaymentType().AccountType(accountType);
                                } else {
                                    self.NewBankAccount().PaymentType().AccountType("");
                                    self.NewBankAccount().PaymentType().AccountType.isModified(false);
                                }
                            }
                        }
                    }
                    self.ValidType(0);
                },
            });

            var tempValue = $(autoCompleteElement).val().trim();
            if (tempValue != '' && (tempCorrespondents == null || tempCorrespondents == ''
                || cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, tempValue, false) < 0)) {
                self.ValidType(2);
            }

            $(autoCompleteElement).off("input.correspondentchanged");
            $(autoCompleteElement).on("input.correspondentchanged", function () {
                var tempValue = $(autoCompleteElement).val().trim();
                if (cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, tempValue, false) > -1) {
                    self.ValidType(0);
                }
                else {
                    self.NewBankAccount().PaymentType(new PaymentType());
                    self.ValidType(2);
                }
            });

            $(autoCompleteElement).off('blur.correspondentchanged')
            .on('blur.correspondentchanged', function () {
                if ($('.autocomplete-selected').length > 0) return;

                var matchedIndex = -1;
                var value = $(this).val();

                if (value == "") {
                    self.ValidType(1);
                }
                else if ($(autoCompleteElement).autocomplete().suggestions.length > 0
                    && (matchedIndex = cs.isMatchSuggestion($(autoCompleteElement).autocomplete().suggestions, value, true)) > -1) {
                    self.ValidType(0);
                    $(autoCompleteElement).autocomplete().select(matchedIndex);
                }
                else {
                    self.ValidType(2);
                }

                if ($(autoCompleteElement).autocomplete()) {
                    $(autoCompleteElement).autocomplete().hide();
                }
            })
            .off('focus.correspondentchanged')
            .on('focus.correspondentchanged', function () {
                if ($(autoCompleteElement).autocomplete().visible) {
                    self.ValidType(0);
                }
            })
        }

        function removePickUpLocationDetail() {
            self.pickupLocationFlag(false);
            self.PickUpLocationPaymentTypes(null);
            self.LocationStores(null);
            self.LocationPickupType = 0;
            self.ShouldShowLocation(false);
        };

        function clearCityLocationContent() {
            if (self.pickupLocationFlag() && !self.SearchCityOutSideCities()) {
                self.PickUpLocationPaymentTypes([]);
                self.LocationStores(null);
                self.ShouldShowLocation(false);
                $("#correspondent-error-message").hide();
            }
        }

        //Pick Up Location
        self.OpenPickupLocationDetail = function (element) {
            var isActive = $(element).parent().hasClass("active");
            if (!(self.CountryId())) {
                return false;
            }
            if (isActive) {
                removePickUpLocationDetail();
            }
            else {
                self.pickupLocationFlag(true);
                self.LocationPickupType = 1;
                initializePaymentTypeList();
                InitializePickUpLocationCities();
            }

            return true;
        }

        self.SearchCityChanged = function (location, element) {
            var checkBoxChecked = $(element).is(":checked");
            self.SearchCityOutSideCities(checkBoxChecked);
            ResetPaymentType();
            ResetLocation();
            $("#location-store-error-message").hide();
            $("#correspondent-error-message").hide();
            initializePaymentTypeList();
        }

        function initializePaymentTypeList() {
            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
            var pickUp = new dataModel.CashPickUp();
            $.when(pickUp.getPayments(self.SearchCityOutSideCities(), self.CountryId(), GetCurrencyId(self.CountryId()), self.StateId(), self.CityId(), self.City, null))
            .done(function (paymentTypes) {
                ko.mapping.fromJS(paymentTypes, {}, self.PickUpLocationPaymentTypes);
            })
            .fail(function () {
                ko.mapping.fromJS([], {}, self.PickUpLocationPaymentTypes);
            });
        }

        function InitializePickUpLocationCities(element, clearCity) {
            var tempCity
            if (!clearCity) {
                tempCity = "";
            }
            return $.when(new dataModel.CashPickUp().getCities(self.CountryId(), element))
             .done(function (cities) {
                 $("#autocomplete-pickup-location-city").autocomplete({
                     lookup: cities,
                     triggerSelectOnValidInput: false,
                     minChars: 1,
                     onSelect: function (suggestion) {
                         var cityName = suggestion.value;
                         if (cityName != tempCity) {
                             tempCity = cityName;
                             var countryId = self.CountryId();
                             var correspondentId = self.PaymentType.Payouts()[0];

                             initLocations(self.CountryId(), suggestion.data, cityName, self.PaymentType);
                         }
                     }
                 });
                 $("#autocomplete-pickup-location-city").autocomplete().getSuggestionsLocal = function (query) { return cs.GetSuggestionsLocal(this.options.lookup, query); };
                 $("#autocomplete-pickup-location-city").off("input.pickup.location");
                 $("#autocomplete-pickup-location-city").on("input.pickup.location", function () {
                     if ($("#autocomplete-pickup-location-city").val() == "" || $("#autocomplete-pickup-location-city").val() != tempCity) {
                         ko.mapping.fromJS(null, {}, self.LocationStores);
                         $("#location-stores").hide();
                         self.Branch = null;
                         tempCity = null;
                     }
                 });
             });
        }

        self.GetPickUpLocationForSearchCities = function (element, isFocus) {
            cs.addSearchSpinner(element);
            $.when(InitializePickUpLocationCities(null, true))
            .done(function () {
                cs.removeSearchSpinner(element);
                if (isFocus) {
                    $("#autocomplete-pickup-location-city").focus();
                }
            });
        }

        function ResetPaymentType() {
            ko.mapping.fromJS(null, {}, self.PickUpLocationPaymentTypes);
            self.PaymentType = new PaymentType();
        }

        function ResetLocation() {
            //ko.mapping.fromJSON(defaultToBeAddedBranch, {}, receiver.Branch);
            ko.mapping.fromJS(null, {}, self.LocationStores);
            $("#autocomplete-pickup-location-city").val(null);
            self.ShouldShowLocation(false);
        }

        self.SelectPaymentType = function (paymentType) {
            if (paymentType.Selected()) {
                return;
            }
            paymentType.SearchCityOutSideCities(self.SearchCityOutSideCities());
            self.PaymentTypeSelectIndexChange(paymentType);
        };

        self.LocationSelectIndexChange = function (index, location) {
            self.Branch = ko.mapping.toJS(location.Branch);
            SetSelectedLocation(index, location);
            $("#location-store-error-message").hide();
        }

        function SetSelectedLocation(index, location) {
            var templocation = self.LocationStores();
            for (var i = 0; i < templocation.length; i++) {
                if (i == index()) {
                    templocation[i].Selected(true);
                } else {
                    templocation[i].Selected(false);
                }
            }
            ko.mapping.fromJS(templocation, {}, self.LocationStores);
        }

        self.PaymentTypeSelectIndexChange = function (paymentType) {
            //var searchCityOutSideCities = self.PaymentType.SearchCityOutSideCities();
            SetPaymentTypeStatus(paymentType);
            //self.PaymentType.SearchCityOutSideCities(searchCityOutSideCities);

            var tempPaymentType = ko.mapping.fromJS(ko.mapping.toJS(paymentType));
            $("#correspondent-error-message").hide();
            $("#location-stores").hide();
            if (tempPaymentType.PaymentTypeId() == 6) {
                self.Branch = null;
                //self.NewPickupLocation.Location.City(self.City());
                //self.NewPickupLocation.Location.State(self.StateName());
                self.ShouldShowLocation(true);
                if (self.SearchCityOutSideCities()) {
                    $("#autocomplete-pickup-location-city").val("");
                } else {
                    $("#autocomplete-pickup-location-city").val(self.City);
                }
                tempCity = $("#autocomplete-pickup-location-city").val();
                initLocations(self.CountryId(), self.StateId(), tempCity, tempPaymentType);
            } else {
                $("#location-store-error-message").hide();
            }
        }

        function SetPaymentTypeStatus(paymentType) {
            paymentType = ko.mapping.toJS(paymentType);
            ko.mapping.fromJS(paymentType, {}, self.PaymentType);
            self.PaymentType.Selected(true);
            self.PaymentType.AccountNumber.isModified(false);

            if (self.PaymentType.IsPaymentTypeAccount()) {
                var accountTypes = self.PaymentType.AccountTypes();
                if (accountTypes.length > 0) {
                    var accountType = accountTypes[0].Value;
                    ko.mapping.fromJS(accountType, {}, self.PaymentType.AccountType);
                }
            }

            var tempPayments = self.PickUpLocationPaymentTypes();
            for (var i = 0; i < tempPayments.length; i++) {
                if (tempPayments[i].CurrencyId() == paymentType.CurrencyId &&
                    tempPayments[i].TransactionTypeId() == paymentType.TransactionTypeId &&
                    tempPayments[i].Payouts()[0] == paymentType.Payouts[0] &&
                    tempPayments[i].PaymentTypeId() == paymentType.PaymentTypeId) {
                    self.ShouldShowLocation(true);
                    tempPayments[i].Selected(true);
                } else {
                    tempPayments[i].Selected(false);
                }
            }
            //ko.mapping.fromJS(tempPayments, {}, self.PickUpLocationPaymentTypes);

            ResetLocation();
        }

        function initLocations(countryId, stateId, cityName, paymentType) {
            if (!cityName) {
                return;
            }
            ko.mapping.fromJS(null, {}, self.LocationStores);
            var transactionType = 14;
            $("#location-stores").show();
            $.when(new dataModel.CashPickUp().getLocations(countryId, stateId, cityName, paymentType))
            .done(function (data) {
                var stores = ko.mapping.toJS(data);
                ko.mapping.fromJS(stores, {}, self.LocationStores);
            })
            .always(function () {
                $("#location-stores").hide();
            });
        };

        self.PaymentTypeCitySelectIndexChange = function (index, receiver, city) {
            receiver.NewPickupLocation.Location.City(city.CityName());
            receiver.NewPickupLocation.Location.State(city.StateName());
            GetPaymentTypeLocations(index, city, receiver.CountryId());
        }

        var trackCloseTotalClick = trackEvent;
        self.closeAddRecipient = R.compose(cs.closeModal, trackCancelTimeOnPage, R.tap(trackCloseTotalClick));

        function trackEvent(eventLabel) {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewRecipient,
                eventAction: track.ActionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: track.PageEnum.AddNewRecipient,
                source: app.page().name
            });
        };

        function trackTotalLoads() {
            track.trackEvent({
                sendType: track.GA + track.MP,
                eventCategory: track.CategoryEnum.AddNewRecipient,
                eventAction: track.ActionEnum.ScreenView,
                eventLabel: "Add New Recipient",
                eventPage: track.PageEnum.AddNewRecipient,
                source: app.page().name
            });
        }

        trackTotalLoads();
    }
});