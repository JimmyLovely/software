﻿define(['knockout', 'ClientScript', 'app', 'DataModel', 'knockout.validation'], function (ko, cs, app, dataModel) {
    return function TransactionHistoryModel(data) {
        var self = this;
        ko.mapping.fromJS(data, {}, self);
        self.TransactionRecords.FilterStatus = ko.observable('status-all');
        self.TransactionRecords.FilterType = ko.observable("0");
        var transactionCountEveryPage = 10;
        self.PageIndex = ko.observable("1");
        self.TimeType = ko.observable("1");
        self.SortType = ko.observable('sortby');
        self.IsAscending = ko.observable(true);

        self.FilterChanged = function () {
            self.PageIndex("1");
            cs.closeFoundationDropdown();
        }

        self.SortedTransactionRecords = ko.computed(function () {
            var tempTransactions = self.TransactionRecords();
            var transactionType = self.TransactionRecords.FilterType();
            var transactionStatus = self.TransactionRecords.FilterStatus();
            if (transactionType == undefined || transactionStatus == undefined) {
                return tempTransactions;
            }

            var newArray = new Array();
            for (var i = 0; i < tempTransactions.length; i++) {
                if ((tempTransactions[i].TransactionType() == transactionType || transactionType == "0")
                    &&
                    (tempTransactions[i].Status() == transactionStatus || transactionStatus == "status-all")
                    ) {
                    newArray.push(tempTransactions[i]);
                }
            }

            return newArray;
        });

        self.FilterTransactionRecords = ko.computed(function () {
            var sortedTransactionList = self.SortedTransactionRecords;
            var sortType = self.SortType();
            var isAscending = self.IsAscending();
            if (sortType == "sortby") {
            }
            else if (sortType == "AmountCollected") {
                if (isAscending) {
                    sortedTransactionList().sort(function (x, y) {
                        var xNumber = parseFloat(x.AmountCollected().replace("$", "").replace(/[,]/g, ""));
                        var yNumber = parseFloat(y.AmountCollected().replace("$", "").replace(/[,]/g, ""));
                        return xNumber > yNumber ? 1 : (xNumber == yNumber ? x.ReceiptNumber() > y.ReceiptNumber() ? 1 : 0 : -1);
                    });
                }
                else {
                    sortedTransactionList().sort(function (x, y) {
                        var xNumber = parseFloat(x.AmountCollected().replace("$", "").replace(/[,]/g, ""));
                        var yNumber = parseFloat(y.AmountCollected().replace("$", "").replace(/[,]/g, ""));
                        return xNumber < yNumber ? 1 : (xNumber == yNumber ? x.ReceiptNumber() < y.ReceiptNumber() ? 1 : 0 : -1);
                    });
                }
            }
            else if (sortType == "AmountToPay") {
                if (isAscending) {
                    sortedTransactionList().sort(function (x, y) {
                        var xNumber = parseFloat(x.AmountToSend().replace("$", "").replace(/[,]/g, ""));
                        var yNumber = parseFloat(y.AmountToSend().replace("$", "").replace(/[,]/g, ""));
                        return xNumber > yNumber ? 1 : (xNumber == yNumber ? x.ReceiptNumber() > y.ReceiptNumber() ? 1 : 0 : -1);
                    });
                }
                else {
                    sortedTransactionList().sort(function (x, y) {
                        var xNumber = parseFloat(x.AmountToSend().replace("$", "").replace(/[,]/g, ""));
                        var yNumber = parseFloat(y.AmountToSend().replace("$", "").replace(/[,]/g, ""));
                        return xNumber < yNumber ? 1 : (xNumber == yNumber ? x.ReceiptNumber() < y.ReceiptNumber() ? 1 : 0 : -1);
                    });
                }
            }
            else {
                sortedTransactionList().sort(cs.compare(sortType, null, isAscending, 'ReceiptNumber'));;
            }

            var newArray = new Array();
            if (sortedTransactionList().length == 0) {
                return newArray;
            }
            else {

                for (var i = 1; i < sortedTransactionList().length + 1; i++) {
                    if (i > (self.PageIndex() - 1) * transactionCountEveryPage && i <= self.PageIndex() * transactionCountEveryPage) {
                        newArray.push(sortedTransactionList()[i - 1]);
                    }
                }
            }
            return newArray;
        });

        self.SortTransactionBy = function (value, element) {

            var classname = element.childNodes[1].className;
            ResetSort();
            self.PageIndex("1");
            if (classname == "sortFieldIcon entypo-icon-arrow-down") {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-up";
                self.IsAscending(true);
                self.SortType(value);
            }
            else {
                element.childNodes[1].className = "sortFieldIcon entypo-icon-arrow-down";
                self.IsAscending(false);
                self.SortType(value);
            }
        }

        function ResetSort() {
            $("#Transaction-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-up");
            $("#Transaction-columns").find('i').removeClass("sortFieldIcon entypo-icon-arrow-down");
            $("#Transaction-columns").find('i').addClass("sortFieldIcon entypo-icon-arrow-down");
            self.SortType("sortby");
            self.IsAscending(true);
        }

        self.ChangePageIndex = function (value) {
            self.PageIndex(value);
            cs.closeFoundationDropdown();
        }

        self.PageIndexs = ko.computed(function () {
            var tempPageIndexs = new Array();
            var i = 1;

            if (self.SortedTransactionRecords().length <= transactionCountEveryPage) {
                tempPageIndexs.push(i);
            }
            else {
                for (var a = 1; a <= self.SortedTransactionRecords().length / transactionCountEveryPage; a++) {
                    tempPageIndexs.push(a);
                    i++;
                }

                if (self.SortedTransactionRecords().length % transactionCountEveryPage > 0) {
                    tempPageIndexs.push(i);
                    i++;
                }
            }

            return tempPageIndexs;
        });

        self.MoveToFirstPage = function () {
            self.PageIndex(1);
        }

        self.MoveToLastPage = function () {
            self.PageIndex(self.PageIndexs().length);
        }

        self.TransactionSearchText = ko.observable("");
        var timerHandler = 0;
        self.Customers$AutoSearch = function (value) {
            var oldValue = self.TransactionSearchText();
            self.TransactionSearchText(value);

            var isSearch = true;
            if (timerHandler != 0) {
                clearTimeout(timerHandler);
                timerHandler = 0;
            }

            var reg = new RegExp('\\d', 'g');
            if (reg.test(value)) {
                value = value.replace('/\D/g', '');
                self.TransactionSearchText(value);

                if (value.length < 3) {
                    isSearch = false;
                }
            }
            else if (value.replace(/(^\s*)|(\s*$)/g, '') != "" && value.length < 3) {
                isSearch = false;
            }

            if (isSearch) {
                timerHandler = setTimeout(function () { self.Customers$Search(); }, 500);
            }
        }

        self.Customers$Search = function () {
            var criteria = $("#input-search-for-transaction-history").val();

            cs.AjaxBySpinner({
                url: '/Customers/SearchTransactionHistory',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "criteria": criteria })
            }, "#search-transaction")
            .done(function (data) {
                if (data && data.TransactionRecords) {
                    ko.mapping.fromJS(data.TransactionRecords, {}, self.TransactionRecords);
                }
                self.PageIndex(1);
                cs.closeFoundationDropdown();
            });
        }

        var voidTransactionStatus = new cs.executeStatus();
        self.ConfirmVoid = function (transactionModel) {
            cs.showConfirmMessage("Message", "Are you sure you want to void this transaction?", function () {
                if (voidTransactionStatus.isExecuting()) {
                    return;
                }
                //For datacapture, void transaction
                cs.AddActivityInfo(27);

                voidTransactionStatus.setExecuting();
                return $.when(VoidTransaction(transactionModel, "#ConfirmOk"))
                .done(function () {
                    voidTransactionStatus.complete();
                })
                .fail(function () {
                    voidTransactionStatus.complete();
                });
            });
        }

        function VoidTransaction(transactionModel, element) {
            $("#ConfirmCancel").off("click");
            $("#ConfirmCancel").attr("disabled", true);
            return cs.AjaxBySpinner({
                url: '/Customers/VoidSelfServiceTransaction',
                type: "POST",
                contentType: "application/json",
                data: JSON.stringify(ko.mapping.toJS(transactionModel))
            }, element)
            .done(function (data) {
                $("#ConfirmCancel").removeAttr("disabled");
                $("#ConfirmCancel").click(function () {
                    cs.closeModal();
                });

                if (data) {
                    app.senderInfo().GetSenderLevel(element);
                    for (var i = 0; i < self.TransactionRecords().length; i++) {
                        if (transactionModel.ReceiptNumber() == self.TransactionRecords()[i].ReceiptNumber()) {
                            self.TransactionRecords()[i].Status("Canceled");
                            self.TransactionRecords()[i].CanVoid(false);
                            var notifyMessageModel = {
                                Title: "Success",
                                Message: "Void transaction Success!"
                            }
                            OpenNotifyMessageModal(notifyMessageModel);
                        }
                    }
                }
                else {
                    cs.showErrorMessage("Error", "Void transaction failed. Please try again later.");
                }
            })
            .fail(function () {
                $("#ConfirmCancel").removeAttr("disabled");
                $("#ConfirmCancel").click(function () {
                    cs.closeModal();
                });
            });
        }

        function OpenNotifyMessageModal(notifyMessageModel) {
            $("#NotificationHead").text(notifyMessageModel.Title);
            $("#NotificationMessage").text(notifyMessageModel.Message);
            $('#NotificationConfirmOK').unbind('click');
            $('#NotificationConfirmOK').click(function () {
                cs.closeModal();
            });
            cs.openModal("modal-notification");
        };

        var transactionDetailStatus = new cs.executeStatus();
        self.ViewTransactionDetail = function (selectedTransaction) {
            if (transactionDetailStatus.isExecuting()) {
                return;
            }
            transactionDetailStatus.setExecuting();
            cs.AjaxByDelayLoading({
                url: '/Customers/GetTransactionDetailByReceiptNumber',
                type: "POST",
                dataType: "json",
                contentType: "application/json",
                data: JSON.stringify({ "receiptNumber": selectedTransaction.ReceiptNumber() })
            })
            .done(function (data) {
                ko.mapping.fromJS(data, {}, self.TransactionDetailModel);
                if (self.TransactionDetailModel.TransactionType() == 'Money Transfer') {
                    $.when(cs.openModal("modal-transaction-details-mt"))
                    .done(function () {
                        transactionDetailStatus.complete();
                    });
                }
                else if (self.TransactionDetailModel.TransactionType() == 'Bill Pay') {
                    $.when(cs.openModal("modal-transaction-details-bp"))
                    .done(function () {
                        transactionDetailStatus.complete();
                    });
                }
                else if (self.TransactionDetailModel.TransactionType() == 'Top Ups') {
                    $.when(cs.openModal("modal-transaction-details-tu"))
                    .done(function () {
                        transactionDetailStatus.complete();
                    });
                }
                $("#TimeType").val("2");
                self.TimeType("2");
            })
            .fail(function () {
                transactionDetailStatus.complete();
            });
        }

        self.GetSelectedTransaction = function (transaction, element) {
            if (cs.isDisabled(element)) {
                return;
            }

            dataModel.GetSelectedTransaction(transaction);
        }

        self.TimeTypeChanged = function () {
            self.TimeType($("#TimeType").val());
        }

        var emailStatus = new cs.executeStatus();
        self.SendTransactionDetailEmail = function (element) {
            self.SendEmailForTransactionHistory(self.TransactionDetailModel.ReceiptNumber(),element);
    };

    self.SendEmailForTransactionHistory = function (receiptNumber, element) {
        if (emailStatus.isExecuting()) {
            return;
        }
        if (cs.isDisabled(element)) {
            return;
        }
        emailStatus.setExecuting();
        cs.AjaxBySpinner({
            url: '/Customers/SelfServiceSendEmailForTransactionDetail',
            dataType:'json',
            cache: false,
            data: { 'receiptNumber': receiptNumber }
        }, element)
        .done(function (data) {
            if (data) {
                cs.showErrorMessage("Message", "Transaction detail email has been sent successfully, please check your email inbox!");
                emailStatus.complete();
            }
            else {
                cs.showErrorMessage("Message", "Transaction detail email sent failed, please try again later!");
                emailStatus.complete();
            }
        })
        .fail(function (xhr, status) {
            cs.showErrorMessage("Message", "Transaction detail email sent failed, please try again later!");
            emailStatus.complete();
        })
    };

    self.PrintTransactionHistoryStandardReceipt = function (receiptNumber, element) {
        var timeType = $('#TimeType').val();
        var timeTypeName = $("#TimeType").find("option:selected").text();

        if (!timeType) {
            timeType = 0;
        }
        if (!timeTypeName) {
            timeTypeName = "";
        }
        cs.AjaxBySpinner({
            url: '/Customers/PrintTransactionHistoryStandardReceipt',
            dataType: "html",
            cache: false,
            data: { 'receiptNumber': receiptNumber, 'timeType': timeType, 'timeTypeName': timeTypeName }
        }, element)
      .done(function (result) {
          cs.PrintTransaction(result, element);
      });
    };
}
});

