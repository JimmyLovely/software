﻿define({
    'root': {
        'profiledetails': 'Profile Details',
        'requiredfields': 'Please fill out required fields.',
        'fullname': {
            'title': 'Full Name',
            'firstname': 'First Name',
            'moddleoption': 'Middle (optional)',
            'lastname': 'Last Name',
        },
        'dateformat': 'MM/DD/YYYY',
        'dateofbirth': 'Date of Birth',
        'selectdate': 'Select a Date of Birth',
        'address': 'Address',
        'validation': {
            'middlenamemaxlength': 'Maximum length of 50 characters',
            'middlenamestart': 'Middle name should start with a letter',
            'middlenameinvalid': 'Invalid middle name',
            'userage': '*Must be at least 18 years of age',
            'selectdate': 'Please select a date after 1920'
        },
        'errormessage': {
            'error': 'error',
            'serviceavailableinus': 'Currently this service is only available in the US.'
        }
    },
    'es-MX': true
});