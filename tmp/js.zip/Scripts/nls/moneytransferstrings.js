﻿define({
    'root': {
        'title': 'Money Transfer',
        'selectrecipient': {
            'title': 'Select Recipient',
            'searchrecipients': 'Search Recipients',
            'select': 'Select',
            'addrecipient': 'Add Recipient',
            'norecipientmessage': 'Please add a Recipient',
            'recipients': 'Recipients'
        },
        'amounttosend': {
            'title': 'Amount to Send',
            'sendminimum': 'Send minimum $10 USD',
            'send': 'Send',
            'receive': 'Receive',
            'exchangerate': 'Exchange Rate',
            'sendamountinvalid': 'Please input a valid send amount',
            'error': 'Error',
            'inputvalidreceiveamount': 'Please input a valid receive amount',
            'minimumamount': 'The minimum amount you can send is $10 USD.'
        },
        'deliveryoption': {
            'title': 'Delivery Option',
            'cashpickup': 'Cash Pickup',
            'unidoscard': 'Unidos Card',
            'accountdeposit': 'Account Deposit',
            'homedelivery': 'Home Delivery',
            'addoption': 'Add Option',
            'adddepositaccount': 'Add Deposit Account',
            'addcashpickup': 'Add Cash Pickup',
            'addhomedelivery': {
                'title': 'Add Home Delivery',
                'addnewcorrespondent': 'Add New Correspondent',
                'selectcorrespondent': 'Select Correspondent',
                'searchcorrespondents': 'Search Correspondents',
                'correspondentrequired': 'Correspondent is required',
                'correspondentinvalid': 'Invalid correspondent'
            },
            'sendtounidoscard': 'Send To Unidos Card',
            'adddeliveryoptionmessage': 'Please add a delivery option.'

        },
        'paymentmethod': {
            'title': 'Payment Method',
            'bankaccount': 'Bank Account',
            'creditanddebitcards': 'Credit/Debit Cards',
            'reviewtransactionmessage': 'You can review your transaction before it\'s final.',
            'credit': 'credit',
            'debit': 'debit',
            'addpayment': 'Add Payment',
            'creditcard': 'Credit Card',
            'debitcard': 'Debit Card',
            'bankaccount': 'Bank Account'
        },
        'summary': {
            'title': 'Summary',
            'recipientinformation': 'Recipient Information',
            'paymentmethod': 'Payment Method',
        },
        'additionalinforequired': {
            'title': 'Additional Info Required',
            'purposeoffunds': '* Purpose Of Funds',
            'recipientidnumber': '* Recipient Id Number',
            'recipientssn': '* Recipient SSN',
            'relationshipwithrecipient': '* Relationship With Recipient',
            'selectrecipientdateofbirth': '* Select Recipient Date Of Birth',
            'selectrecipientidexpiration': '* Select recipient id expiration',
            'selectsenderdateofbirth': '* Select Sender Date Of Birth',
            'selectsenderidexpiration': '* Select Sender Id Expiration',
            'senderidnumber': '* Sender Id Number',
            'senderoccupation': '* Sender Occupation',
            'senderssn': '* Sender SSN',
            'sourceoffunds': '* Source Of Funds',
            'countryrequired': 'Country is required.',
            'idtyperequired': 'Id type is required.',
            'invaliddate': 'Invalid date!',
            'purposeoffundsrequired': 'Purpose of funds is required.',
            'recipientcountryofbirth': 'Recipient Country Of Birth',
            'recipientdateofbirthrequired': 'Recipient date of birth is required.',
            'recipientidexpirationrequired': 'Recipient id expiration is required.',
            'recipientidissuingcountry': 'Recipient Id Issuing Country',
            'recipientidissuingstate': 'Recipient Id Issuing State',
            'recipientidnumberrequired': 'Recipient id number is required.',
            'recipientidtype': 'Recipient Id Type',
            'recipientoccupation': 'Recipient Occupation',
            'recipientoccupationrequired': 'Recipient occupation is required.',
            'recipientssnrequired': 'Recipient ssn is required.',
            'recipienttaxidtype': 'Recipient Tax Id Type',
            'relationshipwithrecipientrequired': 'Relationship with recipient is required.',
            'sendercountryofbirth': 'Sender Country Of Birth',
            'senderdateofbirthrequired': 'Sender date of birth is required.',
            'senderidexpirationrequired': 'Sender id expiration is required.',
            'senderidissuingcountry': 'Sender Id Issuing Country',
            'senderidissuingstate': 'Sender Id Issuing State',
            'senderidnumberrequired': 'Sender id number is required.',
            'senderidtype': 'Sender Id Type',
            'senderoccupationrequired': 'Sender occupation is required.',
            'senderssnrequired': 'Sender ssn is required.',
            'sendertaxidtype': 'Sender Tax Id Type',
            'sourceoffundsrequired': 'Source of funds is required.',
            'staterequired': 'State is required.',
            'taxidtyperequired': 'Tax id type is required.',
            'atleast18yearsofage': 'User is required to be at least 18 years of age',
        },
        'error': 'Error',
        'moneytransactionsuccess': 'Money Transfer - Success!',
        'moneytransactiononhold': 'Money Transfer - On Hold!',
        'transactiononholder': 'Thank you! Your transaction was put on hold until your documents are processed.',
        'receivereceipt': 'You will receive a confirmation number and receipt, sent to',
        'onholdcompleted': ', when this has been completed.',
        'moneytransfersummary': 'Money Transfer Summary',
        'amountsent': 'Amount Sent',
        'upgrade': {
            'ugradetransactionmessage': 'Your transaction will be on hold until your upgrade documents are verified.',
            'summarymessage': 'Your transaction will be put on hold until your documents have been submitted and verified.',
            'errormessage': 'Amount exceeds the maximum current sending limit of',
            'finishupgradelater': 'Finish Upgrade Later',
            'upgradeprompt': {
                'message': 'To send an amount above your current limit of ${currentlevel}, we require additional information for security purposes.',
                'emaillater': 'Email Later',
                'upgradenow': 'Upgrade Now'
            },
            'upgradelater': {
                'message': 'Submit documents later and continue transaction?'
            },
            'attachedsuccess': {
                'title': 'Upgrade Documents Submitted!',
                'message': 'Please continue with your transaction'
            },
            'qpattachedsuccess': {
                'title': 'Upgrade Documents Submitted!',
                'message': 'Your transaction will be <strong>on hold</strong> until your upgrade documents are verified.'
            },
            'confirmationmessage': {
                'title': 'Your transaction is now on hold',
                'message': 'Upon review of your documentation, we will process your transaction.'
            },
            'submitprompt': {
                'title': 'Your transaction is now on hold',
                'message': 'Upon review of your documentation, we will process your transaction. An email has been sent with submission instructions.',
            }
        },
        'needUpgrade': {
            'error': 'Error',
            'content': 'Your current sending limit has been exceeded. You must change your amount or increase your sending limit.',
        }
    },
    'es-MX': true
});
