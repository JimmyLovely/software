﻿define({
    'root': {
        'exchangeratesconsumer': {
            'title': 'Current Rates',
            'country': 'Country',
            'currency': 'Currency',
            'rate': 'Rate',
            'filter': 'Filter'
        },
        'allexchangerate&#187': 'All Exchange Rates &#187;'
    },
    'es-MX': true
});