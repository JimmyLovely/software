﻿define({
    'root': {
        'header': 'Increase Sending Limit',
        'headermessage': 'Please click Upgrade to increase your aggregate sending limits above your Current Levels.',
        'sendfollowingamount': 'Send the following amounts within:',
        'level':'LEVEL',
        'pertransactionlimit': 'Per Transaction',
        'hours24limit': '24 hours',
        'days30limit': '30 Days',
        'months6limit': '6 Months',
        'days': '{days} days',
        'currentlevel': 'Current Level',
        'upgrade': 'Upgrade',
        'arizonacustomer': 'For Arizona customers, 24-hour sending limit is $999 across all levels.'
    },
    'es-MX': true
});
