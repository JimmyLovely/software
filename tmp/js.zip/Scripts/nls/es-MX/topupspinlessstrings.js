﻿define({
    'selectpinlesscarrier': {
        'title': ' Selecciona una compañía de recargas Pinless ',
        'nocarriermessage': 'Por favor agrega una compañía de recarga móvil',
        'searchpinlesscarriers': 'Buscar operadores Pinless',
        'carriers': 'Compañía'
    }
});