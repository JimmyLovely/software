﻿define({
    'header': 'Incrementar el límite de envío',
    'headermessage': 'Por favor da click en Actualizar para incrementar tus límites de envío agregados por encima de tu nivel actual.',
    'sendfollowingamount': 'Envía las siguientes cantidades dentro de:',
    'level': 'Nivel',
    'pertransactionlimit': 'Por Transacción',
    'hours24limit': '24 horas',
    'days30limit': '30 días',
    'months6limit': '180 días',
    'days': '{days} días',
    'currentlevel': 'Nivel actual',
    'upgrade': 'Solicitar incremento de límite',
    'arizonacustomer': 'Todos los clientes que residen en Arizona pueden enviar el monto máximo de $999 en 24 horas.'
});
