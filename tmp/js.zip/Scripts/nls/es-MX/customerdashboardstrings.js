﻿define({
    'welcometo': 'Bienvenido a',
    'unidos': 'Sengo',
    'welcomeback': 'Bienvenido nuevamente',
    'nanda': 'No Aplica',
    'promotions': 'Promociones',
    'learnmore': 'Conoce mas',
    'recenttransactions': 'Transacciones Recientes',
    'norecenttransaction': 'No tienes transacciones recientes.',
    'trackrecentactivity': 'Mantente al tanto de la actividad reciente de tu cuenta aquí.',
    'cannotconnectserver': 'No se puede conectar al servidor',
    'quickpay': 'Quick Pay',
    'sendagain': 'Reenvía',
    'payagain': 'Reenvía',
    'reloadquickpay': 'Recarga',
    'transactionhistory': 'Ver Historial de Transacciones',
    'onhold': 'Envía documentos para incrementar tu límite',
    'canceled': 'Solicitud de incremento de límite no completada, cancelada.',
    'upgrade': {
        'submitdocumenttoupgrade': 'Transacción pendiente. Enviar documento (s) ahora.',
        'documentsubmited': '¡Documentos para solicitud de incremento de límite enviados!',
        'documentexpired': 'Tu documento de identidad ha expirado. Por favor actualízalo aquí',
        'sourceoffundsexpired': 'Tu documento de fuente de ingresos ha expirado. Por favor actualízalo aquí.'
    }
});