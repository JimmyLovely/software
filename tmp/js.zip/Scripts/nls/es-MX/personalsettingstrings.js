﻿define({
    'personalsettings': {
        'title': 'Datos Personales',
        'profile': {
            'title': 'Información de perfil de la cuenta',
            'name': 'Nombre',
            'email': 'Correo electrónico',
            'home': '(Casa)',
            'mobile': '(Móvil)',
            'other': '(Otro)',
            'dateofbirth': 'Fecha de nacimiento',
            'dob': 'Fecha de Nac.',
            'dateofbirthformat': '(DD/MM/AAAA)',
            'buttons': {
                'updateprofile': 'Actualizar Perfil'
            },
            'language': {
                'english': 'English',
                'spanish': 'Español'
            },
            'errormessage': {
                'notvalidphonenumber': 'No es un número de teléfono válido',
                'phonenumberisrequired': 'Se requiere número de teléfono'
            }
        },
        'password': {
            'title': 'Cambio de contraseña',
            'oldpassword': 'Contraseña anterior',
            'newpassword': 'Nueva contraseña',
            'confirmpassword': 'Confirmar contraseña',
            'passwordwarnmessage': 'Contraseña alfanumérica, de 8 a 20 caracteres sin espacios.',
            'buttons': {
                'changepassword': 'Cambiar contraseña'
            },
            'validations': {
                'oldpwdinvalid': 'La contraseña anterior no es valida',
                'newpwdinvalid': 'No es una nueva contraseña válida',
                'oldpwdrequired': 'Se requiere la contraseña anterior',
                'newpwdrequired': 'Se requiere nueva contraseña',
                'confirmpwdrequired': 'Se requiere la confirmación de la contraseña',
                'nomatch': 'Los campos de nueva contraseña y confirmar contraseña no coinciden'
            }
        },
        'address': {
            'title': 'Información de dirección',
            'buttons': {
                'updateaddress': 'Actualizar Dirección'
            }
        },
        'preferences': {
            'title': 'Preferencias de tu perfil',
            'emailnewsletter': 'Novedades por correo electrónico',
            'agreementmessage': 'Estoy de acuerdo en recibir promociones de Sengo vía correo electrónico.',
            'warnmessage': 'No compartimos tu información con terceras personas.',
                            
            'buttons': {
                'updatepreferences': 'Actualizar preferencias'
            },
            'cellphonecapable': 'Por favor proporciona un número de teléfono válido para recibir notificaciones importantes vía texto.'
        }
    },
    'paymentmethods': {
        'title': 'Métodos de Pago'
    },
    'common': {
        'title': 'Mi Cuenta'
    },
    'message': {
        'messagetitle': 'Mensaje',
        'profileinformationupdatesuccess': '¡La información de perfil de la cuenta fue actualizada exítosamente!',
        'passwordupdatesuccess': 'La contraseña fue actualizada exitosamente',
        'profilerpreferencesupdatesuccess': 'La actualización de tu Perfil de Preferencias ha sido exitosa',
        'addressinformationupdatesuccess': 'La información de dirección fue actualizada exítosamente.',
        'nolongerreceiveoffers': '¿Estás seguro que ya no quieres recibir nuestras interesantes ofertas?',
        'receiveemail': 'Cancelaste tu suscripción a nuestra hoja informativa. Sin embargo, seguirás recibiendo correos electrónicos relacionados a la actividad de tu cuenta.',
        'characterslength': 'Se requieren de 8-20 caracteres, al menos un número, sin espacios',
        'notifyonceacquired': 'y le notificaremos cuando la obtengamos. Sin embargo, tu puedes realizar recargas telefónicas con nosotros.',
        'profileaddressnotifyonceacquired': 'y te notificaremos una vez que la consigamos. Sin embargo, puedes hacer recargas telefonicas con nosotros.',
        'addresssaved': 'La información de la dirección ha sido guardada. Estamos tramitando la licencia para transferencia de dinero en',
        'obtaininglicensetosendmoney': 'Estamos en el proceso de obtener una licencia para envios de dinero en el estado de',
        'invalidpassword': 'Se requiere una contraseña alfanumérica de 8 a 20 caracteres sin espacios'
    }
});
