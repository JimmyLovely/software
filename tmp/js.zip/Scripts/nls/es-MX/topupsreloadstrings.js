﻿define({
    'selectreloadcarrier': {
        'title': 'Selecciona compañía de recarga',
        'nocarriermessage': 'Por favor agrega una compañía de recarga móvil',
        'searchreloadcarriers': 'Buscar compañía de recarga',
        'carriers': 'Compañía',
        'addcarrier': {
            'country': 'País'
        }
    },
    'editreloadcarrier': 'Editar compañía de recargas'
});