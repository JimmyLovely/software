﻿define({
    'profiledetails': 'Detalles del perfil de la cuenta',
    'requiredfields': 'Por favor llenar los campos requeridos.',
    'fullname': {
        'title': 'Nombre completo',
        'firstname': 'Nombre',
        'moddleoption': 'Segundo Nombre (Opcional)',
        'lastname': 'Apellido',
    },
    'dateformat': 'DD/MM/AAAA',
    'dateofbirth': 'Fecha de Nacimiento',
    'selectdate': 'Selecciona una fecha de nacimiento',
    'address': 'Dirección',
    'validation': {
        'middlenamemaxlength': 'Longitud Máxima de 50 caracteres',
        'middlenamestart': 'El segundo nombre debe empezar con una letra',
        'middlenameinvalid': 'Segundo Nombre Invalido',
        'userage': 'Se debe tener al menos 18 años de edad',
        'selectdate': 'Por favor selecciona una fecha posterior a 1920'
    },
    'errormessage': {
        'error': 'error',
        'serviceavailableinus': 'En este momento este servicio sólo está disponible en EE.UU.'
    }
});