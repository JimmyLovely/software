﻿define({
    'referralhistory': 'Historial de Referidos',
    'invitessent': 'Invitaciones enviadas',
    'transactionscompleted': 'Transacciones Completadas',
    'totalrewardearned': 'Total de Recompensas por Referir',
    'type': 'Tipo',
    'details': 'Detalles',
    'refeerralfromfacebook': 'Referidos de Facebook',
    'referralfromtwitter': 'Referidos de Twitter',
    'sharedlinks': 'Ligas Compartidas',
    'refermorefriends': 'Refiere mas amigos',
    'completed': 'Completadas',
    'pending': 'Pendientes'
});