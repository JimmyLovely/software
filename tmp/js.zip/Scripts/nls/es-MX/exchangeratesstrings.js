﻿define({
    'exchangeratesconsumer': {
        'title': 'Tipo de cambio vigente',
        'country': 'País',
        'currency': 'Moneda',
        'rate': 'Tipo de Cambio',
        'filter': 'Filtro'
    },
    'allexchangerate&#187': 'Todos los Tipos de Cambio &#187;'
});