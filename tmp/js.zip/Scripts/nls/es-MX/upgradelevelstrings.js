﻿define({
    'title': 'Subir documento para actualizar',
    'headermessage1': 'Para enviar una cantidad por encima de tu límite actual de',
    'headermessage2': 'necesitamos información adicional para propósitos de seguridad',
    'fileformat': 'El formato del archivo no puede subirse. Por favor, sube un archivo con la extensión',
    'or': 'o',
    'fileislarger': 'El archivo es mayor a ',
    'userlowerdocument': 'MB. Por favor usa una imagen de menor resolución o un documento más pequeño.',
    'level': 'Nivel',
});
