﻿define({
    'helpcenter': 'Centro de Ayuda',
    'faqs': {
        'title': 'Preguntas Frecuentes',
        'question1': 'pregunta 1',
        'question2': 'pregunta 2',
        'question3': 'pregunta 3',
        'question4': 'pregunta 4',
        'question5': 'pregunta 5',
        'question6': 'pregunta 6',
        'question7': 'pregunta 7',
        'question8': 'pregunta 8'
    },
    'customercare': {
        'title': 'Servicio al cliente'
    },
    'useragreement': {
        'title': 'Acuerdo del Usuario'
    },
    'privacypolicy': {
        'title': 'Política de Privacidad'
    }
});