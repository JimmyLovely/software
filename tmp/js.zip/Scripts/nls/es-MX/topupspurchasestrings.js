﻿define({
        'selectepincarrier': {
            'title': ' Seleccionar compañía de ePin',
            'seacherepincarriers': 'Busca una compañía de ePin',
            'carriers': 'Compañía'
        }
});