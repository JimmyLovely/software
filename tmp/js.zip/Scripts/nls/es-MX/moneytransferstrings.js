﻿define({
    'title': 'Envío de dinero',
    'selectrecipient': {
        'title': 'Seleccionar beneficiario',
        'searchrecipients': 'Buscar Beneficiarios',
        'addrecipient': 'Añadir beneficiario',
        'norecipientmessage': 'Por favor agrega un beneficiario ',
        'recipients': 'Beneficiarios'
    },
    'amounttosend': {
        'title': 'Cantidad a enviar',
        'sendminimum': 'El monto mínimo de envío es $10 USD',
        'send': 'Enviar',
        'receive': 'Recibir',
        'exchangerate': 'Tipo de cambio',
        'sendamountinvalid': 'Por favor captura una cantidad a enviar válida',
        'error': 'Error',
        'inputvalidreceiveamount': 'Por favor captura una cantidad a recibir válida',
        'minimumamount': 'El monto mínimo de envío es $10 USD.'
    },
    'deliveryoption': {
        'title': 'Opción de entrega',
        'cashpickup': 'Pago en ventanilla',
        'unidoscard': 'Tarjeta Unidos',
        'accountdeposit': 'Depósito a cuenta',
        'homedelivery': 'Entrega a domicilio',
        'addoption': 'Añadir opción',
        'adddepositaccount': 'Depósito a cuenta',
        'addcashpickup': 'Pago en ventanilla',
        'addhomedelivery': {
            'title': 'Añadir entrega a domicilio',
            'addnewcorrespondent': 'Añadir nuevo corresponsal',
            'selectcorrespondent': 'Seleccionar corresponsal',
            'searchcorrespondents': 'Buscar corresponsales',
            'correspondentrequired': 'Se requiere corresponsal',
            'correspondentinvalid': 'Corresponsal Invalido'
        },
        'sendtounidoscard': 'Enviar a la Tarjeta Unidos',
        'adddeliveryoptionmessage': 'Por favor agrega una opción de entrega.'
    },
    'paymentmethod': {
        'title': 'Método de pago',
        'bankaccount': 'Cuenta de banco',
        'creditanddebitcards': 'Tarjetas de Crédito/Debito',
        'reviewtransactionmessage': 'Puedes revisar tu transacción antes de completarla.',
        'credit': 'crédito',
        'debit': 'débito',
        'addpayment': 'Agregar Pago',
        'creditcard': 'Tarjeta de Crédito',
        'debitcard': 'Tarjeta de Debito',
        'bankaccount': 'Cuenta de banco'
    },
    'summary': {
        'title': 'Resumen',
        'recipientinformation': 'Información del beneficiario',
        'paymentmethod': 'Método de pago',
    },
    'additionalinforequired': {
        'title': 'Se quiere información adicional',
        'purposeoffunds': '* Propósito de los fondos',
        'recipientidnumber': '* El número de la identificación del beneficiario',
        'recipientssn': '* El SSN del beneficiario',
        'relationshipwithrecipient': '* Parentesco con el beneficiario',
        'selectrecipientdateofbirth': '* Selecciona la fecha de nacimiento del beneficiario',
        'selectrecipientidexpiration': '* Selecciona la fecha de expiración de la identificación del beneficiario',
        'selectsenderdateofbirth': '* Selecciona la fecha de nacimiento del Cliente',
        'selectsenderidexpiration': '* Selecciona la fecha de expiración de la identificación del Cliente',
        'senderidnumber': '* Número de identificación del cliente',
        'senderoccupation': '* ocupación del cliente',
        'senderssn': '* Número de Seguro Social del Cliente',
        'sourceoffunds': '* Fuente de ingresos',
        'countryrequired': 'Pais es obligatorio',
        'idtyperequired': 'Tipo de identificación requerida.',
        'invaliddate': 'Fecha Invalida!',
        'purposeoffundsrequired': 'Se requiere el propósito de los fondos.',
        'recipientcountryofbirth': 'Lugar de nacimiento del beneficiario',
        'recipientdateofbirthrequired': 'La fecha de nacimiento del beneficiario es obligatoria.',
        'recipientidexpirationrequired': 'La fecha de expiración de la identificación del beneficiario es obligatoria.',
        'recipientidissuingcountry': 'País que expide la identificación del beneficiario',
        'recipientidissuingstate': 'Estado que expide la identificación del beneficiario',
        'recipientidnumberrequired': 'El número de la identificación del beneficiario es obligatoria.',
        'recipientidtype': 'Tipo de identificación del beneficiario',
        'recipientoccupation': 'Ocupación del Beneficiario',
        'recipientoccupationrequired': 'La ocupación del beneficiario es obligatoria',
        'recipientssnrequired': 'El SSN del beneficiario es obligatorio.',
        'recipienttaxidtype': 'Tipo de identificación de impuestos del beneficiario',
        'relationshipwithrecipientrequired': 'El parentesco con el beneficiario es obligatorio.',
        'sendercountryofbirth': 'Selecciona País de Nacimiento',
        'senderdateofbirthrequired': 'La fecha de nacimiento del remitente es obligatoria.',
        'senderidexpirationrequired': 'La fecha de expiración de la identificación del remitente es obligatoria.',
        'senderidissuingcountry': 'País que expide la identificación del cliente',
        'senderidissuingstate': 'Estado que expide la identificación del cliente',
        'senderidnumberrequired': 'El número de la identificación del remitente es obligatorio.',
        'senderidtype': 'Tipo de identificación del cliente',
        'senderoccupationrequired': 'La ocupación del remitente es obligatoria.',
        'senderssnrequired': 'El SSN del remitente es obligatorio.',
        'sendertaxidtype': 'Tipo de identificación de impuestos del cliente',
        'sourceoffundsrequired': 'Se requiere la Fuente de Ingresos.',
        'staterequired': 'Estado es obligatorio.',
        'taxidtyperequired': 'El tipo de identificación de impuestos es obligatorio.',
        'atleast18yearsofage': 'Se requiere que el usuario tenga al menos 18 años de edad',
    },
    'error': 'Error',
    'moneytransactionsuccess': 'Envío de Dinero - ¡Exitoso!',
    'moneytransactiononhold': 'Envío de dinero - en espera！',
    'transactiononholder': '¡Gracias! Tu transacción está en espera hasta que hayamos procesado tus documentos.',
    'receivereceipt': 'Te enviaremos un recibo y un número de confirmación a',
    'onholdcompleted': ', cuando haya sido completada.',
    'moneytransfersummary': 'Resumen de envío de dinero',
    'amountsent': 'Cantidad a enviar',
    'upgrade': {                     
        'ugradetransactionmessage': 'Tu transacción estará pendiente hasta que tus documentos sean verificados.',
        'summarymessage': 'Tu transacción permanecerá pendiente hasta que tus documentos sean enviados y verificados.',
        'errormessage': 'La cantidad excede el máximo límite de envío actual de',
        'finishupgradelater': ' Termina la actualización más tarde',
        'upgradeprompt': { 
            'message': 'Para enviar una cantidad por encima del límite actual de ${currentlevel}, necesitamos información adicional para razones de seguridad.',
            'emaillater': 'Enviar correo después',
            'upgradenow': 'Solicitar incremento ahora'
        },
        'upgradelater': {
            'message': '¿Enviar los documentos después y continuar la transacción?'
        },
        'attachedsuccess': {
            'title': '¡Documentos para solicitud de incremento de límite enviados!',
            'message': 'Por favor, continúa tu transacción.'
        },
        'qpattachedsuccess': {
            'title': '¡Documentos para solicitud de incremento de límite enviados!',
            'message': 'Tu transacción estará <strong>pendiente</strong> hasta que tus documentos sean verificados.'
        },
        'confirmationmessage': {
            'title': 'Tu transacción está pendiente',
            'message': 'Luego de la revisión procesaremos tu transacción. Un correo electrónico ha sido enviado con instrucciones de envío.'
            
        },
        'submitprompt': {
            'title': 'Tu transacción está pendiente',
            'message': 'Luego de la revisión procesaremos tu transacción. Un correo electrónico ha sido enviado con instrucciones de envío.',
        }
    },
    'needUpgrade': {
        'error': 'Error',
        'content': 'Tu limite de envio ha sido excedido. Debes cambiar el monto de envío o solicitar el incremento del límite de envío.',
    }
});
