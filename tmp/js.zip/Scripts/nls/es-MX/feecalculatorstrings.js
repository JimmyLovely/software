﻿define({
    'feecalculatortitle': 'Calculadora de Tarifa',
    'feeconnectCalculator': 'Calculadora de Tarifa',
    'language': 'Inglés',
    'send': 'Enviar',
    'choose': 'Selecciona un',
    'country': 'País',
    'receive': 'Recibir',
    'paymentmethod': 'Método de pago',
    'bank': 'Cuenta', // Need show 'Cuenta de banco' and 'de banco' is in newline
    'account': 'de banco',
    'credit': 'Tarjeta', // Need show 'Tarjeta de crédito' and 'de crédito' is in newline
    'card': 'de crédito',
    'pickupcash': 'Recoje efectivo de uno de nuestros',
    'pickuplocations': 'puntos de pago.',
    'youpay': 'Tu pagarás',
    'sendmoney': 'Enviar dinero',
    'hide': 'Esconder',
    'fee': 'Tarifa',
    'enteranamount': 'Ingresa una cantidad',
    'getstarted': 'Enviar dinero'
});