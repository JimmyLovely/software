﻿define({
    'inviteyourfriends': 'Invita a tus amigos a envíar por Sengo ingresando su correo electrónico.',
    'friendsemail': 'Correo Electrónico de tu amigo',
    'addanotheremail': 'Agrega otro Correo Electrónico',
    'notavaildemail': 'No es un Correo Electrónico Valido',
    'emailrequired': 'Se requiere por lo menos un correo',
    'emailduplicated': 'Algún correo electrónico esta duplicado',
    'sendbutton': 'Enviar',
    'sendemailsuccessful': 'Correo enviado con éxito. Sigue refiriendo a tus amigos para ganar.',
    'emailaddress': 'ej.nombre@dominio.com'
});