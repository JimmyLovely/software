﻿define({
    'paystohavefriends': 'Es bueno tener amigos!',
        'referrallanding': {
            'earn': 'Gana',
            'foreachreferral': 'por cada uno que refieras',
            'referfriendstounidos': 'Recomienda Sengo a tus amigos y los dos ganaran $25 de crédito cuando ellos completen una operación de mínimo $50.<br/>¡La primera operación de tus amigos siempre es Gratis!',
            'itpaystohavefriendsearnmoney': 'Es bueno tener amigos! Gana $25 por cada uno que refieras.',
            'referfriends': 'Recomienda a un amigo',
            'viewreferralhistory': 'Ver Historial de Referidos',
            'shareyourpersonallink': 'o comparte tu enlace personal con amigos',
            'copylink': 'Copiar enlace',
            'linkcopied': '¡Liga copiada!',
            'referviafacebook': 'Refiere vía Facebook',
            'referviatwiter': 'Refiere vía Twitter',
        }
});