﻿define({
    'root': {
        'welcometo': 'Welcome to',
        'unidos': 'Sengo',
        'welcomeback': 'Welcome back,',
        'nanda': 'N/A',
        'promotions': 'Promotions',
        'learnmore': 'Learn more',
        'recenttransactions': 'Recent Transactions',
        'norecenttransaction': 'You have no recent transactions.',
        'trackrecentactivity': 'Keep track of recent activity on your account here.',
        'cannotconnectserver': 'Cannot connect to server',
        'quickpay': 'Quick Pay',
        'sendagain': 'Send again',
        'payagain': 'Pay again',
        'reloadquickpay': 'Reload ',
        'transactionhistory': ' View Transaction History',
        'onhold': 'Submit Upgrade Documents',
        'canceled': 'Upgrade Not Completed, Canceled',
        'upgrade': {
            'submitdocumenttoupgrade': 'Transaction On Hold. Submit Document(s) Now',
            'documentsubmited': 'Upgrade Documentation Submitted',
            'documentexpired': 'Your ID document has expired. Please upload here.',
            'sourceoffundsexpired': 'Your Source of Funds document has expired. Please upload here.'
                                     
        }
    },
    'es-MX': true
});