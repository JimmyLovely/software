﻿define({
    'root': {
        'feecalculatortitle': 'Fee Calculator',
        'feeconnectCalculator': 'Fee-Calculator',
        'language': 'Español',
        'send': 'SEND',
        'choose': 'Choose a',
        'country': 'Country',
        'receive': 'RECEIVE',
        'paymentmethod': 'Payment Method',
        'bank': 'Bank',
        'account': 'Account',
        'credit': 'Credit',
        'card': 'Card',
        'pickupcash': 'Pickup cash from one of our',
        'pickuplocations': 'locations.',
        'youpay': 'You Pay',
        'sendmoney': 'Send Money',
        'hide': 'Hide',
        'fee': 'Fee',
        'enteranamount': 'Please enter an amount',
        'getstarted': 'Get Started'
    },
    'es-MX': true
});