﻿define({
    'root': {
        'inviteyourfriends': 'Invite your friends to Sengo by entering their email addresses below.',
        'friendsemail': 'Friend\'s Email',
        'addanotheremail': 'Add Another Email',
        'notavaildemail': 'Not a valid email',
        'emailrequired': 'At least one email is required',
        'emailduplicated': 'At least one email is duplicated',
        'sendbutton': 'Send',
        'sendemailsuccessful': 'Your email has been successfully sent! Keep referring friends to earn more.',
        'emailaddress': 'ex.name@domain.com'
    },
    'es-MX': true
});