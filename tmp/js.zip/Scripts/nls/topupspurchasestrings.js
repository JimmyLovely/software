﻿define({
    'root': {
        'selectepincarrier': {
            'title': ' Select ePin Carrier',
            'seacherepincarriers': 'Search ePin Carriers',
            'carriers': 'Carriers'
        }
    },
    'es-MX': true
});