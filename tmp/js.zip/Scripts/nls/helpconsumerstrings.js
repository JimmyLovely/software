﻿define({
    'root': {
        'helpcenter':'Help Center',
        'faqs': {
            'title': 'FAQs',
            'question1': 'Question 1',
            'question2': 'Question 2',
            'question3': 'Question 3',
            'question4': 'Question 4',
            'question5': 'Question 5',
            'question6': 'Question 6',
            'question7': 'Question 7',
            'question8': 'Question 8'
        },
        'customercare': {
            'title': 'Customer Care'
        },
        'useragreement': {
            'title': 'User Agreement'
        },
        'privacypolicy': {
            'title': 'Privacy Policy'
        },
    },
    'es-MX': true
});