﻿define({
    'root': {
        'title': 'Submit Document to Upgrade',
        'headermessage1': 'To send an amount above your current limit of',
        'headermessage2': 'we require additional information for security purposes.',
        'fileformat': 'File format cannot be uploaded. Please select a file with extension',
        'or': 'or',
        'fileislarger': 'File is larger than',
        'userlowerdocument': 'MB. Please try to use a lower resolution image or upload a smaller document.',
        'level': 'Level',
    },
    'es-MX': true
});
