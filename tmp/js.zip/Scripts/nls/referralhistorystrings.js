﻿define({
    'root': {
        'referralhistory': 'Referral History',
        'invitessent': 'Accepted Invites',
        'transactionscompleted': 'Transactions Completed',
        'totalrewardearned': 'Total Rewards Earned',
        'type': 'Type',
        'details': 'Details',
        'refeerralfromfacebook': 'Referrals from Facebook',
        'referralfromtwitter': 'Referrals from Twitter',
        'sharedlinks': 'Shared Links',
        'refermorefriends': 'Refer More Friends',
        'completed': 'Completed',
        'pending': 'Pending'
    },
    'es-MX': true
})