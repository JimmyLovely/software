﻿define({
    'root': {
        'personalsettings': {
            'title': 'Personal Settings',
            'profile': {
                'title': 'Profile Information',
                'name': 'Name',
                'email': 'Email',
                'home': '(Home)',
                'mobile': '(Mobile)',
                'other': '(Other)',
                'dateofbirth': 'Date of Birth',
                'dob': 'D.O.B.',
                'dateofbirthformat': '(mm/dd/yyyy)',
                'buttons': {
                    'updateprofile': 'Update Profile'
                },
                'language': {
                    'english': 'English',
                    'spanish': 'Español'
                },
                'errormessage': {
                    'notvalidphonenumber': 'Not a valid phone number',
                    'phonenumberisrequired': 'Phone number is required'
                }
            },
            'password': {
                'title': 'Change Password',
                'oldpassword': 'Old Password',
                'newpassword': 'New Password',
                'confirmpassword': 'Confirm Password',
                'passwordwarnmessage': '8 to 20 characters, at least one number, no spaces',
                'buttons': {
                    'changepassword':'Change Password'
                },
                'validations': {
                    'oldpwdinvalid': 'Not a valid old password',
                    'newpwdinvalid': 'Not a valid new password',
                    'oldpwdrequired': 'Old password is required',
                    'newpwdrequired': 'New password is required',
                    'confirmpwdrequired': 'Confirm password is required',
                    'nomatch': 'New Password and confirm password do not match'
                }
            },
            'address': {
                'title': 'Address Information',
                'buttons': {
                    'updateaddress':'Update Address'
                }
            },
            'preferences': {
                'title': 'Profile Preferences',
                'emailnewsletter': 'Email Newsletter',
                'agreementmessage': 'I agree to receive promotional emails from Sengo.',
                'warnmessage': 'We do not share your data with third parties.',
                'buttons': {
                    'updatepreferences':'Update Preferences'
                },
                'cellphonecapable': 'Please provide a valid mobile number to receive important text notifications.'
            }
        },
        'paymentmethods': {
            'title': 'Payment Methods'
        },
        'common': {
            'title': 'My Settings'
        },
        'message': {
            'messagetitle': 'Message',
            'profileinformationupdatesuccess': 'Profile Information updated successfully!',
            'passwordupdatesuccess': 'Password updated successfully!',
            'profilerpreferencesupdatesuccess': 'Profile Preferences updated successfully!',
            'addressinformationupdatesuccess': 'Address Information updated successfully!',
            
            'nolongerreceiveoffers': 'Are you sure you no longer want to receive our exciting offers?',
            'receiveemail': 'You have been unsubscribed from our Email Newsletter. You will still receive important emails related to your account activity.',
            'characterslength': '8-20 characters, at least one number, no spaces',
            'notifyonceacquired': 'and will notify you once acquired. You can still Reload your phone with us.',
            'profileaddressnotifyonceacquired': 'and will notify you once acquired. You can still Reload your phone with us.',
            'addresssaved': 'Address Info saved. We are currently obtaining a license to send money in',
            'obtaininglicensetosendmoney': 'We are currently obtaining a license to send money in',
            'invalidpassword': 'Requires 8-20 characters, at least one number, no spaces'
        }
    },
    'es-MX': true
});
