﻿define({
    'root': {
        'selectreloadcarrier': {
            'title': 'Select Reload Carrier',
            'nocarriermessage': 'Please add a Carrier',
            'searchreloadcarriers': 'Search Reload Carriers',
            'carriers': 'Carriers',
            'addcarrier': {
                'country': 'Country'
            }
        },
        'editreloadcarrier': 'Edit Reload Carrier'
    },
    'es-MX': true
});