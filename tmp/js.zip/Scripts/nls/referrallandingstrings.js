﻿define({
    'root': {
        'paystohavefriends': 'It Pays to Have Friends!',
        'referrallanding': {
            'earn': 'Earn',
            'foreachreferral': 'for each Referral',
            'referfriendstounidos': 'Refer Friends to Sengo and you will both get a $25 credit when they do a $50+ transaction.<br/>Your friend\'s first transaction is always free!',
            'itpaystohavefriendsearnmoney': 'It Pays to Have Friends! Earn $25 for each Referral.',
            'referfriends': 'Refer Friends',
            'viewreferralhistory': 'View Referral History',
            'shareyourpersonallink': 'or share your personal link with friends',
            'copylink': 'Copy Link',
            'linkcopied': 'Link Copied!',
            'referviafacebook': 'Refer via Facebook',
            'referviatwiter': 'Refer via Twitter',
        }
    },
    'es-MX': true
});