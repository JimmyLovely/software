﻿define({
    'root': {
        'selectpinlesscarrier': {
            'title': ' Select Pinless Carrier',
            'nocarriermessage': 'Please add a Carrier',
            'searchpinlesscarriers': 'Search Pinless Carriers',
            'carriers': 'Carriers'
        }
    },
    'es-MX': true
});