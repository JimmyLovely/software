/**
 * @license Copyright (c) 2015 Cheng Fan
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
define(['PageDisposer', 'knockout', 'jquery', 'Router', 'ClientScript', paths['common-strings'], 'TrackEvent'], function (PageDisposer, ko, $, Router, cs, commonstrings, track) {
    var initialRun = true;

    function broswerTriggerTab(fullPath) {
        if (app.lastUrl != "" && fullPath.indexOf(app.lastUrl) != -1 && location.hash != "" && location.hash.indexOf('_refresh') == -1) {
            app.lastUrl = location.pathname;
            return true;
        }
        app.lastUrl = location.pathname;

        return false;
    }

    function isEndSharp() {// url end with #
        if (app.lastUrl != "" && location.toLocaleString().indexOf(app.lastUrl) != -1 && location.toLocaleString().indexOf('#') != -1 && location.hash == "") {
            return true;
        }

        return false;
    }

    function isCreditDebitCardDemo() {
        if (app.lastUrl != "" && location.toLocaleString().indexOf(app.lastUrl) != -1 && location.toLocaleString().indexOf('#') != -1 && location.hash == "#modalDemo" && app.isShowDemo) {
            return true;
        }

        return false;
    }

    var app = {
        isShowDemo: false,  // For Credit Debit Card Number Demo
        lastUrl: null,
        manualTab: false,
        showHeaderAndFooter: ko.observable(true),
        showReferralPromoMessage: ko.observable(false),
        init: function (name, data, controller) {
            if (isEndSharp()) {
                return;
            }

            if (isCreditDebitCardDemo()) {
                return cs.openModal('modal-account-new-demo');
            }

            if (broswerTriggerTab(window.location.toLocaleString())) {
                app.manualTab = false;
                if (cs.isOpeningModal()) {
                    cs.closeModal(cs.isOpenPreviousByBankSpace());
                    return;
                }
                app.urlTriggerTab();
                return;
            }

            if (cs.isOpeningModal()) {
                cs.closeModal(cs.isOpenPreviousByBankSpace());
                return;
            }

            if (!initialRun) {
                app.getConfigurations();
            }

            app.loading(false);

            //cs.showLoading();
            var autoDispose = app.page().data.dispose(app); // if the requested page is not the same page, dispose current page first before swap to the new page
            if (autoDispose !== false) {
                // auto-dispose page's exposed observables and primitive properties to initial values. if not desired, return false in dispose function to suppress
                // auto-disposal for all public properties of the page, or make the particular properties private
                PageDisposer.dispose(app.page().data);
            }

            var date = new Date();
            app.uniqueModuleName = name + date.getTime();

            PageDisposer.init(data); //store initial observable and primitive properties values of the page
            data.init(app); // init view model and call controller (optional) before template is swapped-in

            if (controller) {
                controller(data);
            }

            app.page({
                name: name,
                data: data
            }); // to test if template finished rendering, use afterRender binding in the template binding

            if (cs.IsMobileDevice() && window.screen.width < 642) {
                if (['ReferralLandingConsumer', 'ReferralHistoryConsumer', 'ReferralViaEmailConsumer', 'ReferralHelperConsumer'].indexOf(app.page().name) != -1) {
                    app.showHeaderAndFooter(false);
                    $("#main").addClass("main-padding");
                }
                else {
                    app.showHeaderAndFooter(true);
                    $("#main").removeClass("main-padding");
                }
            }

            document.title = app.title();

            track.trackTotalTimeOnPage(name, app.page().name);
            track.generateTimeOnPageForPageLink(name);

            if (app.initExtra) {
                app.initExtra(name, data, controller); // useful for common init tasks for all pages such as anaylitics page view tracking, can be set in RootBindings
            }

            if (initialRun) {
                $.when(app.getJSModule('knockout.validation.extended'))
                      .done(function () {
                          ko.validation.init({
                              grouping: { deep: false, observable: false },
                              decorateElement: true,
                              insertMessages: false,
                              decorateElementOnModified: true,
                              decorateInputElement: true,
                              errorClass: 'error-msg',
                              errorMessageClass: 'error-msg',
                              errorElementClass: 'error',
                              //messageTemplate: "errorMessageTemplate"
                          });

                          if (cs.IsIpad()) {//handle direct click save button then error show but modal can't scroll in ipad
                              ko.validation.showAllMessageMiddleWare(null, function () {
                                  cs.redrawModal();
                              });
                          }
                      })

                ko.applyBindings(app, document.getElementsByTagName('html')[0]); // apply binding at root node to be able to bind to anywhere
                initialRun = false;

                var timeoutIntervalInMinutes = cs.IsMobileDevice() ? 30 : 55;
                cs.SessionTimeOut.setActivityCheckOff().setActivityCheckOn(timeoutIntervalInMinutes * 60, 60);

                setTimeout(function () {
                    $.ajax({
                        url: '/Customers/GetSenderInfo',
                        type: "GET",
                        dataType: "json",
                        contentType: "application/json"
                    })
                     .done(function (data) {
                         $.when(app.getJSModule('SenderInfo'))
                         .done(function (SenderInfoModel) {
                             app.senderInfo(new SenderInfoModel(data.SenderInfo));
                             app.showReferralPromoMessage(data.IsShowReferralPromoCode);
                             app.senderInfo().PosPaymentConfig(data.PaymentConfig);

                             cs.CacheMoneyTransferPermission(app.senderInfo().HasMoneyTransferPermission());

                             //app.senderInfo().SenderLevel().GetAvailableBalance();
                             localStorage.setItem("SenderInfo", JSON.stringify(data.SenderInfo));
                             if (app.senderInfo().Customer().CustomerBasic.IsShowDOBAndAddress()) {
                                 require(['PersonalInfoConsumer-js']);
                                 app.cachePage(['PersonalInfoConsumer-html']);
                             }

                             dataLayer.push({ 'emailExtension': app.senderInfo().Customer().CustomerBasic.EmailAddress() });
                             setTimeout(function () {
                                 require(['SenderInfo', 'MoneyTransferConsumer-js',
                                        'BillPayConsumer-js', 'BillPayLCRConsumer-js',
                                        'TopUpsReloadConsumer-js', 'TopUpsPurchaseConsumer-js',
                                        'TopUpsPinlessConsumer-js', 'IncreaseLimitConsumer-js', 'UpgradeLevelConsumer-js',
                                        'SettingsConsumer-js', 'ExchangeRatesConsumer-js'], function () {
                                            require(['AccountConsumer-js']);
                                        });

                                 app.cachePage([
                                    'MoneyTransferConsumer-html',
                                    'BillPayLCRConsumer-html',
                                    'BillPayConsumer-html',
                                    'TopUpsReloadConsumer-html',
                                    'TopUpsPinlessConsumer-html',
                                    'TopUpsPurchaseConsumer-html',
                                    'AccountConsumer-html',
                                    'SettingsConsumer-html',
                                    'ExchangeRatesConsumer-html',
                                    'IncreaseLimitConsumer-html',
                                    'UpgradeLevelConsumer-html',
                                    'add-additional-info-html']);

                                 app.cacheComponent(['manage-add-recipient', 'add-biller-lcr', 'add-reload-carrier', 'add-biller', 'select-recipient', 'select-biller-lcr', 'select-biller', 'topups-select-carrier',
                                    'select-epin', 'manage-recipient', 'add-bank-account', 'add-credit-debit-account', 'billing-address', 'manage-lcr-billing-account',
                                 'manage-billing-account', 'manage-carrier', 'manage-transaction-details', 'settings-payment-method', 'personal-settings', 'add-pinless-carrier']);
                             });

                             // Set IsFirstLogin value.
                             try {
                                 if (app.page().name == "CustomerDashboard") {
                                     var firstLogin = configuration.isFirstLogin || sessionStorage.getItem("IsFirstLogin");
                                     sessionStorage.removeItem("IsFirstLogin");
                                     if (firstLogin) {
                                         app.senderInfo().Customer().CustomerBasic.IsFirstLogin(firstLogin.toString().toLowerCase() == "true" ? true : false);
                                     }
                                     else {
                                         getIsFirstLoginInfo(); // It's wrapper.
                                     }
                                 }
                             }
                             catch (e) {
                                 // Do nothing.
                             }

                             if (app.senderInfo().Customer().CustomerBasic.IsFirstLogin()) {
                                 track.generatePartialTimeOnPageTrack(track.CategoryEnum.Tutorial, track.PageEnum.Tutorial);
                             }
                         });
                     })
                     .fail(function (xhr, status) {
                         try {
                             var tempError = $.parseJSON(xhr.responseText);

                             if ((tempError.Priority != null && tempError.Priority == 1) || cs.isSpecialError(tempError.Message)) {// error message is html not json.
                                 ModelSessionTimeOut$RevealAndLogout();
                             }
                         } catch (e) { }
                     });
                    $.ajax({
                        url: '/Customers/GetSenderLevel',
                        type: "GET",
                        dataType: "json",
                    }).done(function (data) {
                        $.when(app.getJSModule('SenderInfo'))
                         .done(function () {
                             var funcSenderLevel = function () {
                                 if (app.senderInfo()) {
                                     app.senderInfo().SenderLevel(data);
                                     if (app.page().data.LoadedSenderInfo) {
                                         app.page().data.LoadedSenderInfo();
                                     }
                                 } else {
                                     setTimeout(function () {
                                         funcSenderLevel();
                                     }, 100);
                                 }
                             };

                             funcSenderLevel();
                         });
                    });

                    app.getConfigurations();
                    var appsflyer = getAppsflyerId();
                    if (!appsflyer) {
                        app.getAppsflyer();
                    }
                });

                var initTrackEvent = function () {
                    $.when(app.getJSModule('TrackEvent'))
                     .done(function (T) {
                         T.init({ userId: configuration.cardHolderId });
                     });
                }

                initTrackEvent();

                if (cssLoadedFlag) {
                    $("#loading-modal").hide();
                }
            }

            return data;
        },
        page: ko.observable({
            name: '', // name of the page - auto-set by the framework, no need to worry
            data: {
                init: function () { }, // preparation before the page's template is rendered, such as checking access control, init/instantiate modules used by the page, etc.
                dispose: function () { } // properly dispose the page to prevent memory leaks and UI leftovers (important for SPA since page doesn't refresh between page views) - remove DOM element event listeners, dispose knockout manual subscriptions, etc.
            }
        }),
        bodyClass: ko.observable(''),
        loading: ko.observable(false),
        title: function () {
            var title = app.page().data.title + " - Sengo";
            if (title) {
                return title;
            } else {
                return app.page().name.titleize(); // override in RootBindings as needed
            }
        },
        refreshEvent: function () {
            //RootBindings.RefreshFoundation();
            //DemoRun($, this);
        },
        senderInfo: ko.observable(null),
        beforeRender: function () {
            $("#main").removeClass();
        },
        afterRender: function () {
            //if (app.page().data && app.page().data.isReady && app.page().data.isReady() == true) {
            //setTimeout(function () {
            //    cs.closeModal();
            //}, 500);
            //app.refreshEvent();

            //if (!viewModel) {
            //    app.senderInfo(null);
            //}

            if (app.page().data.afterRender) {
                app.page().data.afterRender();
            }
            $('body').removeClass('open');
            $('#header').removeClass("blur");
            $('#wrapper').removeClass("blur");

            app.urlTriggerTab();

            scrollTo(0, 0);
            //}
        },
        logout: function (element) {
            if (element && element == '#sidebar-logout') {
                cs.showLoading();
            }
            else {
                $(element).addClass("now-loading");
            }

            $.when(app.getJSModule('DataModel'))
            .done(function (dataModel) {
                dataModel.logout();
            });

            //DataCapture: logout.
            cs.AddActivityInfo(11);
            goToLogin();
        },
        redirectTo: function (url) {
            if (!cs.CheckEnabledCookie()) {
                //Inline message
                cs.showFistLevelError({ Message: commonstrings.clientscriptjsmessagebox.enableyourbrowsercookie, Caption: commonstrings.clientscriptjsmessagebox.error });
                // Handle null exception, do not return json object(Message in json formate will be shown up).
                //Inline message
                var xhr = { "responseText": commonstrings.clientscriptjsmessagebox.enableyourbrowsercookie };
                return $.Deferred().reject(xhr, commonstrings.clientscriptjsmessagebox.error);
            }

            Router().setRoute(url);
        },
        cachePage: function (pageNames) {
            if (pageNames) {
                $.each(pageNames, function (index, pageName) {
                    ko.amdTemplateEngine.renderTemplate(pageName, null, null, document);
                });
            }
        },
        cacheComponent: function (componentNames) {
            if (componentNames) {
                $.each(componentNames, function (index, componentName) {
                    ko.components.get(componentName, function () { })
                });
            }
        },
        uniqueModuleName: '',
        uniqueAjax: {},
        closeModal: function (openPrevious) {
            return cs.closeModal(openPrevious);
        },
        openModal: function (revealId, isUnfocused) {
            return cs.openModal(revealId, isUnfocused);
        },
        openUserAgreement: function (element) {
            cs.closeModalCallBack('modal-user-agreement', function () {
                if (element == 'bottom') {
                    // for normal transaction
                    cs.SlideToBottom();
                } else {
                    // for quick pay
                    element = $('.quick-pay-href #' + element);
                    cs.scrollToElement(element);
                }
            });
            cs.openModal('modal-user-agreement');
        },
        openConsumerFraudWarning: function (element) {
            cs.closeModalCallBack('modal-money-fraud', function () {
                if (element == 'bottom') {
                    // for normal transaction
                    cs.SlideToBottom();
                } else {
                    // for quick pay
                    element = $('.quick-pay-href #' + element);
                    cs.scrollToElement(element);
                }
            });
            cs.openModal('modal-money-fraud');
        },
        keepAmountDecimalPlaces: function (value) {
            if (value && !isNaN(value)) {
                value = parseFloat(value).toFixed(2);
            }

            return app.getFormatFloat(value);
        },
        keepFourDecimal: function (value) {
            if (!value || isNaN(value)) return value;
            return parseFloat(value).toFixed(4);
        },
        getFormatFloat: function (value) {
            if (value == null || value.length <= 3) {
                return value;
            }

            if (!/^(\+|-)?(\d+)(\.\d+)?$/.test(value)) {
                return value;
            }

            var sign = RegExp.$1,
                integerPart = RegExp.$2,
                decimalPart = RegExp.$3;

            var reg = new RegExp();
            reg.compile("(\\d)(\\d{3})(,|$)");
            while (reg.test(integerPart)) {
                integerPart = integerPart.replace(reg, "$1,$2$3");
            }

            return sign + "" + integerPart + "" + decimalPart;
        },
        urlTriggerTab: function () {
            var hash = location.hash.replace("/", "");
            if (hash && hash != "#") {
                if (!$(hash).hasClass("active")) {
                    app.triggerTabWithOutHash(hash.replace('_refresh', ''));
                }
            }
        },
        triggerTabWithOutHash: function (hash) {
            require('AppRouter').triggerTabWithOutHash(hash);
        },
        cancelEvent: function (event, isCancel) {
            if (isCancel) {
                event.stopPropagation();
            }
        },
        printTransactionDone: function (element) {
            cs.PrintTransactionDone(element);
        },
        formatAmountOnFocus: function (element) {
            cs.FormatAmountOnFocus(element);
        },
        isMobileDevice: function () {
            return !!navigator.userAgent.match(/(phone|pad|pod|iPhone|iPod|ios|iPad|Android|Mobile|BlackBerry|Windows Phone)/i);
        },
        addPlaceHolderToDate: function () {
            cs.addPlaceHolderToDate();
        },
        factoryFunc: function (funcName, args) {
            if ($.type(args) === 'array') {
                return app.page().data[funcName].apply(null, args);
            } else {
                return app.page().data[funcName].call(null, args);
            }
        },
        removeOpen: function () {
            cs.RemoveOpen();
            
            return true;
        },
        getJSModule: function (moduleName) {
            var deferred = $.Deferred();
            if (require.defined(moduleName)) {
                deferred.resolve(require(moduleName));
            } else {
                require([moduleName], function (module) {
                    deferred.resolve(module);
                });
            }

            return deferred;
        },
        configurations: ko.observable(),
        getConfigurations: function () {
            if (!!app.configurations()) {
                return;
            }

            $.ajax({
                url: '/Customers/GetConfigurations',
                type: "GET",
                dataType: "json"
            })
            .done(function (data) {
                if (data.ConfigInfo) {
                    app.configurations(data.ConfigInfo);
                }
                if (data.ClientInfo) {
                    cs.getClientInformation(data.ClientInfo);
                }
            })
        },
        appsflyer: ko.observable(),
        getAppsflyer: function () {
            $.ajax({
                url: '/Customers/GetAppsflyer',
                type: "GET",
                dataType: "json"
            })
           .done(function (data) {
               if (data != -1) {
                   app.appsflyer(data);
                   require(['TrackEvent'], function (T) {
                       T.sendCacheEvent();
                   });
               } else {
                   require(['TrackEvent'], function (T) {
                       T.closeTrackAppsflyerEvent();
                   });
               }

           })
        }
    };

    var getAppsflyerId = function () {
        var isIOS = false;
        var isRequestSuccessfull = false;
        try {
            Android.getAppsflyerId();
            isIOS = false;
            isRequestSuccessfull = true;
        } catch (e) {
            // error
        }

        try {
            webkit.messageHandlers.getAppsflyerId.postMessage("Dummy message");
            isIOS = true;
            isRequestSuccessfull = true;
        } catch (e) {
            // error
        }

        if (isRequestSuccessfull) {
            window.getAppsflyerIdCallback = function (data) {
                var appsflyer = {
                    IsIOS: isIOS,
                    AppsflyerId: data.appsflyerId
                };

                app.appsflyer(appsflyer);
                $.when(app.getJSModule('DataModel'))
                .done(function (dataModel) {
                    dataModel.saveAppsflyer(appsflyer);
                });
            }
            return true;
        }


        return false;
    }

    var getIsFirstLoginInfo = function () {
        var isRequestSuccessfull = false;
        try {
            Android.getIsFirstLoginInfo();
            isRequestSuccessfull = true;
        } catch (e) {
            // error
        }

        try {
            webkit.messageHandlers.getIsFirstLoginInfo.postMessage("Dummy message");
            isRequestSuccessfull = true;
        } catch (e) {
            // error
        }

        if (isRequestSuccessfull) {
            window.getIsFirstLoginInfoCallback = function (isFirstLogin) {
                app.senderInfo().Customer().CustomerBasic.IsFirstLogin(isFirstLogin);
            }
        }
    }

    app.isIdPanel = ko.computed(function () {
        var page = app.page();
        return ['PersonalInfoConsumer', 'FeeCalculatorConsumer', 'ReferralLandingConsumer', 'ReferralViaEmailConsumer',
        'ReferralHistoryConsumer', 'UpgradeLevelConsumer'].indexOf(page.name) > -1;
    }).extend({ notify: 'always' });


    app.isReferral = ko.computed(function () {
        var page = app.page();
        return page.name == "ReferralLandingConsumer"
            || page.name == "ReferralViaEmailConsumer"
            || page.name == "ReferralHistoryConsumer"
            || page.name == "ReferralHelperConsumer";
    }).extend({ notify: 'always' });

    app.isTransactionPages = ko.computed(function () {
        var page = app.page();
        return ['MoneyTransferConsumer', 'BillPayLCRConsumer', 'BillPayConsumer', 'TopUpsReloadConsumer', 'TopUpsPurchaseConsumer', 'TopUpsPinlessConsumer'].indexOf(page.name) != -1;
    });

    app.isFeeCalculatorPage = ko.computed(function () {
        var page = app.page();
        return ['FeeCalculatorConsumer'].indexOf(page.name) != -1;
    });

    app.goToPersonalInfo = function (nextPage, previousPage) {
        $.when(app.getJSModule('DataModel'))
         .done(function (dataModel) {
             dataModel.goToPersonalInfo(nextPage, previousPage);
         });
    }

    app.registerComponent = function (componentName) {
        ko.components.register(componentName, {
            viewModel: { require: componentName + '-js' },
            template: { require: 'text!' + componentName + '-html' }
        });
    };

    app.registerComponents = function (componentNames) {
        $.each(componentNames, function (index, componentName) {
            app.registerComponent(componentName);
        });
    };

    app.callPhone = function (phoneNumber) {
        cs.RemoveOpen();

        try {
            Android.callPhone(phoneNumber);
            return true;
        } catch (e) {
            // error
        }

        try {
            webkit.messageHandlers.callPhone.postMessage(phoneNumber);
            return true;
        } catch (e) {
            // error
        }

        location.href = "tel:" + phoneNumber;
        return true;
    }
    
    //app.concat(RootBindings); // additional root bindings as needed by the app

    return app;

});