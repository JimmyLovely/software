﻿/*!
 * EventDataCapture, Send the data to GA/MP/Appsflyer 
 * Version 1.0.0
 */
(function () {
    (function (factory) {
        if (typeof define === 'function' && define['amd']) {
            define([], factory);
        } else {
            factory();
        }
    }(function () {
        var categoryEnum = {
            'LeftMenu': 'Left Menu',
            'AddNewAccountDeposit': 'Add New Account Deposit',
            'AddNewCashPickup': 'Add New Cash Pickup',
            'AddNewRecipient': 'Add New Recipient',
            'EditNewRecipient': 'Edit New Recipient',
            'AddNewBiller': 'Add New Biller',
            'EditNewBiller': 'Edit New Biller',
            'AddNewCarrierReload': 'Add New Carrier-reload',
            'EditNewCarrierReload': 'Edit Carrier-reload',
            'AddNewCarrierPinless': 'Add New Carrier-pinless',
            'EditNewCarrierPinless': 'Edit Carrier-pinless',
            'ManageRecipients': 'Manage Recipients',
            'ManageBillers': 'Manage Billers',
            'ManageCarriers': 'Manage Carriers',
            'TransactionHistory': 'Transaction History',
            'AddBank': 'Add Bank',
            'AddCard': 'Add Card',
            'PersonalSettings': 'Personal Settings',
            'PaymentMethods': 'Payment Methods',
            'Dashboard': 'Dashboard',
            '+Button': '+Button',
            'TransactionDetails': 'Transaction Details',
            'MTFlow': 'MT Flow',
            'BPFlow': 'BP Flow',
            'TUReloadFlow': 'TU-reload Flow',
            'TUEPinFlow': 'TU-ePin Flow',
            'TUPinlessFlow': 'TU-Pinless Flow',
            'TransactionReceiptPage': 'Transaction Receipt Page',
            'PersonalInformation': 'Personal Information Screen',
            'ReferralLandingPage': 'Referral',
            'CalculatorScreen': 'CalculatorScreen',
            'CalculatorScreenPre': 'CalculatorScreen_Pre',
            'CalculatorScreenPost': 'CalculatorScreen_Post',
            'LoginScreen': 'LoginScreen',
            'CarouselScreen': 'CarouselScreen',
            'Registration': 'Registration',
            'RegistrationConfirmation': 'Registration Confirmation',
            'RegistrationComplete': 'Registration Complete',
            'DeviceAuthorization': 'Device Authorization',
            'DeviceAuthorizationActivation': 'Device Authorization Activation',
            'ForgotPassword': 'Forgot Password',
            'ResetPassword': 'Reset Password',
            'ResetPasswordConfirmation': 'Reset Password Confirmation',
            'Tutorial': 'Tutorial'
        };

        var actionEnum = {
            "ButtonClick": "Button Click",
            'ScreenView': 'Screen View',
            'InputField': 'Input Field',
            'Metric': 'Metric',
            'ExitPage': 'ExitPage',
            'Error': 'Error',
            'Swipe': 'Swipe',
            'SourcePage': 'SourcePage'
        };

        var pageEnum = {
            'LeftMenu': 'Left Menu',
            'AddNewAccountDeposit': 'Add New Account Deposit',
            'AddNewCashPickup': 'Add New Cash Pickup',
            'AddNewRecipient': 'Add New Recipient',
            'EditNewRecipient': 'Edit New Recipient',
            'AddNewBiller': 'Add New Biller',
            'EditNewBiller': 'Edit New Biller',
            'AddNewCarrierReload': 'Add New Carrier-reload',
            'EditNewCarrierReload': 'Edit Carrier-reload',
            'AddNewCarrierPinless': 'Add New Carrier-pinless',
            'EditNewCarrierPinless': 'Edit Carrier-pinless',
            'ManageRecipients': 'Manage Recipients',
            'ManageBillers': 'Manage Billers',
            'ManageCarriers': 'Manage Carriers',
            'TransactionHistory': 'Transaction History',
            'AddBank': 'Add Bank',
            'AddCard': 'Add Card',
            'PersonalSettings': 'Personal Settings',
            'PaymentMethods': 'Payment Methods',
            'Dashboard': 'Dashboard',
            '+Button': '+Button Open',
            'TransactionDetails': 'Transaction Details',
            'SendMoney': 'Send Money',
            'PayBills': 'Pay Bills',
            'Reload': 'Reload',
            'EPin': 'ePin',
            'Pinless': 'Pinless',
            'TransactionReceiptPage': 'Transaction Receipt Page',
            'PersonalInformation': 'Personal Information Screen',
            'ReferralLandingPage': 'Referral: Landing Page',
            'ReferralHistory': 'Referral: Referral History',
            'ReferralViaEmail': 'Referral: Refer via Email',
            'HowItWork': 'Referral: How it Works',
            'CalculatorScreen': 'CalculatorScreen',
            'CalculatorScreenPre': 'CalculatorScreen_Pre',
            'CalculatorScreenPost': 'CalculatorScreen_Post',
            'LoginScreen': 'LoginScreen',
            'CarouselScreen': 'CarouselScreen',
            'Registration': 'Registration',
            'RegistrationConfirmation': 'Registration Confirmation',
            'RegistrationComplete': 'Registration Complete',
            'DeviceAuthorization': 'Device Authorization',
            'DeviceAuthorizationActivation': 'Device Authorization Activation',
            'ForgotPassword': 'Forgot Password',
            'ResetPassword': 'Reset Password',
            'ResetPasswordConfirmation': 'Reset Password Confirmation',
            'Tutorial': 'Tutorial',
            'HelpCenter': 'Help Center',
            'IncreaseSendingLimit': 'Increase Sending Limit',
            'UpgradePage':'Submit Document(s) to Upgrade Sending Limit',
            'Logout': 'Log Out',
            'IndependentUpgrade': 'Independence Upgrade'
        };

        var labelEnum = {
            'TimeOnPage': 'TimeOnPage',
            'EmailReceipt': 'Email Receipt',
            'PrintReceipt': 'Print Receipt',
            'ViewTransactionDetails': 'View Transaction Details',
            'Finish': 'Finish',
            'SubmitNow': 'Submit Now'
        };

        var structureEnum = {
            'InitiatedCheckout': 'af_initiated_checkout',
            'Purchase': 'af_purchase',
            'AfShare': 'af_share',
            "AddToCart": "af_add_to_cart",
            'ContentView': 'af_content_view'
        };

        var languageEnum = { English: "English", Spanish: "Spanish" };
        var ga = parseInt(1, 2);
        var mp = parseInt(10, 2);
        var af = parseInt(100, 2);

        var trackTimeOnPageLink;
        function trackTimeOnPageForPageLink(timeStop) {
            if (typeof trackTimeOnPageLink == 'function') {
                trackTimeOnPageLink(timeStop);
            }
        };
        var userId;

        function init(options) {
            userId = options.userId;
        }

        var isGiveUpTrackAppsflyer = false;

        function generateTimeOnPageForPageLink(moduleName) {
            var eventCategory;
            var eventPage;
            switch (moduleName) {
                case "CustomerDashboard":
                    eventCategory = categoryEnum.Dashboard;
                    eventPage = pageEnum.Dashboard;
                    break;
                case "PersonalInfoConsumer":
                    eventCategory = categoryEnum.PersonalInformation;
                    eventPage = pageEnum.PersonalInformation;
                    break;
                case "ReferralLandingConsumer":
                    eventCategory = categoryEnum.ReferralLandingPage;
                    eventPage = pageEnum.ReferralLandingPage;
                    break;
                case "ReferralHistoryConsumer":
                    eventCategory = categoryEnum.ReferralLandingPage;
                    eventPage = pageEnum.ReferralHistory;
                    break;
                case "SettingsConsumer":
                    eventCategory = categoryEnum.PersonalSettings;
                    eventPage = pageEnum.PersonalSettings;
                    break;
                case "ReferralViaEmailConsumer":
                    eventCategory = categoryEnum.ReferralLandingPage;
                    eventPage = pageEnum.ReferralViaEmail;
                    break;
                case "FeeCalculatorConsumer":
                    eventCategory = categoryEnum.CalculatorScreenPost;
                    eventPage = pageEnum.CalculatorScreenPost;
                    break;
                case "AccountConsumer":
                    eventCategory = categoryEnum.TransactionHistory;
                    eventPage = pageEnum.TransactionHistory;
                    break;
                default:
                    break;
            }

            generatePartialTimeOnPageTrack(eventCategory, eventPage);
        }

        function trackTotalTimeOnPage(moduleName, pageName) {
            var category;
            var eventPage;
            var eventLabel;

            switch (moduleName) {
                case "AccountConsumer"://Have tracked in AccountConsumer.viewModel.js
                    break;
                case "SettingsConsumer"://Have tracked in SettingsConsumer.viewModel.js
                    break;
                case "MoneyTransferConsumer":
                    category = categoryEnum.MTFlow;
                    eventPage = pageEnum.SendMoney;
                    eventLabel = 'TimeOnPage';
                    break;
                case "BillPayConsumer":
                case "BillPayLCRConsumer":
                    category = categoryEnum.BPFlow;
                    eventPage = pageEnum.PayBills;
                    eventLabel = 'TimeOnPage';
                    break;
                case "TopUpsReloadConsumer":
                    category = categoryEnum.TUReloadFlow;
                    eventPage = pageEnum.Reload;
                    eventLabel = 'TimeOnPage';
                    break;
                case "TopUpsPinlessConsumer":
                    category = categoryEnum.TUPinlessFlow;
                    eventPage = pageEnum.Pinless;
                    eventLabel = 'TimeOnPage';
                    break;
                case "TopUpsPurchaseConsumer":
                    category = categoryEnum.TUEPinFlow;
                    eventPage = pageEnum.EPin;
                    eventLabel = 'TimeOnPage';
                    break;
                case "CustomerDashboard":
                    category = categoryEnum.Dashboard;
                    eventPage = pageEnum.Dashboard;
                    eventLabel = 'TimeOnPage';
                    break;
                case "PersonalInfoConsumer":
                    category = categoryEnum.PersonalInformation;
                    eventPage = pageEnum.PersonalInformation;
                    eventLabel = 'TimeOnPage';
                    break;
                case "FeeCalculatorConsumer":
                    category = categoryEnum.CalculatorScreenPost;
                    eventPage = pageEnum.CalculatorScreenPost;
                    eventLabel = 'TimeOnPage';
                    break;
                case "ReferralLandingConsumer":
                    category = categoryEnum.ReferralLandingPage;
                    eventPage = pageEnum.ReferralLandingPage;
                    eventLabel = 'Landing: TimeOnPage';
                    break;
                case "ReferralHistoryConsumer":
                    category = categoryEnum.ReferralLandingPage;
                    eventPage = pageEnum.ReferralHistory;
                    eventLabel = 'Referral History: TimeOnPage';
                    break;
                case "ReferralViaEmailConsumer":
                    category = categoryEnum.ReferralLandingPage
                    eventPage = pageEnum.ReferralViaEmail;
                    eventLabel = 'Refer via Email: TimeOnPage';
                    break;
                default:
                    category = moduleName;
                    eventPage = moduleName
                    eventLabel = 'TimeOnPage';
                    break;
            }

            if (category) {
                trackTimeOnPage({
                    sendType: ga,
                    eventCategory: category,
                    eventAction: actionEnum.Metric,
                    eventLabel: eventLabel,
                    eventPage: eventPage,
                    source: pageName
                });
            }
        }

        function trackEvent(data) {
            data.language = getLanguage();
            data.eventTime = getUTCString(new Date());
            data.source = document.referrer;

            sendEvent(data, false);
        }

        function trackNextPage(nextPage, app) {
            var eventCategory = getEventCategoryForTrackNextPage(app);
            var eventPage = getEventPage(app);
            if (eventCategory) {
                var data = getRequestObject();
                data.sendType = ga + mp;
                data.eventCategory = eventCategory;
                data.eventAction = actionEnum.ExitPage;
                data.eventLabel = nextPage;
                data.eventPage = eventPage;

                sendEvent(data, false);
            }
        }

        function generatePartialTimeOnPageTrack(eventCategory, eventPage) {
            var startTime = new Date();

            trackTimeOnPageLink = function (timeStop) {
                var endTime = new Date();
                var timeSpan = endTime - startTime;

                var data = {};
                data.eventCategory = eventCategory;
                data.eventPage = eventPage;
                data.timeStop = timeStop;
                data.metric = timeSpan / 1000;
                data.sendType = ga;
                data.eventAction = actionEnum.Metric;
                data.eventLabel = labelEnum.TimeOnPage;
                data.nonInteraction = true;

                if (eventCategory && eventPage && timeStop && typeof(timeStop) == 'string') {
                    trackEvent(data);
                }
            }
            return trackTimeOnPageLink;
        }

        function getRequestObject() {
            var data = {};
            data.language = getLanguage();
            data.eventTime = getUTCString(new Date());
            data.source = document.referrer;
            return data;
        }

        function trackTimeOnPage(data) {
            data.language = getLanguage();
            dataLayer.push({
                'event': 'GATrackTime',
                'eventCategory': data.eventCategory,
                'eventAction': data.eventAction,
                'eventLabel': data.eventLabel,
                'eventPage': data.eventPage,
                'language': data.language,
                'source': data.source,
                'userId': userId || 'None'
            });
        }

        function closeTrackAppsflyerEvent() {//Give up appsflyer track event and clear session storage about appslfyer
            try {
                isGiveUpTrackAppsflyer = true;
                var events = JSON.parse(sessionStorage.getItem("DataEvents") || '[]');
                var newEvetns = [];
                for (var i = 0, l = events.length; i < l; i++) {
                    var event = events[i];
                    if (event.sendType != af) {
                        newEvetns.push(event);
                    }
                }

                setSessionStorage("DataEvents", JSON.stringify(newEvetns));
            } catch (e) {
            }
        }

        function sendEvent(data, isFromCache) {
            if ((data.sendType & ga) !== 0) {
                sendGA(data);
                data.sendType = data.sendType ^ ga
            }

            if ((data.sendType & mp) !== 0) {
                sendMP(data);
                data.sendType = data.sendType ^ mp;
            }

            if (isGiveUpTrackAppsflyer) {//If we can't get the appsflyerId, we will give up.
                return;
            }
            if ((data.sendType & af) !== 0) {
                try {
                    if (!(require('app') && require('app').appsflyer() && require('app').appsflyer().AppsflyerId != "")) {
                    if (!isFromCache) {
                        cacheEvent(data);
                    }
                    return;
                }
                sendAppsflyer(data);
                } catch (e) {
                    console.log(e.stack);
            }
            }
        };

        function sendAppsflyer(data) {
            var parameters = function (data) {
                var params = [];
                params.push(['c', data.eventCategory]);
                params.push(["a", data.eventAction]);
                params.push(["l", data.eventLabel]);
                params.push(["p", data.eventPage]);
                params.push(["amt", isNumber(data.amount) ? data.amount : 0]);
                params.push(["cid", userId]);
                params.push(["lgg", data.language]);
                params.push(["s", data.source]);
                params.push(["es", data.eventStructure]);
                params.push(["en", data.eventName]);
                params.push(["isios", require('app').appsflyer().IsIOS]);
                params.push(["afid", require('app').appsflyer().AppsflyerId]);
                params.push(["et", data.eventTime]);
                params.push(["pe", data.price]);
                params.push(["r", data.revenue]);
                params.push(["ctid", data.contentId]);
                params.push(["ct", data.contentType]);
                params.push(["cy", data.currency]);
                params.push(["rid", data.receiptId]);
                params.push(["d", data.description]);

                var parameterList = params.map(function (item) {
                    return item.join("=");
                });

                return parameterList.join("&");
            };

            var url = configuration.dataCaptureServerUrl + '/DataCapture/Appsflyer/Message?' + parameters(data);
            (new Image()).src = url + "&ver=" + ((new Date()).getTime() + '' + Math.ceil(Math.random() * 100000000000000));
        }

        function sendGA(data) {
            dataLayer.push({
                'event': 'GAEvent',
                'eventCategory': data.eventCategory,
                'eventAction': data.eventAction,
                'eventLabel': data.eventLabel,
                'eventPage': data.eventPage,
                'language': data.language,
                'source': data.source,
                'userId': userId || 'None',
                'amount': data.amount,
                'metric': data.metric,
                'timeStop': data.timeStop,
                'nonInteraction': (typeof data.nonInteraction !== 'boolean' ? false : data.nonInteraction)
            });
        };

        function sendMP(data) {
            dataLayer.push({
                'event': 'MixPanelEvent',
                'eventCategory': data.eventCategory,
                'eventAction': data.eventAction,
                'eventLabel': data.eventLabel,
                'eventPage': data.eventPage,
                'language': data.language,
                'amount': data.amount
            });
        }

        function cacheEvent(data) {
            try {
                var dataList = getCacheEvent();
                dataList.push(data);

                setSessionStorage("DataEvents", JSON.stringify(dataList))
            } catch (e) { }
        };

        function getCacheEvent() {
            try {
                var dataList = JSON.parse(sessionStorage.getItem("DataEvents") || '[]');
                sessionStorage.removeItem("DataEvents");

                return dataList;
            } catch (e) {
            }

            return [];
        }

        function getLanguage() {
            var getCookie = function (key) {
                var cookies = document.cookie.split(';');
                if (cookies) {
                    for (var i = 0; i < cookies.length ; i++) {
                        var cookie = cookies[i].replace(/\s/g, '').split('=');
                        if (cookie[0].toLowerCase() === key.toLowerCase()) {
                            return cookie[1];
                        }
                    }
                }

                return "";
            }

            return (["en-US", "english"].indexOf(getCookie('language')) !== -1) ? languageEnum.English : languageEnum.Spanish;
        }

        function sendCacheEvent() {
            var cacheDataList = getCacheEvent();

            for (var i = 0; i < cacheDataList.length; i++) {
                sendEvent(cacheDataList[i], true);
            }
        };

        function getUTCString(date) {
            return date.getUTCFullYear() + "-" + (date.getUTCMonth() + 1) + "-" + date.getUTCDate() + " " + date.getUTCHours() + ":" + date.getUTCMinutes() + ":" + date.getUTCSeconds() + "." + date.getUTCMilliseconds();
        }

        function setSessionStorage(key, value) {
            try {
                sessionStorage.setItem(key, value);
                return value;
            } catch (e) {
                return "";
            }
        };

        function getSessionStorage(key) {
            try {
                return sessionStorage.getItem(key) || '[]';
            } catch (e) {
                return '[]';
            }
        };

        function isNumber(number) {
            if (number === null && number === undefined) {
                return false;
            }

            return !isNaN(number)
        }

        function getEventPage(app) {
            var eventPage;
            switch (app.page().name) {
                case "AccountConsumer"://Have tracked in AccountConsumer.viewModel.js
                    if (app && app.page().data.carrierFlag() && $('#panel-carriers').hasClass('active')) {
                        eventPage = pageEnum.ManageCarriers;
                    } else if (app && app.page().data.billingAccountFlag() && $('#panel-billers').hasClass('active')) {
                        eventPage = pageEnum.ManageBillers;
                    } else if (app && app.page().data.transactionDetailsFlag() && $('#panel-transaction').hasClass('active')) {
                        eventPage = pageEnum.TransactionHistory;
                    } else {
                        eventPage = pageEnum.ManageRecipients;
                    }

                    break;
                case "SettingsConsumer"://Have tracked in SettingsConsumer.viewModel.js
                    if (app && app.page().data.paymentMethodFlag() && $('#panel-payments').hasClass('active')) {
                        eventPage = pageEnum.PaymentMethods;
                    } else {
                        eventPage = pageEnum.PersonalSettings;
                    }
                    break;
                case "MoneyTransferConsumer":
                    eventPage = pageEnum.SendMoney;
                    if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventPage = pageEnum.TransactionReceiptPage;
                    }
                    break;
                case "BillPayConsumer":
                case "BillPayLCRConsumer":
                    eventPage = pageEnum.PayBills;
                    if (app && app.page().data && typeof app.page().data.completeTransactionProcess === 'function' && app.page().data.completeTransactionProcess()) {
                        eventPage = pageEnum.TransactionReceiptPage;
                    } else if (app && app.page().data && typeof app.page().data.ShowTransactionDone === 'function' && app.page().data.ShowTransactionDone()) {
                        eventPage = pageEnum.TransactionReceiptPage;
                    }
                    break;
                case "TopUpsReloadConsumer":
                    eventPage = pageEnum.Reload;
                    if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventPage = pageEnum.TransactionReceiptPage;
                    }
                    break;
                case "TopUpsPinlessConsumer":
                    eventPage = pageEnum.Pinless;
                    if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventPage = pageEnum.TransactionReceiptPage;
                    }
                    break;
                case "TopUpsPurchaseConsumer":
                    eventPage = pageEnum.EPin;
                    if (app && app.page().data && app.page().data.CompleteTransactionProcess()) {
                        eventPage = pageEnum.TransactionReceiptPage;
                    }
                    break;
                case "CustomerDashboard":
                    eventPage = pageEnum.Dashboard;
                    break;
                case "PersonalInfoConsumer":
                    eventPage = pageEnum.PersonalInformation;
                    break;
                case "FeeCalculatorConsumer":
                    eventPage = pageEnum.CalculatorScreenPost;
                    break;
                case "ReferralLandingConsumer":
                    eventPage = pageEnum.ReferralLandingPage;
                    break;
                case "ReferralHistoryConsumer":
                    eventPage = pageEnum.ReferralHistory;
                    break;
                case "ReferralViaEmailConsumer":
                    eventPage = pageEnum.ReferralViaEmail;
                    break;
                case "IncreaseLimitConsumer":
                    eventpage = pageEnum.IncreaseSendingLimit
                    break;
                case "UpgradeLevelConsumer":
                    eventPage = pageEnum.UpgradePage;
                    break;
                default:
                    eventPage = app.page().name;
                    break;
            }

            return eventPage;
        }

        function getEventCategoryForTrackNextPage(app) {
            var eventCategory;
            switch (app.page().name) {
                case "AccountConsumer"://Have tracked in AccountConsumer.viewModel.js
                    if (app && app.page().data.carrierFlag() && $('#panel-carriers').hasClass('active')) {
                        eventCategory = categoryEnum.ManageCarriers;
                    } else if (app && app.page().data.billingAccountFlag() && $('#panel-billers').hasClass('active')) {
                        eventCategory = categoryEnum.ManageBillers;
                    } else if (app && app.page().data.transactionDetailsFlag() && $('#panel-transaction').hasClass('active')) {
                        eventCategory = categoryEnum.TransactionHistory;
                    } else {
                        eventCategory = categoryEnum.ManageRecipients;
                    }

                    break;
                case "MoneyTransferConsumer":
                    if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventCategory = categoryEnum.TransactionReceiptPage;
                    }
                    break;
                case "BillPayConsumer":
                case "BillPayLCRConsumer":
                    if (app && app.page().data && typeof app.page().data.completeTransactionProcess === 'function') {
                        eventCategory = categoryEnum.TransactionReceiptPage;
                    } else if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventCategory = categoryEnum.TransactionReceiptPage;
                    }
                    break;
                case "TopUpsReloadConsumer":
                    if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventCategory = categoryEnum.TransactionReceiptPage;
                    }
                    break;
                case "TopUpsPinlessConsumer":
                    if (app && app.page().data && app.page().data.ShowTransactionDone()) {
                        eventCategory = categoryEnum.TransactionReceiptPage;
                    }
                    break;
                case "TopUpsPurchaseConsumer":
                    if (app && app.page().data && app.page().data.CompleteTransactionProcess()) {
                        eventCategory = categoryEnum.TransactionReceiptPage;
                    }
                    break;
                default:
                    eventCategory = ""
                    break;
            }

            return eventCategory;
        }

        function trackLeftMenu(eventLabel, app) {
            var trackLinkTotalClicks = trackEvent;
            trackLinkTotalClicks({
                sendType: ga + mp,
                eventCategory: categoryEnum.LeftMenu,
                eventAction: actionEnum.ButtonClick,
                eventLabel: eventLabel,
                eventPage: getEventPage(app)
            });

            var trackPreviousPage = trackEvent;

            trackPreviousPage({
                sendType: ga + mp,
                eventCategory: categoryEnum.LeftMenu,
                eventAction: actionEnum.SourcePage,
                eventLabel: getEventPage(app),
                eventPage: pageEnum.LeftMenu
            });
        }

        function commonTrackErrorMessage(errorMessage, isServerMessage) {
            if (typeof trackErrorMessage === 'function') {
                trackErrorMessage(errorMessage, isServerMessage);
            } else {
                console.log("NO function");
            }
        }

        var trackErrorMessage;
        function generateErrorMessageTrack(eventCategory, eventPage) {
            var messages = {};

            trackErrorMessage = function (errorMessage, isServerMessage) {
                if (typeof errorMessage !== 'string' || !errorMessage) { return; }

                if (!isServerMessage) {
                    if (typeof messages[errorMessage] === 'number') { return; }
                    messages[errorMessage] = 1;
                }

                trackEvent({
                    sendType: ga + mp,
                    eventCategory: eventCategory,
                    eventAction: actionEnum.Error,
                    eventLabel: "Error: " + errorMessage,
                    eventPage: eventPage
                });
            }

            return trackErrorMessage;
        }

        function clearTrackErrorMessage() {//No long track common error message, include ajax error and knockout.validation error.
            trackErrorMessage = null;
        }

        var T = {
            CategoryEnum: categoryEnum,
            ActionEnum: actionEnum,
            PageEnum: pageEnum,
            LabelEnum: labelEnum,
            LanguageEnum: languageEnum,
            StructureEnum: structureEnum,
            GA: ga,
            MP: mp,
            AF: af,
            getLanguage: getLanguage,
            trackTimeOnPage: trackTimeOnPage,
            trackEvent: trackEvent,
            trackNextPage: trackNextPage,
            trackLeftMenu: trackLeftMenu,
            sendCacheEvent: sendCacheEvent,
            closeTrackAppsflyerEvent: closeTrackAppsflyerEvent,
            init: init,
            getEventPage: getEventPage,
            trackTimeOnPageForPageLink: trackTimeOnPageForPageLink,
            generatePartialTimeOnPageTrack: generatePartialTimeOnPageTrack,
            generateTimeOnPageForPageLink: generateTimeOnPageForPageLink,
            trackTotalTimeOnPage: trackTotalTimeOnPage,
            generateErrorMessageTrack: generateErrorMessageTrack,
            commonTrackErrorMessage: commonTrackErrorMessage,
            clearTrackErrorMessage: clearTrackErrorMessage
        }
        window["T"] = T;
        return T
    }));
})();